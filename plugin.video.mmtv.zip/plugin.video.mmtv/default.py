# -*- coding: utf-8 -*-
import urllib, urllib2, re, sys, os
import xbmcplugin, xbmcgui
import xbmcaddon
import urlparse

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
scriptID        = my_addon.getAddonInfo('id')

PATH        = my_addon.getAddonInfo('path')       
sys.path.append( os.path.join( PATH, "resources", "lib" ) )
sys.path.append( os.path.join( PATH, "host" ) )

import mmtv

tv = mmtv.mmtv()
tv.handleService()
  
