# coding: UTF-8
import sys
l1lll_onl_ = sys.version_info [0] == 2
l11ll_onl_ = 2048
l1111_onl_ = 7
def l1ll1_onl_ (keyedStringLiteral):
	global l1l1l_onl_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1lll_onl_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll_onl_ - (charIndex + stringNr) % l1111_onl_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll_onl_ - (charIndex + stringNr) % l1111_onl_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys
l1l1l_cdax_ = sys.version_info [0] == 2
l1l11_cdax_ = 2048
l11ll_cdax_ = 7
def l1l1_cdax_ (keyedStringLiteral):
	global l1l11lll1_onl_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1l_cdax_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l11_cdax_ - (charIndex + stringNr) % l11ll_cdax_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l11_cdax_ - (charIndex + stringNr) % l11ll_cdax_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)