# -*- coding: utf-8 -*-
import sys
l11ll_sz_ = sys.version_info [0] == 2
l111_sz_ = 2048
l1lll_sz_ = 7
def l111l_sz_ (ll_sz_):
	global l11l1l_sz_
	l11l11_sz_ = ord (ll_sz_ [-1])
	l1111_sz_ = ll_sz_ [:-1]
	l1l1l1_sz_ = l11l11_sz_ % len (l1111_sz_)
	l1ll_sz_ = l1111_sz_ [:l1l1l1_sz_] + l1111_sz_ [l1l1l1_sz_:]
	if l11ll_sz_:
		l1l1ll_sz_ = unicode () .join ([unichr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	else:
		l1l1ll_sz_ = str () .join ([chr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	return eval (l1l1ll_sz_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _11lll_sz_(l1ll11_sz_):
    import json,xbmcplugin,urllib2
    url=l111l_sz_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡲࡪࡸࡨ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡷࡦࡃࡪࡾࡰࡰࡴࡷࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࠬࡩࡥ࠿ࠪࠀ")
    try:
        l1l_sz_ = json.load(urllib2.urlopen(url+l111l_sz_ (u"ࠬ࠶ࡂ࠱ࡒࡰࡰ࡛ࡏࡸࡺࡩ࡮ࡸࡪࡴࡆࡌࡑࡖ࠵ࡷࡩ࠳ࡆ࠲ࡘ࡙࠵࠭ࠁ")))
    except:
        l1l_sz_=[{l111l_sz_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࠂ"):l111l_sz_ (u"ࠧࡎࡱॿࡩࠥࡩ࡯ड़ࠢࡶ࡭ञࠦࡴࡶࠢࡳࡳ࡯ࡧࡷࡪࠩࠃ")}]
    for l11_sz_ in l1l_sz_:
        l1llll_sz_ = xbmcgui.ListItem(l11_sz_.get(l111l_sz_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࠄ")), iconImage=l11_sz_.get(l111l_sz_ (u"ࠩ࡬ࡱ࡬࠭ࠅ")) , thumbnailImage=l11_sz_.get(l111l_sz_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪࠆ")) )
        l1llll_sz_.setInfo(type=l111l_sz_ (u"࡛ࠦ࡯ࡤࡦࡱࠥࠇ"), infoLabels=l11_sz_)
        l1llll_sz_.setProperty(l111l_sz_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࠈ"), l111l_sz_ (u"࠭ࡦࡢ࡮ࡶࡩࠬࠉ"))
        l1llll_sz_.setProperty(l111l_sz_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭ࠊ"),l11_sz_.get(l111l_sz_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࠋ")))
        xbmcplugin.addDirectoryItem(handle=l1ll11_sz_, url=l11_sz_.get(l111l_sz_ (u"ࠩࡸࡶࡱ࠭ࠌ")), listitem=l1llll_sz_, isFolder=False)
def l1_sz_(l111ll_sz_,l11l_sz_=[l111l_sz_ (u"ࠪࠫࠍ")]):
    debug=1
def l1ll1l_sz_(name=l111l_sz_ (u"ࠫࠬࠎ")):
    debug=1
def l1ll1_sz_(top):
    debug=1
def check():
    l111ll_sz_ = os.path.join(xbmc.translatePath(l111l_sz_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ࠙")),l111l_sz_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩࠚ"))
    xbmc.log(l111ll_sz_)
    if l1_sz_(l111ll_sz_,[l111l_sz_ (u"ࠪࡥࡱ࡯ࡥ࡯ࡹ࡬ࡾࡦࡸࡤࠨࠛ"),l111l_sz_ (u"ࠫࡪࡾࡴࡦࡰࡧࡩࡷ࠴ࡡ࡭࡫ࡨࡲࠬࠜ")])>0:
        l1ll1l_sz_(l111l_sz_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࠝ"))
        return
    l11ll1_sz_ = os.path.join(xbmc.translatePath(l111l_sz_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡸࡷࡪࡸࡤࡢࡶࡤࠫࠞ")),l111l_sz_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫࠟ"),l111l_sz_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪࠠ"),l111l_sz_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨࠡ"))
    if os.path.exists(l11ll1_sz_):
        data = open(l11ll1_sz_,l111l_sz_ (u"ࠪࡶࠬࠢ")).read()
        data= re.sub(l111l_sz_ (u"ࠫࡡࡡ࠮ࠫ࡞ࡠࠫࠣ"),l111l_sz_ (u"ࠬ࠭ࠤ"),data)
        if len(re.compile(l111l_sz_ (u"࠭࠾࠯ࠬࠫࡴࡴࡲࡳ࡬ࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࠥ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll1l_sz_(l111l_sz_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩࠦ"))
            return
        if len(re.compile(l111l_sz_ (u"ࠨࡀ࠱࠮࠭ࡪࡡࡳ࡯ࡲࡻࡦࡢࡳࠫࡶ࡟ࡷ࠯ࡼࠩࠨࠧ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll1l_sz_(l111l_sz_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡢࡧࡲࡲ࠳ࡴ࡯ࡹ࠰࠸ࠫࠨ"))
            return
    l11ll1_sz_ = os.path.join(xbmc.translatePath(l111l_sz_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࠩ")),l111l_sz_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࠪ"),l111l_sz_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡼࡴࡴࡦ࡭ࡷࡨࡲࡨ࡫ࠧࠫ"),l111l_sz_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࠬ"))
    if os.path.exists(l11ll1_sz_):
        data = open(l11ll1_sz_,l111l_sz_ (u"ࠧࡳࠩ࠭")).read()
        data= re.sub(l111l_sz_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨ࠮"),l111l_sz_ (u"ࠩࠪ࠯"),data)
        if len(re.compile(l111l_sz_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩ࠰"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll1l_sz_(l111l_sz_ (u"ࠫࡸࡱࡩ࡯࠰ࡻࡳࡳ࡬࡬ࡶࡧࡱࡧࡪ࠭࠱"))
            return
    l111ll_sz_ = os.path.join(xbmc.translatePath(l111l_sz_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡷࡶࡩࡷࡪࡡࡵࡣࠪ࠲")),l111l_sz_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࡳࠨ࠳"))
    if os.path.exists(l111ll_sz_):
        if l1_sz_(l111ll_sz_,[l111l_sz_ (u"ࠧ࡬࡫ࡧࡷࠬ࠴")])>0:
            l1ll1l_sz_(l111l_sz_ (u"ࠨࡹ࡬ࡾࡦࡸࡤࠨ࠵"))
            return
    l1l1_sz_ = xbmc.translatePath(l111l_sz_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ࠶"))
    for f in os.listdir(l1l1_sz_):
        if f.startswith(l111l_sz_ (u"ࠪࡑࡒࡋࡓࠨ࠷")):
            l1ll1l_sz_()
            return
try:
    debug=1
except: pass
