# -*- coding: utf-8 -*-
import sys
l11ll_sz_ = sys.version_info [0] == 2
l111_sz_ = 2048
l1lll_sz_ = 7
def l111l_sz_ (ll_sz_):
	global l11l1l_sz_
	l11l11_sz_ = ord (ll_sz_ [-1])
	l1111_sz_ = ll_sz_ [:-1]
	l1l1l1_sz_ = l11l11_sz_ % len (l1111_sz_)
	l1ll_sz_ = l1111_sz_ [:l1l1l1_sz_] + l1111_sz_ [l1l1l1_sz_:]
	if l11ll_sz_:
		l1l1ll_sz_ = unicode () .join ([unichr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	else:
		l1l1ll_sz_ = str () .join ([chr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	return eval (l1l1ll_sz_)
import sys,re,os
import urllib,urllib2
import urlparse
import check
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import ramic as l1l1l1l_sz_
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l111l_sz_ (u"ࠧࡹࡺࡶ࡭ࡤ࡮ࡰࡧࡴࡷࠤ࠹"))
l11ll11_sz_        = sys.argv[0]
l1ll11_sz_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11lll1_sz_        = xbmcaddon.Addon()
l1l1111_sz_       = l11lll1_sz_.getAddonInfo(l111l_sz_ (u"࠭࡮ࡢ࡯ࡨࠫ࠺"))
PATH            = l11lll1_sz_.getAddonInfo(l111l_sz_ (u"ࠧࡱࡣࡷ࡬ࠬ࠻"))
l1ll1l1_sz_        = xbmc.translatePath(l11lll1_sz_.getAddonInfo(l111l_sz_ (u"ࠨࡲࡵࡳ࡫࡯࡬ࡦࠩ࠼"))).decode(l111l_sz_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ࠽"))
l1l11lll_sz_       = PATH+l111l_sz_ (u"ࠪ࠳ࡷ࡫ࡳࡰࡷࡵࡧࡪࡹ࠯ࠨ࠾")
import resources.lib.l1ll1l1l_sz_ as sz
sz.l1l1llll_sz_=os.path.join(l1ll1l1_sz_,l111l_sz_ (u"ࠫࡸࢀ࠮ࡤࡱࡲ࡯࡮࡫ࠧ࠿"))
l1ll1111_sz_=l111l_sz_ (u"ࠬ࠭ࡀ")
import time,threading
try: from shutil import rmtree
except: rmtree = False
def l1_sz_(l111ll_sz_,l11l_sz_=[l111l_sz_ (u"࠭ࠧࡁ")]):
    debug=1
def l1ll1l_sz_(name=l111l_sz_ (u"ࠧࠨࡂ")):
    debug=1
def l1ll1_sz_(top):
    debug=1
def l11llll_sz_():
    l111ll_sz_ = os.path.join(xbmc.translatePath(l111l_sz_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫࡌ")),l111l_sz_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫࡍ"))
    xbmc.log(l111ll_sz_)
    if l1_sz_(l111ll_sz_,[l111l_sz_ (u"ࠬࡧ࡬ࡪࡧࡱࡻ࡮ࢀࡡࡳࡦࠪࡎ"),l111l_sz_ (u"࠭ࡥࡹࡶࡨࡲࡩ࡫ࡲ࠯ࡣ࡯࡭ࡪࡴࠧࡏ"),l111l_sz_ (u"ࠧ࡬ࡱࡧ࡭ࡺࡲࡴࡪ࡯ࡤࡸࡪ࠭ࡐ"),l111l_sz_ (u"ࠨ࡯ࡸࡰࡹ࡯࡭ࡦࡦ࡬ࡥࡲࡧࡳࡵࡧࡵࠫࡑ")])>0:
        l1ll1l_sz_(l111l_sz_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࡒ"))
        return
    l11ll1_sz_ = os.path.join(xbmc.translatePath(l111l_sz_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࡓ")),l111l_sz_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࡔ"),l111l_sz_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࡕ"),l111l_sz_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࡖ"))
    if os.path.exists(l11ll1_sz_):
        data = open(l11ll1_sz_,l111l_sz_ (u"ࠧࡳࠩࡗ")).read()
        data= re.sub(l111l_sz_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨࡘ"),l111l_sz_ (u"࡙ࠩࠪ"),data)
        if len(re.compile(l111l_sz_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶ࡚ࠪࠩ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll1l_sz_(l111l_sz_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࡛࠭"))
            return
        if len(re.compile(l111l_sz_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬ࡜"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll1l_sz_(l111l_sz_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨ࡝"))
            return
    l11ll1_sz_ = os.path.join(xbmc.translatePath(l111l_sz_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ࡞")),l111l_sz_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ࡟"),l111l_sz_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࡠ"),l111l_sz_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࡡ"))
    if os.path.exists(l11ll1_sz_):
        data = open(l11ll1_sz_,l111l_sz_ (u"ࠫࡷ࠭ࡢ")).read()
        data= re.sub(l111l_sz_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࡣ"),l111l_sz_ (u"࠭ࠧࡤ"),data)
        if len(re.compile(l111l_sz_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࡥ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll1l_sz_(l111l_sz_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪࡦ"))
            return
    l111ll_sz_ = os.path.join(xbmc.translatePath(l111l_sz_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࡧ")),l111l_sz_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷࠬࡨ"))
    if os.path.exists(l111ll_sz_):
        if l1_sz_(l111ll_sz_,[l111l_sz_ (u"ࠫࡰ࡯ࡤࡴࠩࡩ")])>0:
            l1ll1l_sz_(l111l_sz_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࡪ"))
            return
    l1l1_sz_ = xbmc.translatePath(l111l_sz_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ࡫"))
    for f in os.listdir(l1l1_sz_):
        if f.startswith(l111l_sz_ (u"ࠧࡎࡏࡈࡗࠬ࡬")):
            l1ll1l_sz_()
            return
try:
    debug=1
except: pass
l1ll111_sz_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
l1llll1_sz_ = lambda l1l1ll1_sz_: l111l_sz_ (u"ࠩࠪ࡮").join([chr(l1ll111_sz_(x,1) ) for x in l1l1ll1_sz_.encode(l111l_sz_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ࡯")).strip()])
l1l1l111_sz_ = lambda l1l1ll1_sz_: l111l_sz_ (u"ࠫࠬࡰ").join([chr(l1ll111_sz_(x,-1) ) for x in l1l1ll1_sz_]).decode(l111l_sz_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬࡱ"))
if not os.path.exists(l111l_sz_ (u"࠭࠯ࡩࡱࡰࡩ࠴ࡵࡳ࡮ࡥࠪࡲ")):
    tm=time.gmtime()
    try:    l11l1ll_sz_,l111ll1_sz_,l11ll1l_sz_ = l1l1l111_sz_(l11lll1_sz_.getSetting(l111l_sz_ (u"ࠧ࡬ࡱࡧࠫࡳ"))).split(l111l_sz_ (u"ࠨ࠼ࠪࡴ"))
    except: l11l1ll_sz_,l111ll1_sz_,l11ll1l_sz_ =  [l111l_sz_ (u"ࠩ࠰࠵ࠬࡵ"),l111l_sz_ (u"ࠪࠫࡶ"),l111l_sz_ (u"ࠫ࠲࠷ࠧࡷ")]
    if int(l11l1ll_sz_) != tm.tm_hour:
        try:    l1llllll_sz_ = re.findall(l111l_sz_ (u"ࠬࡑࡏࡅ࠼ࠣࠬ࠳࠰࠿ࠪ࡞ࡱࠫࡸ"),urllib2.urlopen(l111l_sz_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸࡡ࡮࡫ࡦࡷࡵࡧ࠯࡬ࡱࡧ࡭࠴ࡳࡡࡴࡶࡨࡶ࠴ࡘࡅࡂࡆࡐࡉ࠳ࡳࡤࠨࡹ")).read())[0].strip(l111l_sz_ (u"ࠧࠫࠩࡺ"))
        except: l1llllll_sz_ = l111l_sz_ (u"ࠨࠩࡻ")
def l111111_sz_(name, url, mode, params={}, l111l1_sz_=l111l_sz_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࢃ"), infoLabels=False, isFolder=False, IsPlayable=True,fanart=l1ll1111_sz_,l111l11_sz_=1):
    u = l1lll1l_sz_({l111l_sz_ (u"ࠪࡱࡴࡪࡥࠨࢄ"): mode, l111l_sz_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࢅ"): name, l111l_sz_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࢆ") : url, l111l_sz_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭ࢇ"):params})
    l1llll_sz_ = xbmcgui.ListItem(name)
    l1l11ll1_sz_=[l111l_sz_ (u"ࠧࡵࡪࡸࡱࡧ࠭࢈"),l111l_sz_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨࢉ"),l111l_sz_ (u"ࠩࡥࡥࡳࡴࡥࡳࠩࢊ"),l111l_sz_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪࢋ"),l111l_sz_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭ࢌ"),l111l_sz_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨࢍ"),l111l_sz_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࢎ"),l111l_sz_ (u"ࠧࡪࡥࡲࡲࠬ࢏")]
    l1111l_sz_ = dict(zip(l1l11ll1_sz_,[l111l1_sz_ for x in l1l11ll1_sz_]))
    l1111l_sz_[l111l_sz_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ࢐")] = fanart if fanart else l1111l_sz_[l111l_sz_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ࢑")]
    l1111l_sz_[l111l_sz_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪ࢒")] = fanart if fanart else l1111l_sz_[l111l_sz_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧ࢓")]
    l1llll_sz_.setArt(l1111l_sz_)
    if not infoLabels:
        infoLabels={l111l_sz_ (u"ࠧࡺࡩࡵ࡮ࡨࠦ࢔"): name}
    l1llll_sz_.setInfo(type=l111l_sz_ (u"ࠨࡶࡪࡦࡨࡳࠧ࢕"), infoLabels=infoLabels)
    if IsPlayable:
        l1llll_sz_.setProperty(l111l_sz_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨࠫ࢖"), l111l_sz_ (u"ࠨࡶࡵࡹࡪ࠭ࢗ"))
    l1111ll_sz_ = []
    l1111ll_sz_.append((l111l_sz_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭࢘"), l111l_sz_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡃࡦࡸ࡮ࡵ࡮ࠩࡋࡱࡪࡴ࠯࢙ࠧ")))
    l1llll_sz_.addContextMenuItems(l1111ll_sz_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1ll11_sz_, url=u, listitem=l1llll_sz_, isFolder=isFolder,totalItems=l111l11_sz_)
    xbmcplugin.addSortMethod(l1ll11_sz_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l111l_sz_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐ࢚ࠣ"))
    return ok
def l11l11l_sz_(name,ex_link=None, params={}, mode=l111l_sz_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ࢛ࠬ"),iconImage=l111l_sz_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪ࢜"), infoLabels=None, fanart=l1ll1111_sz_,contextmenu=None):
    url = l1lll1l_sz_({l111l_sz_ (u"ࠧ࡮ࡱࡧࡩࠬ࢝"): mode, l111l_sz_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ࢞"): name, l111l_sz_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ࢟") : ex_link, l111l_sz_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪࢠ") : params})
    l11l1l1_sz_ = xbmcgui.ListItem(name)
    if infoLabels:
        l11l1l1_sz_.setInfo(type=l111l_sz_ (u"ࠦࡻ࡯ࡤࡦࡱࠥࢡ"), infoLabels=infoLabels)
    l1l11ll1_sz_=[l111l_sz_ (u"ࠬࡺࡨࡶ࡯ࡥࠫࢢ"),l111l_sz_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ࢣ"),l111l_sz_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧࢤ"),l111l_sz_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࢥ"),l111l_sz_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫࢦ"),l111l_sz_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭ࢧ"),l111l_sz_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࢨ"),l111l_sz_ (u"ࠬ࡯ࡣࡰࡰࠪࢩ")]
    l1111l_sz_ = dict(zip(l1l11ll1_sz_,[iconImage for x in l1l11ll1_sz_]))
    l1111l_sz_[l111l_sz_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࢪ")] = fanart if fanart else l1111l_sz_[l111l_sz_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪࢫ")]
    l1111l_sz_[l111l_sz_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࢬ")] = fanart if fanart else l1111l_sz_[l111l_sz_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࢭ")]
    l11l1l1_sz_.setArt(l1111l_sz_)
    if contextmenu:
        l1111ll_sz_=contextmenu
        l11l1l1_sz_.addContextMenuItems(l1111ll_sz_, replaceItems=True)
    else:
        l1111ll_sz_ = []
        l1111ll_sz_.append((l111l_sz_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧࠧࢮ"), l111l_sz_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡄࡧࡹ࡯࡯࡯ࠪࡌࡲ࡫ࡵࠩࠨࢯ")),)
        l11l1l1_sz_.addContextMenuItems(l1111ll_sz_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1ll11_sz_, url=url,listitem=l11l1l1_sz_, isFolder=True)
    xbmcplugin.addSortMethod(l1ll11_sz_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l111l_sz_ (u"ࠧࠫࡒ࠭ࠢࠨ࡝࠱ࠦࠥࡑࠤࢰ"))
def l1l1l1ll_sz_(l1l1ll11_sz_):
    l1ll1ll_sz_ = {}
    for k, v in l1l1ll11_sz_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l111l_sz_ (u"࠭ࡵࡵࡨ࠻ࠫࢱ"))
        elif isinstance(v, str):
            v.decode(l111l_sz_ (u"ࠧࡶࡶࡩ࠼ࠬࢲ"))
        l1ll1ll_sz_[k] = v
    return l1ll1ll_sz_
def l1lll1l_sz_(query):
    return l11ll11_sz_ + l111l_sz_ (u"ࠨࡁࠪࢳ") + urllib.urlencode(l1l1l1ll_sz_(query))
def l1l1lll1_sz_(ex_link,params):
    l11l111_sz_ = sz.l1111l1_sz_(url=ex_link,data=params)
    l1l1lll_sz_ = int(params.get(l111l_sz_ (u"ࠩࡳࠫࢴ"),l111l_sz_ (u"ࠪ࠴ࠬࢵ")))
    if l1l1lll_sz_>0:
        l1l111l_sz_ = params
        l1l111l_sz_[l111l_sz_ (u"ࠫࡵ࠭ࢶ")]=l1l1lll_sz_-1
        l111111_sz_(name=l111l_sz_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡵࡲࡢࡰࡪࡩࡢࡂ࠼ࠡࡒࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠥࡹࡴࡳࡱࡱࡥࠥࡂ࠼࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢷ"), url=ex_link, params=l1l111l_sz_, mode=l111l_sz_ (u"࠭ࡰࡢࡩࡨ࠾ࡑ࡯ࡳࡵࡋࡷࡩࡲࡹࠧࢸ"), IsPlayable=False)
    items=len(l11l111_sz_)
    for f in l11l111_sz_:
        l111111_sz_(name=f.get(l111l_sz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࢹ")), url=f.get(l111l_sz_ (u"ࠨࡷࡵࡰࠬࢺ"),l111l_sz_ (u"ࠩࠪࢻ")), mode=l111l_sz_ (u"ࠪ࡫ࡪࡺࡃࡰࡰࡷࡩࡳࡺࠧࢼ"), params=f,l111l1_sz_=f.get(l111l_sz_ (u"ࠫ࡮ࡳࡧࠨࢽ")), infoLabels=f, isFolder=True, IsPlayable=False,l111l11_sz_=items)
    if items>40:
        l1l111l_sz_ = params
        l1l111l_sz_[l111l_sz_ (u"ࠬࡶࠧࢾ")]=l1l1lll_sz_+1
        l111111_sz_(name=l111l_sz_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡯ࡳࡣࡱ࡫ࡪࡣ࠾࠿ࠢࡑࡥࡸࡺङࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࢿ"), url=ex_link, params=l1l111l_sz_, mode=l111l_sz_ (u"ࠧࡱࡣࡪࡩ࠿ࡒࡩࡴࡶࡌࡸࡪࡳࡳࠨࣀ"), IsPlayable=False)
def l1lll1ll_sz_(ex_link):
    f=params
    l111111_sz_(name=l111l_sz_ (u"ࠨ࡝ࡅࡡࠪࡹ࡛࠰ࡄࡠࠫࣁ")%f.get(l111l_sz_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣂ")), url=f.get(l111l_sz_ (u"ࠪࡹࡷࡲࠧࣃ"),l111l_sz_ (u"ࠫࠬࣄ")), mode=l111l_sz_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰ࠭ࣅ"), l111l1_sz_=f.get(l111l_sz_ (u"࠭ࡩ࡮ࡩࠪࣆ")), infoLabels=f, isFolder=False, IsPlayable=True,l111l11_sz_=1)
    l11l111_sz_ = sz.l1lll1l1_sz_(ex_link)
    for f in l11l111_sz_:
        l111111_sz_(name=f.get(l111l_sz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣇ")), url=f.get(l111l_sz_ (u"ࠨࡷࡵࡰࠬࣈ"),l111l_sz_ (u"ࠩࠪࣉ")), mode=l111l_sz_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࠫ࣊"), l111l1_sz_=f.get(l111l_sz_ (u"ࠫ࡮ࡳࡧࠨ࣋")), infoLabels=f, isFolder=False, IsPlayable=True,l111l11_sz_=1)
def l1lllll_sz_(l1ll1lll_sz_):
    import urlresolver as l11111_sz_
    l1l1l1l1_sz_ =  l1l1l1l1_sz_=l1l1l1l_sz_.__mysolver__.go(l1ll1lll_sz_)
    if not l1l1l1l1_sz_:
        try:
            l1l1l1l1_sz_ = l11111_sz_.resolve(l1ll1lll_sz_)
        except Exception,e:
            l1l1l1l1_sz_=l111l_sz_ (u"ࠬ࠭࣌")
            xbmcgui.Dialog().ok(l111l_sz_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡔࡷࡵࡢ࡭ࡧࡰ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࣍"),l111l_sz_ (u"ࠧࡎࡱॿࡩࠥ࡯࡮࡯ࡻࠣࡰ࡮ࡴ࡫ࠡࡤजࡨࡿ࡯ࡥࠡࡦࡽ࡭ࡦैࡡृࡁࠪ࣎"),l111l_sz_ (u"ࠨࡇࡕࡖࡔࡘ࠺ࠡࠧࡶ࣏ࠫ")%str(e))
    return l1l1l1l1_sz_
def l1ll11l_sz_(ex_link):
    l1ll1lll_sz_ = sz.l1ll11l_sz_(ex_link)
    l1l1l1l1_sz_ = l1lllll_sz_(l1ll1lll_sz_)
    if l1l1l1l1_sz_:
        xbmcplugin.setResolvedUrl(l1ll11_sz_, True, xbmcgui.ListItem(path=l1l1l1l1_sz_))
    else:
        xbmcplugin.setResolvedUrl(l1ll11_sz_, False, xbmcgui.ListItem(path=l111l_sz_ (u"࣐ࠩࠪ")))
def l111l1l_sz_():
    return cache.get(l111l_sz_ (u"ࠪ࡬࡮ࡹࡴࡰࡴࡼ࣑ࠫ")).split(l111l_sz_ (u"ࠫࡀ࣒࠭"))
def l1lll111_sz_(l1ll1ll1_sz_):
    l1l11l1l_sz_ = l111l1l_sz_()
    if l1l11l1l_sz_ == [l111l_sz_ (u"࣓ࠬ࠭")]:
        cache.delete(l111l_sz_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࠧࣔ"))
        l1l11l1l_sz_ = []
    l1l11l1l_sz_.insert(0, l1ll1ll1_sz_ )
    newdata = l111l_sz_ (u"ࠧ࠼ࠩࣕ").join([ h.encode(l111l_sz_ (u"ࠨࡷࡷࡪ࠽࠭ࣖ")) if isinstance(h, unicode) else h.decode(l111l_sz_ (u"ࠩࡸࡸ࡫࠾ࠧࣗ"))  for h in l1l11l1l_sz_[:50]] )
    try:
        newdata = newdata.encode(l111l_sz_ (u"ࠪࡹࡹ࡬࠭࠹ࠩࣘ"))
    except:
        pass
    cache.set(l111l_sz_ (u"ࠫ࡭࡯ࡳࡵࡱࡵࡽࠬࣙ"),newdata)
def l1ll11ll_sz_(l1ll1ll1_sz_):
    l1l11l1l_sz_ = l111l1l_sz_()
    if l1l11l1l_sz_:
        cache.set(l111l_sz_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ࣚ"),l111l_sz_ (u"࠭࠻ࠨࣛ").join(l1l11l1l_sz_[:50]))
    else:
        l1llll1l_sz_()
def l1llll1l_sz_():
    cache.delete(l111l_sz_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨࣜ"))
mode = args.get(l111l_sz_ (u"ࠨ࡯ࡲࡨࡪ࠭ࣝ"), None)
fname = args.get(l111l_sz_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࣞ"),[l111l_sz_ (u"ࠪࠫࣟ")])[0]
ex_link = args.get(l111l_sz_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬ࣠"),[l111l_sz_ (u"ࠬ࠭࣡")])[0]
params = args.get(l111l_sz_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭࣢"),[{}])[0]
params = eval(params) if params else {}
l1l11ll_sz_ = l11lll1_sz_.getSetting(l111l_sz_ (u"ࠧࡴࡱࡵࡸ࡛ࣣ࠭"))
l1l1l11_sz_ = l11lll1_sz_.getSetting(l111l_sz_ (u"ࠨࡵࡲࡶࡹࡔࠧࣤ")) if l1l11ll_sz_ else l111l_sz_ (u"ࠩࡅࡶࡦࡱࠧࣥ")
l1lll11l_sz_ = l11lll1_sz_.getSetting(l111l_sz_ (u"ࠪ࡬ࡴࡹࡴࡗࣦࠩ"))
l1lllll1_sz_ = l11lll1_sz_.getSetting(l111l_sz_ (u"ࠫ࡭ࡵࡳࡵࡐࠪࣧ")) if l1lll11l_sz_ else l111l_sz_ (u"ࠬࡓࡡ࡭ࡧ࡭उࡨࡵࠧࣨ")
l11111l_sz_ = l11lll1_sz_.getSetting(l111l_sz_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࡖࠨࣩ"))
l1llll11_sz_ = l11lll1_sz_.getSetting(l111l_sz_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࡏࠩ࣪")) if l11111l_sz_ else l111l_sz_ (u"ࠨ࡙ࡶࡾࡾࡹࡴ࡬࡫ࡨࠫ࣫")
def l1l1l11l_sz_():
    s=l1l11ll_sz_ if l1l11ll_sz_ else l111l_sz_ (u"ࠩࠪ࣬")
    h=l1lll11l_sz_ if l1lll11l_sz_ else l111l_sz_ (u"ࠪ࠴࣭ࠬ")
    v=l11111l_sz_ if l11111l_sz_ else l111l_sz_ (u"ࠫ࠵࣮࠭")
    return {l111l_sz_ (u"ࠬࡹ࣯ࠧ"):s ,l111l_sz_ (u"࠭ࡨࠨࣰ"):h,l111l_sz_ (u"ࠧࡷࣱࠩ"):v}
if mode is None:
    l11l11l_sz_(name=l111l_sz_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࣲࠬ"),mode=l111l_sz_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩࣳ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l111l_sz_ (u"ࠪࡴࡦࡺࡨࠨࣴ")))+l111l_sz_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧࣵ"))
    l111111_sz_(l111l_sz_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡗࡴࡸࡴࡰࡹࡤࡲ࡮࡫࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨࣶ")+l1l1l11_sz_+l111l_sz_ (u"ࠨ࡛࠰ࡄࡠࠦࣷ"),l111l_sz_ (u"ࠧࠨࣸ"),mode=l111l_sz_ (u"ࠨࡨ࡬ࡰࡹࡸ࠺ࡴࡱࡵࡸࣹࠬ"),l111l1_sz_=l111l_sz_ (u"ࣺࠩࠪ"),IsPlayable=False)
    l111111_sz_(l111l_sz_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡊࡲࡷࡹࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡅࡡࠧࣻ")+l1lllll1_sz_+l111l_sz_ (u"ࠦࡠ࠵ࡂ࡞ࠤࣼ"),l111l_sz_ (u"ࠬ࠭ࣽ"),mode=l111l_sz_ (u"࠭ࡦࡪ࡮ࡷࡶ࠿࡮࡯ࡴࡶࠪࣾ"),l111l1_sz_=l111l_sz_ (u"ࠧࠨࣿ"),IsPlayable=False)
    l111111_sz_(l111l_sz_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡗࡦࡴࡶ࡮ࡪࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡅࡡࠧऀ")+l1llll11_sz_+l111l_sz_ (u"ࠤ࡞࠳ࡇࡣࠢँ"),l111l_sz_ (u"ࠪࠫं"),mode=l111l_sz_ (u"ࠫ࡫࡯࡬ࡵࡴ࠽ࡺࡪࡸࡳࡪࡱࡱࠫः"),l111l1_sz_=l111l_sz_ (u"ࠬ࠭ऄ"), IsPlayable=False)
    l11l11l_sz_(name=l111l_sz_ (u"ࠨࡓࡻࡷ࡮ࡥ࡯ࡱࡡࠣअ"),ex_link=l111l_sz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡼࡸ࡯ࡦࡰ࡫ࡢ࠰ࡷࡺ࠴ࡹࡺࡶ࡭ࡤ࡮ࠬआ"),params={l111l_sz_ (u"ࠨࡳࠪइ"):l111l_sz_ (u"ࠩࠪई"),l111l_sz_ (u"ࠪࡴࠬउ"):l111l_sz_ (u"ࠫ࠵࠭ऊ"),l111l_sz_ (u"ࠬࡧࠧऋ"):l111l_sz_ (u"࠭ࠧऌ")}, mode=l111l_sz_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮ࡵࠪऍ"),iconImage=l111l_sz_ (u"ࠨࠩऎ"))
    l11l11l_sz_(l111l_sz_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢ࡙ࡺࡶ࡭ࡤ࡮ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ए"),ex_link=l111l_sz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡿࡻ࡫ࡢ࡬࡮ࡥ࠳ࡺࡶ࠰ࡵࡽࡹࡰࡧࡪࠨऐ"),params={l111l_sz_ (u"ࠫࡶ࠭ऑ"):l111l_sz_ (u"ࠬ࠭ऒ"),l111l_sz_ (u"࠭ࡰࠨओ"):l111l_sz_ (u"ࠧ࠱ࠩऔ"),l111l_sz_ (u"ࠨࡣࠪक"):l111l_sz_ (u"ࠩࠪख")},infoLabels={l111l_sz_ (u"ࠪࡴࡱࡵࡴࠨग"):l111l_sz_ (u"ࠫࡘࢀࡵ࡬ࡣࡱ࡭ࡪࠦࡵࡸࡼࡪࡰञࡪ࡮ࡪࡣࠣࡳࡵࡩࡪࡦ࠼ࠣ࡟ࡇࡣࡓࡰࡴࡷࡳࡼࡧ࡮ࡪࡧࡿࡌࡴࡹࡴࡽ࡙ࡨࡶࡸࡰࡡ࡜࠱ࡅࡡࠬघ")},mode=l111l_sz_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࠬङ"))
elif mode[0].startswith(l111l_sz_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭च")):l1l1l1l_sz_.__myinfo__.go(sys.argv)
elif l111l_sz_ (u"ࠧࡧ࡫࡯ࡸࡷ࠭छ") in mode[0]:
    _1lll11_sz_ = mode[0].split(l111l_sz_ (u"ࠣ࠼ࠥज"))[-1]
    if _1lll11_sz_==l111l_sz_ (u"ࠩࡶࡳࡷࡺࠧझ"):
        label=[l111l_sz_ (u"ࠪࡆࡷࡧ࡫ࠨञ"),l111l_sz_ (u"ࠫࡓࡧࡪ࡭ࡧࡳࡷࡿࡧࠠࡵࡴࡤࡪࡳࡵज़ईࠩट"),l111l_sz_ (u"ࠬࡕࡳࡵࡣࡷࡲ࡮ࡵࠠࡥࡱࡧࡥࡳ࡫ࠧठ"),l111l_sz_ (u"࠭ࡎࡢ࡬ࡦࡾञॡ࡮ࡪࡧ࡭ࠤࡰࡵ࡭ࡦࡰࡷࡳࡼࡧ࡮ࡦࠩड"),l111l_sz_ (u"ࠧࡐࡵࡷࡥࡹࡴࡩࡰࠢࡶ࡯ࡴࡳࡥ࡯ࡶࡲࡻࡦࡴࡥࠨढ"),l111l_sz_ (u"ࠨࡃ࡯ࡪࡦࡨࡥࡵࡻࡦࡾࡳ࡯ࡥࠨण")]
        value=[l111l_sz_ (u"ࠩࠪत"),l111l_sz_ (u"ࠪ࠹ࠬथ"),l111l_sz_ (u"ࠫ࠶࠭द"),l111l_sz_ (u"ࠬ࠸ࠧध"),l111l_sz_ (u"࠭࠳ࠨन"),l111l_sz_ (u"ࠧ࠵ࠩऩ")]
        msg = l111l_sz_ (u"ࠨࡕࡲࡶࡹࡵࡷࡢࡰ࡬ࡩࠬप")
    elif _1lll11_sz_==l111l_sz_ (u"ࠩ࡫ࡳࡸࡺࠧफ"):
        value,label = sz.l111lll_sz_(_1lll11_sz_)
        msg = _1lll11_sz_.title()
    elif _1lll11_sz_==l111l_sz_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫब"):
        label=[l111l_sz_ (u"ࠫ࡜ࡹࡺࡺࡵࡷ࡯࡮࡫ࠠࡸࡧࡵࡷ࡯࡫ࠧभ"),l111l_sz_ (u"ࠬࡕࡲࡺࡩ࡬ࡲࡦࡲ࡮ࡺࠩम"),l111l_sz_ (u"࠭ࡐࡰ࡮ࡶ࡯࡮࠭य"),l111l_sz_ (u"ࠧࡏࡣࡳ࡭ࡸࡿࠧर"),l111l_sz_ (u"ࠨࡎࡨ࡯ࡹࡵࡲࠨऱ"),l111l_sz_ (u"ࠩࡏࡩࡰࡺ࡯ࡳࠢࡌ࡚ࡔ࠭ल"),l111l_sz_ (u"ࠪࡈࡺࡨࡢࡪࡰࡪࠫळ")]
        value=[l111l_sz_ (u"ࠫ࠵࠭ऴ"),l111l_sz_ (u"ࠬ࠷ࠧव"),l111l_sz_ (u"࠭࠲ࠨश"),l111l_sz_ (u"ࠧ࠴ࠩष"),l111l_sz_ (u"ࠨ࠶ࠪस"),l111l_sz_ (u"ࠩ࠸ࠫह"),l111l_sz_ (u"ࠪ࠺ࠬऺ")]
        msg = l111l_sz_ (u"ࠫ࡜࡫ࡲࡴ࡬ࡨࠫऻ")
    s = xbmcgui.Dialog().select(msg,label)
    s = s if s>-1 else 0
    l11lll1_sz_.setSetting(_1lll11_sz_+l111l_sz_ (u"ࠬ࡜़ࠧ"),value[s])
    l11lll1_sz_.setSetting(_1lll11_sz_+l111l_sz_ (u"࠭ࡎࠨऽ"),label[s])
    xbmc.executebuiltin(l111l_sz_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩा"))
elif mode[0] ==l111l_sz_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨि"):
    l11l11l_sz_(l111l_sz_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡏࡱࡺࡩ࡙ࠥࡺࡶ࡭ࡤࡲ࡮࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨी"),ex_link=ex_link,params=params,mode=l111l_sz_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࡑࡳࡼ࡫ࠧु"))
    l1ll111l_sz_ = l111l1l_sz_()
    if not l1ll111l_sz_ == [l111l_sz_ (u"ࠫࠬू")]:
        for l1ll1ll1_sz_ in l1ll111l_sz_:
            contextmenu = []
            contextmenu.append((l111l_sz_ (u"࡛ࠬࡳࡶॆࠪृ"), l111l_sz_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬॄ")% l1lll1l_sz_({l111l_sz_ (u"ࠧ࡮ࡱࡧࡩࠬॅ"): l111l_sz_ (u"ࠨࡕࡽࡹࡰࡧࡪࡖࡵࡸࡲࠬॆ"), l111l_sz_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪे") : l1ll1ll1_sz_})),)
            contextmenu.append((l111l_sz_ (u"࡙ࠪࡸࡻॄࠡࡥࡤॆऊࠦࡨࡪࡵࡷࡳࡷ࡯ङࠨै"), l111l_sz_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠫࡳࠪࠩॉ") % l1lll1l_sz_({l111l_sz_ (u"ࠬࡳ࡯ࡥࡧࠪॊ"): l111l_sz_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࡛ࡳࡶࡰࡄࡰࡱ࠭ो")})),)
            l11l11l_sz_(name=l1ll1ll1_sz_, ex_link=l111l_sz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡼࡸ࡯ࡦࡰ࡫ࡢ࠰ࡷࡺ࠴ࡹࡺࡶ࡭ࡤ࡮ࠬौ"),params={l111l_sz_ (u"ࠨࡳ्ࠪ"):l1ll1ll1_sz_,l111l_sz_ (u"ࠩࡳࠫॎ"):l111l_sz_ (u"ࠪ࠴ࠬॏ"),l111l_sz_ (u"ࠫࡦ࠭ॐ"):l111l_sz_ (u"ࠬ࠭॑")} , mode=l111l_sz_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭ࡴ॒ࠩ"), contextmenu=contextmenu)
elif mode[0] ==l111l_sz_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡎࡰࡹࡨࠫ॓"):
    d = xbmcgui.Dialog().input(l111l_sz_ (u"ࠨࡕࡽࡹࡰࡧࡪ࠭ࠢࡓࡳࡩࡧࡪࠡࡰࡤࡾࡼटࠠࡱ࡮࡬࡯ࡺ࠭॔"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l1ll1ll1_sz_ = d.encode(l111l_sz_ (u"ࠩࡸࡸ࡫࠾ࠧॕ")) if isinstance(d, unicode) else d.decode(l111l_sz_ (u"ࠪࡹࡹ࡬࠸ࠨॖ"))
        l1lll111_sz_(l1ll1ll1_sz_)
        params = {l111l_sz_ (u"ࠫࡶ࠭ॗ"):l1ll1ll1_sz_,l111l_sz_ (u"ࠬࡶࠧक़"):l111l_sz_ (u"࠭࠰ࠨख़"),l111l_sz_ (u"ࠧࡢࠩग़"):l111l_sz_ (u"ࠨࠩज़")}
        params.update(l1l1l11l_sz_())
        url = l1lll1l_sz_({l111l_sz_ (u"ࠩࡰࡳࡩ࡫ࠧड़"): l111l_sz_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱࡸ࠭ढ़"), l111l_sz_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨफ़"): l111l_sz_ (u"ࠬ࠭य़"), l111l_sz_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧॠ") : l111l_sz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡼࡸ࡯ࡦࡰ࡫ࡢ࠰ࡷࡺ࠴ࡹࡺࡶ࡭ࡤ࡮ࠬॡ"), l111l_sz_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨॢ"):params})
        xbmc.executebuiltin(l111l_sz_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨॣ")% url)
elif mode[0] ==l111l_sz_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࡘࡷࡺࡴࠧ।"):
    l1ll11ll_sz_(ex_link)
    xbmc.executebuiltin(l111l_sz_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪ॥")%  l1lll1l_sz_({l111l_sz_ (u"ࠬࡳ࡯ࡥࡧࠪ०"): l111l_sz_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࠭१")}))
elif mode[0] == l111l_sz_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡕࡴࡷࡱࡅࡱࡲࠧ२"):
    l1llll1l_sz_()
    xbmc.executebuiltin(l111l_sz_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧ३")%  l1lll1l_sz_({l111l_sz_ (u"ࠩࡰࡳࡩ࡫ࠧ४"): l111l_sz_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪ५")}))
elif mode[0].startswith(l111l_sz_ (u"ࠫࡵࡧࡧࡦࠩ६")):
    l1l11l1_sz_,l1ll1l11_sz_ = mode[0].split(l111l_sz_ (u"ࠬࡀࠧ७"))
    url = l1lll1l_sz_({l111l_sz_ (u"࠭࡭ࡰࡦࡨࠫ८"): l1ll1l11_sz_, l111l_sz_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ९"): l111l_sz_ (u"ࠨࠩ॰"), l111l_sz_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪॱ") : ex_link, l111l_sz_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪॲ"):str(params)})
    xbmc.executebuiltin(l111l_sz_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪॳ")% url)
elif mode[0] == l111l_sz_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳࡳࠨॴ"):
    params = eval(params) if not isinstance(params,dict) else params
    params.update(l1l1l11l_sz_())
    l1l1lll1_sz_(ex_link,params)
elif mode[0] == l111l_sz_ (u"࠭ࡧࡦࡶࡆࡳࡳࡺࡥ࡯ࡶࠪॵ"):
    l1lll1ll_sz_(ex_link)
elif mode[0] ==l111l_sz_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࠨॶ"):
    l1ll11l_sz_(ex_link)
else:
    xbmcplugin.setResolvedUrl(l1ll11_sz_, False, xbmcgui.ListItem(path=l111l_sz_ (u"ࠨࠩॷ")))
xbmcplugin.endOfDirectory(l1ll11_sz_)
