# -*- coding: utf-8 -*-

STRINGS={
  "Information": 30203, 
  "Set Language": 30011, 
  "Remove all": 30102, 
  "TV Shows": 30002, 
  "New Search": 30100, 
  "Available Sources": 30202, 
  "Sort by": 30012, 
  "Remove": 30101, 
  "Set Quality": 30010, 
  "Movies": 30001, 
  "Select video quality": 30200, 
  "Set Genre": 30013, 
  "Search, type movie title": 30103, 
  "Select Genre": 30201, 
  "[COLOR blue]>> next page >>[/COLOR]": 30211, 
  "[COLOR blue]<< previous page <<[/COLOR]": 30210, 
  "Search Movies": 30015,
  "Search TV Shows": 30016
}