# coding: UTF-8
import sys
l1lll_an_ = sys.version_info [0] == 2
l1ll_an_ = 2048
l11l_an_ = 7
def l11llll_an_ (ll_an_):
	global l1l1lll_an_
	l11l111_an_ = ord (ll_an_ [-1])
	l1llll1_an_ = ll_an_ [:-1]
	l1ll1_an_ = l11l111_an_ % len (l1llll1_an_)
	l1l1l_an_ = l1llll1_an_ [:l1ll1_an_] + l1llll1_an_ [l1ll1_an_:]
	if l1lll_an_:
		l1l1l1l_an_ = unicode () .join ([unichr (ord (char) - l1ll_an_ - (l111ll_an_ + l11l111_an_) % l11l_an_) for l111ll_an_, char in enumerate (l1l1l_an_)])
	else:
		l1l1l1l_an_ = str () .join ([chr (ord (char) - l1ll_an_ - (l111ll_an_ + l11l111_an_) % l11l_an_) for l111ll_an_, char in enumerate (l1l1l_an_)])
	return eval (l1l1l1l_an_)