# -*- coding: utf-8 -*-

import sys,os,re
import urllib,urllib2
import urlparse
import json
import cookielib

UA = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.101 Safari/537.36 OPR/40.0.2308.54'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393'
BASEURL='http://www.animezone.pl'
TIMEOUT=10
COOKIEFILE=r'D:\animezone.cookie'


def getUrl(url,data=None,header={}):
    req = urllib2.Request(url,data)
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        print response.headers['set-cookie']
        link = response.read()
        response.close()
    except:
        link=''
    return link

# def getUrl(url,data=None,header={},useCookies=False,saveCookie=False):
#     if COOKIEFILE and useCookies:
#         cj = cookielib.LWPCookieJar()
#         #if os.path.isfile(COOKIEFILE): cj.load(COOKIEFILE)
#         opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
#         urllib2.install_opener(opener)
#     
#     req = urllib2.Request(url,data)
#     if not header:
#         header = {'User-Agent':UA}
#     req = urllib2.Request(url,data,headers=header)
#     try:
#         response = urllib2.urlopen(req,timeout=TIMEOUT)
#         link =  response.read()
#         response.close()
#         if COOKIEFILE and saveCookie:
#              cj.save(COOKIEFILE, ignore_discard = True) 
#     except urllib2.HTTPError as e:
#         #link = e.read()
#         link = ''
#     return link



def get_rankingi(url='http://www.animezone.pl/anime/ranking/ocen'):
    content = getUrl(url)
    out=[]
    tbody = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content)
    if tbody:
        trs = re.compile('<tr>(.*?)</tr>',re.DOTALL).findall(tbody[0])
        for tr in trs:
            #tr =trs[0]
            href_t=re.compile('<a href="(.*?)">(.*?)</a>').findall(tr)
            ocena_glosy=re.compile('<td class="text-center">(.*?)</td>').findall(tr)
            if href_t:
                href = BASEURL+href_t[0][0]
                title = unicodePLchar(href_t[0][1])
                rating = ocena_glosy[1] if len(ocena_glosy)>1 else ''
                glosy = ocena_glosy[2] if len(ocena_glosy)>2 else ''
                title += '   [COLOR lightblue]Ocena:%s[/COLOR]'%rating if rating else ''
                title += ' [COLOR lightgreen]Głosy:%s[/COLOR]'%glosy if glosy else ''
                out.append({'title':title,'url':href,'rating':rating,'code':glosy})
    return out

def get_episodes(url='http://www.animezone.pl/odcinki-online/attack-on-titan'):
    cookie=_setCookie(url)
    header = {'User-Agent':UA,'Referer':url,'Upgrade-Insecure-Requests':'1','Cookie':cookie}
    content = getUrl(url,header=header)

    out=[]
    idx=content.find('Odcinki')
    tbody = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content[idx:])
    if tbody:
        trs = re.compile('<tr>(.*?)</tr>',re.DOTALL).findall(tbody[0])
        img = re.compile('<img src="(.*?)" alt="" class="img-responsive">').findall(content)
        img = urlparse.urljoin(BASEURL,img[0]) if img else ''
        for tr in trs:
            #tr =trs[0]
            number=re.compile('<td class="text-center"><strong>(.*?)</strong></td>').findall(tr)
            title=re.compile('<td class="episode-title">(.*?)</td>').findall(tr)
            href =re.compile('<a href="(.*?)"').findall(tr)
            lang = re.compile('<span class="sprites(.*?)">').findall(tr)
            if href and title and number:
                href = urlparse.urljoin(url,href[0])
                title = '%s - %s'%(number[0],title[0])
                lang = lang[0].strip() if lang else ''
                title += ' [COLOR blue]%s[/COLOR]'%(lang)
                out.append({
                    'title':unicodePLchar(title),
                    'url':href,
                    'img':img,
                    'code':lang
                    })
    return out  

def getLinks(url='http://www.animezone.pl/odcinki-online/attack-on-titan/25'):
    # cookie=_setCookie('http://www.animezone.pl/odcinki-online/attack-on-titan')
    # cookie='_SESS=rj81vlqb3k4ni6v7rtnb1iv9d4;'
    # getUrl('http://www.animezone.pl',header={'User-Agent':UA,'Referer':url},useCookies=True,saveCookie=True)
    # cookie=_getCookie()
    # cookie='_SESS=d7ns1i01da0mh7th62cdsa2co0'

        
    import urllib
    import urllib2
    import httplib2
    import re
    
    http = httplib2.Http()

    UA='Mozilla/5.0 (Windows NT 10.0; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0'
    
    urlc='http://www.animezone.pl/resources/javascript/jquery-2.1.1.min.js'
    headers = {'User-Agent':UA,'Referer':'http://www.animezone.pl/','Upgrade-Insecure-Requests':'1'}
    #headers['Cookie']='_SESS=_SESS=k5bk27kbop29ulh7qol0b6ll86'
    response, content = http.request(urlc, 'POST', headers=headers)
    
    cookie=response['set-cookie'].split(';')[0].split('=')[-1]
    sh=26
    headers['Cookie']= '_SESS=%s'%(cookie)
    response, content = http.request(url, 'GET', headers=headers)
    'sucuri_cloudproxy_js' in content
    
    data=re.compile('data-[^=]+="(\d+:.*?)"').search(content).group(1)
    
    print data
    headers['Content-Type']='application/x-www-form-urlencoded; charset=UTF-8'
    headers['Referer']=url
    response, content = http.request(url, 'POST', headers=headers,body=urllib.urlencode({ "data" : data}))
    
    print response['status']


    import client2
    content = client2.http_get(url)
    data=re.compile('data-[^=]+="(\d+:.*?)"').search(content).group(1)
    print data
    result = client2.http_get(url,cookies={'_SESS',''}, data=urllib.urlencode({ "data" : data}))


    class NoRedirection(urllib2.HTTPErrorProcessor):
        def http_response(self, request, response):
            
            return response
        https_response = http_response
    
##   
    cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(NoRedirection,urllib2.HTTPCookieProcessor(cj),urllib2.HTTPBasicAuthHandler(),urllib2.HTTPHandler())
    urllib2.install_opener(opener)
    header={'Pragma':'no-cache','User-Agent':UA,'Content-Type':'text/html; charset=UTF-8','Connection':'keep-alive','Upgrade-Insecure-Requests':1,'Accept-Encoding':'gzip, deflate, lzma, sdch'}
    req = urllib2.Request(url,headers=header)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    cookie= response.headers['set-cookie']
    cookie=';'.join(['%s=%s'%(c.name, c.value) for c in cj])
    header['Cookie']=cookie
    
    
    urlsss=['device.js','bootstrap.min.js','core.js','query.autosize.min.js','episode.js']
    for l in urlsss:
        req = urllib2.Request('http://www.animezone.pl/resources/javascript/l',headers=header)
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        #response.headers['etag']
        content = response.read()
        response.close()
    
    urld='http://www.animezone.pl/resources/javascript/device.js'
    req = urllib2.Request(urld,headers=header)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    header['etag']=response.headers['etag']
    response.close()
    
    urlc='http://www.animezone.pl/resources/javascript/core.js'
    req = urllib2.Request(urlc,headers=header)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    header['etag']=response.headers['etag']
    response.close()
    
    urla='http://www.animezone.pl/resources/javascript/jquery.autosize.min.js'
    req = urllib2.Request(urlc,headers=header)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    header['etag']=response.headers['etag']
    response.close()
    
    req = urllib2.Request(url,headers=header)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    content = response.read()
    
    data=re.compile('data-[^=]+="(\d+:.*?)"').search(content).group(1)
    print data
    time.sleep(5)
    header={'User-Agent':UA,'Content-Type':'text/html; charset=UTF-8'}
    header['Cookie']=cookie
    header['Referer']=url
    header['X-Requested-With']='XMLHttpRequest'
    header['Content-Type']='application/x-www-form-urlencoded; charset=UTF-8'
    req = urllib2.Request(url,data=urllib.urlencode({ "data" : data}),headers=header)
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    print response.code
    content = response.read()
    
    content = getUrl(url,data=urllib.urlencode({ "data" : data}),header=header)

##    
    # req = urllib2.Request(BASEURL,headers={'User-Agent':UA,'Upgrade-Insecure-Requests':1,'Cookie':cookie})
    # response = urllib2.urlopen(req,timeout=TIMEOUT)
    # content = response.read()
    
    out=[]
    tbody = re.compile('<tbody>(.*?)</tbody>',re.DOTALL).findall(content)
    if tbody:
        trs = re.compile('<tr>(.*?)</tr>',re.DOTALL).findall(tbody[0])
        #for tr in trs:
        if trs:
            tr =trs[0]
            print tr
            host=re.compile('<td>(.*?)</td>').findall(tr)
            lang = re.compile('<span class="sprites(.*?)">').findall(tr)
            data=re.compile('data-[^=]+="(\d+:.*?)"').findall(tr)
            data2=re.compile('data-(.*?)+=".*?"').findall(tr)
            if host and data:
                host = host[0]
                host = host.split('>')[-1].strip() if '>' in host else host
                #content2 = getUrl(url,data=urllib.urlencode({ "data" : data[0]}),header=header)
                
                req = urllib2.Request(url,data=urllib.urlencode({ "data" : data[0]}),headers={'User-Agent':UA,'Referer':url,'Cookie':cookie})
                response = urllib2.urlopen(req,timeout=TIMEOUT)
                content2 = response.read()
                response.close()
                
                if content2:
                    src=re.compile('(?:src|href)=["\'](.*?)["\']').findall(content2)
                    if src:
                        print src
                        video_link= urllib.unquote(src[0]).replace('&amp;','&')
                        out.append({'url'   : video_link,
                            'data'  : data[0] ,
                            'cookie'  : cookie ,
                            'title'  : unicodePLchar(host),
                            'code' : lang[0].strip() if lang else ''
                            })
    return out     
#out=getLinks(url='http://www.animezone.pl/odcinki-online/attack-on-titan/25')
# data=out[1]['data']
# url=out[1]['url']
# data='104539:0e93c472991edafd86483bf1f7a74d85'
# url='http://www.animezone.pl/odcinki-online/attack-on-titan/25'
def _setCookie(url):
    cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    urllib2.install_opener(opener)
    req = urllib2.Request(url,headers={'User-Agent':UA,'Connection':'keep-alive','Host':'www.animezone.pl','Upgrade-Insecure-Requests':1})
    response = urllib2.urlopen(req,timeout=TIMEOUT)
    cookie = response.headers['set-cookie']
    response.read()
    response.close()
    # cookie = response.headers['set-cookie']
    # req = urllib2.Request(BASEURL,headers={'User-Agent':UA,'Upgrade-Insecure-Requests':'1','Cookie':cookie})
    # response = urllib2.urlopen(req,timeout=TIMEOUT)
    # cookie = response.headers['set-cookie']
    # response.close()
    # req = urllib2.Request(BASEURL,headers={'User-Agent':UA,'Upgrade-Insecure-Requests':'1','Cookie':cookie})
    # response = urllib2.urlopen(req,timeout=TIMEOUT)
    # cookie = response.headers['set-cookie']
    if COOKIEFILE:
        cj.save(COOKIEFILE, ignore_discard = True) 
    return ''.join(['%s=%s'%(c.name, c.value) for c in cj])

def _getCookie():
    try:
        cj = cookielib.LWPCookieJar()
        cj.load(COOKIEFILE)
        cookie=';'.join(['%s=%s'%(c.name, c.value) for c in cj])
    except:
        cookie=''
    return cookie
      
        

def getVideoUrl(url,data):
    video_link=''
    payload = urllib.urlencode({ "data" : data})
    cookie = _getCookie()
    header = {'User-Agent':UA,'Referer':url,'Upgrade-Insecure-Requests':'1','Cookie':cookie}
    content = getUrl(url,data=payload,header=header)
    if content:
        src=re.compile('(?:src|href)=["\'](.*?)["\']').findall(content)
        if src:
            video_link= urllib.unquote(src[0]).replace('&amp;','&')
    return video_link
    
def test():
    out=getLinks(url='http://www.animezone.pl/odcinki-online/attack-on-titan/25')
    data=out[1]['data']
    url=out[1]['url']
    video_link = getVideoUrl(url,data)
    print video_link
    
# cj = CookieJar()
# opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
# # input-type values from the html form
# formdata = { "data" : data}
# data_encoded = urllib.urlencode(formdata)
# opener.addheaders = [('User-agent', UA),('Upgrade-Insecure-Requests',1)]
# response = opener.open(url)
# cookie=response.headers['set-cookie']
# response.close()
# # cookie=''.join(['%s=%s;'%(c.name, c.value) for c in cj])
# opener.addheaders = [('User-agent', UA),("Cookie",'_SESS=dt73qfmjo7m6uutfusqjs0ssi3;'),('Referer',url)]
# opener.addheaders = [('User-agent', UA),("Cookie",cookie),('Referer',url)]        
#       
# response = opener.open(url, data_encoded)
# content = response.read()
    


def unicodePLchar(txt):
    txt = txt.replace('#038;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8217;','\'')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    #txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt     