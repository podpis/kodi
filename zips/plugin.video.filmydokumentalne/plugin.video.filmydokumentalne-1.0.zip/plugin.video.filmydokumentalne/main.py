# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse

import xbmc,xbmcgui,xbmcaddon
import xbmcplugin

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')

PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

import resources.lib.fd as fd

FANART=''

## COMMON Functions


def addLinkItem(name, url, mode, params={}, iconimage='DefaultFolder.png', infoLabels=False, isFolder=False, IsPlayable=True,fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    
    liz = xbmcgui.ListItem(name)
    
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    art['fanart'] = fanart if fanart else art['landscape'] 
    liz.setArt(art)
        
    if not infoLabels:
        infoLabels={"title": name}
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    contextMenuItems = []
    contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)        
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=isFolder,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok

def addDir(name,ex_link=None, params={}, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params})

    li = xbmcgui.ListItem(name)
    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)
    
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    art['fanart'] = fanart if fanart else art['landscape'] 
    li.setArt(art)
    if contextmenu:
        contextMenuItems=contextmenu
        li.addContextMenuItems(contextMenuItems, replaceItems=True) 
    else:
        contextMenuItems = []
        contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'),)
        li.addContextMenuItems(contextMenuItems, replaceItems=False)  
          
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

## ######################

def ListItems(ex_link):
    filmy,pagination = fd.scanMainpage(ex_link)
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=pagination[0], params={}, mode='page:ListItems', IsPlayable=False)
    items=len(filmy)
    for f in filmy:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img'), infoLabels=f, isFolder=False, IsPlayable=True,itemcount=items)
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> Następna strona >>[/COLOR]', url=pagination[1], params={}, mode='page:ListItems', IsPlayable=False)
    xbmcplugin.setContent(addon_handle, 'movies')

def ListFolders(fun_name):
    methodToCall = getattr(fd, fun_name)
    items = methodToCall()
    for f in items:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='ListItems', iconimage=f.get('img'), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=len(items))
    
def LinkResolver(link):
    stream_url=''
    if 'cda.pl' in link:
        print 'CDA'
        import resources.lib.cdaresolver as cdaresolver
        stream_url = cdaresolver.getVideoUrls(link)
        if type(stream_url) is list:
            qualityList = [x[0] for x in stream_url]
            selection = xbmcgui.Dialog().select("Dostępne jakości strumienia video", qualityList)
            if selection>-1:
                stream_url = cdaresolver.getVideoUrls(stream_url[selection][1])
            else:
                stream_url=''
    elif 'anyfiles.pl' in link: 
        stream_url= fd.getanyfiles(link)
    else:                
        try:
            import urlresolver
            stream_url = urlresolver.resolve(link)
        except Exception,e:
            xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','ERROR: %s'%str(e))
    return stream_url
    
def getLinks(ex_link):
    link = fd.getVideoUrl(ex_link)
    xbmcgui.Dialog().ok('link',link)
    stream_url = LinkResolver(link)
    print stream_url
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
## ######################
## MAIN
## ######################
            
    
# Get passed arguments
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]


if mode is None:

    addDir(name="Polecane",ex_link='http://www.filmydokumentalne.eu/polecane/',params={}, mode='ListItems',iconImage='')
    addDir(name="Najnowsze",ex_link='http://www.filmydokumentalne.eu/najnowsze-filmy/',params={}, mode='ListItems',iconImage='')
    addDir(name="Rankingi",ex_link='http://www.filmydokumentalne.eu/ranking/',params={}, mode='ListItems',iconImage='')
    
    addDir(name="[COLOR blue]Kanały[/COLOR]",ex_link='getKanaly',params={}, mode='ListFolders',iconImage='')
    addDir(name="[COLOR blue]Kategorie[/COLOR]",ex_link='getKategorie',params={}, mode='ListFolders',iconImage='')
    addDir(name="[COLOR blue]Archiwum[/COLOR]",ex_link='getArchiwum',params={}, mode='ListFolders',iconImage='')
    addDir(name="[COLOR blue]Serwery[/COLOR]",ex_link='getSerwery',params={}, mode='ListFolders',iconImage='')
    addDir(name="Spis od A do Z",ex_link='',params={}, mode='ListSpis',iconImage='')

elif mode[0].startswith('page'):
    tmp,nmode = mode[0].split(':')
    url = build_url({'mode': nmode, 'foldername': '', 'ex_link' : ex_link, 'params':params})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    
elif mode[0] == 'ListItems':    ListItems(ex_link)
elif mode[0] == 'ListFolders':  ListFolders(ex_link)

elif mode[0] == 'ListSpis':
    items = fd.getSpisAZ()
    for f in items:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img',''), infoLabels=f, isFolder=False, IsPlayable=True,itemcount=len(items))
    xbmcplugin.setContent(addon_handle, 'movies')
        
elif mode[0] =='getLinks':
    getLinks(ex_link)       
   

else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))        


xbmcplugin.endOfDirectory(addon_handle)

