# -*- coding: utf-8 -*-

import urllib2,urllib
import re,os
import json
import cookielib
from urlparse import urlparse

BASEURL='http://www.filmydokumentalne.eu'
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'


def getUrl(url,data=None,header={}):
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link =  response.read()
    except urllib2.HTTPError as e:
        link = ''
    return link

# url='http://www.filmydokumentalne.eu/kanaly/bbc/'
# url='http://www.filmydokumentalne.eu/najnowsze-filmy/'
# url='http://www.filmydokumentalne.eu/ranking/'
# url='http://www.filmydokumentalne.eu/2016/10/'
def scanMainpage(url):
    content = getUrl(url)
    out=[]
    news= re.compile('<div id="news">(.*?)</div>',re.DOTALL).findall(content)
    for n in news:
        #n=news[0]
        href_title = re.compile('<a href="(.*?)" title="czytaj wiecej">(.*?)</a>').findall(n)
        plot = re.compile('<p>(.*?)<').findall(n)
        plot = '\n'.join(plot) if plot else ''
        if href_title:
            h = href_title[0][0]
            t = unicodePLchar(href_title[0][1].strip())
            out.append({'url':h,'title':t,'plot':plot})
    
    prevPage = re.compile('<a class="previouspostslink" rel="prev" href="(.*?)">').search(content)
    prevPage = prevPage.group(1) if prevPage else False

    nextPage = re.compile('<a class="nextpostslink" rel="next" href="(.*?)">').search(content)
    nextPage = nextPage.group(1) if nextPage else False
    
    return (out, (prevPage,nextPage))
    
def getKanaly():
    content = getUrl(BASEURL)
    items = re.compile('<a href=["\'](http://www.filmydokumentalne.eu/kanaly/.*?)["\']\s*>(.*?)</a>').findall(content)
    out=[]
    for href,title in items:
        out.append({'title':unicodePLchar(title.strip()),'url':href})
    return out

def getKategorie():
    content = getUrl(BASEURL)
    items = re.compile('<a href=["\'](http://www.filmydokumentalne.eu/kategorie/.*?)["\']\s*>(.*?)</a>').findall(content)
    out=[]
    for href,title in items:
        out.append({'title':unicodePLchar(title.strip()),'url':href})
    return out

def getArchiwum():
    content = getUrl(BASEURL)
    items = re.compile('<a href=["\'](http://www.filmydokumentalne.eu/\d{4}/\d{2}/)["\']\s*>(.*?)</a>').findall(content)
    out=[]
    for href,title in items:
        out.append({'title':unicodePLchar(title.strip()),'url':href})
    return out   
    
def getSerwery():  
    out=[
    {'title':'anyfiles','url':'http://www.filmydokumentalne.eu/serwery/anyfiles/'},
    {'title':'cda','url':'http://www.filmydokumentalne.eu/serwery/cda/'},
    {'title':'vimeo','url':'http://www.filmydokumentalne.eu/serwery/vimeo/'},
    {'title':'youtube','url':'http://www.filmydokumentalne.eu/serwery/youtube/'},
    ]
    return out    

def getSpisAZ():
    content = getUrl('http://www.filmydokumentalne.eu/spis-od-a-do-z/') 
    items = re.compile('<a href="(http://www.filmydokumentalne.eu/.*?)"><span class="head">(.*?)</span></a>').findall(content)
    out=[]
    for href,title in items:
        out.append({'title':unicodePLchar(title.strip()),'url':href})
    return out 
    
    
# url='http://www.filmydokumentalne.eu/starozytna-bron-dalekiego-wschodu/' #youtube
# url='http://www.filmydokumentalne.eu/wyprawy-krzyzowe-polksiezyc-i-krzyz-iii-krucjata/' # CDA
# url='http://www.filmydokumentalne.eu/14-dni-14-days/'
# url='http://www.filmydokumentalne.eu/straznicy-izraela/'
def getVideoUrl(url):
    content = getUrl(url)
    video=''
    iframe = re.compile('<p>\s*<iframe(.*?)</iframe>',re.DOTALL).findall(content)
    if iframe:
        src = re.compile('src="(.*?)"').findall(iframe[0])
        if src:
            video= src[0]
    return video

url='http://video.anyfiles.pl/w.jsp?id=108343&#038;width=620&#038;height=349&#038;pos=0&#038;skin=0'

def getUrlc(url,data=None,header={},cj=None):
    if not cj:
        cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPHandler(), urllib2.HTTPCookieProcessor(cj))
    urllib2.install_opener(opener)
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link =  response.read()
        response.close()
            
    except urllib2.HTTPError as e:
        link = ''
    return link,cj

def getanyfiles(url):
    cj = cookielib.LWPCookieJar()
    id = re.compile('id=(\d+)').search(url).group(1)
    urlref = 'http://video.anyfiles.pl/videos.jsp?id='+id
    header = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko',
            'Referer':urlref} 
    url = "http://video.anyfiles.pl/w.jsp?id=%s&width=620&height=349&pos=&skin=0" % id
    content,cj = getUrlc("http://video.anyfiles.pl/w.jsp?id=%s&width=620&height=349&pos=&skin=0" % id,header=header,cj=cj)
    r = re.search('src="/?(pcs\?code=[^"]+?)"', content, re.DOTALL)
    if r:
        url2 = 'http://video.anyfiles.pl/%s' % r.group(1)
        header['Cookie']=';'.join(['%s=%s'%(c.name,c.value) for c in cj])
        header['Referer']=url
        data,cj = getUrlc(url2, header=header,cj=cj)
        match = re.search('(http[^"]+?mp4)',data)
        if match:
            return match.group(1)
    return ''


def unicodePLchar(txt):
    #if type(txt) is not str:
    #    txt=txt.encode('utf-8')

    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','')
    txt = txt.replace('&#8222;','')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','').replace('&amp;quot;','')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    #txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt               