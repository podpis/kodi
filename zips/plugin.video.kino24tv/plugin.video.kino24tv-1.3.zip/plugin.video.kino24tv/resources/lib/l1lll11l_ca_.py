# -*- coding: utf-8 -*-
import sys
l1_ca_ = sys.version_info [0] == 2
l1lll1_ca_ = 2048
l11ll_ca_ = 7
def l1l11_ca_ (ll_ca_):
	global l1llll_ca_
	l1l11l_ca_ = ord (ll_ca_ [-1])
	l11l1_ca_ = ll_ca_ [:-1]
	l11_ca_ = l1l11l_ca_ % len (l11l1_ca_)
	l1ll_ca_ = l11l1_ca_ [:l11_ca_] + l11l1_ca_ [l11_ca_:]
	if l1_ca_:
		l1ll1l_ca_ = unicode () .join ([unichr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	else:
		l1ll1l_ca_ = str () .join ([chr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	return eval (l1ll1l_ca_)
l1l11_ca_ (u"ࠨࠢࠣࠏࠍࡇࡷ࡫ࡡࡵࡧࡧࠤࡴࡴࠠࡕࡪࡸࠤࡋ࡫ࡢࠡ࠳࠴ࠤ࠶࠾࠺࠵࠹࠽࠸࠸ࠦ࠲࠱࠳࠹ࠑࠏࠓࠊࡁࡣࡸࡸ࡭ࡵࡲ࠻ࠢࡵࡥࡲ࡯ࡣࠎࠌࠥࠦࠧঃ")
import urllib2
import re
import l1l11111l_ca_ as l1l11111l_ca_
l1l111111_ca_=l1l11_ca_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯ࠫ঄")
l1l111l11_ca_ = 5
def l1l1111ll_ca_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l11_ca_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬঅ"), l1l11_ca_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧআ"))
    if cookies:
        req.add_header(l1l11_ca_ (u"ࠥࡇࡴࡵ࡫ࡪࡧࠥই"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1l111l11_ca_)
        l111l11_ca_ =  response.read()
        response.close()
    except:
        l111l11_ca_=l1l11_ca_ (u"ࠫࠬঈ")
    return l111l11_ca_
def _1l111l1l_ca_(content):
    src =l1l11_ca_ (u"ࠬ࠭উ")
    l11lll1l1_ca_ = re.compile(l1l11_ca_ (u"ࠨࡥࡷࡣ࡯ࠬ࠳࠰࠿ࠪ࡞ࡾࡠࢂࡢࠩ࡝ࠫࠥঊ"),re.DOTALL).findall(content)
    for l11lll11l_ca_ in l11lll1l1_ca_:
        l11lll11l_ca_=re.sub(l1l11_ca_ (u"ࠧࠡࠢࠪঋ"),l1l11_ca_ (u"ࠨࠢࠪঌ"),l11lll11l_ca_)
        l11lll11l_ca_=re.sub(l1l11_ca_ (u"ࠩ࡟ࡲࠬ঍"),l1l11_ca_ (u"ࠪࠫ঎"),l11lll11l_ca_)
        try:
            l11ll1l1l_ca_ = l1l11111l_ca_.unpack(l11lll11l_ca_)
        except:
            l11ll1l1l_ca_=l1l11_ca_ (u"ࠫࠬএ")
        if l11ll1l1l_ca_:
            l11ll1l1l_ca_=re.sub(l1l11_ca_ (u"ࡷ࠭࡜࡝ࠩঐ"),l1l11_ca_ (u"ࡸࠧࠨ঑"),l11ll1l1l_ca_)
            l11lll1ll_ca_ = re.compile(l1l11_ca_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࠰ࡦࡪ࡮ࡨ࡟ࠧࡢࠧ࡞ࠬ࡟ࡷ࠯ࡀ࡜ࡴࠬ࡞ࠦࡡ࠭࡝ࠩ࠰࠮ࡃ࠮ࡡࠢ࡝ࠩࡠ࠰ࠬ঒"),  re.DOTALL).search(content)
            l11lllll1_ca_ = re.compile(l1l11_ca_ (u"ࠨ࡝ࠥࡠࠬࡣࡦࡪ࡮ࡨ࡟ࠧࡢࠧ࡞࠼࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃࡡ࠴࡭ࡱ࠶ࠬ࡟ࠧࡢࠧ࡞ࠩও"),  re.DOTALL).search(content)
            l11llll1l_ca_ = re.compile(l1l11_ca_ (u"ࠩ࡞ࠦࡡ࠭࡝ࠫࠪ࠱࠮ࡄࡢ࠮࡮ࡲ࠷࠭ࡠࠨ࡜ࠨ࡟࠭ࠫঔ"),  re.DOTALL).search(content)
            if l11lll1ll_ca_:   src = l11lll1ll_ca_.group(1)
            elif l11lllll1_ca_: src = l11lllll1_ca_.group(1)
            elif l11llll1l_ca_: src = l11llll1l_ca_.group(1)
            if src:
                break
    return src
def l1l1111l1_ca_(content):
    l1l11_ca_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡘࡩࡡ࡯ࡵࠣࡪࡴࡸࠠࡷ࡫ࡧࡩࡴࠦ࡬ࡪࡰ࡮ࠤ࡮ࡴࡣ࡭ࡷࡧࡩࡩࠦࡥ࡯ࡥࡲࡨࡪࡪࠠࡰࡰࡨࠑࠏࠦࠠࠡࠢࠥࠦࠧক")
    l11lll111_ca_=l1l11_ca_ (u"ࠫࠬখ")
    l11lll1ll_ca_ = re.compile(l1l11_ca_ (u"ࠬࡡࠢ࡝ࠩࡠ࠮࡫࡯࡬ࡦ࡝ࠥࡠࠬࡣࠪ࡝ࡵ࠭࠾ࡡࡹࠪ࡜ࠤ࡟ࠫࡢ࠮࠮ࠬࡁࠬ࡟ࠧࡢࠧ࡞࠮ࠪগ"),  re.DOTALL).search(content)
    l11lllll1_ca_ = re.compile(l1l11_ca_ (u"࡛࠭ࠣ࡞ࠪࡡ࡫࡯࡬ࡦ࡝ࠥࡠࠬࡣ࠺࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁ࡟࠲ࡲࡶ࠴ࠪ࡝ࠥࡠࠬࡣࠧঘ"),  re.DOTALL).search(content)
    l11llll1l_ca_ = re.compile(l1l11_ca_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࠰ࠨ࠯ࠬࡂࡠ࠳ࡳࡰ࠵ࠫ࡞ࠦࡡ࠭࡝ࠫࠩঙ"),  re.DOTALL).search(content)
    if l11lll1ll_ca_:
        print l1l11_ca_ (u"ࠨࡨࡲࡹࡳࡪࠠࡓࡇࠣ࡟࡫࡯࡬ࡦ࠼ࡠࠫচ")
        l11lll111_ca_ = l11lll1ll_ca_.group(1)
    elif l11lllll1_ca_:
        print l1l11_ca_ (u"ࠩࡩࡳࡺࡴࡤࠡࡔࡈࠤࡠࡻࡲ࡭࠼ࡠࠫছ")
        l11lll111_ca_ = l11lllll1_ca_.group(1)
    elif l11llll1l_ca_:
        print l1l11_ca_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡵࡳ࡮࠽ࡡࠬজ")
        l11lll111_ca_ = l11llll1l_ca_.group(1)
    else:
        print l1l11_ca_ (u"ࠫࡪࡴࡣࡰࡦࡨࡨࠥࡀࠠࡶࡰࡳࡥࡨࡱࡥࡳࠩঝ")
        l11lll111_ca_ = _1l111l1l_ca_(content)
    l11lll111_ca_ = l11lll111_ca_.replace(l1l11_ca_ (u"ࠧࡢ࡜ࠣঞ"), l1l11_ca_ (u"ࠨࠢট"))
    if l11lll111_ca_.startswith(l1l11_ca_ (u"ࠧࡶࡩࡪࡧࠬঠ")):
        l11ll1ll1_ca_ = lambda x: 0 if not x.isalpha() else -13 if l1l11_ca_ (u"ࠨࡃࠪড") <=x.upper()<=l1l11_ca_ (u"ࠩࡐࠫঢ") else 13
        l11lll111_ca_ = l1l11_ca_ (u"ࠪࠫণ").join([chr((ord(x)-l11ll1ll1_ca_(x)) ) for x in l11lll111_ca_])
        l11lll111_ca_=l11lll111_ca_[:-7] + l11lll111_ca_[-4:]
    return l11lll111_ca_
def l1lllll1_ca_(url):
    l1l11_ca_ (u"ࠦࠧࠨࠍࠋࠢࠣࠤࠥࡸࡥࡵࡷࡵࡲࡸࠦࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡺࡲࡲࠡࡪࡷࡸࡵࡀ࠯࠰࠰࠱࠲࠳ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡳࡷࠦ࡬ࡪࡵࡷࠤࡴ࡬ࠠ࡜ࠪࠪ࠻࠷࠶ࡰࠨ࠮ࠣࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࡸ࡬ࡨࡪࡵ࠯࠲࠻࠷࠺࠾࠿࠱ࡧࡁࡺࡩࡷࡹࡪࡢ࠿࠺࠶࠵ࡶࠧࠪ࠮࠱࠲࠳ࡣࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࠥࠦࠧত")
    l11llll11_ca_=l1l11_ca_ (u"ࠬࢂࡃࡰࡱ࡮࡭ࡪࡃࡐࡉࡒࡖࡉࡘ࡙ࡉࡅ࠿࠴ࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡩࡤࡢ࠰ࡳࡰ࠴࡬࡬ࡰࡹࡳࡰࡦࡿࡥࡳ࠱ࡩࡰࡦࡹࡨ࠰ࡨ࡯ࡳࡼࡶ࡬ࡢࡻࡨࡶ࠳ࡩ࡯࡮࡯ࡨࡶࡨ࡯ࡡ࡭࠯࠶࠲࠷࠴࠱࠹࠰ࡶࡻ࡫࠭থ")
    content = l1l1111ll_ca_(url)
    src=[]
    if not l1l11_ca_ (u"࠭࠿ࡸࡧࡵࡷ࡯ࡧࠧদ") in url:
         l11ll1lll_ca_ = re.compile(l1l11_ca_ (u"ࠧ࠽ࡣࠣࡨࡦࡺࡡ࠮ࡳࡸࡥࡱ࡯ࡴࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࠬࡄࡖ࠼ࡉࡀ࠱࠮ࡄ࠯࠾ࠩࡁࡓࡀࡖࡄ࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨধ"), re.DOTALL).findall(content)
         for quality in l11ll1lll_ca_:
             l111l11_ca_ = re.search(l1l11_ca_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧন"),quality[1])
             l11ll1l11_ca_ = quality[2]
             src.insert(0,(l11ll1l11_ca_,l1l111111_ca_+l111l11_ca_.group(1)))
    if not src:
        src = l1l1111l1_ca_(content)
        if src:
            src+=l11llll11_ca_
    return src
def l11llllll_ca_(url,quality=0):
    l1l11_ca_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡶࡪࡺࡵࡳࡰࡶࠤࡺࡸ࡬ࠡࡶࡲࠤࡻ࡯ࡤࡦࡱࠐࠎࠥࠦࠠࠡࠤࠥࠦ঩")
    src = l1lllll1_ca_(url)
    if type(src)==list:
        selected=src[quality]
        print l1l11_ca_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠤ࠿࠭প"),selected[0]
        src = l1lllll1_ca_(selected[1])
    return src