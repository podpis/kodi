# coding: UTF-8
import sys
l1_ca_ = sys.version_info [0] == 2
l1lll1_ca_ = 2048
l11ll_ca_ = 7
def l1l11_ca_ (ll_ca_):
	global l1llll_ca_
	l1l11l_ca_ = ord (ll_ca_ [-1])
	l11l1_ca_ = ll_ca_ [:-1]
	l11_ca_ = l1l11l_ca_ % len (l11l1_ca_)
	l1ll_ca_ = l11l1_ca_ [:l11_ca_] + l11l1_ca_ [l11_ca_:]
	if l1_ca_:
		l1ll1l_ca_ = unicode () .join ([unichr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	else:
		l1ll1l_ca_ = str () .join ([chr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	return eval (l1ll1l_ca_)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l1l11_ca_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡤࡢ࠯ࡲࡲࡱ࡯࡮ࡦ࠰ࡳࡰ࠴࠭ফ")
l11ll11ll_ca_= cookielib.LWPCookieJar()
l11l1111l_ca_=l1l11_ca_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠺࠶࠮࠱࠰࠵࠺࠻࠷࠮࠲࠲࠵ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫব")
def l11l11lll_ca_(url,l11ll11ll_ca_=l11ll11ll_ca_,l11l1ll11_ca_=l11l1111l_ca_):
    l11l111ll_ca_=l1l11_ca_ (u"࠭ࠧভ")
    try:
        class l11l1l11l_ca_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l11l11l11_ca_(s):
            try:
                offset=1 if s[0]==l1l11_ca_ (u"ࠧࠬࠩম") else 0
                val = int(eval(s.replace(l1l11_ca_ (u"ࠨࠣ࠮࡟ࡢ࠭য"),l1l11_ca_ (u"ࠩ࠴ࠫর")).replace(l1l11_ca_ (u"ࠪࠥࠦࡡ࡝ࠨ঱"),l1l11_ca_ (u"ࠫ࠶࠭ল")).replace(l1l11_ca_ (u"ࠬࡡ࡝ࠨ঳"),l1l11_ca_ (u"࠭࠰ࠨ঴")).replace(l1l11_ca_ (u"ࠧࠩࠩ঵"),l1l11_ca_ (u"ࠨࡵࡷࡶ࠭࠭শ"))[offset:]))
                return val
            except:
                pass
        if l11ll11ll_ca_==None:
            l11ll11ll_ca_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l11l1l11l_ca_, urllib2.HTTPCookieProcessor(l11ll11ll_ca_))
        opener.l11l1ll1l_ca_ = [(l1l11_ca_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ষ"), l11l1ll11_ca_)]
        try:
            response = opener.open(url)
            result=l11l111ll_ca_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l11l111ll_ca_ = e.read()
        l11ll11l1_ca_ = re.compile(l1l11_ca_ (u"ࠪࡲࡦࡳࡥ࠾ࠤ࡭ࡷࡨ࡮࡬ࡠࡸࡦࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠬࡁࠬࠦ࠴ࡄࠧস")).findall(result)[0]
        init = re.compile(l1l11_ca_ (u"ࠫࡸ࡫ࡴࡕ࡫ࡰࡩࡴࡻࡴ࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡢࠩࡼ࡞ࡶ࠮࠳࠰࠿࠯ࠬ࠽ࠬ࠳࠰࠿ࠪࡿ࠾ࠫহ")).findall(result)[0]
        l11ll111l_ca_ = re.compile(l1l11_ca_ (u"ࡷࠨࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࠯ࡩࡳࡷࡳ࡜ࠨ࡞ࠬ࠿ࡡࡹࠪࠩ࠰࠭࠭ࡦ࠴ࡶࠣ঺")).findall(result)[0]
        l11l1lll1_ca_ = l11l11l11_ca_(init)
        lines = l11ll111l_ca_.split(l1l11_ca_ (u"࠭࠻ࠨ঻"))
        if l11ll11l1_ca_:
            for line in lines:
                if len(line)>0 and l1l11_ca_ (u"ࠧ࠾়ࠩ") in line:
                    l11l1llll_ca_=line.split(l1l11_ca_ (u"ࠨ࠿ࠪঽ"))
                    l11l111l1_ca_ = l11l11l11_ca_(l11l1llll_ca_[1])
                    l11l1lll1_ca_ = int(eval(str(l11l1lll1_ca_)+l11l1llll_ca_[0][-1]+str(l11l111l1_ca_)))
            l11l11ll1_ca_ = l11l1lll1_ca_ + len(urlparse.urlparse(url).netloc)
            u=l1l11_ca_ (u"ࠩ࠲ࠫা").join(url.split(l1l11_ca_ (u"ࠪ࠳ࠬি"))[:-1])
            query = l1l11_ca_ (u"ࠫࠪࡹ࠯ࡤࡦࡱ࠱ࡨ࡭ࡩ࠰࡮࠲ࡧ࡭ࡱ࡟࡫ࡵࡦ࡬ࡱࡅࡪࡴࡥ࡫ࡰࡤࡼࡣ࠾ࠧࡶࠪ࡯ࡹࡣࡩ࡮ࡢࡥࡳࡹࡷࡦࡴࡀࠩࡸ࠭ী") % (u, l11ll11l1_ca_, l11l11ll1_ca_)
            if l1l11_ca_ (u"ࠬࡺࡹࡱࡧࡀࠦ࡭࡯ࡤࡥࡧࡱࠦࠥࡴࡡ࡮ࡧࡀࠦࡵࡧࡳࡴࠤࠪু") in result:
                l11l1l1ll_ca_=re.compile(l1l11_ca_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡶࡡࡴࡵࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫূ")).findall(result)[0]
                query = l1l11_ca_ (u"ࠧࠦࡵ࠲ࡧࡩࡴ࠭ࡤࡩ࡬࠳ࡱ࠵ࡣࡩ࡭ࡢ࡮ࡸࡩࡨ࡭ࡁࡳࡥࡸࡹ࠽ࠦࡵࠩ࡮ࡸࡩࡨ࡭ࡡࡹࡧࡂࠫࡳࠧ࡬ࡶࡧ࡭ࡲ࡟ࡢࡰࡶࡻࡪࡸ࠽ࠦࡵࠪৃ") % (u,urllib.quote_plus(l11l1l1ll_ca_), l11ll11l1_ca_, l11l11ll1_ca_)
                time.sleep(5)
            l11l11l1l_ca_ =l1l11_ca_ (u"ࠨࠩৄ").join([l1l11_ca_ (u"ࠩࠨࡷࡂࠫࡳ࠼ࠩ৅")%(c.name, c.value) for c in l11ll11ll_ca_])
            opener = urllib2.build_opener(l11l1l11l_ca_,urllib2.HTTPCookieProcessor(l11ll11ll_ca_))
            opener.l11l1ll1l_ca_ = [(l1l11_ca_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ৆"), l11l1ll11_ca_)]
            opener.l11l1ll1l_ca_.append((l1l11_ca_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫে"),l11l11l1l_ca_))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
        return l11ll11ll_ca_
    except:
        return None
def l11ll1111_ca_(l1111l1_ca_):
    l11l1l1l1_ca_=l1l11_ca_ (u"ࠬ࠭ৈ")
    if os.path.isfile(l1111l1_ca_):
        l11ll11ll_ca_ = cookielib.LWPCookieJar()
        l11ll11ll_ca_.load(l1111l1_ca_)
        for c in l11ll11ll_ca_:
            l11l1l1l1_ca_+=l1l11_ca_ (u"࠭ࠥࡴ࠿ࠨࡷࡀ࠭৉")%(c.name, c.value)
    return l11l1l1l1_ca_