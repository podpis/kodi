# -*- coding: utf-8 -*-
import sys
l1_ca_ = sys.version_info [0] == 2
l1lll1_ca_ = 2048
l11ll_ca_ = 7
def l1l11_ca_ (ll_ca_):
	global l1llll_ca_
	l1l11l_ca_ = ord (ll_ca_ [-1])
	l11l1_ca_ = ll_ca_ [:-1]
	l11_ca_ = l1l11l_ca_ % len (l11l1_ca_)
	l1ll_ca_ = l11l1_ca_ [:l11_ca_] + l11l1_ca_ [l11_ca_:]
	if l1_ca_:
		l1ll1l_ca_ = unicode () .join ([unichr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	else:
		l1ll1l_ca_ = str () .join ([chr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	return eval (l1ll1l_ca_)
import urllib2,urllib
import re,random,json
import cookielib
l1l111l11_ca_=10
l11l1111l_ca_=l1l11_ca_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠹࠵࠴࠰࠯࠴࠹࠺࠶࠴࠱࠱࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸઼ࠪ")
def l1l1111ll_ca_(url,data=None,header={},l1lll1l11l_ca_=True):
    l11l11l1l_ca_=l1l11_ca_ (u"ࠬ࠭ઽ")
    l11ll11ll_ca_=[]
    if l1lll1l11l_ca_:
        l11ll11ll_ca_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11ll11ll_ca_))
        urllib2.install_opener(opener)
    if not header:
        header = {l1l11_ca_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪા"):l11l1111l_ca_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1l111l11_ca_)
        l111l11_ca_ =  response.read()
        response.close()
        l11l11l1l_ca_ = l1l11_ca_ (u"ࠧࠨિ").join([l1l11_ca_ (u"ࠨࠧࡶࡁࠪࡹ࠻ࠨી")%(c.name, c.value) for c in l11ll11ll_ca_])
    except urllib2.HTTPError as e:
        l111l11_ca_ = l1l11_ca_ (u"ࠩࠪુ")
    return l111l11_ca_,l11l11l1l_ca_
def l1lllll1_ca_(url):
    url = url.replace(l1l11_ca_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩૂ"),l1l11_ca_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫૃ")).replace(l1l11_ca_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭ૄ"),l1l11_ca_ (u"࠭࠯ࡀࡸࡀࠫૅ"))
    content,c = l1l1111ll_ca_(url)
    match = re.findall(l1l11_ca_ (u"ࠧࠨࠩ࡞ࠦࠬࡣ࠿ࡴࡱࡸࡶࡨ࡫ࡳ࡜ࠩࠥࡡࡄࡢࡳࠫ࠼࡟ࡷ࠯࠮࡜࡜࠰࠭ࡃࡡࡣࠩࠨࠩࠪ૆"), content)
    l1lll1l1l1_ca_=l1l11_ca_ (u"ࠨࠩે")
    if not match:
        data = {}
        data[l1l11_ca_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯࠱ࡽࠬૈ")] = random.randint(0, 120)
        data[l1l11_ca_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰ࠲ࡽ࠭ૉ")] = random.randint(0, 120)
        header={l1l11_ca_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ૊"):l11l1111l_ca_,l1l11_ca_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ો"):url}
        l1lll1ll11_ca_ = url + l1l11_ca_ (u"࠭ࠣࠨૌ")
        content,c = l1l1111ll_ca_(l1lll1ll11_ca_,urllib.urlencode(data),header=header)
        match = re.findall(l1l11_ca_ (u"ࠧࠨࠩ࡞ࠦࠬࡣ࠿ࡴࡱࡸࡶࡨ࡫ࡳ࡜ࠩࠥࡡࡄࡢࡳࠫ࠼࡟ࡷ࠯࠮࡜࡜࠰࠭ࡃࡡࡣࠩࠨ્ࠩࠪ"), content)
    if match:
        print match
        try:
            data = json.loads(match[0])
            l1lll1l1l1_ca_=[]
            for d in data:
                if isinstance(d,dict):
                    l1lll1l1ll_ca_ = d.get(l1l11_ca_ (u"ࠨࡨ࡬ࡰࡪ࠭૎"),l1l11_ca_ (u"ࠩࠪ૏"))+l1l11_ca_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠧࡶࠪࡗ࡫ࡦࡦࡴࡨࡶࡂࠫࡳࠨૐ")%(l11l1111l_ca_,url)
                    l1lll1l1l1_ca_.append((d.get(l1l11_ca_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ૑"),l1l11_ca_ (u"ࠬ࠭૒")),l1lll1l1ll_ca_))
        except:
            l1lll1l1l1_ca_ = re.findall(l1l11_ca_ (u"࠭ࠧࠨ࡝ࠪࠦࡢࡅࡦࡪ࡮ࡨ࡟ࠬࠨ࡝ࡀ࡞ࡶ࠮࠿ࡢࡳࠫ࡝ࠪࠦࡢࡅࠨ࡜ࡠࠪࠦࡢ࠱ࠩࠨࠩࠪ૓"), match[0])
            if l1lll1l1l1_ca_:
                l1lll1l1l1_ca_ = l1lll1l1l1_ca_[0].replace(l1l11_ca_ (u"ࠧ࡝࠱ࠪ૔"), l1l11_ca_ (u"ࠨ࠱ࠪ૕"))
                l1lll1l1l1_ca_ += l1l11_ca_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠪࡹࠧ૖")%(l11l1111l_ca_,url)
    return l1lll1l1l1_ca_