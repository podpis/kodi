# coding: UTF-8
import sys
l1_ca_ = sys.version_info [0] == 2
l1lll1_ca_ = 2048
l11ll_ca_ = 7
def l1l11_ca_ (ll_ca_):
	global l1llll_ca_
	l1l11l_ca_ = ord (ll_ca_ [-1])
	l11l1_ca_ = ll_ca_ [:-1]
	l11_ca_ = l1l11l_ca_ % len (l11l1_ca_)
	l1ll_ca_ = l11l1_ca_ [:l11_ca_] + l11l1_ca_ [l11_ca_:]
	if l1_ca_:
		l1ll1l_ca_ = unicode () .join ([unichr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	else:
		l1ll1l_ca_ = str () .join ([chr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	return eval (l1ll1l_ca_)