# -*- coding: utf-8 -*-
import sys
l1_ca_ = sys.version_info [0] == 2
l1lll1_ca_ = 2048
l11ll_ca_ = 7
def l1l11_ca_ (ll_ca_):
	global l1llll_ca_
	l1l11l_ca_ = ord (ll_ca_ [-1])
	l11l1_ca_ = ll_ca_ [:-1]
	l11_ca_ = l1l11l_ca_ % len (l11l1_ca_)
	l1ll_ca_ = l11l1_ca_ [:l11_ca_] + l11l1_ca_ [l11_ca_:]
	if l1_ca_:
		l1ll1l_ca_ = unicode () .join ([unichr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	else:
		l1ll1l_ca_ = str () .join ([chr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	return eval (l1ll1l_ca_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver
import check
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l1l11_ca_ (u"ࠢ࡬࡫ࡱࡳ࠷࠺ࡴࡷࠤ࠭"))
import resources.lib.l1llll1l_ca_ as l1llll1l_ca_
import resources.lib.l1lll11l_ca_ as l1lll11l_ca_
import resources.lib.l11l11l_ca_
l1l1ll1_ca_        = sys.argv[0]
l11l1ll_ca_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1ll1l11_ca_        = xbmcaddon.Addon()
l111ll_ca_       = l1ll1l11_ca_.getAddonInfo(l1l11_ca_ (u"ࠨࡰࡤࡱࡪ࠭࠮"))
PATH        = l1ll1l11_ca_.getAddonInfo(l1l11_ca_ (u"ࠩࡳࡥࡹ࡮ࠧ࠯"))
l1lllll_ca_    = xbmc.translatePath(l1ll1l11_ca_.getAddonInfo(l1l11_ca_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࠫ࠰"))).decode(l1l11_ca_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ࠱"))
l1llllll_ca_   = PATH+l1l11_ca_ (u"ࠬ࠵ࡲࡦࡵࡲࡹࡷࡩࡥࡴ࠱ࠪ࠲")
l1ll1ll1_ca_=l1llllll_ca_+l1l11_ca_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪ࠳")
l1llll1l_ca_.l1111l1_ca_=os.path.join(l1lllll_ca_,l1l11_ca_ (u"ࠧ࡬࡫ࡱࡳ࠷࠺ࡴࡷ࠰ࡦࡳࡴࡱࡩࡦࠩ࠴"))
l1llll1l_ca_.l11l11_ca_ = l1l11_ca_ (u"ࠨࠩ࠵")
if l1ll1l11_ca_.getSetting(l1l11_ca_ (u"ࠩࡥࡶࡦࡳ࡫ࡢࠩ࠶"))==l1l11_ca_ (u"ࠪࡸࡷࡻࡥࠨ࠷"):
    l1llll1l_ca_.l11l11_ca_ = l1l11_ca_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡵࡥࡲࡱࡡ࠯ࡲࡵࡳࡽࡿ࠮࡯ࡧࡷ࠲ࡵࡲ࠯ࡪࡰࡧࡩࡽ࠴ࡰࡩࡲࡂࡵࡂ࠭࠸")
def l111lll_ca_(name, url, mode, l1ll1111_ca_=1, l1ll111_ca_=l1l11_ca_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩ࠹"), infoLabels={}, IsPlayable=True,fanart=l1ll1ll1_ca_,l1l1111_ca_=1):
    u = l1111l_ca_({l1l11_ca_ (u"࠭࡭ࡰࡦࡨࠫ࠺"): mode, l1l11_ca_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ࠻"): name, l1l11_ca_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ࠼") : url, l1l11_ca_ (u"ࠩࡳࡥ࡬࡫ࠧ࠽"):l1ll1111_ca_})
    l11llll_ca_ = xbmcgui.ListItem(name,)
    l1l1llll_ca_=[l1l11_ca_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩ࠾"),l1l11_ca_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫ࠿"),l1l11_ca_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬࡀ"),l1l11_ca_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭ࡁ"),l1l11_ca_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩࡂ"),l1l11_ca_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫࡃ"),l1l11_ca_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࡄ"),l1l11_ca_ (u"ࠪ࡭ࡨࡵ࡮ࠨࡅ")]
    l11l1l_ca_=dict(zip(l1l1llll_ca_,[l1ll111_ca_ for x in l1l1llll_ca_]))
    l11l1l_ca_[l1l11_ca_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫࡆ")] = infoLabels.get(l1l11_ca_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬࡇ"),fanart)
    l11llll_ca_.setArt(l11l1l_ca_)
    if not infoLabels: infoLabels={l1l11_ca_ (u"ࠨࡴࡪࡶ࡯ࡩࠧࡈ"): name}
    l11llll_ca_.setInfo(type=l1l11_ca_ (u"ࠢࡷ࡫ࡧࡩࡴࠨࡉ"), infoLabels=infoLabels)
    if IsPlayable:
        l11llll_ca_.setProperty(l1l11_ca_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬࡊ"), l1l11_ca_ (u"ࠩࡷࡶࡺ࡫ࠧࡋ"))
    l1ll1l1_ca_ = []
    l1ll1l1_ca_.append((l1l11_ca_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧࠧࡌ"), l1l11_ca_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡄࡧࡹ࡯࡯࡯ࠪࡌࡲ࡫ࡵࠩࠨࡍ")))
    l11llll_ca_.addContextMenuItems(l1ll1l1_ca_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l11l1ll_ca_, url=u, listitem=l11llll_ca_,isFolder=False,totalItems=l1l1111_ca_)
    xbmcplugin.addSortMethod(l11l1ll_ca_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11_ca_ (u"ࠧࠫࡒ࠭ࠢࠨ࡝࠱ࠦࠥࡑࠤࡎ"))
    return ok
def l1l11ll_ca_(name,ex_link=None, l1ll1111_ca_=1, mode=l1l11_ca_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࡏ"),iconImage=l1l11_ca_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࡐ"), infoLabels={}, fanart=l1ll1ll1_ca_,contextmenu=None):
    url = l1111l_ca_({l1l11_ca_ (u"ࠨ࡯ࡲࡨࡪ࠭ࡑ"): mode, l1l11_ca_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࡒ"): name, l1l11_ca_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࡓ") : ex_link, l1l11_ca_ (u"ࠫࡵࡧࡧࡦࠩࡔ") : l1ll1111_ca_})
    l1l1l11_ca_ = xbmcgui.ListItem(name)
    l1l1llll_ca_=[l1l11_ca_ (u"ࠬࡺࡨࡶ࡯ࡥࠫࡕ"),l1l11_ca_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ࡖ"),l1l11_ca_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧࡗ"),l1l11_ca_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࡘ"),l1l11_ca_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷ࡙ࠫ"),l1l11_ca_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࡚࠭"),l1l11_ca_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࡛ࠧ"),l1l11_ca_ (u"ࠬ࡯ࡣࡰࡰࠪ࡜")]
    l11l1l_ca_=dict(zip(l1l1llll_ca_,[iconImage for x in l1l1llll_ca_]))
    l11l1l_ca_[l1l11_ca_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭࡝")] = infoLabels.get(l1l11_ca_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ࡞"),fanart)
    l1l1l11_ca_.setArt(l11l1l_ca_)
    if infoLabels: l1l1l11_ca_.setInfo(type=l1l11_ca_ (u"ࠣ࡯ࡲࡺ࡮࡫ࠢ࡟"), infoLabels=infoLabels)
    if contextmenu:
        l1ll1l1_ca_=contextmenu
        l1l1l11_ca_.addContextMenuItems(l1ll1l1_ca_, replaceItems=True)
    else:
        l1ll1l1_ca_ = []
        l1ll1l1_ca_.append((l1l11_ca_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭ࡠ"), l1l11_ca_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡃࡦࡸ࡮ࡵ࡮ࠩࡋࡱࡪࡴ࠯ࠧࡡ")),)
        l1l1l11_ca_.addContextMenuItems(l1ll1l1_ca_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l11l1ll_ca_, url=url,listitem=l1l1l11_ca_, isFolder=True)
    xbmcplugin.addSortMethod(l11l1ll_ca_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11_ca_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐࠣࡢ"))
def l1ll11l_ca_(l1111ll_ca_):
    l11111l_ca_ = {}
    for k, v in l1111ll_ca_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11_ca_ (u"ࠬࡻࡴࡧ࠺ࠪࡣ"))
        elif isinstance(v, str):
            v.decode(l1l11_ca_ (u"࠭ࡵࡵࡨ࠻ࠫࡤ"))
        l11111l_ca_[k] = v
    return l11111l_ca_
def l1111l_ca_(query):
    return l1l1ll1_ca_ + l1l11_ca_ (u"ࠧࡀࠩࡥ") + urllib.urlencode(l1ll11l_ca_(query))
def l11l1l1_ca_(ex_link,l1lll11_ca_=l1l11_ca_ (u"ࠨࠩࡦ")):
    l1l11l1_ca_,l1llll11_ca_ = l1llll1l_ca_.l11ll1l_ca_(ex_link,l1lll11_ca_)
    print l1l11_ca_ (u"ࠩࠧࠨࠩࠪࠤࠥࠦࠧࠨࠩࠪࠤࠥࠦࠧࠨࠩࠪࠤࠥࠦࠧࠫࡧ"),l1l11l1_ca_
    if l1llll11_ca_[0]:
        l111lll_ca_(name=l1l11_ca_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࠾࠿ࠤࡵࡵࡰࡳࡼࡨࡨࡳ࡯ࡡࠡࡵࡷࡶࡴࡴࡡࠡ࠾࠿࡟࠴ࡉࡏࡍࡑࡕࡡࠬࡨ"), url=l1llll11_ca_[1], mode=l1l11_ca_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡓࠧࡩ"),  IsPlayable=False)
    items=len(l1l11l1_ca_)
    for f in l1l11l1_ca_:
        l111lll_ca_(name=f.get(l1l11_ca_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࡪ")), url=f.get(l1l11_ca_ (u"࠭ࡨࡳࡧࡩࠫ࡫")), mode=l1l11_ca_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩ࡬"), l1ll111_ca_=f.get(l1l11_ca_ (u"ࠨ࡫ࡰ࡫ࠬ࡭")), infoLabels=f, IsPlayable=True,l1l1111_ca_=items)
    if l1llll11_ca_[1]:
        l111lll_ca_(name=l1l11_ca_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࠿ࡀࠣࡲࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࡄ࠾࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࡮"), url=l1llll11_ca_[1], mode=l1l11_ca_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣࡒ࠭࡯"), IsPlayable=False)
def l11lll_ca_(ex_link,l1ll1111_ca_):
    l1l11l1_ca_,l1llll11_ca_ = l1llll1l_ca_.l11ll1l_ca_(ex_link)
    if l1llll11_ca_[0]:
        l111lll_ca_(name=l1l11_ca_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟࠿ࡀࠥࡶ࡯ࡱࡴࡽࡩࡩࡴࡩࡢࠢࡶࡸࡷࡵ࡮ࡢࠢ࠿ࡀࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡰ"), url=ex_link, mode=l1l11_ca_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡓࠨࡱ"), l1ll1111_ca_=l1llll11_ca_[1], IsPlayable=False)
    items=len(l1l11l1_ca_)
    for f in l1l11l1_ca_:
        l1l11ll_ca_(name=f.get(l1l11_ca_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࡲ")), ex_link=f.get(l1l11_ca_ (u"ࠧࡩࡴࡨࡪࠬࡳ")), mode=l1l11_ca_ (u"ࠨࡩࡨࡸࡊࡶࡩࡴࡱࡧࡩࡸ࠭ࡴ"), iconImage=f.get(l1l11_ca_ (u"ࠩ࡬ࡱ࡬࠭ࡵ")), infoLabels=f)
    if l1llll11_ca_[1]:
        l111lll_ca_(name=l1l11_ca_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡀࡁࠤࡳࡧࡳࡵࡧࡳࡲࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠾࠿࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡶ"), url=ex_link, mode=l1l11_ca_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤ࡙ࠧࡷ"), l1ll1111_ca_=l1llll11_ca_[1], IsPlayable=False)
def l1l1l1l_ca_(ex_link):
    l1llll1_ca_ = l1llll1l_ca_.l1lll111_ca_(ex_link)
    for f in l1llll1_ca_:
        l111lll_ca_(name=f.get(l1l11_ca_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࡸ")), url=f.get(l1l11_ca_ (u"࠭ࡨࡳࡧࡩࠫࡹ")), mode=l1l11_ca_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩࡺ"), l1ll111_ca_=f.get(l1l11_ca_ (u"ࠨ࡫ࡰ࡫ࠬࡻ")), infoLabels=f, IsPlayable=True)
def l11l111_ca_(ex_link):
    import resources.lib.l11l11l_ca_
    l11ll11_ca_ = l1llll1l_ca_.l1lll1l1_ca_(ex_link)
    l1ll11ll_ca_=l1l11_ca_ (u"ࠩࠪࡼ")
    check.run()
    t = [ x.get(l1l11_ca_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࡽ")) for x in l11ll11_ca_]
    u = [ x.get(l1l11_ca_ (u"ࠫࡺࡸ࡬ࠨࡾ")) for x in l11ll11_ca_]
    h = [ x.get(l1l11_ca_ (u"ࠬ࡮࡯ࡴࡶࠪࡿ")) for x in l11ll11_ca_]
    l11ll1_ca_ = xbmcgui.Dialog().select(l1l11_ca_ (u"ࠨࡓࡰࡷࡵࡧࡪࡹࠢࢀ"), t)
    if l11ll1_ca_>-1:
        l111l11_ca_ =u[l11ll1_ca_]
        if l1l11_ca_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࡮ࡢࡷࡷࠫࢁ") in l111l11_ca_: l111l11_ca_ = l111l11_ca_.replace(l1l11_ca_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࡯ࡣࡸࡸࠬࢂ"),l1l11_ca_ (u"ࠩࡵࡥࡵࡺࡵࠨࢃ"))
        if l1l11_ca_ (u"ࠪࡧࡩࡧࠧࢄ") in h[l11ll1_ca_]:
            l1ll11ll_ca_ = l1lll11l_ca_.l1lllll1_ca_(l111l11_ca_)
            if type(l1ll11ll_ca_) is list:
                l1lll1ll_ca_ = [x[0] for x in l1ll11ll_ca_]
                l11ll1_ca_ = xbmcgui.Dialog().select(l1l11_ca_ (u"ࠦ࡜ࡿࡢࡪࡧࡵࡾࠥࡰࡡ࡬ࡱफ़ऋࠥ࠮ࡣࡥࡣࠬࠦࢅ"), l1lll1ll_ca_)
                if l11ll1_ca_>-1:
                    l1ll11ll_ca_ = l1lll11l_ca_.l1lllll1_ca_(l1ll11ll_ca_[l11ll1_ca_][1])
                else:
                    l1ll11ll_ca_=l1l11_ca_ (u"ࠬ࠭ࢆ")
        elif l1l11_ca_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪࢇ") in l111l11_ca_ or l1l11_ca_ (u"ࠧࡳࡣࡳࡸࡺ࠭࢈") in l111l11_ca_:
            import resources.lib.l1ll1lll_ca_ as l111l1_ca_
            l1ll11ll_ca_ = l111l1_ca_.l1lllll1_ca_(l111l11_ca_)
            if type(l1ll11ll_ca_) is list:
                if len(l1ll11ll_ca_)==1:
                    l1ll11ll_ca_ = l1ll11ll_ca_[0][1]
                else:
                    l1lll1ll_ca_ = [x[0] for x in l1ll11ll_ca_]
                    l11ll1_ca_ = xbmcgui.Dialog().select(l1l11_ca_ (u"࡙ࠣࡼࡦ࡮࡫ࡲࡻࠢ࡭ࡥࡰࡵज़ईࠢࠫࡶࡦࡶࡴࡶࠫࠥࢉ"), l1lll1ll_ca_)
                    if l11ll1_ca_>-1:
                        l1ll11ll_ca_ = l1ll11ll_ca_[l11ll1_ca_][1]
                    else:
                        try:l1ll11ll_ca_ = urlresolver.resolve(l111l11_ca_)
                        except: l1ll11ll_ca_=l1l11_ca_ (u"ࠩࠪࢊ")
        if l111l11_ca_ and not l1ll11ll_ca_:
            try:
                l1ll11ll_ca_ = urlresolver.resolve(l111l11_ca_)
            except Exception,e:
                l1ll11ll_ca_=l1l11_ca_ (u"ࠪࠫࢋ")
                s = xbmcgui.Dialog().ok(l1l11_ca_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡒࡵࡳࡧࡲࡥ࡮࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢌ"),l1l11_ca_ (u"ࠬࡓ࡯ॽࡧࠣ࡭ࡳࡴࡹࠡ࡮࡬ࡲࡰࠦࡢचࡦࡽ࡭ࡪࠦࡤࡻ࡫ࡤॆࡦै࠿ࠨࢍ"),l1l11_ca_ (u"࠭ࡅࡓࡔࡒࡖ࠿ࠦࠥࡴࠩࢎ")%str(e))
    print l1ll11ll_ca_
    if l1ll11ll_ca_:
        xbmcplugin.setResolvedUrl(l11l1ll_ca_, True, xbmcgui.ListItem(path=l1ll11ll_ca_))
    else:
        xbmcplugin.setResolvedUrl(l11l1ll_ca_, False, xbmcgui.ListItem(path=l1l11_ca_ (u"ࠧࠨ࢏")))
def l1l111l_ca_():
    return cache.get(l1l11_ca_ (u"ࠨࡪ࡬ࡷࡹࡵࡲࡺࠩ࢐")).split(l1l11_ca_ (u"ࠩ࠾ࠫ࢑"))
def l111l1l_ca_(l1ll11l1_ca_):
    l1ll111l_ca_ = l1l111l_ca_()
    if l1ll111l_ca_ == [l1l11_ca_ (u"ࠪࠫ࢒")]:
        l1ll111l_ca_ = []
    l1ll111l_ca_.insert(0, l1ll11l1_ca_)
    cache.set(l1l11_ca_ (u"ࠫ࡭࡯ࡳࡵࡱࡵࡽࠬ࢓"),l1l11_ca_ (u"ࠬࡁࠧ࢔").join(l1ll111l_ca_[:50]))
def l1ll1ll_ca_(l1ll11l1_ca_):
    l1ll111l_ca_ = l1l111l_ca_()
    l1ll111l_ca_.remove(l1ll11l1_ca_)
    if l1ll111l_ca_:
        cache.set(l1l11_ca_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࠧ࢕"),l1l11_ca_ (u"ࠧ࠼ࠩ࢖").join(l1ll111l_ca_[:50]))
    else:
        l11111_ca_()
def l11111_ca_():
    cache.delete(l1l11_ca_ (u"ࠨࡪ࡬ࡷࡹࡵࡲࡺࠩࢗ"))
xbmcplugin.setContent(l11l1ll_ca_, l1l11_ca_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ࢘"))
mode = args.get(l1l11_ca_ (u"ࠪࡱࡴࡪࡥࠨ࢙"), None)
fname = args.get(l1l11_ca_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ࢚"),[l1l11_ca_ (u"࢛ࠬ࠭")])[0]
ex_link = args.get(l1l11_ca_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧ࢜"),[l1l11_ca_ (u"ࠧࠨ࢝")])[0]
l1ll1111_ca_ = args.get(l1l11_ca_ (u"ࠨࡲࡤ࡫ࡪ࠭࢞"),[1])[0]
if mode is None:
    l1l11ll_ca_(name=l1l11_ca_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡇ࡫࡯ࡱࡾࡡ࠯ࡄࡑࡏࡓࡗࡣࠢ࢟"),ex_link=l1l11_ca_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡩࡧ࠭࡬࡫ࡱࡳ࠳ࡶ࡬࠰࡭ࡤࡸࡪ࡭࡯ࡳ࡫ࡤ࠳࡫࡯࡬࡮ࡻ࠰ࡳࡳࡲࡩ࡯ࡧ࠲ࠫࢠ"),l1ll1111_ca_=1, mode=l1l11_ca_ (u"ࠫࡑ࡯ࡳࡵࡏࡲࡺ࡮࡫ࡳࠨࢡ"),iconImage=l1l11_ca_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩࢢ"),fanart=l1ll1ll1_ca_)
    l1l11ll_ca_(name=l1l11_ca_ (u"ࠨࠠࠡ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡕࡵ࡬ࡦࡥࡤࡲࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࢣ"),ex_link=l1l11_ca_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡦࡤ࠱ࡰ࡯࡮ࡰ࠰ࡳࡰࠬࢤ"), mode=l1l11_ca_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࡕࡵ࡬ࡦࡥࡤࡲࡪ࠭ࢥ"),iconImage=l1l11_ca_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࢦ"),fanart=l1ll1ll1_ca_)
    l1l11ll_ca_(name=l1l11_ca_ (u"ࠥࠤࠥࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷࡦࡱࡻࡥ࡞ࡑࡶࡸࡦࡺ࡮ࡪࡱࠣࡨࡴࡪࡡ࡯ࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠦࢧ"),ex_link=l1l11_ca_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡪࡡ࠮࡭࡬ࡲࡴ࠴ࡰ࡭ࠩࢨ"),l1ll1111_ca_=1, mode=l1l11_ca_ (u"ࠬࡒࡩࡴࡶࡐࡳࡻ࡯ࡥࡴࠩࢩ"),iconImage=l1l11_ca_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪࢪ"),fanart=l1ll1ll1_ca_)
    l1l11ll_ca_(name=l1l11_ca_ (u"ࠢࠡࠢࡀࡂࠥࡡࡇࡢࡶࡸࡲࡪࡱ࡝ࠣࢫ"),ex_link=l1l11_ca_ (u"ࠨࡨ࡬ࡰࡲࢂࡧࡢࡶࡸࡲࡪࡱࠧࢬ"),l1ll1111_ca_=1, mode=l1l11_ca_ (u"ࠩࡊࡥࡹࡻ࡮ࡦ࡭ࡕࡳࡰ࠭ࢭ"),iconImage=l1l11_ca_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࢮ"),fanart=l1ll1ll1_ca_)
    l1l11ll_ca_(name=l1l11_ca_ (u"ࠦࠥࠦ࠽࠿ࠢ࡞ࡖࡴࡱ࡝ࠣࢯ"),ex_link=l1l11_ca_ (u"ࠬ࡬ࡩ࡭࡯ࡿࡶࡴࡱࠧࢰ"),l1ll1111_ca_=1, mode=l1l11_ca_ (u"࠭ࡇࡢࡶࡸࡲࡪࡱࡒࡰ࡭ࠪࢱ"),iconImage=l1l11_ca_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࢲ"),fanart=l1ll1ll1_ca_)
    l1l11ll_ca_(name=l1l11_ca_ (u"ࠣࠢࠣࡁࡃ࡛ࠦࡋࡣ࡮ࡳॠऍ࡝ࠣࢳ"),ex_link=l1l11_ca_ (u"ࠩࡩ࡭ࡱࡳࡼ࡫ࡣ࡮ࡳࡸࡩࠧࢴ"),l1ll1111_ca_=1, mode=l1l11_ca_ (u"ࠪࡋࡦࡺࡵ࡯ࡧ࡮ࡖࡴࡱࠧࢵ"),iconImage=l1l11_ca_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨࢶ"),fanart=l1ll1ll1_ca_)
    l1l11ll_ca_(l1l11_ca_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭ࡲࡦࡧࡱࡡࡘࢀࡵ࡬ࡣ࡭࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢷ"),l1l11_ca_ (u"࠭ࠧࢸ"),mode=l1l11_ca_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠧࢹ"))
    l111lll_ca_(l1l11_ca_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠭࠾ࡑࡳࡧ࡯࡫࠽࠮࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢺ"),l1l11_ca_ (u"ࠩࠪࢻ"),l1l11_ca_ (u"ࠪࡓࡵࡩࡪࡦࠩࢼ"))
elif mode[0] == l1l11_ca_ (u"ࠫࡔࡶࡣ࡫ࡧࠪࢽ"):
    l1ll1l11_ca_.openSettings()
elif mode[0] == l1l11_ca_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡍࠨࢾ"):
    url = l1111l_ca_({l1l11_ca_ (u"࠭࡭ࡰࡦࡨࠫࢿ"): l1l11_ca_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫࣀ"), l1l11_ca_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࣁ"): l1l11_ca_ (u"ࠩࠪࣂ"), l1l11_ca_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࣃ") : ex_link, l1l11_ca_ (u"ࠫࡵࡧࡧࡦࠩࣄ"): l1ll1111_ca_})
    xbmc.executebuiltin(l1l11_ca_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫࣅ")% url)
elif mode[0] == l1l11_ca_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟ࡔࠩࣆ"):
    url = l1111l_ca_({l1l11_ca_ (u"ࠧ࡮ࡱࡧࡩࠬࣇ"): l1l11_ca_ (u"ࠨࡎ࡬ࡷࡹ࡙ࡥࡳ࡫ࡤࡰࡪ࠭ࣈ"), l1l11_ca_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࣉ"): l1l11_ca_ (u"ࠪࠫ࣊"), l1l11_ca_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬ࣋") : ex_link, l1l11_ca_ (u"ࠬࡶࡡࡨࡧࠪ࣌"): l1ll1111_ca_})
    xbmc.executebuiltin(l1l11_ca_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬ࣍")% url)
elif mode[0] == l1l11_ca_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫ࣎"):
    l11l1l1_ca_(ex_link)
elif mode[0] == l1l11_ca_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࡕࡵ࡬ࡦࡥࡤࡲࡪ࣏࠭"):
    l11l1l1_ca_(ex_link,l1l11_ca_ (u"ࠩࡳࡳࡱ࡫ࡣࡢࡰࡨ࣐ࠫ"))
elif mode[0] ==l1l11_ca_ (u"ࠪࡋࡦࡺࡵ࡯ࡧ࡮࣑ࠫ"):
    data = l1llll1l_ca_.l1ll1l1l_ca_()
    for f in data:
        l1l11ll_ca_(name=f.get(l1l11_ca_ (u"ࠫࡹ࡯ࡴ࡭ࡧ࣒ࠪ")), ex_link=f.get(l1l11_ca_ (u"ࠬ࡮ࡲࡦࡨ࣓ࠪ")), mode=l1l11_ca_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࠪࣔ"), iconImage=f.get(l1l11_ca_ (u"ࠧࡪ࡯ࡪࠫࣕ")), infoLabels=f)
elif mode[0] == l1l11_ca_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪࣖ"):
    l11l111_ca_(ex_link)
elif mode[0] == l1l11_ca_ (u"ࠩࡊࡥࡹࡻ࡮ࡦ࡭ࡕࡳࡰ࠭ࣗ"):
    param = ex_link.split(l1l11_ca_ (u"ࠪࢀࠬࣘ"))
    data = l1llll1l_ca_.l1l1lll_ca_(l11lll1_ca_=param[0],l111111_ca_=param[1])
    if data:
        l1lll1l_ca_ = xbmcgui.Dialog().select(l1l11_ca_ (u"ࠫ࡜ࡿࡢࡪࡧࡵࡾ࠿࠭ࣙ"), data[0])
        if l1lll1l_ca_>-1:
            if param[0]==l1l11_ca_ (u"ࠬ࡬ࡩ࡭࡯ࠪࣚ"):
                l1l1lll1_ca_ = l1l11_ca_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࠪࣛ")
            else:
                l1l1lll1_ca_ = l1l11_ca_ (u"ࠧࡍ࡫ࡶࡸࡘ࡫ࡲࡪࡣ࡯ࡩࠬࣜ")
            url = l1111l_ca_({l1l11_ca_ (u"ࠨ࡯ࡲࡨࡪ࠭ࣝ"): l1l1lll1_ca_, l1l11_ca_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࣞ"): l1l11_ca_ (u"ࠪࠫࣟ"), l1l11_ca_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬ࣠") : data[1][l1lll1l_ca_], l1l11_ca_ (u"ࠬࡶࡡࡨࡧࠪ࣡"): 1})
            xbmc.executebuiltin(l1l11_ca_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬ࣢")% url)
elif mode[0] == l1l11_ca_ (u"ࠧࡐࡲࡦ࡮ࡪࣣ࠭"):
    l1ll1l11_ca_.openSettings()
elif mode[0] ==l1l11_ca_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨࣤ"):
    l1l11ll_ca_(l1l11_ca_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡶࡪ࡫࡮࡞ࡐࡲࡻࡪࠦࡓࡻࡷ࡮ࡥࡳ࡯ࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣥ"),l1l11_ca_ (u"ࣦࠪࠫ"),mode=l1l11_ca_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࡒࡴࡽࡥࠨࣧ"))
    l111ll1_ca_ = l1l111l_ca_()
    if not l111ll1_ca_ == [l1l11_ca_ (u"ࠬ࠭ࣨ")]:
        for l1ll11l1_ca_ in l111ll1_ca_:
            contextmenu = []
            contextmenu.append((l1l11_ca_ (u"࠭ࡕࡴࡷेࣩࠫ"), l1l11_ca_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭࣪")% l1111l_ca_({l1l11_ca_ (u"ࠨ࡯ࡲࡨࡪ࠭࣫"): l1l11_ca_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳ࠭࣬"), l1l11_ca_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮࣭ࠫ") : l1ll11l1_ca_})),)
            contextmenu.append((l1l11_ca_ (u"࡚ࠫࡹࡵॅࠢࡦࡥेऋࠠࡩ࡫ࡶࡸࡴࡸࡩच࣮ࠩ"), l1l11_ca_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠥࡴ࣯ࠫࠪ") % l1111l_ca_({l1l11_ca_ (u"࠭࡭ࡰࡦࡨࣰࠫ"): l1l11_ca_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡕࡴࡷࡱࡅࡱࡲࣱࠧ")})),)
            l1l11ll_ca_(name=l1ll11l1_ca_, ex_link=l1l11_ca_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡧࡥ࠲ࡱࡩ࡯ࡱ࠱ࡴࡱ࠵࠿ࡴ࠿ࣲࠪ")+l1ll11l1_ca_.replace(l1l11_ca_ (u"ࠩࠣࠫࣳ"),l1l11_ca_ (u"ࠪ࠯ࠬࣴ")), mode=l1l11_ca_ (u"ࠫࡑ࡯ࡳࡵࡏࡲࡺ࡮࡫ࡳࠨࣵ"), fanart=None, contextmenu=contextmenu)
elif mode[0] ==l1l11_ca_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࡓࡵࡷࡦࣶࠩ"):
    d = xbmcgui.Dialog().input(l1l11_ca_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࠲ࠠࡑࡱࡧࡥ࡯ࠦࡴࡺࡶࡸࡰࠥ࡬ࡩ࡭࡯ࡸ࠳ࡸ࡫ࡲࡪࡣ࡯ࡹ࠴ࡨࡡ࡫࡭࡬ࠫࣷ"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l111l1l_ca_(d)
        ex_link=l1l11_ca_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡦࡤ࠱ࡰ࡯࡮ࡰ࠰ࡳࡰ࠴ࡅࡳ࠾ࠩࣸ")+d.replace(l1l11_ca_ (u"ࠨࣹࠢࠪ"),l1l11_ca_ (u"ࠩ࠮ࣺࠫ"))
        l11l1l1_ca_(ex_link,l1l11_ca_ (u"ࠪࠫࣻ"))
elif mode[0] ==l1l11_ca_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭࡙ࡸࡻ࡮ࠨࣼ"):
    l1ll1ll_ca_(ex_link)
    xbmc.executebuiltin(l1l11_ca_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫࣽ")%  l1111l_ca_({l1l11_ca_ (u"࠭࡭ࡰࡦࡨࠫࣾ"): l1l11_ca_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠧࣿ")}))
elif mode[0] == l1l11_ca_ (u"ࠨࡕࡽࡹࡰࡧࡪࡖࡵࡸࡲࡆࡲ࡬ࠨऀ"):
    l11111_ca_()
    xbmc.executebuiltin(l1l11_ca_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨँ")%  l1111l_ca_({l1l11_ca_ (u"ࠪࡱࡴࡪࡥࠨं"): l1l11_ca_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫः")}))
elif mode[0] == l1l11_ca_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬऄ"):
    pass
else:
    xbmcplugin.setResolvedUrl(l11l1ll_ca_, False, xbmcgui.ListItem(path=l1l11_ca_ (u"࠭ࠧअ")))
xbmcplugin.endOfDirectory(l11l1ll_ca_)