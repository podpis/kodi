# -*- coding: utf-8 -*-
import sys
l1_ca_ = sys.version_info [0] == 2
l1lll1_ca_ = 2048
l11ll_ca_ = 7
def l1l11_ca_ (ll_ca_):
	global l1llll_ca_
	l1l11l_ca_ = ord (ll_ca_ [-1])
	l11l1_ca_ = ll_ca_ [:-1]
	l11_ca_ = l1l11l_ca_ % len (l11l1_ca_)
	l1ll_ca_ = l11l1_ca_ [:l11_ca_] + l11l1_ca_ [l11_ca_:]
	if l1_ca_:
		l1ll1l_ca_ = unicode () .join ([unichr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	else:
		l1ll1l_ca_ = str () .join ([chr (ord (char) - l1lll1_ca_ - (l1l1l_ca_ + l1l11l_ca_) % l11ll_ca_) for l1l1l_ca_, char in enumerate (l1ll_ca_)])
	return eval (l1ll1l_ca_)
license = (
'''Copyright 2014, 2015, 2016 Jacques de Hooge, GEATEC engineering, www.geatec.com
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.'''
)
import re
import os
import sys
import errno
import keyword
import importlib
import random
import codecs
import shutil
l111l11l_ca_ = l1l11_ca_ (u"ࠧࡰࡲࡼࠫआ")
l1llllll1_ca_ = l1l11_ca_ (u"ࠨ࠳࠱࠵࠳࠸࠲ࠨइ")
if __name__ == l1l11_ca_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫई"):
	print (l1l11_ca_ (u"ࠪࡿࢂࠦࠨࡕࡏࠬࠤࡈࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡢ࡭ࡧࠣࡑࡺࡲࡴࡪࠢࡐࡳࡩࡻ࡬ࡦࠢࡓࡽࡹ࡮࡯࡯ࠢࡒࡦ࡫ࡻࡳࡤࡣࡷࡳࡷࠦࡖࡦࡴࡶ࡭ࡴࡴࠠࡼࡿࠪउ").format (l111l11l_ca_.capitalize (), l1llllll1_ca_))
	print (l1l11_ca_ (u"ࠫࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࠩࡅࠬࠤࡌ࡫ࡡࡵࡧࡦࠤࡊࡴࡧࡪࡰࡨࡩࡷ࡯࡮ࡨ࠰ࠣࡐ࡮ࡩࡥ࡯ࡵࡨ࠾ࠥࡇࡰࡢࡥ࡫ࡩࠥ࠸࠮࠱ࠢࡤࡸࠥࠦࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡵࡧࡣࡩࡧ࠱ࡳࡷ࡭࠯࡭࡫ࡦࡩࡳࡹࡥࡴ࠱ࡏࡍࡈࡋࡎࡔࡇ࠰࠶࠳࠶࡜࡯ࠩऊ"))
	random.seed ()
	l1ll11l1l_ca_ = sys.version_info [0] == 2
	l111ll1l_ca_ = 2048
	l1l11l_ca_ = l111ll1l_ca_
	l1l1l1lll_ca_ = 7
	l111l1ll_ca_ = os.path.sep
	def l1111lll_ca_ (l1l11111_ca_, open = False):
		print l1l11_ca_ (u"ࠬࡩࡲࡦࡣࡷࡩࡋ࡯࡬ࡦࡒࡤࡸ࡭ࠦࠥࡴࠩऋ")%l1l11111_ca_
		try:
			os.makedirs (l1l11111_ca_.rsplit (l111l1ll_ca_, 1) [0])
		except OSError as l1ll1ll1l_ca_:
			print l1l11_ca_ (u"࠭ࡅࡓࡔࡒࡖ࠿ࠦࡣࡳࡧࡤࡸࡪࡌࡩ࡭ࡧࡓࡥࡹ࡮ࠧऌ")
			if l1ll1ll1l_ca_.errno != errno.EEXIST:
				raise
		if open:
			return codecs.open (l1l11111_ca_, encoding = l1l11_ca_ (u"ࠧࡶࡶࡩ࠱࠽࠭ऍ"), mode = l1l11_ca_ (u"ࠨࡹࠪऎ"))
	def l11l1111_ca_ (l1l1l11l1_ca_, name):
		return l1l11_ca_ (u"ࠩࡾ࠴ࢂࢁ࠱ࡾࡽ࠵ࢁࠬए").format (
			l1l11_ca_ (u"ࠪࡣࡤ࠭ऐ") if name.startswith (l1l11_ca_ (u"ࠫࡤࡥࠧऑ")) else l1l11_ca_ (u"ࠬࡥࠧऒ") if name.startswith (l1l11_ca_ (u"࠭࡟ࠨओ")) else l1l11_ca_ (u"ࠧ࡭ࠩऔ"),
			bin (l1l1l11l1_ca_) [2:] .replace (l1l11_ca_ (u"ࠨ࠲ࠪक"), l1l11_ca_ (u"ࠩ࡯ࠫख")),
			l1l1lll1l_ca_
		)
	def l1ll111ll_ca_ (l1ll1l_ca_):
		global l1l11l_ca_
		if l1ll11l1l_ca_:
			l1ll_ca_ = unicode () .join ([unichr (l111ll1l_ca_ + ord (char) + (l1l1l_ca_ + l1l11l_ca_) % l1l1l1lll_ca_) for l1l1l_ca_, char in enumerate (l1ll1l_ca_)])
			l1l11llll_ca_ = unichr (l1l11l_ca_)
		else:
			l1ll_ca_ = str () .join ([chr (l111ll1l_ca_ + ord (char) + (l1l1l_ca_ + l1l11l_ca_) % l1l1l1lll_ca_) for l1l1l_ca_, char in enumerate (l1ll1l_ca_)])
			l1l11llll_ca_ = chr (l1l11l_ca_)
		l11_ca_ = l1l11l_ca_ % len (l1ll1l_ca_)
		l11l1_ca_ = l1ll_ca_ [:-l11_ca_] + l1ll_ca_ [-l11_ca_:]
		ll_ca_ = l11l1_ca_ + l1l11llll_ca_
		l1l11l_ca_ += 1
		return l1l11_ca_ (u"ࠪࡹࠧ࠭ग") + ll_ca_ + l1l11_ca_ (u"ࠫࠧ࠭घ")
	def l1l1ll1l_ca_ (l11l11l1_ca_):
		return l1l11_ca_ (u"ࠬ࠭ࠧࠎࠌ࡬ࡱࡵࡵࡲࡵࠢࡶࡽࡸࠓࠊࠎࠌ࡬ࡷࡕࡿࡴࡩࡱࡱ࠶ࢀ࠶ࡽࠡ࠿ࠣࡷࡾࡹ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࡠ࡫ࡱࡪࡴ࡛ࠦ࠱࡟ࠣࡁࡂࠦ࠲ࠎࠌࡦ࡬ࡦࡸࡂࡢࡵࡨࡿ࠵ࢃࠠ࠾ࠢࡾ࠵ࢂࠓࠊࡤࡪࡤࡶࡒࡵࡤࡶ࡮ࡸࡷࢀ࠶ࡽࠡ࠿ࠣࡿ࠷ࢃࠍࠋࠏࠍࡨࡪ࡬ࠠࡶࡰࡖࡧࡷࡧ࡭ࡣ࡮ࡨࡿ࠵ࢃࠠࠩ࡭ࡨࡽࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࠯࠺ࠎࠌࠌ࡫ࡱࡵࡢࡢ࡮ࠣࡷࡹࡸࡩ࡯ࡩࡑࡶࢀ࠶ࡽࠎࠌࠌࠑࠏࠏࡳࡵࡴ࡬ࡲ࡬ࡔࡲࠡ࠿ࠣࡳࡷࡪࠠࠩ࡭ࡨࡽࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࡛ࠦ࠮࠳ࡠ࠭ࠒࠐࠉࡳࡱࡷࡥࡹ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠠ࠾ࠢ࡮ࡩࡾ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠠ࡜࠼࠰࠵ࡢࠓࠊࠊࠏࠍࠍࡷࡵࡴࡢࡶ࡬ࡳࡳࡊࡩࡴࡶࡤࡲࡨ࡫ࠠ࠾ࠢࡶࡸࡷ࡯࡮ࡨࡐࡵࠤࠪࠦ࡬ࡦࡰࠣࠬࡷࡵࡴࡢࡶࡨࡨࡘࡺࡲࡪࡰࡪࡐ࡮ࡺࡥࡳࡣ࡯࠭ࠒࠐࠉࡳࡧࡦࡳࡩ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠠ࠾ࠢࡵࡳࡹࡧࡴࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢ࡞࠾ࡷࡵࡴࡢࡶ࡬ࡳࡳࡊࡩࡴࡶࡤࡲࡨ࡫࡝ࠡ࠭ࠣࡶࡴࡺࡡࡵࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣ࡟ࡷࡵࡴࡢࡶ࡬ࡳࡳࡊࡩࡴࡶࡤࡲࡨ࡫࠺࡞ࠏࠍࠍࠎࠓࠊࠊ࡫ࡩࠤ࡮ࡹࡐࡺࡶ࡫ࡳࡳ࠸ࡻ࠱ࡿ࠽ࠑࠏࠏࠉࡴࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠠ࠾ࠢࡸࡲ࡮ࡩ࡯ࡥࡧࠣࠬ࠮ࠦ࠮࡫ࡱ࡬ࡲࠥ࠮࡛ࡶࡰ࡬ࡧ࡭ࡸࠠࠩࡱࡵࡨࠥ࠮ࡣࡩࡣࡵ࠭ࠥ࠳ࠠࡤࡪࡤࡶࡇࡧࡳࡦࡽ࠳ࢁࠥ࠳ࠠࠩࡥ࡫ࡥࡷࡏ࡮ࡥࡧࡻࠤ࠰ࠦࡳࡵࡴ࡬ࡲ࡬ࡔࡲࠪࠢࠨࠤࡨ࡮ࡡࡳࡏࡲࡨࡺࡲࡵࡴࡽ࠳ࢁ࠮ࠦࡦࡰࡴࠣࡧ࡭ࡧࡲࡊࡰࡧࡩࡽ࠲ࠠࡤࡪࡤࡶࠥ࡯࡮ࠡࡧࡱࡹࡲ࡫ࡲࡢࡶࡨࠤ࠭ࡸࡥࡤࡱࡧࡩࡩ࡙ࡴࡳ࡫ࡱ࡫ࡑ࡯ࡴࡦࡴࡤࡰ࠮ࡣࠩࠎࠌࠌࡩࡱࡹࡥ࠻ࠏࠍࠍࠎࡹࡴࡳ࡫ࡱ࡫ࡑ࡯ࡴࡦࡴࡤࡰࠥࡃࠠࡴࡶࡵࠤ࠭࠯ࠠ࠯࡬ࡲ࡭ࡳࠦࠨ࡜ࡥ࡫ࡶࠥ࠮࡯ࡳࡦࠣࠬࡨ࡮ࡡࡳࠫࠣ࠱ࠥࡩࡨࡢࡴࡅࡥࡸ࡫ࡻ࠱ࡿࠣ࠱ࠥ࠮ࡣࡩࡣࡵࡍࡳࡪࡥࡹࠢ࠮ࠤࡸࡺࡲࡪࡰࡪࡒࡷ࠯ࠠࠦࠢࡦ࡬ࡦࡸࡍࡰࡦࡸࡰࡺࡹࡻ࠱ࡿࠬࠤ࡫ࡵࡲࠡࡥ࡫ࡥࡷࡏ࡮ࡥࡧࡻ࠰ࠥࡩࡨࡢࡴࠣ࡭ࡳࠦࡥ࡯ࡷࡰࡩࡷࡧࡴࡦࠢࠫࡶࡪࡩ࡯ࡥࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠬࡡ࠮ࠓࠊࠊࠋࠐࠎࠎࡸࡥࡵࡷࡵࡲࠥ࡫ࡶࡢ࡮ࠣࠬࡸࡺࡲࡪࡰࡪࡐ࡮ࡺࡥࡳࡣ࡯࠭ࠒࠐࠉࠨࠩࠪङ").format (l11ll11l_ca_, l111ll1l_ca_, l1l1l1lll_ca_)
	def l1ll1l11l_ca_ (l1ll1l1l1_ca_):
		print (l1l11_ca_ (u"ࡸࠧࠨࠩࠐࠎࠒࠐࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠏࠍࡿ࠵ࢃࠠࡸ࡫࡯ࡰࠥࡵࡢࡧࡷࡶࡧࡦࡺࡥࠡࡻࡲࡹࡷࠦࡥࡹࡶࡨࡲࡸ࡯ࡶࡦ࠮ࠣࡶࡪࡧ࡬ࠡࡹࡲࡶࡱࡪࠬࠡ࡯ࡸࡰࡹ࡯ࠠ࡮ࡱࡧࡹࡱ࡫ࠠࡑࡻࡷ࡬ࡴࡴࠠࡴࡱࡸࡶࡨ࡫ࠠࡤࡱࡧࡩࠥ࡬࡯ࡳࠢࡩࡶࡪ࡫ࠡࠎࠌࡄࡲࡩ࡙ࠦࡐࡗࠣࡧ࡭ࡵ࡯ࡴࡧࠣࡴࡪࡸࠠࡱࡴࡲ࡮ࡪࡩࡴࠡࡹ࡫ࡥࡹࠦࡴࡰࠢࡲࡦ࡫ࡻࡳࡤࡣࡷࡩࠥࡧ࡮ࡥࠢࡺ࡬ࡦࡺࠠ࡯ࡱࡷ࠰ࠥࡨࡹࠡࡧࡧ࡭ࡹࡺࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡤࡱࡱࡪ࡮࡭ࠠࡧ࡫࡯ࡩ࠳ࠓࠊࠎࠌࡅࡅࡈࡑࡕࡑࠢ࡜ࡓ࡚ࡘࠠࡄࡑࡇࡉࠥࡇࡎࡅ࡙ࠢࡅࡑ࡛ࡁࡃࡎࡈࠤࡉࡇࡔࡂࠢࡗࡓࠥࡇࡎࠡࡑࡉࡊ࠲ࡒࡉࡏࡇࠣࡑࡊࡊࡉࡖࡏࠣࡊࡎࡘࡓࡕࠢࡗࡓࠥࡖࡒࡆࡘࡈࡒ࡙ࠦࡁࡄࡅࡌࡈࡊࡔࡔࡂࡎࠣࡐࡔ࡙ࡓࠡࡑࡉࠤ࡜ࡕࡒࡌࠣࠤࠥࠒࠐࠍࠋࡖ࡫ࡩࡳࠦࡣࡰࡲࡼࠤࡹ࡮ࡥࠡࡦࡨࡪࡦࡻ࡬ࡵࠢࡦࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡵࡱࠣࡸ࡭࡫ࠠࡴࡱࡸࡶࡨ࡫ࠠࡵࡱࡳࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠠ࠽ࡶࡲࡴࡩ࡯ࡲ࠿ࠢࡤࡲࡩࠦࡲࡶࡰࠣࡿ࠵ࢃࠠࡧࡴࡲࡱࠥࡺࡨࡦࡴࡨ࠲ࠒࠐࡉࡵࠢࡺ࡭ࡱࡲࠠࡨࡧࡱࡩࡷࡧࡴࡦࠢࡤࡲࠥࡵࡢࡧࡷࡶࡧࡦࡺࡩࡰࡰࠣࡨ࡮ࡸࡥࡤࡶࡲࡶࡾࠦ࠼ࡵࡱࡳࡨ࡮ࡸ࠾࠰࠰࠱࠳ࡁࡺ࡯ࡱࡦ࡬ࡶࡃࡥࡻ࠲ࡿࠐࠎࠒࠐࡁࡵࠢࡩ࡭ࡷࡹࡴࠡࡵࡲࡱࡪࠦࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࡶࠤࡲࡧࡹࠡࡤࡨࠤࡴࡨࡦࡶࡵࡦࡥࡹ࡫ࡤࠡࡶ࡫ࡥࡹࠦࡳࡩࡱࡸࡰࡩࡴࠧࡵࠢࡥࡩ࠱ࠦࡥ࠯ࡩ࠱ࠤࡸࡵ࡭ࡦࠢࡲࡪࠥࡺࡨࡰࡵࡨࠤ࡮ࡳࡰࡰࡴࡷࡩࡩࠦࡦࡳࡱࡰࠤࡪࡾࡴࡦࡴࡱࡥࡱࠦ࡭ࡰࡦࡸࡰࡪࡹ࠮ࠊࠏࠍࡅࡩࡧࡰࡵࠢࡼࡳࡺࡸࠠࡤࡱࡱࡪ࡮࡭ࠠࡧ࡫࡯ࡩࠥࡺ࡯ࠡࡣࡹࡳ࡮ࡪࠠࡵࡪ࡬ࡷ࠱ࠦࡥ࠯ࡩ࠱ࠤࡧࡿࠠࡢࡦࡧ࡭ࡳ࡭ࠠࡦࡺࡷࡩࡷࡴࡡ࡭ࠢࡰࡳࡩࡻ࡬ࡦࠢࡱࡥࡲ࡫ࡳࠡࡶ࡫ࡥࡹࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡳࡧࡦࡹࡷࡹࡩࡷࡧ࡯ࡽࠥࡹࡣࡢࡰࡱࡩࡩࠦࡦࡰࡴࠣ࡭ࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࡳ࠯ࠏࠍ࡝ࡴࡻࠠ࡮ࡣࡼࠤࡦࡲࡳࡰࠢࡨࡼࡨࡲࡵࡥࡧࠣࡧࡪࡸࡴࡢ࡫ࡱࠤࡼࡵࡲࡥࡵࠣࡳࡷࠦࡦࡪ࡮ࡨࡷࠥ࡯࡮ࠡࡻࡲࡹࡷࠦࡰࡳࡱ࡭ࡩࡨࡺࠠࡧࡴࡲࡱࠥࡵࡢࡧࡷࡶࡧࡦࡺࡩࡰࡰࠣࡩࡽࡶ࡬ࡪࡥ࡬ࡸࡱࡿ࠮ࠎࠌࡖࡳࡺࡸࡣࡦࠢࡧ࡭ࡷ࡫ࡣࡵࡱࡵࡽ࠱ࠦ࡯ࡣࡨࡸࡷࡨࡧࡴࡪࡱࡱࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠠࡢࡰࡧࠤࡨࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡳࡥࡹ࡮ࠠࡤࡣࡱࠤࡦࡲࡳࡰࠢࡥࡩࠥࡹࡵࡱࡲ࡯࡭ࡪࡪࠠࡢࡵࠣࡧࡴࡳ࡭ࡢࡰࡧࠤࡱ࡯࡮ࡦࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡸࠦࡩ࡯ࠢࡷ࡬ࡦࡺࠠࡰࡴࡧࡩࡷ࠴ࠍࠋࡅࡲࡱࡲ࡫࡮ࡵࡵࠣࡥࡳࡪࠠࡴࡶࡵ࡭ࡳ࡭ࠠ࡭࡫ࡷࡩࡷࡧ࡬ࡴࠢࡦࡥࡳࠦࡢࡦࠢࡰࡥࡷࡱࡥࡥࠢࡤࡷࠥࡶ࡬ࡢ࡫ࡱ࠰ࠥࡨࡹࡱࡣࡶࡷ࡮ࡴࡧࠡࡱࡥࡪࡺࡹࡣࡢࡶ࡬ࡳࡳࠓࠊࠎࠌࡎࡲࡴࡽ࡮ࠡ࡮࡬ࡱ࡮ࡺࡡࡵ࡫ࡲࡲࡸࡀࠍࠋࡃࠣࡧࡴࡳ࡭ࡦࡰࡷࠤࡦ࡬ࡴࡦࡴࠣࡥࠥࡹࡴࡳ࡫ࡱ࡫ࠥࡲࡩࡵࡧࡵࡥࡱࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡳࡶࡪࡩࡥࡥࡧࡧࠤࡧࡿࠠࡸࡪ࡬ࡸࡪࡹࡰࡢࡥࡨࠑࠏࡇࠠࠨࠢࡲࡶࠥࠨࠠࡪࡰࡶ࡭ࡩ࡫ࠠࡢࠢࡶࡸࡷ࡯࡮ࡨࠢ࡯࡭ࡹ࡫ࡲࡢ࡮ࠣࡷ࡭ࡵࡵ࡭ࡦࠣࡦࡪࠦࡥࡴࡥࡤࡴࡪࡪࠠࡸ࡫ࡷ࡬ࠥࡢࠠࡳࡣࡷ࡬ࡪࡸࠠࡵࡪࡨࡲࠥࡪ࡯ࡶࡤ࡯ࡩࡩࠓࠊࡂࠢࡾ࠶ࢂࠦࡩ࡯ࠢࡤࠤࡸࡺࡲࡪࡰࡪࠤࡱ࡯ࡴࡦࡴࡤࡰࠥࡩࡡ࡯ࠢࡲࡲࡱࡿࠠࡣࡧࠣࡹࡸ࡫ࡤࠡࡣࡷࠤࡹ࡮ࡥࠡࡵࡷࡥࡷࡺࠬࠡࡵࡲࠤࡺࡹࡥࠡࠩࡳࠫࠬࢁ࠲ࡾࠩࠪࡶࠬࠦࡲࡢࡶ࡫ࡩࡷࠦࡴࡩࡣࡱࠤࠬࡶࡻ࠳ࡿࡵࠫࠒࠐࡏࡣࡨࡸࡷࡨࡧࡴࡪࡱࡱࠤࡴ࡬ࠠࡴࡶࡵ࡭ࡳ࡭ࠠ࡭࡫ࡷࡩࡷࡧ࡬ࡴࠢ࡬ࡷࠥࡻ࡮ࡴࡷ࡬ࡸࡦࡨ࡬ࡦࠢࡩࡳࡷࠦࡳࡦࡰࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴࠠࡴ࡫ࡱࡧࡪࠦࡩࡵࠢࡦࡥࡳࠦࡢࡦࠢࡷࡶ࡮ࡼࡩࡢ࡮࡯ࡽࠥࡨࡲࡰ࡭ࡨࡲࠒࠐࡎࡰࠢࡵࡩࡳࡧ࡭ࡪࡰࡪࠤࡧࡧࡣ࡬ࡦࡲࡳࡷࠦࡳࡶࡲࡳࡳࡷࡺࠠࡧࡱࡵࠤࡲ࡫ࡴࡩࡱࡧࡷࠥࡹࡴࡢࡴࡷ࡭ࡳ࡭ࠠࡸ࡫ࡷ࡬ࠥࡥ࡟ࠡࠪࡱࡳࡳ࠳࡯ࡷࡧࡵࡶ࡮ࡪࡡࡣ࡮ࡨࠤࡲ࡫ࡴࡩࡱࡧࡷ࠱ࠦࡡ࡭ࡵࡲࠤࡰࡴ࡯ࡸࡰࠣࡥࡸࠦࡰࡳ࡫ࡹࡥࡹ࡫ࠠ࡮ࡧࡷ࡬ࡴࡪࡳࠪࠏࠍࠑࠏࡒࡩࡤࡧࡱࡧࡪࡀࠍࠋࡽ࠶ࢁࠒࠐࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠏࠍࠍࠎ࠭ࠧࠨच").format (l111l11l_ca_.capitalize (), l111l11l_ca_, l1l11_ca_ (u"ࡲࠨࠥࠪछ"), license))
		exit (l1ll1l1l1_ca_)
	if len (sys.argv) > 1:
		if l1l11_ca_ (u"ࠨࡁࠪज") in sys.argv [1]:
			l1ll1l11l_ca_ (0)
		l1l11lll_ca_ = sys.argv [1]
	else:
		l1l11lll_ca_ = os.getcwd ()
	if len (sys.argv) > 2:
		l1l11ll11_ca_ = sys.argv [2]
	else:
		l1l11ll11_ca_ = l1l11_ca_ (u"ࠩࡾ࠴ࢂࡢ࡜ࡼ࠳ࢀࡣࢀ࠸ࡽࠨझ").format (* (l1l11lll_ca_.rsplit (l111l1ll_ca_, 1) + [l111l11l_ca_]))
	if len (sys.argv) > 3:
		l1l1ll111_ca_ = sys.argv [3]
	else:
		l1l1ll111_ca_ = l1l11_ca_ (u"ࠪࡿ࠵ࢃ࡜࡝ࡽ࠴ࢁࡤࡩ࡯࡯ࡨ࡬࡫࠳ࡺࡸࡵࠩञ").format (l1l11lll_ca_, l111l11l_ca_)
	obfuscate_strings = False
	obfuscated_name_tail = l1l11_ca_ (u"ࠫࡤࢁࡽࡠࠩट").format (l111l11l_ca_)
	plain_marker = l1l11_ca_ (u"ࠬࡥࡻࡾࡡࠪठ").format (l111l11l_ca_)
	source_extensions = l1l11_ca_ (u"࠭ࠧड")
	skip_extensions = l1l11_ca_ (u"ࠧࠨढ")
	external_modules = l1l11_ca_ (u"ࠨࠩण")
	plain_files = l1l11_ca_ (u"ࠩࠪत")
	plain_names = l1l11_ca_ (u"ࠪࠫथ")
	try:
		l1lll1l1l_ca_ = open (l1l1ll111_ca_)
	except Exception as l1ll1ll1l_ca_:
		print (l1ll1ll1l_ca_)
		l1ll1l11l_ca_ (1)
	exec (l1lll1l1l_ca_.read ())
	l1lll1l1l_ca_.close ()
	try:
		l1l11ll1_ca_ = obfuscate_strings
	except:
		l1l11ll1_ca_ = False
	try:
		l1lll111l_ca_ = l1ll1ll11_ca_
	except:
		l1lll111l_ca_ = False
	try:
		l1l1lll1l_ca_ = obfuscated_name_tail
	except:
		l1l1lll1l_ca_ = l1l11_ca_ (u"ࠫࠬद")
	try:
		l11ll11l_ca_ = plain_marker
	except:
		l11ll11l_ca_ = l1l11_ca_ (u"ࠬࡥࡻ࠱ࡿࡢࠫध").format (l111l11l_ca_)
	l111l1l1_ca_ = source_extensions.split ()
	l1l1l111l_ca_ = skip_extensions.split ()
	l1l11l11l_ca_ = external_modules.split ()
	l1lll1lll_ca_ = plain_files.split ()
	l1ll1111l_ca_ = plain_names.split ()
	l1l111ll_ca_ = [
		l1l11_ca_ (u"࠭ࡻ࠱ࡿ࡟ࡠࢀ࠷ࡽࠨन").format (l1l11l111_ca_.replace (l1l11_ca_ (u"ࠧ࡝࡞ࠪऩ"), l111l1ll_ca_), l11llll1_ca_)
		for l1l11l111_ca_, l1l11ll1l_ca_, l1l1ll1l1_ca_ in os.walk (l1l11lll_ca_)
		for l11llll1_ca_ in l1l1ll1l1_ca_
	]
	l1llll111_ca_ = re.compile (l1l11_ca_ (u"ࡳࠩࡡࡿ࠵ࢃࠡࠨप").format (l1l11_ca_ (u"ࡴࠪࠧࠬफ")))
	l1lll1111_ca_ = re.compile (l1l11_ca_ (u"ࠪࡧࡴࡪࡩ࡯ࡩ࡞࠾ࡂࡣ࡜ࡴࠬࠫ࡟࠲ࡢࡷ࠯࡟࠮࠭ࠬब"))
	l1l11l11_ca_ = re.compile (l1l11_ca_ (u"ࠫ࠳࠰ࡻ࠱ࡿ࠱࠮ࠬभ").format (l11ll11l_ca_), re.DOTALL)
	def l11111l1_ca_ (l1l1l1l11_ca_):
		comment = l1l1l1l11_ca_.group (0)
		if l1l11l11_ca_.search (comment):
			l1lllll11_ca_.append (comment.replace (l11ll11l_ca_, l1l11_ca_ (u"ࠬ࠭म")))
			return l1lll11ll_ca_
		else:
			return l1l11_ca_ (u"࠭ࠧय")
	def l11lll1l_ca_ (l1l1l1l11_ca_):
		global l11ll111_ca_
		l11ll111_ca_ += 1
		return l1lllll11_ca_ [l11ll111_ca_]
	l1l1l1111_ca_ = re.compile (l1l11_ca_ (u"ࡲࠨࡽ࠳ࢁࢀ࠷ࡽࡼ࠴ࢀ࠲࠯ࡅࠤࠨर").format (
		l1l11_ca_ (u"ࡳࠤࠫࡃࡁࠧࠧࠪࠤऱ"),
		l1l11_ca_ (u"ࡴࠪࠬࡄࡂࠡࠣࠫࠪल"),
		l1l11_ca_ (u"ࡵࠫࠨ࠭ळ")
	), re.MULTILINE)
	l1lll11ll_ca_ = l1l11_ca_ (u"ࠫࡤࢁ࠰ࡾࡡࡦࡣࠬऴ").format (l111l11l_ca_)
	l1ll111l1_ca_ = re.compile (l1l11_ca_ (u"ࡷ࠭ࡻ࠱ࡿࠪव").format (l1lll11ll_ca_))
	l1l11l1l_ca_ = re.compile (l1l11_ca_ (u"ࡸࠧ࠯ࠬࡾ࠴ࢂ࠴ࠪࠨश").format (l11ll11l_ca_))
	def l1l1l1ll1_ca_ (l1l1l1l11_ca_):
		string = l1l1l1l11_ca_.group (0)
		if l1l11ll1_ca_:
			if l1l11l1l_ca_.search (string):
				l11l1lll_ca_.append (string.replace (l11ll11l_ca_, l1l11_ca_ (u"ࠧࠨष")))
				return l1ll1l111_ca_
			else:
				l11l1lll_ca_.append (l1ll111ll_ca_ (string))
				return l1l11_ca_ (u"ࠨࡷࡱࡗࡨࡸࡡ࡮ࡤ࡯ࡩࢀ࠶ࡽࠡࠪࡾ࠵ࢂ࠯ࠧस").format (l11ll11l_ca_, l1ll1l111_ca_)
		else:
			l11l1lll_ca_.append (string)
			return l1ll1l111_ca_
	def l1llll11l_ca_ (l1l1l1l11_ca_):
		global l111llll_ca_
		l111llll_ca_ += 1
		return l11l1lll_ca_ [l111llll_ca_]
	l1l1l1l1l_ca_ = re.compile (l1l11_ca_ (u"ࡴࠪࠬࡠࡸࡵ࡞ࡾࡵࡹࢁࡻࡲࠪࡁࠫࠬࢀ࠶ࡽࠪࡾࠫࡿ࠶ࢃࠩࡽࠪࡾ࠶ࢂ࠯ࡼࠩࡽ࠶ࢁ࠮࠯ࠧह").format (
		l1l11_ca_ (u"ࡵࠦࠬ࠭ࠧ࠯ࠬࡂࠬࡄࡂࠡ࡜ࡠ࡟ࡠࡢࡢ࡜ࠪࠪࡂࡀࠦࡡ࡞࡝࡞ࡠࡠࠬ࠯ࠧࠨࠩࠥऺ"),
		l1l11_ca_ (u"ࡶࠬࠨࠢࠣ࠰࠭ࡃ࠭ࡅ࠼ࠢ࡝ࡡࡠࡡࡣ࡜࡝ࠫࠫࡃࡁ࡛ࠧ࡟࡞࡟ࡡࡡࠨࠩࠣࠤࠥࠫऻ"),
		l1l11_ca_ (u"ࡷࠨࠧ࠯ࠬࡂࠬࡄࡂࠡ࡜ࡠ࡟ࡠࡢࡢ࡜़ࠪࠩࠥ"),
		l1l11_ca_ (u"ࡸࠧࠣ࠰࠭ࡃ࠭ࡅ࠼ࠢ࡝ࡡࡠࡡࡣ࡜࡝ࠫࠥࠫऽ")
	), re.MULTILINE | re.DOTALL | re.VERBOSE)
	l1ll1l111_ca_ = l1l11_ca_ (u"ࠧࡠࡽ࠳ࢁࡤࡹ࡟ࠨा").format (l111l11l_ca_)
	l1lllllll_ca_ = re.compile (l1l11_ca_ (u"ࡳࠩࡾ࠴ࢂ࠭ि").format (l1ll1l111_ca_))
	def l1l1l1ll_ca_ (l1l1l1l11_ca_):
		l1ll11l11_ca_ = l1l1l1l11_ca_.group (0)
		if l1ll11l11_ca_:
			global l1llll1ll_ca_
			l1lll1ll1_ca_ [l1llll1ll_ca_:l1llll1ll_ca_] = [l1ll11l11_ca_]
			l1llll1ll_ca_ += 1
		return l1l11_ca_ (u"ࠩࠪी")
	l1ll11111_ca_ = re.compile (l1l11_ca_ (u"ࠪࡪࡷࡵ࡭࡝ࡵ࠭ࡣࡤ࡬ࡵࡵࡷࡵࡩࡤࡥ࡜ࡴࠬ࡬ࡱࡵࡵࡲࡵ࡞ࡶ࠮ࡡࡽࠫ࠯ࠬࠧࠫु"), re.MULTILINE)
	l11l1l1l_ca_ = re.compile (l1l11_ca_ (u"ࡶࠬ࠭ࠧࠎࠌࠌࠍࡡࡨࠉࠊࠋࠍࠍࠎ࠮࠿ࠢࡽ࠳ࢁ࠮ࠏࠉࠋࠋࠌࠬࡄࠧࡻ࠲ࡿࠬࠍࠎࠐࠉࠊ࡝ࡡࡠࡩࡢࡗ࡞ࠋࠌࠎࠎࠏ࡜ࡸࠬࠌࠍࠎࠐࠉࠊࠪࡂࡀࠦࡥ࡟ࠪࠋࠌࠎࠎࠏࠨࡀ࠾ࠤࡿ࠵ࢃࠩࠊࠌࠌࠍ࠭ࡅ࠼ࠢࡽ࠴ࢁ࠮ࠏࠊࠊࠋ࡟ࡦࠎࠏࠉࠋࠋࠪࠫࠬू").format (l1lll11ll_ca_, l1ll1l111_ca_), re.VERBOSE)
	l1ll1llll_ca_ = re.compile (l1l11_ca_ (u"ࡷ࠭࡜ࡣࡥ࡫ࡶࡡࡨࠧृ"))
	l1111111_ca_ = set (keyword.kwlist + [l1l11_ca_ (u"࠭࡟ࡠ࡫ࡱ࡭ࡹࡥ࡟ࠨॄ")] + l1ll1111l_ca_)
	l1l1ll1ll_ca_ = [l1l11_ca_ (u"ࠧࡼ࠲ࢀࡠࡡࢁ࠱ࡾࠩॅ").format (l1l11lll_ca_, l1111l1l_ca_) for l1111l1l_ca_ in l1lll1lll_ca_]
	for l11ll1ll_ca_ in l1l1ll1ll_ca_:
		l1l1lll11_ca_ = open (l11ll1ll_ca_)
		content = l1l1lll11_ca_.read ()
		l1l1lll11_ca_.close ()
		content = l1l1l1111_ca_.sub (l1l11_ca_ (u"ࠨࠩॆ"), content)
		content = l1l1l1l1l_ca_.sub (l1l11_ca_ (u"ࠩࠪे"), content)
		l1111111_ca_.update (re.findall (l11l1l1l_ca_, content))
	class l1ll1lll1_ca_:
		def __init__ (self):
			for l111ll11_ca_ in l1l11l11l_ca_:
				l11lllll_ca_ = l111ll11_ca_.replace (l1l11_ca_ (u"ࠪ࠲ࠬै"), l11ll11l_ca_)
				try:
					exec (
						l1l11_ca_ (u"ࠫࠬ࠭ࠍࠋ࡫ࡰࡴࡴࡸࡴࠡࡽ࠳ࢁࠥࡧࡳࠡࡥࡸࡶࡷ࡫࡮ࡵࡏࡲࡨࡺࡲࡥࠎࠌࠌࠍࠎࠏࠉࠊࠩࠪࠫॉ").format (l111ll11_ca_),
						globals ()
					)
					setattr (self, l11lllll_ca_, currentModule)
				except Exception as l1ll1ll1l_ca_:
					print (l1ll1ll1l_ca_)
					setattr (self, l11lllll_ca_, None)
					print (l1l11_ca_ (u"ࠬ࡝ࡡࡳࡰ࡬ࡲ࡬ࡀࠠࡤࡱࡸࡰࡩࠦ࡮ࡰࡶࠣ࡭ࡳࡹࡰࡦࡥࡷࠤࡪࡾࡴࡦࡴࡱࡥࡱࠦ࡭ࡰࡦࡸࡰࡪࠦࡻ࠱ࡿࠪॊ").format (l111ll11_ca_))
	l1l1111l_ca_ = l1ll1lll1_ca_ ()
	l111l111_ca_ = set ()
	def l111lll1_ca_ (l111111l_ca_):
		if l111111l_ca_ in l111l111_ca_:
			return
		else:
			l111l111_ca_.update ([l111111l_ca_])
		try:
			l1l1l11l_ca_ = list (l111111l_ca_.__dict__)
		except:
			l1l1l11l_ca_ = []
		try:
			if l1ll11l1l_ca_:
				l11l1ll1_ca_ = list (l111111l_ca_.func_code.co_varnames)
			else:
				l11l1ll1_ca_ = list (l111111l_ca_.__code__.co_varnames)
		except:
			l11l1ll1_ca_ = []
		l1lll11l1_ca_ = [getattr (l111111l_ca_, l11lllll_ca_) for l11lllll_ca_ in l1l1l11l_ca_]
		l1l1ll11l_ca_ = (l11ll11l_ca_.join (l1l1l11l_ca_)) .split (l11ll11l_ca_)
		l1l111lll_ca_ = set ([l1ll11l1_ca_ for l1ll11l1_ca_ in (l11l1ll1_ca_ + l1l1ll11l_ca_) if not (l1ll11l1_ca_.startswith (l1l11_ca_ (u"࠭࡟ࡠࠩो")) and l1ll11l1_ca_.endswith (l1l11_ca_ (u"ࠧࡠࡡࠪौ")))])
		l1111111_ca_.update (l1l111lll_ca_)
		for l1l1llll1_ca_ in l1lll11l1_ca_:
			try:
				l111lll1_ca_ (l1l1llll1_ca_)
			except:
				pass
	l111lll1_ca_ (__builtins__)
	l111lll1_ca_ (l1l1111l_ca_)
	l11lll11_ca_ = list (l1111111_ca_)
	l11lll11_ca_.sort (key = lambda s: s.lower ())
	l1llll1l1_ca_ = []
	l1ll1l1ll_ca_ = []
	for l1l11l1l1_ca_ in l1l111ll_ca_:
		if l1l11l1l1_ca_ == l1l1ll111_ca_:
			continue
		l1l111l1_ca_, l1ll11lll_ca_ = l1l11l1l1_ca_.rsplit (l111l1ll_ca_, 1)
		l1l11lll1_ca_, l1lllll1l_ca_ = (l1ll11lll_ca_.rsplit (l1l11_ca_ (u"ࠨ࠰्ࠪ"), 1) + [l1l11_ca_ (u"ࠩࠪॎ")]) [ : 2]
		l1111l11_ca_ =  l1l11l1l1_ca_ [len (l1l11lll_ca_) : ]
		if l1lllll1l_ca_ in l111l1l1_ca_ and not l1l11l1l1_ca_ in l1l1ll1ll_ca_:
			l11l11l1_ca_ = random.randrange (64)
			l11ll1l1_ca_ = codecs.open (l1l11l1l1_ca_, encoding = l1l11_ca_ (u"ࠪࡹࡹ࡬࠭࠹ࠩॏ"))
			content = l11ll1l1_ca_.read ()
			l11ll1l1_ca_.close ()
			l1lllll11_ca_ = []
			l1lll1ll1_ca_ = content.split (l1l11_ca_ (u"ࠫࡡࡴࠧॐ"), 2)
			l1llll1ll_ca_ = 0
			l1lll1l11_ca_ = True
			if len (l1lll1ll1_ca_) > 0:
				if l1llll111_ca_.search (l1lll1ll1_ca_ [0]):
					l1llll1ll_ca_ += 1
					if len (l1lll1ll1_ca_) > 1 and l1lll1111_ca_.search (l1lll1ll1_ca_ [1]):
						l1llll1ll_ca_ += 1
						l1lll1l11_ca_ = False
				elif l1lll1111_ca_.search (l1lll1ll1_ca_ [0]):
					l1llll1ll_ca_ += 1
					l1lll1l11_ca_ = False
			if l1l11ll1_ca_ and l1lll1l11_ca_:
				l1lll1ll1_ca_ [l1llll1ll_ca_:l1llll1ll_ca_] = [l1l11_ca_ (u"ࠬࠩࠠࡤࡱࡧ࡭ࡳ࡭࠺ࠡࡗࡗࡊ࠲࠾ࠧ॑")]
				l1llll1ll_ca_ += 1
			if l1l11ll1_ca_:
				l1l1ll11_ca_ = l1l11_ca_ (u"࠭࡜࡯॒ࠩ").join ([l1l1ll1l_ca_ (l11l11l1_ca_)] + l1lll1ll1_ca_ [l1llll1ll_ca_:])
			else:
				l1l1ll11_ca_ = l1l11_ca_ (u"ࠧ࡝ࡰࠪ॓").join (l1lll1ll1_ca_ [l1llll1ll_ca_:])
			l1l1ll11_ca_ = l1l1l1111_ca_.sub (l11111l1_ca_, l1l1ll11_ca_)
			l11l1lll_ca_ = []
			l1l1ll11_ca_ = l1l1l1l1l_ca_.sub (l1l1l1ll1_ca_, l1l1ll11_ca_)
			l1l1ll11_ca_ = l1ll11111_ca_.sub (l1l1l1ll_ca_, l1l1ll11_ca_)
			l1l1l111_ca_ = set (re.findall (l11l1l1l_ca_, l1l1ll11_ca_) + [l1l11lll1_ca_])
			l11l11ll_ca_ = l1l1l111_ca_.difference (l1llll1l1_ca_).difference (l1111111_ca_)
			l11l111l_ca_ = list (l11l11ll_ca_)
			l1l11l1ll_ca_ = [re.compile (l1l11_ca_ (u"ࡳࠩ࡟ࡦࢀ࠶ࡽ࡝ࡤࠪ॔").format (l11l1l11_ca_)) for l11l1l11_ca_ in l11l111l_ca_]
			l1llll1l1_ca_ += l11l111l_ca_
			l1ll1l1ll_ca_ += l1l11l1ll_ca_
			for l1l1l11l1_ca_, l1l1l11ll_ca_ in enumerate (l1ll1l1ll_ca_):
				l1l1ll11_ca_ = l1l1l11ll_ca_.sub (
					l11l1111_ca_ (l1l1l11l1_ca_, l1llll1l1_ca_ [l1l1l11l1_ca_]),
					l1l1ll11_ca_
				)
			l111llll_ca_ = -1
			l1l1ll11_ca_ = l1lllllll_ca_.sub (l1llll11l_ca_, l1l1ll11_ca_)
			l11ll111_ca_ = -1
			l1l1ll11_ca_ = l1ll111l1_ca_.sub (l11lll1l_ca_, l1l1ll11_ca_)
			content = l1l11_ca_ (u"ࠩ࡟ࡲࠬॕ").join (l1lll1ll1_ca_ [:l1llll1ll_ca_] + [l1l1ll11_ca_])
			content = l1l11_ca_ (u"ࠪࡠࡳ࠭ॖ").join ([line for line in [line.rstrip () for line in content.split (l1l11_ca_ (u"ࠫࡡࡴࠧॗ"))] if line])
			try:
				l1ll11ll1_ca_ = l11l1111_ca_ (l1llll1l1_ca_.index (l1l11lll1_ca_), l1l11lll1_ca_)
			except:
				l1ll11ll1_ca_ = l1l11lll1_ca_
			l1111ll1_ca_ = l1111l11_ca_.split (l111l1ll_ca_)
			for index in range (len (l1111ll1_ca_)):
				try:
					l1111ll1_ca_ [index] = l11l1111_ca_ (l1llll1l1_ca_.index (l1111ll1_ca_ [index]), l1111ll1_ca_ [index])
				except:
					pass
			l1111l11_ca_ = l111l1ll_ca_.join (l1111ll1_ca_)
			l1l1l1l1_ca_ = l1l11_ca_ (u"ࠬࢁ࠰ࡾࡽ࠴ࢁࠬक़").format (l1l11ll11_ca_, l1111l11_ca_) .rsplit (l111l1ll_ca_, 1) [0]
			l11111ll_ca_ = l1111lll_ca_ (l1l11_ca_ (u"࠭ࡻ࠱ࡿ࡟ࡠࢀ࠷ࡽ࠯ࡽ࠵ࢁࠬख़").format (l1l1l1l1_ca_, l1ll11ll1_ca_, l1lllll1l_ca_), open = True)
			l11111ll_ca_.write (content)
			l11111ll_ca_.close ()
		elif not l1lllll1l_ca_ in l1l1l111l_ca_:
			l1l1l1l1_ca_ = l1l11_ca_ (u"ࠧࡼ࠲ࢀࡿ࠶ࢃࠧग़").format (l1l11ll11_ca_, l1111l11_ca_) .rsplit (l111l1ll_ca_, 1) [0]
			l1l1lllll_ca_ = l1l11_ca_ (u"ࠨࡽ࠳ࢁࡡࡢࡻ࠲ࡿࠪज़").format (l1l1l1l1_ca_, l1ll11lll_ca_)
			l1111lll_ca_ (l1l1lllll_ca_)
			shutil.copyfile (l1l11l1l1_ca_, l1l1lllll_ca_)
	print (l1l11_ca_ (u"ࠩࡒࡦ࡫ࡻࡳࡤࡣࡷࡩࡩࠦࡷࡰࡴࡧࡷ࠿ࠦࡻ࠱ࡿࠪड़").format (len (l1llll1l1_ca_)))