# -*- coding: utf-8 -*-

import sys,os,re
import urllib,urllib2
import urlparse
import check

BASEURL='http://ekino-tv.pl'
#http://nasze-kino.eu/film/mission-impossible-rogue-nation-mission-impossible-5-2015-lektor-pl/3476


def unicodePLchar(txt):
    txt = txt.replace('#038;','')
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt
    
def getUrl(url,post_data=None):
    if post_data:
        dataPost = urllib.urlencode(post_data)
        req = urllib2.Request(url,dataPost)
    else:
        req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20100101 Firefox/22.0')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link
    

def skanuj_filmy(kat='',wer='', page='1', url='http://ekino-tv.pl/movie/cat/kategoria[35]+'):
    if kat or wer:
        my_url = 'http://ekino-tv.pl/movie/cat/kategoria[%s]+wersja[%s]+strona[%s]+' %(kat,wer,page)
    else:
        my_url = url
    print '#'*10
    print my_url
    content  = getUrl(my_url)
    return _getData(content)

def _getData(content):

    ids = [(a.start(), a.end()) for a in re.finditer('<div class="movies-list-item"', content)]
    ids.append( (-1,-1) )
    res=[]
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ]
        
        img = re.compile('<img src="(/static/thumb/.*.jpg)" alt=').findall(subset)
        title = re.compile('<div class="title">[\s]*<a href="(.*?)">(.*?)</a><br>').findall(subset)
        des = re.compile('<div class="movieDesc">[\s\n]*(.*?)</div>').findall(subset)
        rating = re.compile('<div class="sum-vote"><[^>]*>([^>]*)</div>').findall(subset)
        rok = re.compile('<p class="cates">(.*) \|').findall(subset)
        categorie = re.compile('<p class="cates">(.*) \| (<a href="/movie/cat/kategoria\[\d+\]">.*</a>[,]*)*</p>').findall(subset)
        info_cat = re.compile('<div class="info-categories"(.*?)</div>',re.DOTALL).findall(subset)
        if info_cat:
            info_cat = ''.join(re.compile('>(.*?)<').findall(info_cat[0]))
            
        if title:
            out={}
            #cat = dict(zip(range(len(_Links)),_Links))
            out['href'] = title[0][0]
            if info_cat: out['href']+= ' (%s)'%info_cat
            out['title'] = unicodePLchar(title[0][1].strip('\n '))
            out['year'] = rok[0] if rok else ''
            out['genre'] = ''.join(re.compile('>(.*?)<').findall(categorie[0][1])) if categorie else ''
            out['code'] = 'HD' if 'HD' in out['genre'] else ''
            out['plot'] = unicodePLchar(des[0].strip('\n ')) if des else ''
            out['rating'] = rating[0].strip() if rating else ''
            out['img'] = BASEURL+img[0].replace('/thumb/','/normal/') if img else ''
            res.append(out)
    return res

    

# url='/movie/show/piraci-z-karaiboacutew-na-nieznanych-wodach-pirates-of-the-caribbean-on-stranger-tides-2011-lektor/3132'
# url='/movie/show/igrzyska-smierci-kosoglos-czesc-2-lektor-pl-the-hunger-games-mockingjay-part-2-2015-lektor/13000'
# url='/serie/watch/nie-z-tego-swiata+season[11]+episode[23]+'
url='/movie/show/dom-klownow-clownhouse-1989-lektor/17629'
def get_sources(url='/movie/show/partyzant-napisy-pl-partisan-2015-napisy/7909'):
    content  = getUrl(BASEURL+url)
    iframes = re.compile('ShowPlayer\(\'(.*?)\',\'.*?\'\)').findall(content)
    _Lables=[]
    _Links=[]
    #one=iframes[0]
    for one in iframes:
        print one
        if 'hosting=vshare' in one:
            one='http://vshare.io/v/%s/width-640/height-400/'  % (one.split('=')[-1])
        if one.startswith('http'):
            _Links.append(one)
            _Lables.append(one.split('/')[2])
    return (_Lables,_Links)



def _old_get_sources(url='/movie/show/partyzant-napisy-pl-partisan-2015-napisy/7909'):
    content  = getUrl(BASEURL+url)
    iframes = re.compile('<iframe(.*)></iframe>\n', re.DOTALL).findall(content)
    _Lables=[]
    _Links=[]
    for f in iframes:
        links = re.compile('src="(.*?)"', re.DOTALL).findall(content)
        for one in links:
            if 'hosting=vshare' in one:
                one='http://vshare.io/v/%s/width-640/height-400/'  % (one.split('=')[-1])
            # if 'openload.co/embed' in one:
            #     content=getUrl(one)
            #     kod = re.compile('var suburl = "(.*?)"', re.DOTALL).findall(content)
            #     one = one.replace('/embed/','/stream/')+'~'+kod[0].split('/')[-1][:-1]+'?mime=true'
            #     print one
            if one.startswith('http'):
                _Links.append(one)
                _Lables.append(one.split('/')[2])
    return (_Lables,_Links)
       
def getCategories(url='http://ekino-tv.pl/movie/cat/'):
    content  = getUrl(url)   
    cats = re.compile('<li data-id="(\d+)">[\s\n]+<a href="/movie/cat/kategoria\[\d+\]">(.*?)</a>[\s\n]*</li>').findall(content)
    number = [x[0] for x in cats]
    opis = [x[1] for x in cats]
    return (opis,number)
    
def szukaj(what='Piraci'):
    postdata = {'search_field': what}
    content = getUrl('http://ekino-tv.pl/search/', postdata)
    return _getData(content)


def scanTVshows(url='/serie/catalog/W'):
    content  = getUrl(BASEURL+url)
    out = _getData(content)
    return out


def serieCatalog():
    content  = getUrl('http://ekino-tv.pl/serie/')  
    serialsmenu = re.compile('<ul class="serialsmenu">(.*?)</ul>',re.DOTALL).findall(content)
    out=[] 
    if serialsmenu:
        items = re.compile('<a href="(.*?)"><span class="name">(.*?)</span><span class="count">(.*?)</span></a>').findall(serialsmenu[0])
        for item in items:
            out.append({'href':item[0],'title':'%s ([COLOR blue]%s[/COLOR])'%(item[1],item[2])})
    return out
            


            
#url = 'http://ekino-tv.pl/serie/show/zagubieni-lost/'
def scanEpisodes(url):
    content = getUrl(BASEURL+url)
    seasons = re.compile('<ul class="list-series">(.*?)</ul>',re.DOTALL).findall(content)
    out=[]    
    for season in seasons:
        #season = seasons[0]
        episodes = re.compile('<a href="(.*?)">(.*?)</a>').findall(season)
        for e in episodes:
            #e = episodes[0]
            href = e[0]
            title = e[1]
            sN = re.compile('season\[(\d+)\]').findall(href)
            sN = int(sN[0]) if sN else ''
            eN = re.compile('episode\[(\d+)\]').findall(href)
            eN = int(eN[0]) if eN else ''
            one = { 'href'  : href,
                    'season' : sN,
                    'episode' : eN,
                    'mediatype': 'episode',
                    'title' : 'S%02dE%02d %s'%(sN,eN, unicodePLchar(title.strip()))}
            out.append(one)
    return out

# cat=getCategories()
# s=szukaj('dom')
#s=szukaj('Piraci z Karaibów')
# len(s)
#f=skanuj_filmy(kat='35',wer='',url='')
# (_Lables,_Links)=get_sources(f[0]['href'])

