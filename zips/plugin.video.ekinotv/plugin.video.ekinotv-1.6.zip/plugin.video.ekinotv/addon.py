# -*- coding: utf-8 -*-
import sys,os,re
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver

import ekino as EK

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()


def addDir(name,mode='',kat='',wer='',page='1',ex_link=None,infoLabels=None,iconImage='DefaultFolder.png'):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link,'kat' : kat,'wer' : wer,'page' : page})
    li = xbmcgui.ListItem(name)
    art_keys=['thumb','poster','banner','clearart','clearlogo','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    li.setArt(art)
    
    if not infoLabels:
        infoLabels={"Title": name}
    li.setInfo(type="Video", infoLabels=infoLabels)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def ChooseAndPlay(ex_link):
    (_Lables,_Links)=EK.get_sources(ex_link)
    if _Lables:
        dialog = xbmcgui.Dialog()
        ret = dialog.select('Wybierz źródło', _Lables)
        if ret>-1:
            try:
                media_url = urlresolver.resolve(_Links[ret])
            except Exception,e:
                media_url=''
                s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działał?','UTRresolver ERROR: [%s]'%str(e))

            print media_url
            if media_url:
                xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=media_url))
            else:
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
    else:
        xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Brak linków?')   
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def addLinkItem(name, url, mode, iconimage='DefaultFolder.png', infoLabels={}, IsPlayable=True, fanart=None, kat='',wer='',page='1'):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url,'kat' : kat,'wer' : wer,'page' : page})


    liz = xbmcgui.ListItem(name)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    liz.setArt(art)
    
    if not infoLabels:
        infoLabels={"Title": name}
    liz.setInfo(type="Video", infoLabels=infoLabels)
    liz.setLabel2(infoLabels.get('code',''))
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    contextMenuItems = []
    contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)     
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R,%Y,%P")
    return ok

def addFilmLinks(kat,wer,page,ex_link):
    pozycje= EK.skanuj_filmy(kat=kat,wer=wer, page=page,url=ex_link)
    if int(page)>1:
        addLinkItem('[COLOR gold]<< Poprzednia Strona %d <<[/COLOR]' %(int(page)-1), url=ex_link , mode='__page__', kat=kat,wer=wer,page= int(page)-1, IsPlayable=False)
    for p in pozycje:
        addLinkItem(name=p['title'],url=p['href'],mode='ChooseAndPlay',iconimage=p['img'],infoLabels=p,fanart=p['img'])
    
    addLinkItem('[COLOR gold]>> Nastepna Strona %d >>[/COLOR]' %(int(page)+1), url=ex_link , mode='__page__', kat=kat,wer=wer,page= int(page)+1, IsPlayable=False)

    # xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_GENRE )

def testPlay(ex_link):
    if 'openload.co/stream' in ex_link:
        media_url=ex_link
    else:
        media_url = urlresolver.resolve(ex_link)

    print '==testPlay'
    print media_url
    if media_url:
        listitem = xbmcgui.ListItem(path=media_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
    
 
 
xbmcplugin.setContent(addon_handle, 'movies')	

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
kat = args.get('kat',[''])[0]
wer = args.get('wer',[''])[0]
page = args.get('page',[''])[0]

def get_WERSJE():
    _WERSJE=['Napisy','Lektor','Dubbing','ENG','PL']
    WERSJE=''
    for w in _WERSJE:
        if my_addon.getSetting(w)=='true':
            if WERSJE:
                WERSJE += ','
            WERSJE += w
    return WERSJE

WERSJE  = get_WERSJE()


if mode is None:
    addDir('[COLOR blue]Filmy[/COLOR]',mode='filmy',kat='',wer=WERSJE)
    addDir('Filmy HD',mode='filmy',kat='35',wer=WERSJE)
    addDir('Filmy 3D',mode='filmy',kat='36',wer=WERSJE)
    addDir('Filmy Dla Dzieci HD',mode='filmy',kat='2,3,5,6',wer=WERSJE)
    addDir('Filmy [Kategoria]',mode='filmy_kategoria',kat='',wer=WERSJE)
    addDir('[COLOR blue]Seriale Katalog[/COLOR]',mode='seriale_ktalog')
   
    addDir('[COLOR green]Szukaj[/COLOR]',mode='szukaj')
    url = build_url({'mode': 'Opcje'})
    li = xbmcgui.ListItem(label = '-=Opcje=-', iconImage='DefaultScript.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li)

elif mode[0] == '__page__':
    url = build_url({'mode': 'filmy', 'foldername': '', 'ex_link' : ex_link,'kat' : kat,'wer' : wer,'page' : page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'testPlay':
    testPlay(ex_link) 
     
elif mode[0] == 'ChooseAndPlay':
    print ex_link
    ChooseAndPlay(ex_link)
    
elif mode[0] == 'Opcje':
    my_addon.openSettings()
    url = build_url({'mode': '', 'foldername': '', 'ex_link' : '', 'page': 1})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0]=='filmy':
    addFilmLinks(kat,wer,page,ex_link)

elif mode[0]=='filmy_kategoria':
    data = EK.getCategories()
    ret = xbmcgui.Dialog().select('Wybierz:', data[0])
    if ret>-1:
        addFilmLinks(data[1][ret],wer,page,ex_link) 

elif mode[0]=='szukaj':
    dialog = xbmcgui.Dialog()
    d = dialog.input('Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
    pozycje = EK.szukaj(d.replace(' ','%20'))
    print len(pozycje)
    for p in pozycje:
        addLinkItem(p['title'],p['href'],'ChooseAndPlay',p['img'],p)

elif mode[0]=='seriale_ktalog':
    pozycje = EK.serieCatalog()
    for p in pozycje:
        addDir(p.get('title'),ex_link=p.get('href'),mode='seriale')

elif mode[0]=='seriale':
    pozycje = EK.scanTVshows(ex_link)
    for p in pozycje:
        addDir(p.get('title'),ex_link=p.get('href'),mode='epizody',infoLabels=p,iconImage=p.get('img'))

elif mode[0]=='epizody':
    pozycje = EK.scanEpisodes(ex_link)
    print len(pozycje)
    for p in pozycje:
        addLinkItem(p['title'],p['href'],'ChooseAndPlay',p.get('img'),p)
         

xbmcplugin.endOfDirectory(addon_handle)