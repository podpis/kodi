# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import re,os
import xbmc,xbmcaddon,xbmcgui
import l1lll11ll1ll1_r_ as l1l1lllll1ll1_r_
import l11llll11ll1_r_ as l11ll1l11ll1_r_
import l11lll1l1ll1_r_
import l1ll1lll11ll1_r_ as l1ll11l1l1ll1_r_
go={}
def l1ll1l11l1ll1_r_(msg=l1ll1l11ll1_r_ (u"ࠧࠨࣕ")):
    if True:
       l11ll1l11ll1_r_.l1lll1l1l1ll1_r_(l1ll1l11ll1_r_ (u"ࠨ࡝ࠨࡷࡢࡀࠠࠦࡵࠪࣖ")%(l11ll1l11ll1_r_.l1llll1111ll1_r_,msg))
def l1ll1l1ll1ll1_r_():
    tm=l1ll11l1l1ll1_r_.l1ll11ll11ll1_r_()
    l1ll11l111ll1_r_,l1ll1111l1ll1_r_,l1l1ll1ll1ll1_r_ = (tm.tm_yday,tm.tm_mday,tm.tm_mon)
    try:    l1ll11lll1ll1_r_,l1ll1ll1l1ll1_r_,l1ll111l11ll1_r_ = l11lll1l1ll1_r_.l1l1ll1l1ll1_r_(l11ll1l11ll1_r_.l1llll11l1ll1_r_(l1ll1l11ll1_r_ (u"ࠩࡦࡳࡩ࠭ࣗ"))).split(l1ll1l11ll1_r_ (u"ࠪ࠾ࠬࣘ"))
    except: l1ll11lll1ll1_r_,l1ll1ll1l1ll1_r_,l1ll111l11ll1_r_ =  [l1ll1l11ll1_r_ (u"ࠫ࠲࠷࠰࠱ࠩࣙ"),l1ll1l11ll1_r_ (u"ࠬ࠳࠱࠱ࠩࣚ"),l1ll1l11ll1_r_ (u"࠭࠭࠲࠲ࠪࣛ")]
    if int(l1ll11lll1ll1_r_) != int(l1ll11l111ll1_r_):
        l1ll1ll111ll1_r_ = l1ll1l11ll1_r_ (u"ࠨࠧࡧ࠾ࠪࡪ࠺ࠦࡦࠪࣝ")%(l1ll11l111ll1_r_,l1ll1111l1ll1_r_,l1l1ll1ll1ll1_r_)
        l11ll1l11ll1_r_.l1l11ll11ll1_r_(l1ll1l11ll1_r_ (u"ࠩࡦࡳࡩ࠭ࣞ"),l11lll1l1ll1_r_.l1l1111l1ll1_r_(l1ll1ll111ll1_r_))
def l1l1lll111ll1_r_():
    l1ll111ll1ll1_r_ = l11ll1l11ll1_r_.l1ll11111ll1_r_(l11ll1l11ll1_r_.l1lll1l111ll1_r_).decode(l1ll1l11ll1_r_ (u"ࠪࡹࡹ࡬࠭࠹ࠩࣟ"))
    l1lll11111ll1_r_ = []

l11ll1l11ll1_r_.l111ll1l1ll1_r_(target = l1l1lll111ll1_r_).start()
l1ll1l1ll1ll1_r_()
go[l1ll1l11ll1_r_ (u"࠭ࡤࡦࡤࡸ࡫ࠬ࣢")] = l1l1lllll1ll1_r_.l1lll11ll1ll1_r_
go[l1ll1l11ll1_r_ (u"ࠧ࡮ࡻࡧࡩࡧࡻࡧࠨࣣ")] = l1l1lllll1ll1_r_.notify
go[l1ll1l11ll1_r_ (u"ࠨࡥ࡫ࡩࡨࡱ࡟ࡳࡧࡳࡳࡤࡧࡣࡤࡧࡶࡷࠬࣤ")] = l11lll1l1ll1_r_.l1l1l1ll1ll1_r_
go[l1ll1l11ll1_r_ (u"ࠩࡦ࡬ࡪࡩ࡫ࡠࡴࡶࡷࡤ࡬ࡥࡦࡦࡶࠫࣥ")] = l11lll1l1ll1_r_.l1l11l1l1ll1_r_
go[l1ll1l11ll1_r_ (u"ࠪࡶࡪࡶ࡯ࡻࡻࡷࡳࡷࡿ࡟ࡤࡪࡨࡧࡰࣦ࠭")] = l1ll1l1ll1ll1_r_
go[l1ll1l11ll1_r_ (u"ࠫࡩ࡫ࡣࡰࡦࡨࡌ࡙ࡓࡌࡦࡰࡷࡶ࡮࡫ࡳࠨࣧ")] = l1ll11l1l1ll1_r_.l1ll1l1l11ll1_r_
go[l1ll1l11ll1_r_ (u"ࠬࡨࡵࡪ࡮ࡧࡧ࡭࡫ࡣ࡬ࠩࣨ")] = l1ll11l1l1ll1_r_.l1ll111111ll1_r_
go[l1ll1l11ll1_r_ (u"࠭ࡡࡥࡦࡲࡲࡤࡩ࡬ࡦࡣࡱࣩࠫ")] = l1l1lll111ll1_r_
