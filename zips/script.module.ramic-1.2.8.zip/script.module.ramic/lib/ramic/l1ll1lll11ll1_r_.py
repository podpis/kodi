# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import re
import sys
import time
l1ll1l1111ll1_r_ = sys.exit
l1ll11ll11ll1_r_ = time.gmtime
def l1ll111111ll1_r_():
    import l11111111ll1_r_
    return True
def l1ll1l1l11ll1_r_(l1l1ll1l11ll1_r_):
    if type(l1l1ll1l11ll1_r_) is not str:
        l1l1ll1l11ll1_r_=l1l1ll1l11ll1_r_.encode(l1ll1l11ll1_r_ (u"ࠧࡶࡶࡩ࠱࠽࠭࣪"))
    s=l1ll1l11ll1_r_ (u"ࠨࡌ࡬ࡒࡨࡠࡃࡴ࠹ࠪ࣫")
    l1l1ll1l11ll1_r_ = re.sub(s.decode(l1ll1l11ll1_r_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩ࣬")),l1ll1l11ll1_r_ (u"࣭ࠪࠫ"),l1l1ll1l11ll1_r_)
    l1l1ll1l11ll1_r_ = re.sub(l1ll1l11ll1_r_ (u"ࠫࡁࡨࡲ࡝ࡵ࠭࠳ࡃ࣮࠭"),l1ll1l11ll1_r_ (u"ࠬࡢ࡮ࠨ࣯"),l1l1ll1l11ll1_r_)
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"࠭ࠦ࡯ࡤࡶࡴࡀࣰ࠭"),l1ll1l11ll1_r_ (u"ࠧࠨࣱ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠨࠨ࡯ࡸࡀࡨࡲ࠰ࠨࡪࡸࡀࣲ࠭"),l1ll1l11ll1_r_ (u"ࠩࠣࠫࣳ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠪࠪࡳࡪࡡࡴࡪ࠾ࠫࣴ"),l1ll1l11ll1_r_ (u"ࠫ࠲࠭ࣵ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࣶࠬ"),l1ll1l11ll1_r_ (u"࠭ࠢࠨࣷ")).replace(l1ll1l11ll1_r_ (u"ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫࣸ"),l1ll1l11ll1_r_ (u"ࠨࠤࣹࠪ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࣺࠫ"),l1ll1l11ll1_r_ (u"ࠪࣷࠬࣻ")).replace(l1ll1l11ll1_r_ (u"ࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭ࣼ"),l1ll1l11ll1_r_ (u"ࠬࣙࠧࣽ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬࣾ"),l1ll1l11ll1_r_ (u"ࠧࣴࠩࣿ")).replace(l1ll1l11ll1_r_ (u"ࠨࠨࡤࡱࡵࡁࡏࡢࡥࡸࡸࡪࡁࠧऀ"),l1ll1l11ll1_r_ (u"ࠩࣖࠫँ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠪࠪࡦࡳࡰ࠼ࠩं"),l1ll1l11ll1_r_ (u"ࠫࠫ࠭ः"))
    l1l1ll1l11ll1_r_ = re.sub(l1ll1l11ll1_r_ (u"ࠬࠬ࠮ࠬ࠽ࠪऄ"),l1ll1l11ll1_r_ (u"࠭ࠧअ"),l1l1ll1l11ll1_r_)
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠧ࡝ࡷ࠳࠵࠵࠻ࠧआ"),l1ll1l11ll1_r_ (u"ࠨइࠪइ")).replace(l1ll1l11ll1_r_ (u"ࠩ࡟ࡹ࠵࠷࠰࠵ࠩई"),l1ll1l11ll1_r_ (u"ࠪईࠬउ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠫࡡࡻ࠰࠲࠲࠺ࠫऊ"),l1ll1l11ll1_r_ (u"ࠬऍࠧऋ")).replace(l1ll1l11ll1_r_ (u"࠭࡜ࡶ࠲࠴࠴࠻࠭ऌ"),l1ll1l11ll1_r_ (u"ࠧइࠩऍ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠨ࡞ࡸ࠴࠶࠷࠹ࠨऎ"),l1ll1l11ll1_r_ (u"ࠩजࠫए")).replace(l1ll1l11ll1_r_ (u"ࠪࡠࡺ࠶࠱࠲࠺ࠪऐ"),l1ll1l11ll1_r_ (u"ࠫझ࠭ऑ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠬࡢࡵ࠱࠳࠷࠶ࠬऒ"),l1ll1l11ll1_r_ (u"࠭ूࠨओ")).replace(l1ll1l11ll1_r_ (u"ࠧ࡝ࡷ࠳࠵࠹࠷ࠧऔ"),l1ll1l11ll1_r_ (u"ࠨृࠪक"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩख"),l1ll1l11ll1_r_ (u"ࠪैࠬग")).replace(l1ll1l11ll1_r_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫघ"),l1ll1l11ll1_r_ (u"ࠬॉࠧङ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"࠭࡜ࡶ࠲࠳ࡪ࠸࠭च"),l1ll1l11ll1_r_ (u"ࠧࣴࠩछ")).replace(l1ll1l11ll1_r_ (u"ࠨ࡞ࡸ࠴࠵ࡪ࠳ࠨज"),l1ll1l11ll1_r_ (u"ࠩࣖࠫझ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠪࡠࡺ࠶࠱࠶ࡤࠪञ"),l1ll1l11ll1_r_ (u"ࠫॠ࠭ट")).replace(l1ll1l11ll1_r_ (u"ࠬࡢࡵ࠱࠳࠸ࡥࠬठ"),l1ll1l11ll1_r_ (u"࠭ग़ࠨड"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡧࠧढ"),l1ll1l11ll1_r_ (u"ࠨॼࠪण")).replace(l1ll1l11ll1_r_ (u"ࠩ࡟ࡹ࠵࠷࠷࠺ࠩत"),l1ll1l11ll1_r_ (u"ࠪॽࠬथ"))
    l1l1ll1l11ll1_r_ = l1l1ll1l11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠫࡡࡻ࠰࠲࠹ࡦࠫद"),l1ll1l11ll1_r_ (u"ࠬংࠧध")).replace(l1ll1l11ll1_r_ (u"࠭࡜ࡶ࠲࠴࠻ࡧ࠭न"),l1ll1l11ll1_r_ (u"ࠧॼࠩऩ"))
    return l1l1ll1l11ll1_r_
