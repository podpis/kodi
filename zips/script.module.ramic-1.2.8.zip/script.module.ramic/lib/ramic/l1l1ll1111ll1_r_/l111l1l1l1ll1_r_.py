# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import urllib2,urllib
import re,random,json
import cookielib
l1l111l111ll1_r_=10
l1111l11l1ll1_r_=l1ll1l11ll1_r_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ঻")
def l11llllll1ll1_r_(url,data=None,header={},l1111ll1l1ll1_r_=True):
    l1111l1ll1ll1_r_=l1ll1l11ll1_r_ (u"ࠧࠨ়")
    l1111llll1ll1_r_=[]
    if l1111ll1l1ll1_r_:
        l1111llll1ll1_r_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1111llll1ll1_r_))
        urllib2.install_opener(opener)
    if not header:
        header = {l1ll1l11ll1_r_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬঽ"):l1111l11l1ll1_r_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1l111l111ll1_r_)
        l11lll11l1ll1_r_ =  response.read()
        response.close()
        l1111l1ll1ll1_r_ = l1ll1l11ll1_r_ (u"ࠩࠪা").join([l1ll1l11ll1_r_ (u"ࠪࠩࡸࡃࠥࡴ࠽ࠪি")%(c.name, c.value) for c in l1111llll1ll1_r_])
    except urllib2.HTTPError as e:
        l11lll11l1ll1_r_ = l1ll1l11ll1_r_ (u"ࠫࠬী")
    return l11lll11l1ll1_r_,l1111l1ll1ll1_r_
def l11ll1ll11ll1_r_(url):
    url = url.replace(l1ll1l11ll1_r_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫু"),l1ll1l11ll1_r_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭ূ")).replace(l1ll1l11ll1_r_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨৃ"),l1ll1l11ll1_r_ (u"ࠨ࠱ࡂࡺࡂ࠭ৄ"))
    url = url.replace(l1ll1l11ll1_r_ (u"ࠩ࠲ࡩ࠴࠭৅"),l1ll1l11ll1_r_ (u"ࠪ࠳ࡄࡼ࠽ࠨ৆"))
    content,c = l11llllll1ll1_r_(url)
    match = re.findall(l1ll1l11ll1_r_ (u"࡛ࠫࠬ࠭ࠣࠩࡠࡃࡸࡵࡵࡳࡥࡨࡷࡠ࠭ࠢ࡞ࡁ࡟ࡷ࠯ࡀ࡜ࡴࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬ࠭ࠧে"), content)
    l1111lll11ll1_r_=l1ll1l11ll1_r_ (u"ࠬ࠭ৈ")
    if not match:
        data = {}
        data[l1ll1l11ll1_r_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࠮ࡺࠩ৉")] = random.randint(0, 120)
        data[l1ll1l11ll1_r_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭࠯ࡺࠪ৊")] = random.randint(0, 120)
        header={l1ll1l11ll1_r_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬো"):l1111l11l1ll1_r_,l1ll1l11ll1_r_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪৌ"):url}
        l1111ll111ll1_r_ = url + l1ll1l11ll1_r_ (u"্ࠪࠧࠬ")
        content,c = l11llllll1ll1_r_(l1111ll111ll1_r_,urllib.urlencode(data),header=header)
        match = re.findall(l1ll1l11ll1_r_ (u"࡛ࠫࠬ࠭ࠣࠩࡠࡃࡸࡵࡵࡳࡥࡨࡷࡠ࠭ࠢ࡞ࡁ࡟ࡷ࠯ࡀ࡜ࡴࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬ࠭ࠧৎ"), content)
    if match:
        try:
            data = json.loads(match[0])
            l1111lll11ll1_r_=[]
            for d in data:
                if isinstance(d,dict):
                    l1111l1l11ll1_r_ = d.get(l1ll1l11ll1_r_ (u"ࠬ࡬ࡩ࡭ࡧࠪ৏"),l1ll1l11ll1_r_ (u"࠭ࠧ৐"))+l1ll1l11ll1_r_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠫࡳࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠨࡷࠬ৑")%(l1111l11l1ll1_r_,url)
                    l1111lll11ll1_r_.append((d.get(l1ll1l11ll1_r_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ৒"),l1ll1l11ll1_r_ (u"ࠩࠪ৓")),l1111l1l11ll1_r_))
        except:
            l1111lll11ll1_r_ = re.findall(l1ll1l11ll1_r_ (u"ࠪࠫࠬࡡࠧࠣ࡟ࡂࡪ࡮ࡲࡥ࡜ࠩࠥࡡࡄࡢࡳࠫ࠼࡟ࡷ࠯ࡡࠧࠣ࡟ࡂࠬࡠࡤࠧࠣ࡟࠮࠭ࠬ࠭ࠧ৔"), match[0])
            if l1111lll11ll1_r_:
                l1111lll11ll1_r_ = l1111lll11ll1_r_[0].replace(l1ll1l11ll1_r_ (u"ࠫࡡ࠵ࠧ৕"), l1ll1l11ll1_r_ (u"ࠬ࠵ࠧ৖"))
                l1111lll11ll1_r_ += l1ll1l11ll1_r_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠪࡹࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠧࡶࠫৗ")%(l1111l11l1ll1_r_,url)
    return l1111lll11ll1_r_
