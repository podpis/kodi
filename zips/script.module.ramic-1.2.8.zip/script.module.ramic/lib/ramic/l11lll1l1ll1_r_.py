# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import sys,os,re
import xbmcgui,xbmc,xbmcaddon
import time
import shutil
import l11llll11ll1_r_ as l11ll1l11ll1_r_
l11ll11l1ll1_r_ = [l1ll1l11ll1_r_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲ࠴࡫ࡰࡦ࡬ࡹࡱࡺࡩ࡮ࡣࡷࡩࠬ࡜"), l1ll1l11ll1_r_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡺࡡࡳࡩࡨࡸ࡮ࡴ࠱࠱࠺࠳ࡴࡼ࡯ࡺࡢࡴࡧࠫ࡝")]
def l1l1111l1ll1_r_(str):
    return str.encode(l1ll1l11ll1_r_ (u"ࠧࡩࡧࡻࠫ࡞"))
def l1l1ll1l1ll1_r_(str):
    return str.decode(l1ll1l11ll1_r_ (u"ࠨࡪࡨࡼࠬ࡟"))
def l1l1l1ll1ll1_r_():
    return True
def l1l1l11l1ll1_r_():
    import time
    import l1l1llll1ll1_r_
    time.mktime(l1l1llll1ll1_r_.l1l1llll1ll1_r_(2017,12,1).l1l11lll1ll1_r_())
def l11lll111ll1_r_():
    l1l1l1111ll1_r_ = True
def l11ll1ll1ll1_r_():
    l1l1l1111ll1_r_ = True
def l1l11l1l1ll1_r_():
    l1l1l1111ll1_r_ = True
    return l1l1l1111ll1_r_
