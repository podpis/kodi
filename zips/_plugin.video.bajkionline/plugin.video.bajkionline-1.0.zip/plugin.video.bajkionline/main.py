# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse

import xbmc,xbmcgui,xbmcaddon
import xbmcplugin


base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')

PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

import resources.lib.bajkionline as ba
ba.COOKIEFILE=os.path.join(DATAPATH,'bajki.cookie')
FANART='http://bajkipopolsku.com/wp-content/uploads/2015/04/background.jpg'

# xbmcplugin.setContent(addon_handle, 'movies')

## COMMON Functions


def addLinkItem(name, url, mode, page=1, iconimage=None, infoLabels=False, IsPlayable=True,fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page})
    
    if iconimage==None:
        iconimage='DefaultFolder.png'
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    #art=dict(zip(art_keys,[iconimage for x in art_keys]))
    art={el:iconimage for el in art_keys}
    liz.setArt(art)
    if not infoLabels:
        infoLabels={"title": name}
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    liz.setLabel2('label')
     
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok

def addDir(name,ex_link=None,page=1, mode='walk',iconImage=None,fanart=FANART,totalItems=1):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'page' : page})
    if iconImage==None:
        iconImage='DefaultFolder.png'
    li = xbmcgui.ListItem(label=name,iconImage=iconImage)
    li = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    li.setArt({ 'poster': iconImage, 'thumb' : iconImage, 'icon' : iconImage,'banner':iconImage})
    if fanart:li.setProperty('fanart_image', fanart )
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

def getFilmy(ex_link,page):
    filmy,pagination = ba.getContent(ex_link,page)
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=pagination[0], mode='__page:bajki_filmy', page=pagination[0], IsPlayable=False)
    items=len(filmy)
    for f in filmy:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=items,fanart=f.get('img'))
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=pagination[1], mode='__page:bajki_filmy', page=pagination[1], IsPlayable=False)
    xbmcplugin.setContent(addon_handle, 'movies')

def getLinks(ex_link):
    link = ba.getVideoLink(ex_link)
    print link
    if 'cda' in link:
        #print 'CDA'
        import resources.lib.cdaresolver as cdaresolver
        #xbmcgui.Dialog().ok('link',link)
        stream_url = cdaresolver.getVideoUrls(link)
        if type(stream_url) is list:
            qualityList = [x[0] for x in stream_url]
            selection = xbmcgui.Dialog().select("", qualityList)
            if selection>-1:
                stream_url = cdaresolver.getVideoUrls(stream_url[selection][1])
            else:
                stream_url=''
        
    else: 
        #xbmcgui.Dialog().ok('link',link)
        try:
            import urlresolver
            stream_url = urlresolver.resolve(link)
        except Exception,e:
            stream_url=''
            s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działał?','UTRresolver ERROR: [%s]'%str(e))
    print stream_url
    print ba.check.do
    #xbmcgui.Dialog().ok('stream_url',stream_url)
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
        

## ######################
## MAIN
## ######################
            
    
# Get passed arguments
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
page = args.get('page',[1])[0]

if mode is None:
    addDir('[COLOR blue]Bajki po polsku[/COLOR]',ex_link='http://bajkipopolsku.com/',page=1, mode='bajki_filmy',iconImage=None,totalItems=1)
    addDir('  [COLOR lightblue]Spis Alfabetyczny[/COLOR]',ex_link='http://bajkipopolsku.com/',page=1, mode='spis',iconImage=None,totalItems=1)
    addDir('  [COLOR lightblue]Filmy[/COLOR]',ex_link='http://bajkipopolsku.com/category/fimly/page/1',page=1, mode='bajki_filmy',iconImage=None,totalItems=1)

    addDir('[COLOR green]Bajki online[/COLOR]',ex_link='http://bajkionline.com/',page=1, mode='bajki_filmy',iconImage=None,totalItems=1)
    addDir('  [COLOR lightgreen]Spis Alfabetyczny[/COLOR]',ex_link='http://bajkionline.com/',page=1, mode='spis',iconImage=None,totalItems=1)
    addDir('  [COLOR lightgreen]Filmy[/COLOR]',ex_link='http://bajkionline.com/category/filmy-animowane/page/1',page=1, mode='bajki_filmy',iconImage=None,totalItems=1)

elif mode[0] == 'bajki_filmy':
    getFilmy(ex_link,page)

elif mode[0] == 'getLinks':
    getLinks(ex_link)
        
elif mode[0].startswith('__page'):
    nextmode = mode[0].split(':')[-1]
    url = build_url({'mode': nextmode, 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
elif mode[0]== 'spis':
    items = ba.getSpis(ex_link)
    for item in items:
        addDir(item.get('title'),ex_link=item.get('href'),page=1, mode='bajki_filmy',iconImage=item.get('img'))    
    xbmcplugin.setContent(addon_handle, 'movies')   
    

else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))        


xbmcplugin.endOfDirectory(addon_handle)

