# -*- coding: utf-8 -*-
import os,sys,re
from shutil import copyfile

reload(sys)
sys.setdefaultencoding('utf-8')

VI = sys.version_info [0] == 2
M = 2048
P = 7

def decode_u (ctrs):
    a = ord (ctrs [-1])
    b = ctrs [:-1]
    c = a % len (b)
    d = b [:c] + b [c:]
    if VI:
        out = unicode () .join ([unichr (ord (char) - M - (e + a) % P) for e, char in enumerate (d)])
    else:
        out = str () .join ([chr (ord (char) - M - (e + a) % P) for e, char in enumerate (d)])
    return out

vname = 'l1l11ll11l1l11_nktv_'

file = 'l1111llll11l1l11_nktv_.py'

f1 = open(file, 'r')
data=f1.read()
f1.close()

copyfile(file, file + '.bak')

items=re.compile(vname + '\s\(u"(.*?)"\)').findall(data)
for i in xrange(0, len(items)):
	out = 'decode_u(u"' + items[i] + '")'.decode("utf-8")
	ees = str(eval(out)).decode("utf-8")
	ses = vname + ' (u"' + items[i] + '")'
	data = data.replace(ses,ees)

f2 = open(file, 'w')
f2.write(data)
f2.close()

print "Gotowe!"