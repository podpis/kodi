# -*- coding: utf-8 -*-
import urllib2
import re
import jsunpack as jsunpack

BASEURL='http://www.cda.pl'
TIMEOUT = 10

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36')
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        out =  response.read()
        response.close()
    except:
        out=''
    return out

def getMovies(content):
    src =''
    data = re.compile("eval(.*?)\{\}\)\)",re.DOTALL).findall(content)
    for i in data:
        i=re.sub('  ',' ',i)
        i=re.sub('\n','',i)
        try:
            wc = jsunpack.unpack(i)
        except:
            wc=''
        if wc:
            wc=re.sub(r'\\',r'',wc)
            fwc = re.compile('file:\s*[\'"](.+?)[\'"],',  re.DOTALL).search(wc)
            uwc = re.compile('url:\s*[\'"](.+?)[\'"],',  re.DOTALL).search(wc)
            if fwc:
                src = fwc.group(1)
            elif uwc:
                src = uwc.group(1)
            if src:
                break
    return src

def getStreams(content):
    src=''
    http_strings = content.find('|||http')
    if http_strings>0:
        data = content.find('.split',http_strings)
        encoded =content[http_strings:data]
        if encoded:
            pl = encoded.split('player')[0]
            pl=re.sub(r'[|]+\w{2,3}[|]+','|',pl,re.DOTALL)
            pl=re.sub(r'[|]+\w{2,3}[|]+','|',pl,re.DOTALL)
            tags=['http','cda','pl','logo','width','height','true','static','st','mp4','false','video','static',
                    'type','swf','player','file','controlbar','ads','czas','position','duration','bottom','userAgent',
                    'match','png','navigator','id', '37', 'regions', '09', 'enabled', 'src', 'media']
            tags=['http', 'logo', 'width', 'height', 'true', 'static', 'false', 'video', 'player',
                'file', 'type', 'regions', 'none', 'czas', 'enabled', 'duration', 'controlbar', 'match', 'bottom',
                'center', 'position', 'userAgent', 'navigator', 'config', 'html', 'html5', 'provider', 'black',
                'horizontalAlign', 'canFireEventAPICalls', 'useV2APICalls', 'verticalAlign', 'timeslidertooltipplugin',
                'overlays', 'backgroundColor', 'marginbottom', 'plugins', 'link', 'stretching', 'uniform', 'static1',
                'setup', 'jwplayer', 'checkFlash', 'SmartTV', 'v001', 'creme', 'dock', 'autostart', 'idlehide', 'modes',
               'flash', 'over', 'left', 'hide', 'player5', 'image', 'KLIKNIJ', 'companions', 'restore', 'clickSign',
                'schedule', '_countdown_', 'countdown', 'region', 'else', 'controls', 'preload', 'oryginalne', 'style',
                '620px', '387px', 'poster', 'zniknie', 'sekund', 'showAfterSeconds', 'images', 'Reklama', 'skipAd',
                 'levels', 'padding', 'opacity', 'debug', 'video3', 'close', 'smalltext', 'message', 'class', 'align',
                  'notice', 'media']
            for i in tags:
                pl=pl.replace(i,'')
            cleanup=pl.replace('|',' ').split()
            out={'server': '', 'e': '', 'file': '', 'st': ''}
            if len(cleanup)==4:
                print 'Length OK'
                for i in cleanup:
                    if i.isdigit():
                        out['e']=i
                    elif re.match('[a-z]{2,}\d{3}',i) and len(i)<10:
                        out['server'] = i
                    elif len(i)==22:
                        out['st'] = i
                    else:
                        out['file'] = i
                src='http://%s.cda.pl/%s.mp4?st=%s&e=%s'%(out.get('server'),out.get('file'),out.get('st'),out.get('e'))
    return src

def getOne(content):
    out=''
    fwc = re.compile('file: [\'"](.+?)[\'"],',  re.DOTALL).search(content)
    uwc = re.compile('url: [\'"](.+?)[\'"],',  re.DOTALL).search(content)
    if fwc:
        print 'found RE [file:]'
        out = fwc.group(1)
    elif uwc:
        print 'found RE [url:]'
        out = uwc.group(1)
    else:
        print 'encoded : unpacker'
        out = getMovies(content)
        if not out:
            print 'encoded : force '
            out = getStreams(content)
    return out

def getVideos(url):
    cookie='|Cookie="PHPSESSID=1&Referer=http://static.cda.pl/player5.9/player.swf'
    ref='|Referer=http://static.cda.pl/player5.9/player.swf'
    print url
    content = getUrl(url)
    src=[]
    if not '?wersja' in url:
         data = re.compile('<a data-quality="(.*?)" (?P<H>.*?)>(?P<Q>.*?)</a>', re.DOTALL).findall(content)
         for quality in data:
             out = re.search('href="(.*?)"',quality[1])
             q = quality[2]
             src.insert(0,(q,BASEURL+out.group(1)))
    if not src:
        src = getOne(content)
        if src:
            src+=cookie+ref
    return src