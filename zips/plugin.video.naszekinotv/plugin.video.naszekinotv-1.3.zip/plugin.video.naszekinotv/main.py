# -*- coding: utf-8 -*-
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import resolveurl as urlresolver
import time,threading

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer("nktv")

import resources.lib.naszekinotv as nktv

if False:
    import resources.lib.cdapl as cda
    import resources.lib.rapidvideo as rapidvideo

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')
PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'
FANART          = RESOURCES+'fanart.png'
nktv.COOKIEFILE=os.path.join(DATAPATH,'cookie')

def addLinkItem(name, url, mode, params=1, iconimage='DefaultFolder.png', infoLabels=False, IsPlayable=True,fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':params})
    liz = xbmcgui.ListItem(name)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    liz.setArt(art)
    if not infoLabels:
        infoLabels={"title": name}
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    isp = []
    isp.append(('Informacja', 'XBMC.Action(Info)'))
    liz.addContextMenuItems(isp, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok

def addDir(name,ex_link=None, params=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'page' : params})
    li = xbmcgui.ListItem(name)
    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)
    art_keys=['thumb','poster','banner','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    li.setArt(art)
    if contextmenu:
        isp=contextmenu
        li.addContextMenuItems(isp, replaceItems=True)
    else:
        isp = []
        isp.append(('Informacja', 'XBMC.Action(Info)'),)
        li.addContextMenuItems(isp, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v
    return out_dict

def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

def listMovies(ex_link,params):
    params = int(params) if params else 1
    group=''
    if '|'in ex_link:
        ex_link,group = ex_link.split('|')
    mlinks,mparams = nktv.getMovies(ex_link,params,group)
    if mparams[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__M', params=mparams[0], IsPlayable=False)
    items=len(mlinks)
    for f in mlinks:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=items)
    if mparams[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__M', params=mparams[1], IsPlayable=False)

def listSeries(ex_link,params):
    params = int(params) if params else 1
    group=''
    if '|'in ex_link:
        ex_link,group = ex_link.split('|')
    if group:
        mlinks,mparams = nktv.getMovies(ex_link,int(params),group)
    else:
        mlinks,mparams = nktv.getMovie(ex_link)
    mmode = 'getEpisodes'
    if 'true' in my_addon.getSetting('groupEpisodes'):
        mmode = 'getSeasons'
    if mparams[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__S', params=mparams[0], IsPlayable=False)
    items=len(mlinks)
    for f in mlinks:
        addDir(name=f.get('title'), ex_link=f.get('href'), mode=mmode, iconImage=f.get('img'), infoLabels=f)
    if mparams[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__S', params=mparams[1], IsPlayable=False)

def getEpisodes(ex_link):
    episodes = nktv.findEpisodes(ex_link)
    for f in episodes:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True)

def getSeasons(ex_link):
    episodes = nktv.findEpisodes(ex_link)
    seasons =nktv.findSeasons(episodes)
    for name in sorted(seasons.keys()):
        addDir(name=name, ex_link=urllib.quote(str(seasons[name])), mode='getEpisodes2')
    xbmcplugin.setContent(addon_handle, 'season')

def getEpisodes2(ex_link):
    episodes = eval(urllib.unquote(ex_link))
    for f in episodes:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=f.get('img'))
    xbmcplugin.setContent(addon_handle, 'mmode')

def listFS(ex_link):
    mlinks,found = nktv.search(ex_link)
    for f in mlinks:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=len(mlinks))
    for f in found:
        addDir(name=f.get('title'), ex_link=f.get('href'), mode='getEpisodes', iconImage=f.get('img'), infoLabels=f)

def getLinks(ex_link):
    streams = nktv.getVideos(ex_link)
    out=''
    t = [ x.get('title') for x in streams]
    u = [ x.get('url') for x in streams]
    h = [ x.get('host') for x in streams]
    dlg_select = xbmcgui.Dialog().select("Źródła ", t) if len(t)>0 else -1

    if dlg_select>-1:
        wc = u[dlg_select]

        if False:
            if 'playernaut' in wc: wc = wc.replace('playernaut','raptu')
            if 'cda' in h[dlg_select]:
                out = cda.getVideos(wc)
                if type(out) is list:
                    lin = [x[0] for x in out]
                    dlg_select = xbmcgui.Dialog().select("Wybierz", lin)
                    if dlg_select>-1:
                        out = cda.getVideos(out[dlg_select][1])
                    else:
                        out=''
            elif 'rapidvideo.com' in h[dlg_select] or 'raptu.com' in h[dlg_select] or 'playernaut' in h[dlg_select]:
                out = rapidvideo.getVideos(wc)
                if type(out) is list:
                    lin = [x[0] for x in out]
                    dlg_select = xbmcgui.Dialog().select("Wybierz", lin)
                    if dlg_select>-1:
                        out = out[dlg_select][1]
                    else:
                        out=''
        if not out:
            try:
                out = urlresolver.resolve(wc)
            except Exception,e:
                out=''
                s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link bedzie działał?','ERROR: %s'%str(e))
    if out:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=out))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def getHistory():
    return cache.get('history').split(';')

def setHistory(entry):
    history = getHistory()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history',';'.join(history[:50]))

def remCache(entry):
    history = getHistory()
    if history:
        cache.set('history',';'.join(history[:50]))
    else:
        delHistory()

def delHistory():
    cache.delete('history')

#arguments & setting
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('page',[1])[0]
sortv = my_addon.getSetting('sortV')
sortn = my_addon.getSetting('sortN') if sortv else 'Daty dodania'
qualityv = my_addon.getSetting('qualityV')
qualityn = my_addon.getSetting('qualityN') if qualityv else 'Wszystkie'
versionv = my_addon.getSetting('versionV')
versionn = my_addon.getSetting('versionN') if versionv else 'Wszystkie'

if mode is None:
    addLinkItem("[COLOR lightblue]Sortowanie:[/COLOR] [B]"+sortn+"[/B]",'',mode='filtr:sort',iconimage='',IsPlayable=False)
    addLinkItem("[COLOR lightblue]Jakość:[/COLOR] [B]"+qualityn+"[/B]",'',mode='filtr:quality',iconimage='',IsPlayable=False)
    addLinkItem("[COLOR lightblue]Wersja:[/COLOR] [B]"+versionn+"[/B]",'',mode='filtr:version',iconimage='',IsPlayable=False)
    addDir(name="[COLOR blue]Filmy[/COLOR]",ex_link='https://nasze-kino.tv/filmy-online/',params=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" Ostatnio dodane filmy",ex_link='https://nasze-kino.tv/|Ostatnio dodane filmy',params=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" Ranking nowości",ex_link='https://nasze-kino.tv/|Ranking now',params=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" [Kategoria]",ex_link='film|category',params=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" [Rok]",ex_link='film|year',params=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" [Kraj]",ex_link='film|country',params=1, mode='GatunekRok',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name="[COLOR blue]Seriale (Lista)[/COLOR]",ex_link='https://nasze-kino.tv/seriale-online/',params=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" Ostatnio dodane seriale",ex_link='https://nasze-kino.tv/seriale-online/|Ostatnio dodane seriale',params=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name=" Popularne seriale",ex_link='https://nasze-kino.tv/seriale-online/|Popularne seriale',params=1, mode='ListSeriale',iconImage='DefaultFolder.png',fanart=FANART)
    addDir(name="[COLOR blue]Dla dzieci[/COLOR]",ex_link='https://nasze-kino.tv/dla-dzieci/',params=1, mode='ListMovies',iconImage='DefaultFolder.png',fanart=FANART)
    addDir('[COLOR lightblue]Szukaj[/COLOR]','',mode='Szukaj')
    addLinkItem('[COLOR gold]-=Opcje=-[/COLOR]','','Opcje')

elif 'filtr' in mode[0]:
    myMode = mode[0].split(":")[-1]
    if myMode=='sort':
        label=[u'Daty dodania',u'Liczba głosów',u'Premiera',u'Odsłony',u'Ocena']
        value=['sort:date','sort:vote','sort:premiere','sort:view','sort:rate']
        msg = 'Sortowanie'
    elif myMode=='quality':
        label=[u'Wszystkie',u'Kamera',u'Niska',u'Średnia',u'Wysoka']
        value=['','quality:4','quality:2','quality:2','quality:3']
        msg = 'Jakość'
    elif myMode=='version':
        label=['Wszystkie','Dubbing','Lektor','Lektor Amator','Lektor IVO','Napisy','PL','Oryginalna']
        value=['',    'version:2','version:1','version:8','version:6','version:3','version:4','version:7']
        msg = 'Wersja'
    if myMode in ['quality','version']:
        try:
            s = xbmcgui.Dialog().select('Wybierz wersje językową',label)
        except:
            s = xbmcgui.Dialog().select('Wybierz wersje językową',label)
        if isinstance(s,list):
            if 0 in s: s=[0]
            v = myMode+':'+','.join( [ value[i].replace(myMode+':','') for i in s])
            n = ','.join( [ label[i] for i in s])
        else:
            s = s if s>-1 else 0
            v = value[s]
            n = label[s]
    else:
        s = xbmcgui.Dialog().select(msg,label)
        s = s if s>-1 else 0
        v = value[s]
        n = label[s]

    my_addon.setSetting(myMode+'V',v)
    my_addon.setSetting(myMode+'N',n)
    xbmc.executebuiltin('XBMC.Container.Refresh')

elif mode[0] == 'ListMovies':
    sr = '/'.join([x for x in [sortv,qualityv,versionv] if x]) if '/filmy-online/' in ex_link else ''
    listMovies(ex_link+sr,params)
    xbmcplugin.setContent(addon_handle, 'movies')

elif mode[0] == 'ListMoviesKids':
    listMovies(ex_link,params)
    xbmcplugin.setContent(addon_handle, 'movies')

elif mode[0] == 'Opcje':
    my_addon.openSettings()

elif mode[0] == '__page__M':
    url = build_url({'mode': 'ListMovies', 'foldername': '', 'ex_link' : ex_link, 'page': params})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == '__page__S':
    url = build_url({'mode': 'ListSeriale', 'foldername': '', 'ex_link' : ex_link, 'page': params})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'getEpisodes':
    getEpisodes(ex_link)
    xbmcplugin.setContent(addon_handle, 'mmode')

elif mode[0] == 'getEpisodes2':
    getEpisodes2(ex_link)
    xbmcplugin.setContent(addon_handle, 'mmode')

elif mode[0] == 'ListSeriale':
    listSeries(ex_link,params)
    xbmcplugin.setContent(addon_handle, 'tvshows')

elif mode[0] == 'getSeasons':
    getSeasons(ex_link)
    xbmcplugin.setContent(addon_handle, 'tvshows')

elif mode[0] == 'ListFS':
    listFS(ex_link)
    xbmcplugin.setContent(addon_handle, 'tvshows')

elif mode[0] == 'getLinks':
    getLinks(ex_link)

elif mode[0] == 'GatunekRok':
    param = ex_link.split('|')
    label,value = nktv.getSort(mv=param[0],sc=param[1])
    try:
        s = xbmcgui.Dialog().select('Wybierz ',label)
    except:
        s = xbmcgui.Dialog().select('Wybierz',label)
    if isinstance(s,list):
        v = param[1]+':'+','.join([ value[i] for i in s])
    else:
        s = s if s>-1 else 0
        v = param[1]+':'+value[s]
    sr = '/'.join([x for x in [sortv,qualityv,versionv,v] if x])
    listMovies('https://nasze-kino.tv/filmy-online/'+sr,1)

elif mode[0] == 'Opcje':
    my_addon.openSettings()

elif mode[0] =='Szukaj':
    addDir('[COLOR green]Nowe Szukanie[/COLOR]','',mode='SzukajNowe')
    history = getHistory()
    if not history == ['']:
        for entry in history:
            contextmenu = []
            contextmenu.append((u'Usun', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry})),)
            contextmenu.append((u'Usun cała historie', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
            addDir(name=entry, ex_link=entry.replace(' ','+'), mode='ListFS', fanart=None, contextmenu=contextmenu)

elif mode[0] =='SzukajNowe':
    d = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł filmu/serialu', type=xbmcgui.INPUT_ALPHANUM)
    if d:
        setHistory(d)
        ex_link=d.replace(' ','+')
        listFS(ex_link)
        xbmcplugin.setContent(addon_handle, 'tvshows')

elif mode[0] =='SzukajUsun':
    remCache(ex_link)
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))

elif mode[0] == 'SzukajUsunAll':
    delHistory()
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))

elif mode[0] == 'folder':
    pass
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
xbmcplugin.endOfDirectory(addon_handle)
