#! /usr/bin/python
license = (
'''_opy_Copyright 2014, 2015, 2016 Jacques de Hooge, GEATEC engineering, www.geatec.com
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.'''
)
import re
import os
import sys
import errno
import keyword
import importlib
import random
import codecs
import shutil
l11l1111_se_ = 'opy'
l1111ll1_se_ = '1.1.22'
if __name__ == '__main__':
	print ('{} (TM) Configurable Multi Module Python Obfuscator Version {}'.format (l11l1111_se_.capitalize (), l1111ll1_se_))
	print ('Copyright (C) Geatec Engineering. License: Apache 2.0 at  http://www.apache.org/licenses/LICENSE-2.0\n')
	random.seed ()
	l1ll1l1ll_se_ = sys.version_info [0] == 2
	l11l1l11_se_ = 2048
	l1ll1llll_se_ = l11l1l11_se_
	l1l1lll11_se_ = 7
	l11l11l1_se_ = os.path.sep
	def l1111111_se_ (l1l1l1l1_se_, open = False):
		print 'createFilePath %s'%l1l1l1l1_se_
		try:
			os.makedirs (l1l1l1l1_se_.rsplit (l11l11l1_se_, 1) [0])
		except OSError as l1lll1l11_se_:
			print 'ERROR: createFilePath'
			if l1lll1l11_se_.errno != errno.EEXIST:
				raise
		if open:
			return codecs.open (l1l1l1l1_se_, encoding = 'utf-8', mode = 'w')
	def l11l1lll_se_ (l1l1l1ll1_se_, name):
		return '{0}{1}{2}'.format (
			'__' if name.startswith ('__') else '_' if name.startswith ('_') else 'l',
			bin (l1l1l1ll1_se_) [2:] .replace ('0', 'l'),
			l1ll111ll_se_
		)
	def l1ll1l11l_se_ (l1l1l111_se_):
		global l1ll1llll_se_
		if l1ll1l1ll_se_:
			l11lll1l_se_ = unicode () .join ([unichr (l11l1l11_se_ + ord (char) + (l1l1lll1_se_ + l1ll1llll_se_) % l1l1lll11_se_) for l1l1lll1_se_, char in enumerate (l1l1l111_se_)])
			l1l1l11ll_se_ = unichr (l1ll1llll_se_)
		else:
			l11lll1l_se_ = str () .join ([chr (l11l1l11_se_ + ord (char) + (l1l1lll1_se_ + l1ll1llll_se_) % l1l1lll11_se_) for l1l1lll1_se_, char in enumerate (l1l1l111_se_)])
			l1l1l11ll_se_ = chr (l1ll1llll_se_)
		l1111l1l_se_ = l1ll1llll_se_ % len (l1l1l111_se_)
		l1l1ll11l_se_ = l11lll1l_se_ [:-l1111l1l_se_] + l11lll1l_se_ [-l1111l1l_se_:]
		l1l1111l_se_ = l1l1ll11l_se_ + l1l1l11ll_se_
		l1ll1llll_se_ += 1
		return 'u"' + l1l1111l_se_ + '"'
	def l1lll111_se_ (l11ll11l_se_):
		return '''
import sys
isPython2{0} = sys.version_info [0] == 2
charBase{0} = {1}
charModulus{0} = {2}
def unScramble{0} (keyedStringLiteral):
	global stringNr{0}
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if isPython2{0}:
		stringLiteral = unicode () .join ([unichr (ord (char) - charBase{0} - (charIndex + stringNr) % charModulus{0}) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - charBase{0} - (charIndex + stringNr) % charModulus{0}) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
	'''.format (l1l111l1_se_, l11l1l11_se_, l1l1lll11_se_)
	def l1lll1111_se_ (l1lll111l_se_):
		print (r'''
*******************************************************************************
{0} will obfuscate your extensive, real world, multi module Python source code for free!
And YOU choose per project what to obfuscate and what not, by editting the config file.
BACKUP YOUR CODE AND VALUABLE DATA TO AN OFF-LINE MEDIUM FIRST TO PREVENT ACCIDENTAL LOSS OF WORK!!!
Then copy the default config file to the source top directory <topdir> and run {0} from there.
It will generate an obfuscation directory <topdir>/../<topdir>_{1}
At first some identifiers may be obfuscated that shouldn't be, e.g. some of those imported from external modules.
Adapt your config file to avoid this, e.g. by adding external module names that will be recursively scanned for identifiers.
You may also exclude certain words or files in your project from obfuscation explicitly.
Source directory, obfuscation directory and config file path can also be supplied as command line parameters in that order.
Comments and string literals can be marked as plain, bypassing obfuscation
Known limitations:
A comment after a string literal should be preceded by whitespace
A ' or " inside a string literal should be escaped with \ rather then doubled
A {2} in a string literal can only be used at the start, so use 'p''{2}''r' rather than 'p{2}r'
Obfuscation of string literals is unsuitable for sensitive information since it can be trivially broken
No renaming backdoor support for methods starting with __ (non-overridable methods, also known as private methods)
Licence:
{3}
*******************************************************************************
		'''.format (l11l1111_se_.capitalize (), l11l1111_se_, r'#', license))
		exit (l1lll111l_se_)
	if len (sys.argv) > 1:
		if '?' in sys.argv [1]:
			l1lll1111_se_ (0)
		l1ll11l1_se_ = sys.argv [1]
	else:
		l1ll11l1_se_ = os.getcwd ()
	if len (sys.argv) > 2:
		l1l1l1111_se_ = sys.argv [2]
	else:
		l1l1l1111_se_ = '{0}\\{1}_{2}'.format (* (l1ll11l1_se_.rsplit (l11l11l1_se_, 1) + [l11l1111_se_]))
	if len (sys.argv) > 3:
		l1l1lll1l_se_ = sys.argv [3]
	else:
		l1l1lll1l_se_ = '{0}\\{1}_config.txt'.format (l1ll11l1_se_, l11l1111_se_)
	obfuscate_strings = False
	obfuscated_name_tail = '_{}_'.format (l11l1111_se_)
	plain_marker = '_{}_'.format (l11l1111_se_)
	source_extensions = ''
	skip_extensions = ''
	external_modules = ''
	plain_files = ''
	plain_names = ''
	try:
		l1lllll11_se_ = open (l1l1lll1l_se_)
	except Exception as l1lll1l11_se_:
		print (l1lll1l11_se_)
		l1lll1111_se_ (1)
	exec (l1lllll11_se_.read ())
	l1lllll11_se_.close ()
	try:
		l1ll111l_se_ = obfuscate_strings
	except:
		l1ll111l_se_ = False
	try:
		l1llll111_se_ = l1lll11ll_se_
	except:
		l1llll111_se_ = False
	try:
		l1ll111ll_se_ = obfuscated_name_tail
	except:
		l1ll111ll_se_ = ''
	try:
		l1l111l1_se_ = plain_marker
	except:
		l1l111l1_se_ = '_{0}_'.format (l11l1111_se_)
	l11l111l_se_ = source_extensions.split ()
	l1l1l1l1l_se_ = skip_extensions.split ()
	l1l11ll1l_se_ = external_modules.split ()
	l1llllll1_se_ = plain_files.split ()
	l1ll11lll_se_ = plain_names.split ()
	l1l1ll1l_se_ = [
		'{0}\\{1}'.format (l1l11ll11_se_.replace ('\\', l11l11l1_se_), l1l11lll_se_)
		for l1l11ll11_se_, l1l1l111l_se_, l1l1lllll_se_ in os.walk (l1ll11l1_se_)
		for l1l11lll_se_ in l1l1lllll_se_
	]
	l1lllllll_se_ = re.compile (r'^{0}!'.format (r'#'))
	l1lll1lll_se_ = re.compile ('coding[:=]\s*([-\w.]+)')
	l1l1llll_se_ = re.compile ('.*{0}.*'.format (l1l111l1_se_), re.DOTALL)
	def l111l1l1_se_ (l1l1ll111_se_):
		comment = l1l1ll111_se_.group (0)
		if l1l1llll_se_.search (comment):
			l11111ll_se_.append (comment.replace (l1l111l1_se_, ''))
			return l1llll1l1_se_
		else:
			return ''
	def l1l11ll1_se_ (l1l1ll111_se_):
		global l1l11111_se_
		l1l11111_se_ += 1
		return l11111ll_se_ [l1l11111_se_]
	l1l1l1l11_se_ = re.compile (r'{0}{1}{2}.*?$'.format (
		r"(?<!')",
		r'(?<!")',
		r'#'
	), re.MULTILINE)
	l1llll1l1_se_ = '_{0}_c_'.format (l11l1111_se_)
	l1ll1l111_se_ = re.compile (r'{0}'.format (l1llll1l1_se_))
	l1ll1111_se_ = re.compile (r'.*{0}.*'.format (l1l111l1_se_))
	def l1l1ll1ll_se_ (l1l1ll111_se_):
		string = l1l1ll111_se_.group (0)
		if l1ll111l_se_:
			if l1ll1111_se_.search (string):
				l11lllll_se_.append (string.replace (l1l111l1_se_, ''))
				return l1ll1lll1_se_
			else:
				l11lllll_se_.append (l1ll1l11l_se_ (string))
				return 'unScramble{0} ({1})'.format (l1l111l1_se_, l1ll1lll1_se_)
		else:
			l11lllll_se_.append (string)
			return l1ll1lll1_se_
	def l1ll11111_se_ (l1l1ll111_se_):
		global l11l1ll1_se_
		l11l1ll1_se_ += 1
		return l11lllll_se_ [l11l1ll1_se_]
	l1l1ll1l1_se_ = re.compile (r'([ru]|ru|ur)?(({0})|({1})|({2})|({3}))'.format (
		r"'''.*?(?<![^\\]\\)(?<![^\\]\')'''",
		r'""".*?(?<![^\\]\\)(?<![^\\]\")"""',
		r"'.*?(?<![^\\]\\)'",
		r'".*?(?<![^\\]\\)"'
	), re.MULTILINE | re.DOTALL | re.VERBOSE)
	l1ll1lll1_se_ = '_{0}_s_'.format (l11l1111_se_)
	l1111lll_se_ = re.compile (r'{0}'.format (l1ll1lll1_se_))
	def l1ll1ll1_se_ (l1l1ll111_se_):
		l1ll1l1l1_se_ = l1l1ll111_se_.group (0)
		if l1ll1l1l1_se_:
			global l11111l1_se_
			l1lllll1l_se_ [l11111l1_se_:l11111l1_se_] = [l1ll1l1l1_se_]
			l11111l1_se_ += 1
		return ''
	l1ll11ll1_se_ = re.compile ('from\s*__future__\s*import\s*\w+.*$', re.MULTILINE)
	l11lll11_se_ = re.compile (r'''
		\b
		(?!{0})
		(?!{1})
		[^\d\W]
		\w*
		(?<!__)
		(?<!{0})
		(?<!{1})
		\b
	'''.format (l1llll1l1_se_, l1ll1lll1_se_), re.VERBOSE)
	l1lll1ll1_se_ = re.compile (r'\bchr\b')
	l111l111_se_ = set (keyword.kwlist + ['__init__'] + l1ll11lll_se_)
	l111ll11_se_ = ['{0}\\{1}'.format (l1ll11l1_se_, l111ll1l_se_) for l111ll1l_se_ in l1llllll1_se_]
	for l1l11l11_se_ in l111ll11_se_:
		l1ll111l1_se_ = open (l1l11l11_se_)
		content = l1ll111l1_se_.read ()
		l1ll111l1_se_.close ()
		content = l1l1l1l11_se_.sub ('', content)
		content = l1l1ll1l1_se_.sub ('', content)
		l111l111_se_.update (re.findall (l11lll11_se_, content))
	class l1lll1l1l_se_:
		def __init__ (self):
			for l11l11ll_se_ in l1l11ll1l_se_:
				l1l1l11l_se_ = l11l11ll_se_.replace ('.', l1l111l1_se_)
				try:
					exec (
						'''
import {0} as currentModule
						'''.format (l11l11ll_se_),
						globals ()
					)
					setattr (self, l1l1l11l_se_, currentModule)
				except Exception as l1lll1l11_se_:
					print (l1lll1l11_se_)
					setattr (self, l1l1l11l_se_, None)
					print ('Warning: could not inspect external module {0}'.format (l11l11ll_se_))
	l1l1l1ll_se_ = l1lll1l1l_se_ ()
	l111llll_se_ = set ()
	def l11l1l1l_se_ (l111l11l_se_):
		if l111l11l_se_ in l111llll_se_:
			return
		else:
			l111llll_se_.update ([l111l11l_se_])
		try:
			l1ll1l11_se_ = list (l111l11l_se_.__dict__)
		except:
			l1ll1l11_se_ = []
		try:
			if l1ll1l1ll_se_:
				l11llll1_se_ = list (l111l11l_se_.func_code.co_varnames)
			else:
				l11llll1_se_ = list (l111l11l_se_.__code__.co_varnames)
		except:
			l11llll1_se_ = []
		l1llll11l_se_ = [getattr (l111l11l_se_, l1l1l11l_se_) for l1l1l11l_se_ in l1ll1l11_se_]
		l1l1llll1_se_ = (l1l111l1_se_.join (l1ll1l11_se_)) .split (l1l111l1_se_)
		l1l11l1ll_se_ = set ([l1lll1ll_se_ for l1lll1ll_se_ in (l11llll1_se_ + l1l1llll1_se_) if not (l1lll1ll_se_.startswith ('__') and l1lll1ll_se_.endswith ('__'))])
		l111l111_se_.update (l1l11l1ll_se_)
		for l1ll11l11_se_ in l1llll11l_se_:
			try:
				l11l1l1l_se_ (l1ll11l11_se_)
			except:
				pass
	l11l1l1l_se_ (__builtins__)
	l11l1l1l_se_ (l1l1l1ll_se_)
	l1l11l1l_se_ = list (l111l111_se_)
	l1l11l1l_se_.sort (key = lambda s: s.lower ())
	l111111l_se_ = []
	l1lll11l1_se_ = []
	for l1l11lll1_se_ in l1l1ll1l_se_:
		if l1l11lll1_se_ == l1l1lll1l_se_:
			continue
		l1l1ll11_se_, l1ll1ll1l_se_ = l1l11lll1_se_.rsplit (l11l11l1_se_, 1)
		l1l1l11l1_se_, l1111l11_se_ = (l1ll1ll1l_se_.rsplit ('.', 1) + ['']) [ : 2]
		l1ll1111l_se_ =  l1l11lll1_se_ [len (l1ll11l1_se_) : ]
		if l1111l11_se_ in l11l111l_se_ and not l1l11lll1_se_ in l111ll11_se_:
			l11ll11l_se_ = random.randrange (64)
			l1l111ll_se_ = codecs.open (l1l11lll1_se_, encoding = 'utf-8')
			content = l1l111ll_se_.read ()
			l1l111ll_se_.close ()
			l11111ll_se_ = []
			l1lllll1l_se_ = content.split ('\n', 2)
			l11111l1_se_ = 0
			l1llll1ll_se_ = True
			if len (l1lllll1l_se_) > 0:
				if l1lllllll_se_.search (l1lllll1l_se_ [0]):
					l11111l1_se_ += 1
					if len (l1lllll1l_se_) > 1 and l1lll1lll_se_.search (l1lllll1l_se_ [1]):
						l11111l1_se_ += 1
						l1llll1ll_se_ = False
				elif l1lll1lll_se_.search (l1lllll1l_se_ [0]):
					l11111l1_se_ += 1
					l1llll1ll_se_ = False
			if l1ll111l_se_ and l1llll1ll_se_:
				l1lllll1l_se_ [l11111l1_se_:l11111l1_se_] = ['# coding: UTF-8']
				l11111l1_se_ += 1
			if l1ll111l_se_:
				l1ll1lll_se_ = '\n'.join ([l1lll111_se_ (l11ll11l_se_)] + l1lllll1l_se_ [l11111l1_se_:])
			else:
				l1ll1lll_se_ = '\n'.join (l1lllll1l_se_ [l11111l1_se_:])
			l1ll1lll_se_ = l1l1l1l11_se_.sub (l111l1l1_se_, l1ll1lll_se_)
			l11lllll_se_ = []
			l1ll1lll_se_ = l1l1ll1l1_se_.sub (l1l1ll1ll_se_, l1ll1lll_se_)
			l1ll1lll_se_ = l1ll11ll1_se_.sub (l1ll1ll1_se_, l1ll1lll_se_)
			l1ll11ll_se_ = set (re.findall (l11lll11_se_, l1ll1lll_se_) + [l1l1l11l1_se_])
			l11ll1l1_se_ = l1ll11ll_se_.difference (l111111l_se_).difference (l111l111_se_)
			l11ll111_se_ = list (l11ll1l1_se_)
			l1l11llll_se_ = [re.compile (r'\b{0}\b'.format (l11ll1ll_se_)) for l11ll1ll_se_ in l11ll111_se_]
			l111111l_se_ += l11ll111_se_
			l1lll11l1_se_ += l1l11llll_se_
			for l1l1l1ll1_se_, l1l1l1lll_se_ in enumerate (l1lll11l1_se_):
				l1ll1lll_se_ = l1l1l1lll_se_.sub (
					l11l1lll_se_ (l1l1l1ll1_se_, l111111l_se_ [l1l1l1ll1_se_]),
					l1ll1lll_se_
				)
			l11l1ll1_se_ = -1
			l1ll1lll_se_ = l1111lll_se_.sub (l1ll11111_se_, l1ll1lll_se_)
			l1l11111_se_ = -1
			l1ll1lll_se_ = l1ll1l111_se_.sub (l1l11ll1_se_, l1ll1lll_se_)
			content = '\n'.join (l1lllll1l_se_ [:l11111l1_se_] + [l1ll1lll_se_])
			content = '\n'.join ([line for line in [line.rstrip () for line in content.split ('\n')] if line])
			try:
				l1ll1ll11_se_ = l11l1lll_se_ (l111111l_se_.index (l1l1l11l1_se_), l1l1l11l1_se_)
			except:
				l1ll1ll11_se_ = l1l1l11l1_se_
			l111lll1_se_ = l1ll1111l_se_.split (l11l11l1_se_)
			for index in range (len (l111lll1_se_)):
				try:
					l111lll1_se_ [index] = l11l1lll_se_ (l111111l_se_.index (l111lll1_se_ [index]), l111lll1_se_ [index])
				except:
					pass
			l1ll1111l_se_ = l11l11l1_se_.join (l111lll1_se_)
			l1ll1l1l_se_ = '{0}{1}'.format (l1l1l1111_se_, l1ll1111l_se_) .rsplit (l11l11l1_se_, 1) [0]
			l111l1ll_se_ = l1111111_se_ ('{0}\\{1}.{2}'.format (l1ll1l1l_se_, l1ll1ll11_se_, l1111l11_se_), open = True)
			l111l1ll_se_.write (content)
			l111l1ll_se_.close ()
		elif not l1111l11_se_ in l1l1l1l1l_se_:
			l1ll1l1l_se_ = '{0}{1}'.format (l1l1l1111_se_, l1ll1111l_se_) .rsplit (l11l11l1_se_, 1) [0]
			l1ll11l1l_se_ = '{0}\\{1}'.format (l1ll1l1l_se_, l1ll1ll1l_se_)
			l1111111_se_ (l1ll11l1l_se_)
			shutil.copyfile (l1l11lll1_se_, l1ll11l1l_se_)
	print ('Obfuscated words: {0}'.format (len (l111111l_se_)))