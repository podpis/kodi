# coding: UTF-8
import sys
l1l1l_ft_ = sys.version_info [0] == 2
l1lll1_ft_ = 2048
l11l_ft_ = 7
def l11ll_ft_ (ll_ft_):
	global l1l1l1_ft_
	l1l11l_ft_ = ord (ll_ft_ [-1])
	l11l1_ft_ = ll_ft_ [:-1]
	l1l_ft_ = l1l11l_ft_ % len (l11l1_ft_)
	l11_ft_ = l11l1_ft_ [:l1l_ft_] + l11l1_ft_ [l1l_ft_:]
	if l1l1l_ft_:
		l1llll_ft_ = unicode () .join ([unichr (ord (char) - l1lll1_ft_ - (l1l11_ft_ + l1l11l_ft_) % l11l_ft_) for l1l11_ft_, char in enumerate (l11_ft_)])
	else:
		l1llll_ft_ = str () .join ([chr (ord (char) - l1lll1_ft_ - (l1l11_ft_ + l1l11l_ft_) % l11l_ft_) for l1l11_ft_, char in enumerate (l11_ft_)])
	return eval (l1llll_ft_)