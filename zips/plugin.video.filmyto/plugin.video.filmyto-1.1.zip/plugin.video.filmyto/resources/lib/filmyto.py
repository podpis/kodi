# -*- coding: utf-8 -*-

import urllib2,urllib
import re,os
import json
import cookielib
from urlparse import urlparse

BASEURL='http://filmy.to'
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

COOKIEFILE=r'D:\fimlyto.cookie'
BRAMKA = 'http://www.bramka.proxy.net.pl/index.php?q='


def getUrl(url,data=None,header={},useCookies=True,saveCookie=True):
    if COOKIEFILE and useCookies:
        cj = cookielib.LWPCookieJar()
        #cj.load(COOKIEFILE)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        urllib2.install_opener(opener)
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link =  response.read()
        response.close()
        if COOKIEFILE and saveCookie and useCookies:
            dataPath=os.path.dirname(COOKIEFILE)
            if not os.path.exists(dataPath): os.makedirs(dataPath)
            if cj: cj.save(COOKIEFILE, ignore_discard = True) 
            
    except urllib2.HTTPError as e:
        link = ''
    return link


# params={'type':'filmy','page':'1','options':''}
# scanMainpage(**params)
def scanMainpage(type='dokumentalne',page='1',options=''):
    page=int(page)
    url = '%s/%s/%d' %(BASEURL,type,int(page))
    
    url +='?widok=galeria'+options

    print 'URL',url
    # cookie=setCookies(COOKIEFILE)
    # content = getUrl(url,cookies=cookie)
    content = getUrl(url,useCookies=True)
  
    pagination = re.compile('<ul class="pagination pagination-sm">(.*?)</ul>',re.DOTALL).findall(content)
    pagination = pagination[0] if pagination else ''
    nextPage=False
    next_url=url.replace('page/%d/'%page,'page/%d/' %(page+1))
    if pagination.find('href="/%s/%d"'%(type,page+1))>-1:
        nextPage = {'type':'filmy','page':int(page)+1,'options':''}
   
        
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="movie clearfix">', content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('<a href="(.*?)"',re.DOTALL).search(subset)
        img = re.compile('<img src="(.*?)"',re.DOTALL).search(subset)  
        title = re.compile('<h3>(.*?)</h3>',re.DOTALL).search(subset)  
        title_en = re.compile('<span class="title-en">(.*?)</span>').search(subset)
        produkcja = re.compile('title="Produkcja:(.*?)"').findall(subset)
        gatunek = re.compile('title="Gatunek:\s*(.*?)\s*"').findall(subset)
        plot = re.compile('<div class="description">(.*?)</div>').findall(subset)
        rating = re.compile('Ocena: <strong>(.*?)</strong>').findall(subset)
        dt = re.compile('<div class="details-top">(.*?</div>)',re.DOTALL).findall(subset)
        dt = re.compile('</a>[,]*\s*(\d{4}.*?)<',re.DOTALL).findall(dt[0]) if dt else ''
        
        if href and title:
            img = img.group(1).strip() if img else ''
            if img.startswith('/'):
                img = BASEURL+img
            year,lang = dt[0].strip().split('(') if dt else ('','')
            one = {'url'   : href.group(1),
                'title'  : unicodePLchar(title.group(1)),
                'plot'   : unicodePLchar(plot[0]) if plot else '',
                'img'    : img,
                'rating' : rating[0] if rating else '',
                'year'   : year.strip(),
                'genre'  : ''.join(gatunek) if gatunek else '',
                'code'  : lang.replace(')','') ,
                    }
            out.append(one)

    prevPage = {'type':'filmy','page':int(page)-1,'options':''} if page>1 else False
    return (out, (prevPage,nextPage))
    

def getSeasons(url='/serial/Spartakus_Zemsta-2012_s01e01,16223'):
    out=[]
    if url.startswith('/serial'):
        content = getUrl(BASEURL+url)
        aside=re.compile('<aside>(.*?)</aside>',re.DOTALL).findall(content)
        if aside:
            sezony = re.compile('value="(/serial/.*?)">(.*?)</option>').findall(aside[0])
            for href,title in sezony:
                out.append({'title':title.strip(),'url':href})
    return out

def getEpsodes(url='/serial/Spartakus_Zemsta-2012_s01e01,16223'):
    out=[]
    if url.startswith('/serial'):
        content = getUrl(BASEURL+url)
        aside=re.compile('<aside>(.*?)</aside>',re.DOTALL).findall(content)
        if aside:
            aside = aside[0]
            episody = re.compile('<a (.*?)</a>',re.DOTALL).findall(aside)
            for episod in episody:
                #episod=episody[0]
                href_class= re.compile('href="(/serial/.*?)" class="(.*?)"').findall(episod)
                title = re.compile('<span class="ep_tyt">(.*?)</span>').findall(episod)
                if href_class and title:
                    href = href_class[0][0]
                    SE = re.compile('(s\d+e\d+)',re.IGNORECASE).findall(href)
                    clas = href_class[0][1]
                    ep = SE[0] if SE else ''
                    title = '%s: %s'%(ep.upper(),title[0].strip())
                    if not clas or 'active' in clas:
                        out.append({'title':unicodePLchar(title),'url':href})
    return out

def getLinks(url):
    out=[]
    content = getUrl(BASEURL+url)
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="host-container pull-left">', content)]
    out=[]
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ]
        label = re.compile('<span class="label label-default">(.*?)</span>').findall(subset)
        quality = re.compile('title="Jakość: (.*?)"').findall(subset)
        dataurl = re.compile('data-url="(.*?)"').findall(subset)
        if dataurl and label and quality:
            href = re.compile('src="(http.*?)"').findall(dataurl[0].replace('&quot;','"'))
            if href:
                host = urlparse(href[0]).netloc
                title = '[%s] %s %s'%(host,label[0],quality[0])
                out.append({'title':unicodePLchar(title),'url':href[0]})
    return out
   
def getGP(what='gatunek'): #what='produkcja'
    content = getUrl('http://filmy.to/filmy/1')
    value=[]
    label=[]
    select=re.compile('<select name="'+what+'" id="'+what+'" class="form-control">(.*?)</select>',re.DOTALL).findall(content)
    if select:
        out = re.compile('<option value="(.*?)">(.*?)</option>').findall(select[0])
        value = ['%s=%s'%(what,unicodePLchar(x[0])) for x in out]
        value[0]=''
        label= [unicodePLchar(x[1]) for x in out]
    return (value,label)

def search(query='how i'):
    url = 'http://filmy.to/ajax/typeahead'
    out = []
    data = {'q':query}
    header={'User-Agent':UA,
            'X-Requested-With':'XMLHttpRequest',
            'Referer':'http://filmy.to/filmy/1'}
    content = getUrl(url+'?%s'%urllib.urlencode(data),header=header,useCookies=True)
    if content:
        data = json.loads(content)
        out = data.get('movie')
        for m in out:
            m['img']=BASEURL+m.get('img','')
            m['title']=m.get('title_pl')
    return out
    

def unicodePLchar(txt):
    #if type(txt) is not str:
    #    txt=txt.encode('utf-8')

    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    #txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt    