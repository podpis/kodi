# coding: UTF-8
import sys
l1111_fi_ = sys.version_info [0] == 2
l1lll1_fi_ = 2048
l1l11_fi_ = 7
def l11l_fi_ (ll_fi_):
	global l1l11l_fi_
	l1l1l1_fi_ = ord (ll_fi_ [-1])
	l11ll_fi_ = ll_fi_ [:-1]
	l1l_fi_ = l1l1l1_fi_ % len (l11ll_fi_)
	l11_fi_ = l11ll_fi_ [:l1l_fi_] + l11ll_fi_ [l1l_fi_:]
	if l1111_fi_:
		l1llll_fi_ = unicode () .join ([unichr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	else:
		l1llll_fi_ = str () .join ([chr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	return eval (l1llll_fi_)