# coding: UTF-8
from __future__ import unicode_literals
import sys
l1llll_cda_ = sys.version_info [0] == 2
l111ll_cda_ = 2048
l1111l_cda_ = 7
def l1l_cda_ (ll_cda_):
	global l1l1ll_cda_
	l1lll1l_cda_ = ord (ll_cda_ [-1])
	l1ll1l_cda_ = ll_cda_ [:-1]
	l1ll_cda_ = l1lll1l_cda_ % len (l1ll1l_cda_)
	l1l1_cda_ = l1ll1l_cda_ [:l1ll_cda_] + l1ll1l_cda_ [l1ll_cda_:]
	if l1llll_cda_:
		l11lll_cda_ = unicode () .join ([unichr (ord (char) - l111ll_cda_ - (l1lll1_cda_ + l1lll1l_cda_) % l1111l_cda_) for l1lll1_cda_, char in enumerate (l1l1_cda_)])
	else:
		l11lll_cda_ = str () .join ([chr (ord (char) - l111ll_cda_ - (l1lll1_cda_ + l1lll1l_cda_) % l1111l_cda_) for l1lll1_cda_, char in enumerate (l1l1_cda_)])
	return eval (l11lll_cda_)
import sys
import l11111l1l1_cda_
import re
import string
class l1111l1111_cda_(object):
    l1l_cda_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥࡩ࡬ࡢࡵࡶࠤࡩ࡫ࡦࡪࡰࡨࡷࠥࡳࡥࡵࡪࡲࡨࠥࡺ࡯ࠡࡲࡵࡳࡨ࡫ࡳࡴࠢࡶࡸࡷ࡯࡮ࡨࡵࠣ࡭ࡳࠦࡴࡩࡧࠣࡱࡴࡹࡴࠋࠢࠣࠤࠥ࡫ࡦࡧ࡫ࡦ࡭ࡪࡴࡴࠡࡹࡤࡽ࠳ࠦࡉࡥࡧࡤࡰࡱࡿࠠࡢ࡮࡯ࠤࡹ࡮ࡥࠡ࡯ࡨࡸ࡭ࡵࡤࡴࠢࡥࡩࡱࡵࡷࠡࡷࡶࡩࠥࡻ࡮ࡪࡥࡲࡨࡪࠦࡳࡵࡴ࡬ࡲ࡬ࡹࠊࠡࠢࠣࠤ࡫ࡵࡲࠡࡤࡲࡸ࡭ࠦࡩ࡯ࡲࡸࡸࠥࡧ࡮ࡥࠢࡲࡹࡹࡶࡵࡵ࠰ࠍࠤࠥࠦࠠࠣࠤࠥ໙")
    l1111l1l1l_cda_ = re.compile(l1l_cda_ (u"ࡳࠤࠫࡃࡺ࡯ࠩ࡝࡙ࠥ໚"))
    @classmethod
    def l1111l11l1_cda_(cls, l11111lll1_cda_):
        l1l_cda_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࡔࡩ࡫ࡶࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡲࡦࡲ࡯ࡥࡨ࡫ࡳࠡࡣࡱࡽࠥࡹࡥࡲࡷࡨࡲࡨ࡫ࠠࡰࡨࠣࡲࡴࡴࠠ࡭ࡧࡷࡸࡪࡸࡳࠡࡣࡱࡨࠥࡴ࡯࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࡲࡺࡳࡢࡦࡴࡶࠤࡼ࡯ࡴࡩࠢࡤࠤࡸ࡯࡮ࡨ࡮ࡨࠤࡼ࡮ࡩࡵࡧࠣࡷࡵࡧࡣࡦ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢ໛")
        return cls.l1111l1l1l_cda_.sub(l1l_cda_ (u"ࠥࠤࠧໜ"), l11111lll1_cda_)
    strip = staticmethod(string.strip)
    l11111llll_cda_ = staticmethod(string.lower)
    l1111l1l11_cda_ = staticmethod(string.upper)
l1111l11ll_cda_ = sys.version_info[0] == 3
def l11l1lllll_cda_(s):
    try:
        return len(s) > 0
    except TypeError:
        return False
def l11ll1l1ll_cda_(func):
    @l11111l1l1_cda_.l11111ll1l_cda_(func)
    def l111111ll1_cda_(*args, **kwargs):
        if args[0] is None or args[1] is None:
            return 0
        return func(*args, **kwargs)
    return l111111ll1_cda_
def l11l11ll11_cda_(func):
    @l11111l1l1_cda_.l11111ll1l_cda_(func)
    def l111111ll1_cda_(*args, **kwargs):
        if len(args[0]) == 0 or len(args[1]) == 0:
            return 0
        return func(*args, **kwargs)
    return l111111ll1_cda_
l111111lll_cda_ = str(l1l_cda_ (u"ࠦࠧໝ")).join([chr(i) for i in range(128, 256)])
if l1111l11ll_cda_:
    l11111l1ll_cda_ = dict((ord(c), None) for c in l111111lll_cda_)
    unicode = str
def l11111l11l_cda_(s):
    if l1111l11ll_cda_:
        return s.translate(l11111l1ll_cda_)
    else:
        return s.translate(None, l111111lll_cda_)
def l11111l111_cda_(s):
    if type(s) is str:
        return l11111l11l_cda_(s)
    elif type(s) is unicode:
        return l11111l11l_cda_(s.encode(l1l_cda_ (u"ࠬࡧࡳࡤ࡫࡬ࠫໞ"), l1l_cda_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭ໟ")))
    else:
        return l11111l111_cda_(unicode(s))
def l11lllll1l_cda_(s1, s2):
    l1l_cda_ (u"ࠢࠣࠤࡌࡪࠥࡨ࡯ࡵࡪࠣࡳࡧࡰࡥࡤࡶࡶࠤࡦࡸࡥ࡯ࠩࡷࠤࡪ࡯ࡴࡩࡧࡵࠤࡧࡵࡴࡩࠢࡶࡸࡷ࡯࡮ࡨࠢࡲࡶࠥࡻ࡮ࡪࡥࡲࡨࡪࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࡴࠢࡩࡳࡷࡩࡥࠡࡶ࡫ࡩࡲࠦࡴࡰࠢࡸࡲ࡮ࡩ࡯ࡥࡧࠥࠦࠧ໠")
    if isinstance(s1, str) and isinstance(s2, str):
        return s1, s2
    elif isinstance(s1, unicode) and isinstance(s2, unicode):
        return s1, s2
    else:
        return unicode(s1), unicode(s2)
def l11l1lll1l_cda_(s, l11ll1l111_cda_=False):
    l1l_cda_ (u"ࠣࠤࠥࡔࡷࡵࡣࡦࡵࡶࠤࡸࡺࡲࡪࡰࡪࠤࡧࡿࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠯࠰ࠤࡷ࡫࡭ࡰࡸ࡬ࡲ࡬ࠦࡡ࡭࡮ࠣࡦࡺࡺࠠ࡭ࡧࡷࡸࡪࡸࡳࠡࡣࡱࡨࠥࡴࡵ࡮ࡤࡨࡶࡸࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠮࠯ࠣࡸࡷ࡯࡭ࠡࡹ࡫࡭ࡹ࡫ࡳࡱࡣࡦࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠭࠮ࠢࡩࡳࡷࡩࡥࠡࡶࡲࠤࡱࡵࡷࡦࡴࠣࡧࡦࡹࡥࠋࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥ࡬࡯ࡳࡥࡨࡣࡦࡹࡣࡪ࡫ࠣࡁࡂࠦࡔࡳࡷࡨ࠰ࠥ࡬࡯ࡳࡥࡨࠤࡨࡵ࡮ࡷࡧࡵࡸࠥࡺ࡯ࠡࡣࡶࡧ࡮࡯ࠢࠣࠤ໡")
    if s is None:
        return l1l_cda_ (u"ࠤࠥ໢")
    if l11ll1l111_cda_:
        s = l11111l111_cda_(s)
    l11111ll11_cda_ = l1111l1111_cda_.l1111l11l1_cda_(s)
    l11111ll11_cda_ = l1111l1111_cda_.l11111llll_cda_(l11111ll11_cda_)
    l11111ll11_cda_ = l1111l1111_cda_.strip(l11111ll11_cda_)
    return l11111ll11_cda_
def l11lll1lll_cda_(n):
    l1l_cda_ (u"ࠪࠫࠬࡘࡥࡵࡷࡵࡲࡸࠦࡡࠡࡥࡲࡶࡷ࡫ࡣࡵ࡮ࡼࠤࡷࡵࡵ࡯ࡦࡨࡨࠥ࡯࡮ࡵࡧࡪࡩࡷ࠭ࠧࠨ໣")
    return int(round(n))