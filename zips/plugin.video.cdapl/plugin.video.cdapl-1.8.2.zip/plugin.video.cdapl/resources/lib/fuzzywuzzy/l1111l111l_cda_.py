# coding: UTF-8
from __future__ import unicode_literals
import sys
l1llll_cda_ = sys.version_info [0] == 2
l111ll_cda_ = 2048
l1111l_cda_ = 7
def l1l_cda_ (ll_cda_):
	global l1l1ll_cda_
	l1lll1l_cda_ = ord (ll_cda_ [-1])
	l1ll1l_cda_ = ll_cda_ [:-1]
	l1ll_cda_ = l1lll1l_cda_ % len (l1ll1l_cda_)
	l1l1_cda_ = l1ll1l_cda_ [:l1ll_cda_] + l1ll1l_cda_ [l1ll_cda_:]
	if l1llll_cda_:
		l11lll_cda_ = unicode () .join ([unichr (ord (char) - l111ll_cda_ - (l1lll1_cda_ + l1lll1l_cda_) % l1111l_cda_) for l1lll1_cda_, char in enumerate (l1l1_cda_)])
	else:
		l11lll_cda_ = str () .join ([chr (ord (char) - l111ll_cda_ - (l1lll1_cda_ + l1lll1l_cda_) % l1111l_cda_) for l1lll1_cda_, char in enumerate (l1l1_cda_)])
	return eval (l11lll_cda_)
import re
import string
import sys
l1111l11ll_cda_ = sys.version_info[0] == 3
if l1111l11ll_cda_:
    string = str
class l1111l1111_cda_(object):
    l1l_cda_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࡘ࡭࡯ࡳࠡࡥ࡯ࡥࡸࡹࠠࡥࡧࡩ࡭ࡳ࡫ࡳࠡ࡯ࡨࡸ࡭ࡵࡤࠡࡶࡲࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࡹࡴࡳ࡫ࡱ࡫ࡸࠦࡩ࡯ࠢࡷ࡬ࡪࠦ࡭ࡰࡵࡷࠎࠥࠦࠠࠡࡧࡩࡪ࡮ࡩࡩࡦࡰࡷࠤࡼࡧࡹ࠯ࠢࡌࡨࡪࡧ࡬࡭ࡻࠣࡥࡱࡲࠠࡵࡪࡨࠤࡲ࡫ࡴࡩࡱࡧࡷࠥࡨࡥ࡭ࡱࡺࠤࡺࡹࡥࠡࡷࡱ࡭ࡨࡵࡤࡦࠢࡶࡸࡷ࡯࡮ࡨࡵࠍࠤࠥࠦࠠࡧࡱࡵࠤࡧࡵࡴࡩࠢ࡬ࡲࡵࡻࡴࠡࡣࡱࡨࠥࡵࡵࡵࡲࡸࡸ࠳ࠐࠠࠡࠢࠣࠦࠧࠨ໕")
    l1111l1l1l_cda_ = re.compile(l1l_cda_ (u"ࡶࠧ࠮࠿ࡶ࡫ࠬࡠ࡜ࠨ໖"))
    @classmethod
    def l1111l11l1_cda_(cls, l11111lll1_cda_):
        l1l_cda_ (u"ࠧࠨࠢࠋࠢࠣࠤࠥࠦࠠࠡࠢࡗ࡬࡮ࡹࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡵࡩࡵࡲࡡࡤࡧࡶࠤࡦࡴࡹࠡࡵࡨࡵࡺ࡫࡮ࡤࡧࠣࡳ࡫ࠦ࡮ࡰࡰࠣࡰࡪࡺࡴࡦࡴࡶࠤࡦࡴࡤࠡࡰࡲࡲࠏࠦࠠࠡࠢࠣࠤࠥࠦ࡮ࡶ࡯ࡥࡩࡷࡹࠠࡸ࡫ࡷ࡬ࠥࡧࠠࡴ࡫ࡱ࡫ࡱ࡫ࠠࡸࡪ࡬ࡸࡪࠦࡳࡱࡣࡦࡩ࠳ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ໗")
        return cls.l1111l1l1l_cda_.sub(l1l_cda_ (u"ࠨࠠࠣ໘"), l11111lll1_cda_)
    strip = staticmethod(string.strip)
    l11111llll_cda_ = staticmethod(string.lower)
    l1111l1l11_cda_ = staticmethod(string.upper)