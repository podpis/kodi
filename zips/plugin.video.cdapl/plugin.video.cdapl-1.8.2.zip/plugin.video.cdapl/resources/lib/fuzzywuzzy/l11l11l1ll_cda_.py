#!/usr/bin/env python
# encoding: utf-8
from __future__ import unicode_literals
import sys
l1llll_cda_ = sys.version_info [0] == 2
l111ll_cda_ = 2048
l1111l_cda_ = 7
def l1l_cda_ (ll_cda_):
	global l1l1ll_cda_
	l1lll1l_cda_ = ord (ll_cda_ [-1])
	l1ll1l_cda_ = ll_cda_ [:-1]
	l1ll_cda_ = l1lll1l_cda_ % len (l1ll1l_cda_)
	l1l1_cda_ = l1ll1l_cda_ [:l1ll_cda_] + l1ll1l_cda_ [l1ll_cda_:]
	if l1llll_cda_:
		l11lll_cda_ = unicode () .join ([unichr (ord (char) - l111ll_cda_ - (l1lll1_cda_ + l1lll1l_cda_) % l1111l_cda_) for l1lll1_cda_, char in enumerate (l1l1_cda_)])
	else:
		l11lll_cda_ = str () .join ([chr (ord (char) - l111ll_cda_ - (l1lll1_cda_ + l1lll1l_cda_) % l1111l_cda_) for l1lll1_cda_, char in enumerate (l1l1_cda_)])
	return eval (l11lll_cda_)
l1l_cda_ (u"ࠥࠦࠧࠐࡦࡶࡼࡽ࠲ࡵࡿࠊࠋࡅࡲࡴࡾࡸࡩࡨࡪࡷࠤ࠭ࡩࠩࠡ࠴࠳࠵࠶ࠦࡁࡥࡣࡰࠤࡈࡵࡨࡦࡰࠍࠎࡕ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࠡ࡫ࡶࠤ࡭࡫ࡲࡦࡤࡼࠤ࡬ࡸࡡ࡯ࡶࡨࡨ࠱ࠦࡦࡳࡧࡨࠤࡴ࡬ࠠࡤࡪࡤࡶ࡬࡫ࠬࠡࡶࡲࠤࡦࡴࡹࠡࡲࡨࡶࡸࡵ࡮ࠡࡱࡥࡸࡦ࡯࡮ࡪࡰࡪࠎࡦࠦࡣࡰࡲࡼࠤࡴ࡬ࠠࡵࡪ࡬ࡷࠥࡹ࡯ࡧࡶࡺࡥࡷ࡫ࠠࡢࡰࡧࠤࡦࡹࡳࡰࡥ࡬ࡥࡹ࡫ࡤࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡࡨ࡬ࡰࡪࡹࠠࠩࡶ࡫ࡩࠏࠨࡓࡰࡨࡷࡻࡦࡸࡥࠣࠫ࠯ࠤࡹࡵࠠࡥࡧࡤࡰࠥ࡯࡮ࠡࡶ࡫ࡩ࡙ࠥ࡯ࡧࡶࡺࡥࡷ࡫ࠠࡸ࡫ࡷ࡬ࡴࡻࡴࠡࡴࡨࡷࡹࡸࡩࡤࡶ࡬ࡳࡳ࠲ࠠࡪࡰࡦࡰࡺࡪࡩ࡯ࡩࠍࡻ࡮ࡺࡨࡰࡷࡷࠤࡱ࡯࡭ࡪࡶࡤࡸ࡮ࡵ࡮ࠡࡶ࡫ࡩࠥࡸࡩࡨࡪࡷࡷࠥࡺ࡯ࠡࡷࡶࡩ࠱ࠦࡣࡰࡲࡼ࠰ࠥࡳ࡯ࡥ࡫ࡩࡽ࠱ࠦ࡭ࡦࡴࡪࡩ࠱ࠦࡰࡶࡤ࡯࡭ࡸ࡮ࠬࠋࡦ࡬ࡷࡹࡸࡩࡣࡷࡷࡩ࠱ࠦࡳࡶࡤ࡯࡭ࡨ࡫࡮ࡴࡧ࠯ࠤࡦࡴࡤ࠰ࡱࡵࠤࡸ࡫࡬࡭ࠢࡦࡳࡵ࡯ࡥࡴࠢࡲࡪࠥࡺࡨࡦࠢࡖࡳ࡫ࡺࡷࡢࡴࡨ࠰ࠥࡧ࡮ࡥࠢࡷࡳࠏࡶࡥࡳ࡯࡬ࡸࠥࡶࡥࡳࡵࡲࡲࡸࠦࡴࡰࠢࡺ࡬ࡴࡳࠠࡵࡪࡨࠤࡘࡵࡦࡵࡹࡤࡶࡪࠦࡩࡴࠢࡩࡹࡷࡴࡩࡴࡪࡨࡨࠥࡺ࡯ࠡࡦࡲࠤࡸࡵࠬࠡࡵࡸࡦ࡯࡫ࡣࡵࠢࡷࡳࠏࡺࡨࡦࠢࡩࡳࡱࡲ࡯ࡸ࡫ࡱ࡫ࠥࡩ࡯࡯ࡦ࡬ࡸ࡮ࡵ࡮ࡴ࠼ࠍࠎ࡙࡮ࡥࠡࡣࡥࡳࡻ࡫ࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡲࡴࡺࡩࡤࡧࠣࡥࡳࡪࠠࡵࡪ࡬ࡷࠥࡶࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࠢࡱࡳࡹ࡯ࡣࡦࠢࡶ࡬ࡦࡲ࡬ࠡࡤࡨࠎ࡮ࡴࡣ࡭ࡷࡧࡩࡩࠦࡩ࡯ࠢࡤࡰࡱࠦࡣࡰࡲ࡬ࡩࡸࠦ࡯ࡳࠢࡶࡹࡧࡹࡴࡢࡰࡷ࡭ࡦࡲࠠࡱࡱࡵࡸ࡮ࡵ࡮ࡴࠢࡲࡪࠥࡺࡨࡦࠢࡖࡳ࡫ࡺࡷࡢࡴࡨ࠲ࠏࠐࡔࡉࡇࠣࡗࡔࡌࡔࡘࡃࡕࡉࠥࡏࡓࠡࡒࡕࡓ࡛ࡏࡄࡆࡆࠣࠦࡆ࡙ࠠࡊࡕࠥ࠰ࠥ࡝ࡉࡕࡊࡒ࡙࡙ࠦࡗࡂࡔࡕࡅࡓ࡚࡙ࠡࡑࡉࠤࡆࡔ࡙ࠡࡍࡌࡒࡉ࠲ࠊࡆ࡚ࡓࡖࡊ࡙ࡓࠡࡑࡕࠤࡎࡓࡐࡍࡋࡈࡈ࠱ࠦࡉࡏࡅࡏ࡙ࡉࡏࡎࡈࠢࡅ࡙࡙ࠦࡎࡐࡖࠣࡐࡎࡓࡉࡕࡇࡇࠤ࡙ࡕࠠࡕࡊࡈࠤ࡜ࡇࡒࡓࡃࡑࡘࡎࡋࡓࠡࡑࡉࠎࡒࡋࡒࡄࡊࡄࡒ࡙ࡇࡂࡊࡎࡌࡘ࡞࠲ࠠࡇࡋࡗࡒࡊ࡙ࡓࠡࡈࡒࡖࠥࡇࠠࡑࡃࡕࡘࡎࡉࡕࡍࡃࡕࠤࡕ࡛ࡒࡑࡑࡖࡉࠥࡇࡎࡅࠌࡑࡓࡓࡏࡎࡇࡔࡌࡒࡌࡋࡍࡆࡐࡗ࠲ࠥࡏࡎࠡࡐࡒࠤࡊ࡜ࡅࡏࡖࠣࡗࡍࡇࡌࡍࠢࡗࡌࡊࠦࡁࡖࡖࡋࡓࡗ࡙ࠠࡐࡔࠣࡇࡔࡖ࡙ࡓࡋࡊࡌ࡙ࠦࡈࡐࡎࡇࡉࡗ࡙ࠠࡃࡇࠍࡐࡎࡇࡂࡍࡇࠣࡊࡔࡘࠠࡂࡐ࡜ࠤࡈࡒࡁࡊࡏ࠯ࠤࡉࡇࡍࡂࡉࡈࡗࠥࡕࡒࠡࡑࡗࡌࡊࡘࠠࡍࡋࡄࡆࡎࡒࡉࡕ࡛࠯ࠤ࡜ࡎࡅࡕࡊࡈࡖࠥࡏࡎࠡࡃࡑࠤࡆࡉࡔࡊࡑࡑࠎࡔࡌࠠࡄࡑࡑࡘࡗࡇࡃࡕ࠮ࠣࡘࡔࡘࡔࠡࡑࡕࠤࡔ࡚ࡈࡆࡔ࡚ࡍࡘࡋࠬࠡࡃࡕࡍࡘࡏࡎࡈࠢࡉࡖࡔࡓࠬࠡࡑࡘࡘࠥࡕࡆࠡࡑࡕࠤࡎࡔࠠࡄࡑࡑࡒࡊࡉࡔࡊࡑࡑࠎ࡜ࡏࡔࡉࠢࡗࡌࡊࠦࡓࡐࡈࡗ࡛ࡆࡘࡅࠡࡑࡕࠤ࡙ࡎࡅࠡࡗࡖࡉࠥࡕࡒࠡࡑࡗࡌࡊࡘࠠࡅࡇࡄࡐࡎࡔࡇࡔࠢࡌࡒ࡚ࠥࡈࡆࠢࡖࡓࡋ࡚ࡗࡂࡔࡈ࠲ࠏࠨູࠢࠣ")
import platform
import warnings
from l11llll1l1_cda_ import l11ll11l11_cda_
from . import l11ll111ll_cda_
@l11ll111ll_cda_.l11ll1l1ll_cda_
@l11ll111ll_cda_.l11l11ll11_cda_
def l11ll1llll_cda_(s1, s2):
    s1, s2 = l11ll111ll_cda_.l11lllll1l_cda_(s1, s2)
    m = l11ll11l11_cda_(None, s1, s2)
    return l11ll111ll_cda_.l11lll1lll_cda_(100 * m.l11ll1llll_cda_())
@l11ll111ll_cda_.l11ll1l1ll_cda_
@l11ll111ll_cda_.l11l11ll11_cda_
def l11ll11111_cda_(s1, s2):
    l1l_cda_ (u"ࠦࠧࠨࠢࡓࡧࡷࡹࡷࡴࠠࡵࡪࡨࠤࡷࡧࡴࡪࡱࠣࡳ࡫ࠦࡴࡩࡧࠣࡱࡴࡹࡴࠡࡵ࡬ࡱ࡮ࡲࡡࡳࠢࡶࡹࡧࡹࡴࡳ࡫ࡱ࡫ࠏࠦࠠࠡࠢࡤࡷࠥࡧࠠ࡯ࡷࡰࡦࡪࡸࠠࡣࡧࡷࡻࡪ࡫࡮ࠡ࠲ࠣࡥࡳࡪࠠ࠲࠲࠳࠲ࠧࠨ຺ࠢ")
    s1, s2 = l11ll111ll_cda_.l11lllll1l_cda_(s1, s2)
    if len(s1) <= len(s2):
        l11ll1l1l1_cda_ = s1
        l11l1l111l_cda_ = s2
    else:
        l11ll1l1l1_cda_ = s2
        l11l1l111l_cda_ = s1
    m = l11ll11l11_cda_(None, l11ll1l1l1_cda_, l11l1l111l_cda_)
    l11ll1111l_cda_ = m.l11ll1ll1l_cda_()
    l11l1ll11l_cda_ = []
    for block in l11ll1111l_cda_:
        l11l1l1l11_cda_ = block[1] - block[0] if (block[1] - block[0]) > 0 else 0
        l11l1ll111_cda_ = l11l1l1l11_cda_ + len(l11ll1l1l1_cda_)
        l11lllllll_cda_ = l11l1l111l_cda_[l11l1l1l11_cda_:l11l1ll111_cda_]
        l11ll11lll_cda_ = l11ll11l11_cda_(None, l11ll1l1l1_cda_, l11lllllll_cda_)
        r = l11ll11lll_cda_.l11ll1llll_cda_()
        if r > .995:
            return 100
        else:
            l11l1ll11l_cda_.append(r)
    return l11ll111ll_cda_.l11lll1lll_cda_(100 * max(l11l1ll11l_cda_))
def _11l1l11ll_cda_(s, l11ll1l111_cda_, l11l1lll1l_cda_=True):
    l1l_cda_ (u"ࠧࠨࠢࡓࡧࡷࡹࡷࡴࠠࡢࠢࡦࡰࡪࡧ࡮ࡦࡦࠣࡷࡹࡸࡩ࡯ࡩࠣࡻ࡮ࡺࡨࠡࡶࡲ࡯ࡪࡴࠠࡴࡱࡵࡸࡪࡪ࠮ࠣࠤࠥົ")
    l11ll1ll11_cda_ = l11ll111ll_cda_.l11l1lll1l_cda_(s, l11ll1l111_cda_=l11ll1l111_cda_) if l11l1lll1l_cda_ else s
    l11l1ll1ll_cda_ = l11ll1ll11_cda_.split()
    l1l111111l_cda_ = l1l_cda_ (u"ࡻࠢࠡࠤຼ").join(sorted(l11l1ll1ll_cda_))
    return l1l111111l_cda_.strip()
@l11ll111ll_cda_.l11ll1l1ll_cda_
def _11l1l1111_cda_(s1, s2, partial=True, l11ll1l111_cda_=True, l11l1lll1l_cda_=True):
    l11ll1lll1_cda_ = _11l1l11ll_cda_(s1, l11ll1l111_cda_, l11l1lll1l_cda_=l11l1lll1l_cda_)
    l11l11llll_cda_ = _11l1l11ll_cda_(s2, l11ll1l111_cda_, l11l1lll1l_cda_=l11l1lll1l_cda_)
    if partial:
        return l11ll11111_cda_(l11ll1lll1_cda_, l11l11llll_cda_)
    else:
        return l11ll1llll_cda_(l11ll1lll1_cda_, l11l11llll_cda_)
def l1l11111ll_cda_(s1, s2, l11ll1l111_cda_=True, l11l1lll1l_cda_=True):
    l1l_cda_ (u"ࠢࠣࠤࡕࡩࡹࡻࡲ࡯ࠢࡤࠤࡲ࡫ࡡࡴࡷࡵࡩࠥࡵࡦࠡࡶ࡫ࡩࠥࡹࡥࡲࡷࡨࡲࡨ࡫ࡳࠨࠢࡶ࡭ࡲ࡯࡬ࡢࡴ࡬ࡸࡾࠦࡢࡦࡶࡺࡩࡪࡴࠠ࠱ࠢࡤࡲࡩࠦ࠱࠱࠲ࠍࠤࠥࠦࠠࡣࡷࡷࠤࡸࡵࡲࡵ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡷࡳࡰ࡫࡮ࠡࡤࡨࡪࡴࡸࡥࠡࡥࡲࡱࡵࡧࡲࡪࡰࡪ࠲ࠏࠦࠠࠡࠢࠥࠦࠧຽ")
    return _11l1l1111_cda_(s1, s2, partial=False, l11ll1l111_cda_=l11ll1l111_cda_, l11l1lll1l_cda_=l11l1lll1l_cda_)
def l11llll11l_cda_(s1, s2, l11ll1l111_cda_=True, l11l1lll1l_cda_=True):
    l1l_cda_ (u"ࠣࠤࠥࡖࡪࡺࡵࡳࡰࠣࡸ࡭࡫ࠠࡳࡣࡷ࡭ࡴࠦ࡯ࡧࠢࡷ࡬ࡪࠦ࡭ࡰࡵࡷࠤࡸ࡯࡭ࡪ࡮ࡤࡶࠥࡹࡵࡣࡵࡷࡶ࡮ࡴࡧࠡࡣࡶࠤࡦࠦ࡮ࡶ࡯ࡥࡩࡷࠦࡢࡦࡶࡺࡩࡪࡴࠊࠡࠢࠣࠤ࠵ࠦࡡ࡯ࡦࠣ࠵࠵࠶ࠠࡣࡷࡷࠤࡸࡵࡲࡵ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡷࡳࡰ࡫࡮ࠡࡤࡨࡪࡴࡸࡥࠡࡥࡲࡱࡵࡧࡲࡪࡰࡪ࠲ࠏࠦࠠࠡࠢࠥࠦࠧ຾")
    return _11l1l1111_cda_(s1, s2, partial=True, l11ll1l111_cda_=l11ll1l111_cda_, l11l1lll1l_cda_=l11l1lll1l_cda_)
@l11ll111ll_cda_.l11ll1l1ll_cda_
def _11lll11ll_cda_(s1, s2, partial=True, l11ll1l111_cda_=True, l11l1lll1l_cda_=True):
    l1l_cda_ (u"ࠤࠥࠦࡋ࡯࡮ࡥࠢࡤࡰࡱࠦࡡ࡭ࡲ࡫ࡥࡳࡻ࡭ࡦࡴ࡬ࡧࠥࡺ࡯࡬ࡧࡱࡷࠥ࡯࡮ࠡࡧࡤࡧ࡭ࠦࡳࡵࡴ࡬ࡲ࡬࠴࠮࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡺࡲࡦࡣࡷࠤࡹ࡮ࡥ࡮ࠢࡤࡷࠥࡧࠠࡴࡧࡷࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡤࡱࡱࡷࡹࡸࡵࡤࡶࠣࡸࡼࡵࠠࡴࡶࡵ࡭ࡳ࡭ࡳࠡࡱࡩࠤࡹ࡮ࡥࠡࡨࡲࡶࡲࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂࡳࡰࡴࡷࡩࡩࡥࡩ࡯ࡶࡨࡶࡸ࡫ࡣࡵ࡫ࡲࡲࡃࡂࡳࡰࡴࡷࡩࡩࡥࡲࡦ࡯ࡤ࡭ࡳࡪࡥࡳࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡴࡢ࡭ࡨࠤࡷࡧࡴࡪࡱࡶࠤࡴ࡬ࠠࡵࡪࡲࡷࡪࠦࡴࡸࡱࠣࡷࡹࡸࡩ࡯ࡩࡶࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡤࡱࡱࡸࡷࡵ࡬ࡴࠢࡩࡳࡷࠦࡵ࡯ࡱࡵࡨࡪࡸࡥࡥࠢࡳࡥࡷࡺࡩࡢ࡮ࠣࡱࡦࡺࡣࡩࡧࡶࠦࠧࠨ຿")
    l11l1l11l1_cda_ = l11ll111ll_cda_.l11l1lll1l_cda_(s1, l11ll1l111_cda_=l11ll1l111_cda_) if l11l1lll1l_cda_ else s1
    l11l1l1l1l_cda_ = l11ll111ll_cda_.l11l1lll1l_cda_(s2, l11ll1l111_cda_=l11ll1l111_cda_) if l11l1lll1l_cda_ else s2
    if not l11ll111ll_cda_.l11l1lllll_cda_(l11l1l11l1_cda_):
        return 0
    if not l11ll111ll_cda_.l11l1lllll_cda_(l11l1l1l1l_cda_):
        return 0
    l11ll1l11l_cda_ = set(l11l1l11l1_cda_.split())
    l11l1llll1_cda_ = set(l11l1l1l1l_cda_.split())
    intersection = l11ll1l11l_cda_.intersection(l11l1llll1_cda_)
    l11lllll11_cda_ = l11ll1l11l_cda_.difference(l11l1llll1_cda_)
    l1l11111l1_cda_ = l11l1llll1_cda_.difference(l11ll1l11l_cda_)
    l11lll1ll1_cda_ = l1l_cda_ (u"ࠥࠤࠧເ").join(sorted(intersection))
    l11l11ll1l_cda_ = l1l_cda_ (u"ࠦࠥࠨແ").join(sorted(l11lllll11_cda_))
    l11l11l11l_cda_ = l1l_cda_ (u"ࠧࠦࠢໂ").join(sorted(l1l11111l1_cda_))
    l11lll1l1l_cda_ = l11lll1ll1_cda_ + l1l_cda_ (u"ࠨࠠࠣໃ") + l11l11ll1l_cda_
    l11l1lll11_cda_ = l11lll1ll1_cda_ + l1l_cda_ (u"ࠢࠡࠤໄ") + l11l11l11l_cda_
    l11lll1ll1_cda_ = l11lll1ll1_cda_.strip()
    l11lll1l1l_cda_ = l11lll1l1l_cda_.strip()
    l11l1lll11_cda_ = l11l1lll11_cda_.strip()
    if partial:
        l11lll1l11_cda_ = l11ll11111_cda_
    else:
        l11lll1l11_cda_ = l11ll1llll_cda_
    l11l11l1l1_cda_ = [
        l11lll1l11_cda_(l11lll1ll1_cda_, l11lll1l1l_cda_),
        l11lll1l11_cda_(l11lll1ll1_cda_, l11l1lll11_cda_),
        l11lll1l11_cda_(l11lll1l1l_cda_, l11l1lll11_cda_)
    ]
    return max(l11l11l1l1_cda_)
def l1l1111111_cda_(s1, s2, l11ll1l111_cda_=True, l11l1lll1l_cda_=True):
    return _11lll11ll_cda_(s1, s2, partial=False, l11ll1l111_cda_=l11ll1l111_cda_, l11l1lll1l_cda_=l11l1lll1l_cda_)
def l11l11lll1_cda_(s1, s2, l11ll1l111_cda_=True, l11l1lll1l_cda_=True):
    return _11lll11ll_cda_(s1, s2, partial=True, l11ll1l111_cda_=l11ll1l111_cda_, l11l1lll1l_cda_=l11l1lll1l_cda_)
def l11llll111_cda_(s1, s2, l11ll1l111_cda_=True):
    l11l1l11l1_cda_ = l11ll111ll_cda_.l11l1lll1l_cda_(s1, l11ll1l111_cda_=l11ll1l111_cda_)
    l11l1l1l1l_cda_ = l11ll111ll_cda_.l11l1lll1l_cda_(s2, l11ll1l111_cda_=l11ll1l111_cda_)
    if not l11ll111ll_cda_.l11l1lllll_cda_(l11l1l11l1_cda_):
        return 0
    if not l11ll111ll_cda_.l11l1lllll_cda_(l11l1l1l1l_cda_):
        return 0
    return l11ll1llll_cda_(l11l1l11l1_cda_, l11l1l1l1l_cda_)
def l11l1l1lll_cda_(s1, s2):
    return l11llll111_cda_(s1, s2, l11ll1l111_cda_=False)
def l11llllll1_cda_(s1, s2, l11ll1l111_cda_=True):
    l1l_cda_ (u"ࠣࠤࠥࡖࡪࡺࡵࡳࡰࠣࡥࠥࡳࡥࡢࡵࡸࡶࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡳࡦࡳࡸࡩࡳࡩࡥࡴࠩࠣࡷ࡮ࡳࡩ࡭ࡣࡵ࡭ࡹࡿࠠࡣࡧࡷࡻࡪ࡫࡮ࠡ࠲ࠣࡥࡳࡪࠠ࠲࠲࠳࠰ࠏࠦࠠࠡࠢࡸࡷ࡮ࡴࡧࠡࡦ࡬ࡪ࡫࡫ࡲࡦࡰࡷࠤࡦࡲࡧࡰࡴ࡬ࡸ࡭ࡳࡳ࠯ࠌࠣࠤࠥࠦࠢࠣࠤ໅")
    l11l1l11l1_cda_ = l11ll111ll_cda_.l11l1lll1l_cda_(s1, l11ll1l111_cda_=l11ll1l111_cda_)
    l11l1l1l1l_cda_ = l11ll111ll_cda_.l11l1lll1l_cda_(s2, l11ll1l111_cda_=l11ll1l111_cda_)
    if not l11ll111ll_cda_.l11l1lllll_cda_(l11l1l11l1_cda_):
        return 0
    if not l11ll111ll_cda_.l11l1lllll_cda_(l11l1l1l1l_cda_):
        return 0
    l11ll11l1l_cda_ = True
    l11l1l1ll1_cda_ = .95
    l11l1ll1l1_cda_ = .90
    base = l11ll1llll_cda_(l11l1l11l1_cda_, l11l1l1l1l_cda_)
    l11ll111l1_cda_ = float(max(len(l11l1l11l1_cda_), len(l11l1l1l1l_cda_))) / min(len(l11l1l11l1_cda_), len(l11l1l1l1l_cda_))
    if l11ll111l1_cda_ < 1.5:
        l11ll11l1l_cda_ = False
    if l11ll111l1_cda_ > 8:
        l11l1ll1l1_cda_ = .6
    if l11ll11l1l_cda_:
        partial = l11ll11111_cda_(l11l1l11l1_cda_, l11l1l1l1l_cda_) * l11l1ll1l1_cda_
        l11lll1111_cda_ = l11llll11l_cda_(l11l1l11l1_cda_, l11l1l1l1l_cda_, l11l1lll1l_cda_=False) \
            * l11l1l1ll1_cda_ * l11l1ll1l1_cda_
        l11lll111l_cda_ = l11l11lll1_cda_(l11l1l11l1_cda_, l11l1l1l1l_cda_, l11l1lll1l_cda_=False) \
            * l11l1l1ll1_cda_ * l11l1ll1l1_cda_
        return l11ll111ll_cda_.l11lll1lll_cda_(max(base, partial, l11lll1111_cda_, l11lll111l_cda_))
    else:
        l11ll11ll1_cda_ = l1l11111ll_cda_(l11l1l11l1_cda_, l11l1l1l1l_cda_, l11l1lll1l_cda_=False) * l11l1l1ll1_cda_
        l11llll1ll_cda_ = l1l1111111_cda_(l11l1l11l1_cda_, l11l1l1l1l_cda_, l11l1lll1l_cda_=False) * l11l1l1ll1_cda_
        return l11ll111ll_cda_.l11lll1lll_cda_(max(base, l11ll11ll1_cda_, l11llll1ll_cda_))
def l11lll11l1_cda_(s1, s2):
    l1l_cda_ (u"ࠤࠥࠦࡗ࡫ࡴࡶࡴࡱࠤࡦࠦ࡭ࡦࡣࡶࡹࡷ࡫ࠠࡰࡨࠣࡸ࡭࡫ࠠࡴࡧࡴࡹࡪࡴࡣࡦࡵࠪࠤࡸ࡯࡭ࡪ࡮ࡤࡶ࡮ࡺࡹࠡࡤࡨࡸࡼ࡫ࡥ࡯ࠢ࠳ࠤࡦࡴࡤࠡ࠳࠳࠴࠱ࠐࠠࠡࠢࠣࡹࡸ࡯࡮ࡨࠢࡧ࡭࡫࡬ࡥࡳࡧࡱࡸࠥࡧ࡬ࡨࡱࡵ࡭ࡹ࡮࡭ࡴ࠰ࠣࡗࡦࡳࡥࠡࡣࡶࠤ࡜ࡘࡡࡵ࡫ࡲࠤࡧࡻࡴࠡࡲࡵࡩࡸ࡫ࡲࡷ࡫ࡱ࡫ࠥࡻ࡮ࡪࡥࡲࡨࡪ࠴ࠊࠡࠢࠣࠤࠧࠨࠢໆ")
    return l11llllll1_cda_(s1, s2, l11ll1l111_cda_=False)