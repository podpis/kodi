#!/usr/bin/env python
# encoding: utf-8
import sys
l1llll_cda_ = sys.version_info [0] == 2
l111ll_cda_ = 2048
l1111l_cda_ = 7
def l1l_cda_ (ll_cda_):
	global l1l1ll_cda_
	l1lll1l_cda_ = ord (ll_cda_ [-1])
	l1ll1l_cda_ = ll_cda_ [:-1]
	l1ll_cda_ = l1lll1l_cda_ % len (l1ll1l_cda_)
	l1l1_cda_ = l1ll1l_cda_ [:l1ll_cda_] + l1ll1l_cda_ [l1ll_cda_:]
	if l1llll_cda_:
		l11lll_cda_ = unicode () .join ([unichr (ord (char) - l111ll_cda_ - (l1lll1_cda_ + l1lll1l_cda_) % l1111l_cda_) for l1lll1_cda_, char in enumerate (l1l1_cda_)])
	else:
		l11lll_cda_ = str () .join ([chr (ord (char) - l111ll_cda_ - (l1lll1_cda_ + l1lll1l_cda_) % l1111l_cda_) for l1lll1_cda_, char in enumerate (l1l1_cda_)])
	return eval (l11lll_cda_)
l1l_cda_ (u"ࠧࠨࠢࠋࡕࡷࡶ࡮ࡴࡧࡎࡣࡷࡧ࡭࡫ࡲ࠯ࡲࡼࠎࠏࡶ࡯ࡳࡶࡨࡨࠥ࡬ࡲࡰ࡯ࠣࡴࡾࡺࡨࡰࡰ࠰ࡐࡪࡼࡥ࡯ࡵ࡫ࡸࡪ࡯࡮ࠋ࡝࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯࡮࡫ࡲ࡬ࡹࡧ࡭ࡢ࠱ࡳࡽࡹ࡮࡯࡯࠯ࡏࡩࡻ࡫࡮ࡴࡪࡷࡩ࡮ࡴ࡝ࠋࡎ࡬ࡧࡪࡴࡳࡦࠢࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥ࡮ࡥࡳࡧ࠽ࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱ࡰ࡭ࡴ࡮ࡴࡢ࡯ࡤ࠳ࡵࡿࡴࡩࡱࡱ࠱ࡑ࡫ࡶࡦࡰࡶ࡬ࡹ࡫ࡩ࡯࠱ࡥࡰࡴࡨ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡄࡑࡓ࡝ࡎࡔࡇࠋࠤࠥࠦ໐")
from l1111ll1ll_cda_ import *
from warnings import warn
class l111l11l11_cda_:
    l1l_cda_ (u"ࠨࠢࠣࡃࠣࡗࡪࡷࡵࡦࡰࡦࡩࡒࡧࡴࡤࡪࡨࡶ࠲ࡲࡩ࡬ࡧࠣࡧࡱࡧࡳࡴࠢࡥࡹ࡮ࡲࡴࠡࡱࡱࠤࡹ࡮ࡥࠡࡶࡲࡴࠥࡵࡦࠡࡎࡨࡺࡪࡴࡳࡩࡶࡨ࡭ࡳࠨࠢࠣ໑")
    def _1111l1ll1_cda_(self):
        self._111l1llll_cda_ = self._111l11l1l_cda_ = None
        self._111l1l1l1_cda_ = self._1111lll11_cda_ = self._111l1l111_cda_ = None
    def __init__(self, l1111ll11l_cda_=None, l1111l1lll_cda_=l1l_cda_ (u"ࠧࠨ໒"), l1111ll111_cda_=l1l_cda_ (u"ࠨࠩ໓")):
        if l1111ll11l_cda_:
            warn(l1l_cda_ (u"ࠤ࡬ࡷ࡯ࡻ࡮࡬ࠢࡱࡳࡹࠦࡎࡐࡖࠣ࡭ࡲࡶ࡬ࡦ࡯ࡨࡲࡹ࡫ࡤ࠭ࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡩࡨࡰࡲࡶࡪࡪࠢ໔"))
        self._111l11lll_cda_, self._111l11ll1_cda_ = l1111l1lll_cda_, l1111ll111_cda_
        self._1111l1ll1_cda_()
    def l1111llll1_cda_(self, l1111l1lll_cda_, l1111ll111_cda_):
        self._111l11lll_cda_, self._111l11ll1_cda_ = l1111l1lll_cda_, l1111ll111_cda_
        self._1111l1ll1_cda_()
    def l111l111l1_cda_(self, l1111l1lll_cda_):
        self._111l11lll_cda_ = l1111l1lll_cda_
        self._1111l1ll1_cda_()
    def l111l1111l_cda_(self, l1111ll111_cda_):
        self._111l11ll1_cda_ = l1111ll111_cda_
        self._1111l1ll1_cda_()
    def l111l11111_cda_(self):
        if not self._111l1l1l1_cda_:
            if self._1111lll11_cda_:
                self._111l1l1l1_cda_ = l111l1l1ll_cda_(self._1111lll11_cda_, self._111l11lll_cda_, self._111l11ll1_cda_)
            else:
                self._111l1l1l1_cda_ = l111l1l1ll_cda_(self._111l11lll_cda_, self._111l11ll1_cda_)
        return self._111l1l1l1_cda_
    def l111l111ll_cda_(self):
        if not self._1111lll11_cda_:
            if self._111l1l1l1_cda_:
                self._1111lll11_cda_ = l111l1l11l_cda_(self._111l1l1l1_cda_, self._111l11lll_cda_, self._111l11ll1_cda_)
            else:
                self._1111lll11_cda_ = l111l1l11l_cda_(self._111l11lll_cda_, self._111l11ll1_cda_)
        return self._1111lll11_cda_
    def l11ll1ll1l_cda_(self):
        if not self._111l1l111_cda_:
            self._111l1l111_cda_ = l111l1lll1_cda_(self.l111l11111_cda_(),
                                                    self._111l11lll_cda_, self._111l11ll1_cda_)
        return self._111l1l111_cda_
    def l11ll1llll_cda_(self):
        if not self._111l1llll_cda_:
            self._111l1llll_cda_ = l11ll1llll_cda_(self._111l11lll_cda_, self._111l11ll1_cda_)
        return self._111l1llll_cda_
    def l1111ll1l1_cda_(self):
        if not self._111l1llll_cda_:
            self._111l1llll_cda_ = l11ll1llll_cda_(self._111l11lll_cda_, self._111l11ll1_cda_)
        return self._111l1llll_cda_
    def l1111lllll_cda_(self):
        l111l1ll11_cda_, l111l1ll1l_cda_ = len(self._111l11lll_cda_), len(self._111l11ll1_cda_)
        return 2.0 * min(l111l1ll11_cda_, l111l1ll1l_cda_) / (l111l1ll11_cda_ + l111l1ll1l_cda_)
    def l1111lll1l_cda_(self):
        if not self._111l11l1l_cda_:
            self._111l11l1l_cda_ = l1111lll1l_cda_(self._111l11lll_cda_, self._111l11ll1_cda_)
        return self._111l11l1l_cda_