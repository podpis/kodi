# -*- coding: utf-8 -*-

import dbJson as dj
import urllib2
import urllib
import os
import re,json


COOKIEFILE='D:\\cookie.mic'
dj.cda.COOKIEFILE=COOKIEFILE

jmain=r'C:\Users\ramic\Google Drive\cda\1main.json'
jfilename=r'C:\Users\ramic\Google Drive\cda\filmyAutomat.json'

f_polska    =r'C:\Users\ramic\Google Drive\cda\filmy_Polskie.json'
f_2016      =r'C:\Users\ramic\Google Drive\cda\filmy_2016.json'
f_2015      =r'C:\Users\ramic\Google Drive\cda\filmy_2015.json'
f_starsze   =r'C:\Users\ramic\Google Drive\cda\filmy_Starsze.json'
f_automat   =r'C:\Users\ramic\Google Drive\cda\filmyAutomat.json'
f_3D     =r'C:\Users\ramic\Google Drive\cda\filmy_3D.json'

jfilename   =r'C:\Users\ramic\Google Drive\cda\_poczekalnia.json'       

files=[r'C:\Users\ramic\Google Drive\cda\filmy_2016.json',
       r'C:\Users\ramic\Google Drive\cda\filmy_2015.json',
       r'C:\Users\ramic\Google Drive\cda\filmy_Polskie.json',
       r'C:\Users\ramic\Google Drive\cda\filmyAutomat.json',
       r'C:\Users\ramic\Google Drive\cda\filmy_Starsze.json'
       ]


#UpdateFilmwebInfo(files[3])     

url='http://www.cda.pl/video/show/cale_filmy_or_caly_film_fps_lektor_pl_dubbing/p1?duration=dlugie&section=&quality=720p&section=&s=date&section=' # film polski
url='http://www.cda.pl/video/show/2015_2016_film_filmy/p1?duration=dlugie&section=&quality=720p&section=&s=date&section='
url='http://www.cda.pl/video/show/3d?duration=dlugie&section=&quality=1080p&section=&s=date&section='

# jfilename   =r'C:\Users\ramic\Google Drive\cda\_poczekalnia.json'  
# UpdateFilmwebInfo(jfilename)

def Scan_newItems(pages=4):
    new_items=[]
    for page in range(pages):
        page+=1
        url='http://www.cda.pl/video/show/cale_filmy_or_caly_film_fps_lektor_pl_dubbing/p%d?duration=dlugie&section=&quality=720p&section=&s=date&section='
        #url='http://www.cda.pl/video/show/2015_2016_film_filmy/p%d?duration=dlugie&section=&quality=720p&section=&s=date&section='
        url = url % page
        one_data = dj.GET_newMovies(url,t_patter='')
        new_items.extend(one_data)
        
    (new_items,removed)=dj.jdata_remove_duplicates(new_items)
    print 'Potencjane %s items' % len(new_items) 
    for one in new_items:
        print one.get('filmweb'),one.get('title')
    return new_items


url='http://www.cda.pl/arkas34/folder/863691'
url='http://www.cda.pl/ramicspa/folder/1456625'
url='http://www.cda.pl/Dobre-Kino/folder/961263'
jfilename   =r'C:\Users\ramic\Google Drive\cda\_poczekalnia.json'  
def scan_poczekalnia(url,jfilename):
    new_items=dj.GET_newMovies(url,t_patter='')
    UpdateJsonFile_with_jdata(jfilename,new_items)


# UpdateJsonFile_RemoveDuplicates(f_2015)
# CheckJsonfileLinks(f_starsze,remove_incative=True)

#new_items=Scan_newItems(2)
def UpdateJsonFiles_NewItems(new_items,hd=True):
    
    if hd:
        hd_items = [x for x in new_items if x.get('code','')!= '']
        print len(new_items), len(hd_items)
        new_items = hd_items
    
    # Polska
    filtered=dj.jdata_filter_in(new_items,key='studio',value='Polska')
    if filtered:
        print '\n== UPDATE Polska =='
        UpdateJsonFile_with_jdata(f_polska,filtered)
    
    # 2016
    filtered=dj.jdata_filter_in(new_items,key='year',value='2016')
    if filtered:  
        print '\n== UPDATE 2016 =='
        UpdateJsonFile_with_jdata(f_2016,filtered)
    
    # 2015
    filtered=dj.jdata_filter_in(new_items,key='year',value='2015')
    if filtered: 
        print '\n== UPDATE 2015 ==' 
        UpdateJsonFile_with_jdata(f_2015,filtered)
    
    print '\n== UPDATE Starsze Filmy =='
    # for f in filtered:
    #     print f.get('filmweb',''), f.get('title')
    UpdateJsonFile_with_jdata(f_starsze,new_items)
    updateMain(jmain)

jfilename=f_2016
def UpdateJsonFile_with_jdata(jfilename,filtered):
    existing_items = dj.readJsonFile(jfilename)
    
    # List of filmweb_id,qualities
    filmweb_db = [i.get('filmweb') for i in existing_items if i.get('filmweb')]
    code_db = [i.get('code') for i in existing_items if i.get('code')]
    print len(existing_items),len(filmweb_db),len(code_db)
    
    filtered=dj.rename_key(filtered,old_key='_filmweb',new_key='filmweb')
    
    count_new = 0
    count_upd = 0
    for one in filtered:
        if one.has_key('filmweb'):
            if one.get('filmweb') not in filmweb_db:
                filmweb_db.insert(0,one.get('filmweb'))
                existing_items.insert(0,one)
                count_new +=1
            else:
                index = filmweb_db.index(one.get('filmweb'))
                old_item = existing_items[index]
                selcted = dj.jdata_pick_better(one,old_item)
                if old_item!=selcted:
                    existing_items[index]=selcted
                    count_upd +=1
    print '#'*4
    print 'Dodano %d, Uaktualniono %d ' % (count_new,count_upd)
    print 'DUPLICATES %d' % (len(filmweb_db)-len(set(filmweb_db)))
    if count_new>0 or count_upd>0:
        dj.writeJsonFile(existing_items,jfilename)
    return True


def UpdateFilmwebInfo(jfilename):
    existing_items = dj.readJsonFile(jfilename)
    for one in existing_items:
        one = dj.filmweb_updateItemInfo(one)
    dj.writeJsonFile(existing_items,jfilename)

#CheckJsonfileLinks(jfilename,remove_incative=False)
def CheckJsonfileLinks(jfilename,remove_incative=False):
    jdata=dj.readJsonFile(jfilename)
    jdata_new,inactive_items = dj.jdata_validate_cda_links(jdata)
    if remove_incative:
        print 'Removing dead items:'
        for i in reversed(inactive_items):
            print jdata_new[i].get('title'),jdata_new[i].get('msg')
            del jdata_new[i] 
        dj.writeJsonFile(jdata_new,jfilename)


jfilename=f_2015
jfilename=f_starsze
jfilename=f_3D
def UpdateJsonFile_RemoveDuplicates(jfilename):
    jdata=dj.readJsonFile(jfilename)
    len(jdata)
    duplicates = dj.jdata_separate_duplicates(jdata)
    for one in duplicates:
        print '->',one.get('title'),one.get('label')
    dj.writeJsonFile(jdata,jfilename)

def _find_NOT_HD(filename):
    jdata=dj.readJsonFile(jfilename)
    len(jdata)
    notHD =[(x,i) for i,x in enumerate(jdata) if x.get('code','') not in ['480p','720p','1080p'] ]
    len(notHD)
    for one,idx in notHD:
        print one.get('code',''),one.get('title','')
        one['code']=''
        urls = dj.cda.getVideoUrls(one.get('url',''))
        if type(urls) is list:
            one['code']=urls[0][0]
        else:
            one['code']=''
            

def updateMain(jmain):
    ROOTPATH=r"C:\Users\ramic\Google Drive\cda"
    
    with open(jmain, 'r') as outfile:
        main=outfile.read()
    output=''    
    for line in main.split('\n'):
        #line = main.split('\n')[1]
        match = re.search('"count":"(.*?)","update":"(.*?)","jsonfile":"(.*?)"',line)
        if match:
            print match.group(1),match.group(2),match.group(3)
            f = urllib2.urlopen(match.group(3))
            fname = re.search('filename="(.*?)";',f.headers['Content-Disposition'])
            count,update = dj.get_file_info(os.path.join(ROOTPATH,fname.group(1)))
            print count,update
            line = re.sub('"count":"(.*?)"','"count":" %s"'%count,line)
            line = re.sub('"update":"(.*?)"','"update":"Aktualizacja: [COLOR aqua]%s[/COLOR]"'%update,line)
        if line:
            output += line+'\n'
    print output
    with open(jmain, 'w') as outfile:
        outfile.write(output)
