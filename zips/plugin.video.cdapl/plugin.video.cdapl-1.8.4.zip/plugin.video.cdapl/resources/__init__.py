# coding: UTF-8
import sys
l1l1l_cda_ = sys.version_info [0] == 2
l1lll1_cda_ = 2048
l1l1l1_cda_ = 7
def l1l_cda_ (ll_cda_):
	global l11l1_cda_
	l1l11l_cda_ = ord (ll_cda_ [-1])
	l11ll_cda_ = ll_cda_ [:-1]
	l11_cda_ = l1l11l_cda_ % len (l11ll_cda_)
	l1ll_cda_ = l11ll_cda_ [:l11_cda_] + l11ll_cda_ [l11_cda_:]
	if l1l1l_cda_:
		l1llll_cda_ = unicode () .join ([unichr (ord (char) - l1lll1_cda_ - (l1l11_cda_ + l1l11l_cda_) % l1l1l1_cda_) for l1l11_cda_, char in enumerate (l1ll_cda_)])
	else:
		l1llll_cda_ = str () .join ([chr (ord (char) - l1lll1_cda_ - (l1l11_cda_ + l1l11l_cda_) % l1l1l1_cda_) for l1l11_cda_, char in enumerate (l1ll_cda_)])
	return eval (l1llll_cda_)