# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse

import xbmc,xbmcgui,xbmcaddon
import xbmcplugin



base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')

PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

FANART=''

import resources.lib.serialosypl as serialosypl
import urlresolver
# xbmcplugin.setContent(addon_handle, 'movies')

## COMMON Functions


def addLinkItem(name, url, mode, params={}, iconimage='DefaultFolder.png', infoLabels=False, isFolder=False, IsPlayable=True,fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    
    liz = xbmcgui.ListItem(name)
    
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    art['fanart'] = fanart if fanart else art['landscape'] 
    liz.setArt(art)
        
    if not infoLabels:
        infoLabels={"title": name}
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    contextMenuItems = []
    contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)        
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=isFolder,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok

def addDir(name,ex_link=None, params={}, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params})

    li = xbmcgui.ListItem(name)
    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)
    
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    art['fanart'] = fanart if fanart else art['landscape'] 
    li.setArt(art)
    if contextmenu:
        contextMenuItems=contextmenu
        li.addContextMenuItems(contextMenuItems, replaceItems=True) 
    else:
        contextMenuItems = []
        contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'),)
        li.addContextMenuItems(contextMenuItems, replaceItems=False)  
          
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))


def ListContent(ex_link,data):
    filmy,pagination = serialosypl.getContent(ex_link,data)
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=pagination[0], params={}, mode='page:getContent', IsPlayable=False)
    items=len(filmy)
    for f in filmy:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img'), infoLabels=f, isFolder=False, IsPlayable=True,itemcount=items)
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> Następna strona >>[/COLOR]', url=pagination[1], params={}, mode='page:getContent', IsPlayable=False)
    xbmcplugin.setContent(addon_handle, 'tvshows')

def getLinks(ex_link):
    links = serialosypl.getVideoUrl(ex_link)
    print links
    stream_url=''
    t = [ x.get('title') for x in links]
    u = [ x.get('url') for x in links]
    selection = xbmcgui.Dialog().select("Sources", t)
    if selection>-1:
        link = links[selection].get('url')
        
        try:
            stream_url = urlresolver.resolve(link)
        except Exception,e:
            stream_url=''
            xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działał?','ERROR: %s'%str(e))
    
    print stream_url
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
        
## ######################
## MAIN
## ######################
            
    
# Get passed arguments
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]

sortV = my_addon.getSetting('sortV')
sortN = my_addon.getSetting('sortN') if sortV else 'Brak'

if mode is None:
    addLinkItem("[COLOR blue]Sortowanie:[/COLOR] [B]"+sortN+"[/B]",'',mode='filtr:sort',iconimage='',IsPlayable=False)
    addDir(name="Strona główna",ex_link='http://www.serialosy.pl/',params={}, mode='getContent',iconImage='')
    addDir(name="Zagraniczne seriale",ex_link='http://www.serialosy.pl',params={'menu':'Zagraniczne'}, mode='getSeriale',iconImage='')
    addDir(name="Polskie seriale",ex_link='http://www.serialosy.pl',params={'menu':'Polskie'}, mode='getSeriale',iconImage='')
    addDir(name="Dokumentalne",ex_link='http://www.serialosy.pl',params={'menu':'Dokumentalne'}, mode='getSeriale',iconImage='')

elif 'filtr' in mode[0]:
    _type = mode[0].split(":")[-1]
    if _type=='sort':
        label=['Brak','Data dodania','Ocena','Wyświetlenia','Komentarze','Alfabetycznie']
        value=['','dlenewssortby=date&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=rating&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=news_read&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=comm_num&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main','dlenewssortby=title&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main']
        msg = 'Sortowanie'
    s = xbmcgui.Dialog().select(msg,label)
    s = s if s>-1 else 0
    my_addon.setSetting(_type+'V',value[s])
    my_addon.setSetting(_type+'N',label[s])
    xbmc.executebuiltin('XBMC.Container.Refresh')
    
elif mode[0]=='getSeriale':
    params=eval(params)
    seriale = serialosypl.getSeriale(ex_link,**params)
    items=len(seriale)
    for f in seriale:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getContent', iconimage=f.get('img'), infoLabels=f, isFolder=True, IsPlayable=False,itemcount=items)
    xbmcplugin.setContent(addon_handle, 'tvshows')

elif mode[0]=='getContent':
     ListContent(ex_link,sortV)
     
elif mode[0]=='getLinks':
    getLinks(ex_link)
    
elif mode[0].startswith('page'):
    tmp,nmode = mode[0].split(':')
    url = build_url({'mode': nmode, 'foldername': '', 'ex_link' : ex_link, 'params':params})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))        


xbmcplugin.endOfDirectory(addon_handle)

