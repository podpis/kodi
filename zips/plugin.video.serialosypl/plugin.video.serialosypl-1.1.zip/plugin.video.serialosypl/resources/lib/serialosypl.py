# -*- coding: utf-8 -*-

import urllib2,urllib
import re,os
from urlparse import urlparse

BASEURL='http://www.serialosy.pl'
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'


def getUrl(url,data=None,header={}):
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link =  response.read()
        response.close()
    except urllib2.HTTPError as e:
        link = ''
    return link


def getSeriale(url='http://www.serialosy.pl',menu='Zagraniczne'):
    out=[]
    content = getUrl(url)
    sublinks = re.compile('<li class="sublnk"><a href=".*?"><b>(.*?)</b></a>(.*?)</ul>\s*</li>',re.DOTALL).findall(content)
   
    for type,items in sublinks:
        print type
        if menu in type:
            seriale = re.compile('<li><a href="(.*?)"><b>(.*?)</b></a></li>').findall(items)
            for s in seriale:
                out.append({'title':unicodePLchar(s[1].strip()),'url':s[0]})
            return out
    return out

def getContent(url='/zagraniczne-seriale/wojna-i-pokoj/',data='dlenewssortby=date&dledirection=desc&set_new_sort=dle_sort_main&set_direction_sort=dle_direction_main'):
    if url[0]=='/': url = BASEURL+url
    out=[]
    content = getUrl(url,data)
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="base shortstory">', content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('<h3 class="btl"><a href="(.*?)">(.*?)</a></h3>',re.DOTALL).findall(subset)
        info = re.compile('<p class="binfo small">(.*?)<a href=".*?" >(.*?)</a>(.*?)</p>').findall(subset)
        img = re.compile('<img src="(.*?)"').findall(subset)
        if href and info and img:
            h = href[0][0]
            t = '[COLOR lightblue]%s[/COLOR] %s'%(href[0][1],''.join(info[0]))
            i = img[0]
            out.append({'title':unicodePLchar(t),'url':h,'img':i})
    
    prevPage = re.compile('<a href="(.*?)"><span class="thide pprev">Wstecz</span></a>').search(content)
    prevPage = prevPage.group(1) if prevPage else False
    nextPage = re.compile('<a href="(.*?)"><span class="thide pnext">Dalej</span></a>').search(content)
    nextPage = nextPage.group(1) if nextPage else False
    return out,(prevPage,nextPage)

def getVideoUrl(url='http://www.serialosy.pl/zagraniczne-seriale2/agenci-tarczy/9423-agenci-tarczy-s04e04-eng-pl.html'):
    content = getUrl(url)
    videos=[]
    iframes = re.compile('<iframe(.*?)</iframe>',re.DOTALL|re.IGNORECASE).findall(content)
    for irame in iframes:
        irame = iframes[0]
        src = re.compile('src="(.*?)"',re.DOTALL|re.IGNORECASE).findall(irame)
        if src:
            host = urlparse(src[0]).netloc
            videos.append({'url':src[0],'title':host})
    return videos

def unicodePLchar(txt):
    #if type(txt) is not str:
    #    txt=txt.encode('utf-8')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    #txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt     