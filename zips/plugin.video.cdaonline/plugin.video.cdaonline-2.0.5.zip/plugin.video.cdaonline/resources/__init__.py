# coding: UTF-8
import sys
l1ll1_cdx_ = sys.version_info [0] == 2
l11ll_cdx_ = 2048
l111_cdx_ = 7
def l1lll_cdx_ (keyedStringLiteral):
	global l1l11_cdx_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll1_cdx_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll_cdx_ - (charIndex + stringNr) % l111_cdx_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll_cdx_ - (charIndex + stringNr) % l111_cdx_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)