# coding: UTF-8
import sys
l1llll_cdax_ = sys.version_info [0] == 2
l1l11l_cdax_ = 2048
l11ll_cdax_ = 7
def l1l_cdax_ (ll_cdax_):
	global l1ll1l_cdax_
	l1l1l1_cdax_ = ord (ll_cdax_ [-1])
	l1l11_cdax_ = ll_cdax_ [:-1]
	l11_cdax_ = l1l1l1_cdax_ % len (l1l11_cdax_)
	l1ll_cdax_ = l1l11_cdax_ [:l11_cdax_] + l1l11_cdax_ [l11_cdax_:]
	if l1llll_cdax_:
		l1111_cdax_ = unicode () .join ([unichr (ord (char) - l1l11l_cdax_ - (l1l1l_cdax_ + l1l1l1_cdax_) % l11ll_cdax_) for l1l1l_cdax_, char in enumerate (l1ll_cdax_)])
	else:
		l1111_cdax_ = str () .join ([chr (ord (char) - l1l11l_cdax_ - (l1l1l_cdax_ + l1l1l1_cdax_) % l11ll_cdax_) for l1l1l_cdax_, char in enumerate (l1ll_cdax_)])
	return eval (l1111_cdax_)