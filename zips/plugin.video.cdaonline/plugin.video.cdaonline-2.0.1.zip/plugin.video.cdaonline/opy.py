# -*- coding: utf-8 -*-
import sys
l1l1l_cdax_ = sys.version_info [0] == 2
l1l11_cdax_ = 2048
l11ll_cdax_ = 7
def l1l1_cdax_ (keyedStringLiteral):
	global l11l_cdax_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1l_cdax_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l11_cdax_ - (charIndex + stringNr) % l11ll_cdax_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l11_cdax_ - (charIndex + stringNr) % l11ll_cdax_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
license = (
l1l1_cdax_ (u"࠭ࠧࠨࡡࡲࡴࡾࡥࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢ࠵࠴࠶࠺ࠬࠡ࠴࠳࠵࠺࠲ࠠ࠳࠲࠴࠺ࠥࡐࡡࡤࡳࡸࡩࡸࠦࡤࡦࠢࡋࡳࡴ࡭ࡥ࠭ࠢࡊࡉࡆ࡚ࡅࡄࠢࡨࡲ࡬࡯࡮ࡦࡧࡵ࡭ࡳ࡭ࠬࠡࡹࡺࡻ࠳࡭ࡥࡢࡶࡨࡧ࠳ࡩ࡯࡮ࠏࠍࠑࠏࡒࡩࡤࡧࡱࡷࡪࡪࠠࡶࡰࡧࡩࡷࠦࡴࡩࡧࠣࡅࡵࡧࡣࡩࡧࠣࡐ࡮ࡩࡥ࡯ࡵࡨ࠰ࠥ࡜ࡥࡳࡵ࡬ࡳࡳࠦ࠲࠯࠲ࠣࠬࡹ࡮ࡥࠡࠤࡏ࡭ࡨ࡫࡮ࡴࡧࠥ࠭ࡀࠓࠊࡺࡱࡸࠤࡲࡧࡹࠡࡰࡲࡸࠥࡻࡳࡦࠢࡷ࡬࡮ࡹࠠࡧ࡫࡯ࡩࠥ࡫ࡸࡤࡧࡳࡸࠥ࡯࡮ࠡࡥࡲࡱࡵࡲࡩࡢࡰࡦࡩࠥࡽࡩࡵࡪࠣࡸ࡭࡫ࠠࡍ࡫ࡦࡩࡳࡹࡥ࠯ࠏࠍ࡝ࡴࡻࠠ࡮ࡣࡼࠤࡴࡨࡴࡢ࡫ࡱࠤࡦࠦࡣࡰࡲࡼࠤࡴ࡬ࠠࡵࡪࡨࠤࡑ࡯ࡣࡦࡰࡶࡩࠥࡧࡴࠎࠌࠐࠎࠥࠦࠠࠡࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧࡰࡢࡥ࡫ࡩ࠳ࡵࡲࡨ࠱࡯࡭ࡨ࡫࡮ࡴࡧࡶ࠳ࡑࡏࡃࡆࡐࡖࡉ࠲࠸࠮࠱ࠏࠍࠑࠏ࡛࡮࡭ࡧࡶࡷࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠࡣࡻࠣࡥࡵࡶ࡬ࡪࡥࡤࡦࡱ࡫ࠠ࡭ࡣࡺࠤࡴࡸࠠࡢࡩࡵࡩࡪࡪࠠࡵࡱࠣ࡭ࡳࠦࡷࡳ࡫ࡷ࡭ࡳ࡭ࠬࠡࡵࡲࡪࡹࡽࡡࡳࡧࠐࠎࡩ࡯ࡳࡵࡴ࡬ࡦࡺࡺࡥࡥࠢࡸࡲࡩ࡫ࡲࠡࡶ࡫ࡩࠥࡒࡩࡤࡧࡱࡷࡪࠦࡩࡴࠢࡧ࡭ࡸࡺࡲࡪࡤࡸࡸࡪࡪࠠࡰࡰࠣࡥࡳࠦࠢࡂࡕࠣࡍࡘࠨࠠࡃࡃࡖࡍࡘ࠲ࠍࠋ࡙ࡌࡘࡍࡕࡕࡕ࡚ࠢࡅࡗࡘࡁࡏࡖࡌࡉࡘࠦࡏࡓࠢࡆࡓࡓࡊࡉࡕࡋࡒࡒࡘࠦࡏࡇࠢࡄࡒ࡞ࠦࡋࡊࡐࡇ࠰ࠥ࡫ࡩࡵࡪࡨࡶࠥ࡫ࡸࡱࡴࡨࡷࡸࠦ࡯ࡳࠢ࡬ࡱࡵࡲࡩࡦࡦ࠱ࠑࠏ࡙ࡥࡦࠢࡷ࡬ࡪࠦࡌࡪࡥࡨࡲࡸ࡫ࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡵࡳࡩࡨ࡯ࡦࡪࡥࠣࡰࡦࡴࡧࡶࡣࡪࡩࠥ࡭࡯ࡷࡧࡵࡲ࡮ࡴࡧࠡࡲࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸࠦࡡ࡯ࡦࠐࠎࡱ࡯࡭ࡪࡶࡤࡸ࡮ࡵ࡮ࡴࠢࡸࡲࡩ࡫ࡲࠡࡶ࡫ࡩࠥࡒࡩࡤࡧࡱࡷࡪ࠴ࠧࠨࠩঘ")
)
import re
import os
import sys
import errno
import keyword
import importlib
import random
import codecs
import shutil
programName = l1l1_cdax_ (u"ࠧࡰࡲࡼࠫঙ")
programVersion = l1l1_cdax_ (u"ࠨ࠳࠱࠵࠳࠸࠲ࠨচ")
__name__ = l1l1_cdax_ (u"ࠩࡤࠫছ")
if __name__ == l1l1_cdax_ (u"ࠪࡥࠬজ"):
	print (l1l1_cdax_ (u"ࠫࢀࢃࠠࠩࡖࡐ࠭ࠥࡉ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡣ࡮ࡨࠤࡒࡻ࡬ࡵ࡫ࠣࡑࡴࡪࡵ࡭ࡧࠣࡔࡾࡺࡨࡰࡰࠣࡓࡧ࡬ࡵࡴࡥࡤࡸࡴࡸࠠࡗࡧࡵࡷ࡮ࡵ࡮ࠡࡽࢀࠫঝ").format (programName.capitalize (), programVersion))
	print (l1l1_cdax_ (u"ࠬࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࠪࡆ࠭ࠥࡍࡥࡢࡶࡨࡧࠥࡋ࡮ࡨ࡫ࡱࡩࡪࡸࡩ࡯ࡩ࠱ࠤࡑ࡯ࡣࡦࡰࡶࡩ࠿ࠦࡁࡱࡣࡦ࡬ࡪࠦ࠲࠯࠲ࠣࡥࡹࠦࠠࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡦࡶࡡࡤࡪࡨ࠲ࡴࡸࡧ࠰࡮࡬ࡧࡪࡴࡳࡦࡵ࠲ࡐࡎࡉࡅࡏࡕࡈ࠱࠷࠴࠰࡝ࡰࠪঞ"))
	random.seed ()
	isPython2 = sys.version_info [0] == 2
	charBase = 2048
	stringNr = charBase
	charModulus = 7
	pathseparator = os.path.sep
	def createFilePath (filePath, open = False):
		print l1l1_cdax_ (u"࠭ࡣࡳࡧࡤࡸࡪࡌࡩ࡭ࡧࡓࡥࡹ࡮ࠠࠦࡵࠪট")%filePath
		try:
			os.makedirs (filePath.rsplit (pathseparator, 1) [0])
		except OSError as exception:
			print l1l1_cdax_ (u"ࠧࡆࡔࡕࡓࡗࡀࠠࡤࡴࡨࡥࡹ࡫ࡆࡪ࡮ࡨࡔࡦࡺࡨࠨঠ")
			if exception.errno != errno.EEXIST:
				raise
		if open:
			return codecs.open (filePath, encoding = l1l1_cdax_ (u"ࠨࡷࡷࡪ࠲࠾ࠧড"), mode = l1l1_cdax_ (u"ࠩࡺࠫঢ"))
	def getObfuscatedName (obfuscationIndex, name):
		return l1l1_cdax_ (u"ࠪࡿ࠵ࢃࡻ࠲ࡿࡾ࠶ࢂ࠭ণ").format (
			l1l1_cdax_ (u"ࠫࡤࡥࠧত") if name.startswith (l1l1_cdax_ (u"ࠬࡥ࡟ࠨথ")) else l1l1_cdax_ (u"࠭࡟ࠨদ") if name.startswith (l1l1_cdax_ (u"ࠧࡠࠩধ")) else l1l1_cdax_ (u"ࠨ࡮ࠪন"),
			bin (obfuscationIndex) [2:] .replace (l1l1_cdax_ (u"ࠩ࠳ࠫ঩"), l1l1_cdax_ (u"ࠪࡰࠬপ")),
			obfuscatedNameTail
		)
	def scramble (stringLiteral):
		global stringNr
		stringLiteral = stringLiteral.encode(l1l1_cdax_ (u"ࠫࡺࡺࡦ࠮࠺ࠪফ"))
		if isPython2:
			recodedStringLiteral = unicode () .join ([unichr (charBase + ord (char) + (charIndex + stringNr) % charModulus) for charIndex, char in enumerate (stringLiteral)])
			stringKey = unichr (stringNr)
		else:
			recodedStringLiteral = str () .join ([chr (charBase + ord (char) + (charIndex + stringNr) % charModulus) for charIndex, char in enumerate (stringLiteral)])
			stringKey = chr (stringNr)
		rotationDistance = stringNr % len (stringLiteral)
		rotatedStringLiteral = recodedStringLiteral [:-rotationDistance] + recodedStringLiteral [-rotationDistance:]
		keyedStringLiteral = rotatedStringLiteral + stringKey
		stringNr += 1
		return l1l1_cdax_ (u"ࠬࡻࠢࠨব") + keyedStringLiteral + l1l1_cdax_ (u"࠭ࠢࠨভ")
	def getUnScrambler (stringBase):
		return l1l1_cdax_ (u"ࠧࠨࠩࠐࠎ࡮ࡳࡰࡰࡴࡷࠤࡸࡿࡳࠎࠌࠐࠎ࡮ࡹࡐࡺࡶ࡫ࡳࡳ࠸ࡻ࠱ࡿࠣࡁࠥࡹࡹࡴ࠰ࡹࡩࡷࡹࡩࡰࡰࡢ࡭ࡳ࡬࡯ࠡ࡝࠳ࡡࠥࡃ࠽ࠡ࠴ࠐࠎࡨ࡮ࡡࡳࡄࡤࡷࡪࢁ࠰ࡾࠢࡀࠤࢀ࠷ࡽࠎࠌࡦ࡬ࡦࡸࡍࡰࡦࡸࡰࡺࡹࡻ࠱ࡿࠣࡁࠥࢁ࠲ࡾࠏࠍࠑࠏࡪࡥࡧࠢࡸࡲࡘࡩࡲࡢ࡯ࡥࡰࡪࢁ࠰ࡾࠢࠫ࡯ࡪࡿࡥࡥࡕࡷࡶ࡮ࡴࡧࡍ࡫ࡷࡩࡷࡧ࡬ࠪ࠼ࠐࠎࠎ࡭࡬ࡰࡤࡤࡰࠥࡹࡴࡳ࡫ࡱ࡫ࡓࡸࡻ࠱ࡿࠐࠎࠎࠓࠊࠊࡵࡷࡶ࡮ࡴࡧࡏࡴࠣࡁࠥࡵࡲࡥࠢࠫ࡯ࡪࡿࡥࡥࡕࡷࡶ࡮ࡴࡧࡍ࡫ࡷࡩࡷࡧ࡬ࠡ࡝࠰࠵ࡢ࠯ࠍࠋࠋࡵࡳࡹࡧࡴࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢࡀࠤࡰ࡫ࡹࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢ࡞࠾࠲࠷࡝ࠎࠌࠌࠑࠏࠏࡲࡰࡶࡤࡸ࡮ࡵ࡮ࡅ࡫ࡶࡸࡦࡴࡣࡦࠢࡀࠤࡸࡺࡲࡪࡰࡪࡒࡷࠦࠥࠡ࡮ࡨࡲࠥ࠮ࡲࡰࡶࡤࡸࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࠯ࠍࠋࠋࡵࡩࡨࡵࡤࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢࡀࠤࡷࡵࡴࡢࡶࡨࡨࡘࡺࡲࡪࡰࡪࡐ࡮ࡺࡥࡳࡣ࡯ࠤࡠࡀࡲࡰࡶࡤࡸ࡮ࡵ࡮ࡅ࡫ࡶࡸࡦࡴࡣࡦ࡟ࠣ࠯ࠥࡸ࡯ࡵࡣࡷࡩࡩ࡙ࡴࡳ࡫ࡱ࡫ࡑ࡯ࡴࡦࡴࡤࡰࠥࡡࡲࡰࡶࡤࡸ࡮ࡵ࡮ࡅ࡫ࡶࡸࡦࡴࡣࡦ࠼ࡠࠑࠏࠏࠉࠎࠌࠌ࡭࡫ࠦࡩࡴࡒࡼࡸ࡭ࡵ࡮࠳ࡽ࠳ࢁ࠿ࠓࠊࠊࠋࡶࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢࡀࠤࡺࡴࡩࡤࡱࡧࡩࠥ࠮ࠩࠡ࠰࡭ࡳ࡮ࡴࠠࠩ࡝ࡸࡲ࡮ࡩࡨࡳࠢࠫࡳࡷࡪࠠࠩࡥ࡫ࡥࡷ࠯ࠠ࠮ࠢࡦ࡬ࡦࡸࡂࡢࡵࡨࡿ࠵ࢃࠠ࠮ࠢࠫࡧ࡭ࡧࡲࡊࡰࡧࡩࡽࠦࠫࠡࡵࡷࡶ࡮ࡴࡧࡏࡴࠬࠤࠪࠦࡣࡩࡣࡵࡑࡴࡪࡵ࡭ࡷࡶࡿ࠵ࢃࠩࠡࡨࡲࡶࠥࡩࡨࡢࡴࡌࡲࡩ࡫ࡸ࠭ࠢࡦ࡬ࡦࡸࠠࡪࡰࠣࡩࡳࡻ࡭ࡦࡴࡤࡸࡪࠦࠨࡳࡧࡦࡳࡩ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠩ࡞ࠫࠐࠎࠎ࡫࡬ࡴࡧ࠽ࠑࠏࠏࠉࡴࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠠ࠾ࠢࡶࡸࡷࠦࠨࠪࠢ࠱࡮ࡴ࡯࡮ࠡࠪ࡞ࡧ࡭ࡸࠠࠩࡱࡵࡨࠥ࠮ࡣࡩࡣࡵ࠭ࠥ࠳ࠠࡤࡪࡤࡶࡇࡧࡳࡦࡽ࠳ࢁࠥ࠳ࠠࠩࡥ࡫ࡥࡷࡏ࡮ࡥࡧࡻࠤ࠰ࠦࡳࡵࡴ࡬ࡲ࡬ࡔࡲࠪࠢࠨࠤࡨ࡮ࡡࡳࡏࡲࡨࡺࡲࡵࡴࡽ࠳ࢁ࠮ࠦࡦࡰࡴࠣࡧ࡭ࡧࡲࡊࡰࡧࡩࡽ࠲ࠠࡤࡪࡤࡶࠥ࡯࡮ࠡࡧࡱࡹࡲ࡫ࡲࡢࡶࡨࠤ࠭ࡸࡥࡤࡱࡧࡩࡩ࡙ࡴࡳ࡫ࡱ࡫ࡑ࡯ࡴࡦࡴࡤࡰ࠮ࡣࠩࠎࠌࠌࠍࠒࠐࠉࡳࡧࡷࡹࡷࡴࠠࡦࡸࡤࡰࠥ࠮ࡳࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࠯ࠍࠋࠋࠪࠫࠬম").format (plainMarker, charBase, charModulus)
	def printHelpAndExit (errorLevel):
		print (l1l1_cdax_ (u"ࡳࠩࠪࠫࠒࠐࠍࠋࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭ࠑࠏࢁ࠰ࡾࠢࡺ࡭ࡱࡲࠠࡰࡤࡩࡹࡸࡩࡡࡵࡧࠣࡽࡴࡻࡲࠡࡧࡻࡸࡪࡴࡳࡪࡸࡨ࠰ࠥࡸࡥࡢ࡮ࠣࡻࡴࡸ࡬ࡥ࠮ࠣࡱࡺࡲࡴࡪࠢࡰࡳࡩࡻ࡬ࡦࠢࡓࡽࡹ࡮࡯࡯ࠢࡶࡳࡺࡸࡣࡦࠢࡦࡳࡩ࡫ࠠࡧࡱࡵࠤ࡫ࡸࡥࡦࠣࠐࠎࡆࡴࡤ࡛ࠡࡒ࡙ࠥࡩࡨࡰࡱࡶࡩࠥࡶࡥࡳࠢࡳࡶࡴࡰࡥࡤࡶࠣࡻ࡭ࡧࡴࠡࡶࡲࠤࡴࡨࡦࡶࡵࡦࡥࡹ࡫ࠠࡢࡰࡧࠤࡼ࡮ࡡࡵࠢࡱࡳࡹ࠲ࠠࡣࡻࠣࡩࡩ࡯ࡴࡵ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡦࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫࠮ࠎࠌࠐࠎࡇࡇࡃࡌࡗࡓࠤ࡞ࡕࡕࡓࠢࡆࡓࡉࡋࠠࡂࡐࡇࠤ࡛ࡇࡌࡖࡃࡅࡐࡊࠦࡄࡂࡖࡄࠤ࡙ࡕࠠࡂࡐࠣࡓࡋࡌ࠭ࡍࡋࡑࡉࠥࡓࡅࡅࡋࡘࡑࠥࡌࡉࡓࡕࡗࠤ࡙ࡕࠠࡑࡔࡈ࡚ࡊࡔࡔࠡࡃࡆࡇࡎࡊࡅࡏࡖࡄࡐࠥࡒࡏࡔࡕࠣࡓࡋࠦࡗࡐࡔࡎࠥࠦࠧࠍࠋࠏࠍࡘ࡭࡫࡮ࠡࡥࡲࡴࡾࠦࡴࡩࡧࠣࡨࡪ࡬ࡡࡶ࡮ࡷࠤࡨࡵ࡮ࡧ࡫ࡪࠤ࡫࡯࡬ࡦࠢࡷࡳࠥࡺࡨࡦࠢࡶࡳࡺࡸࡣࡦࠢࡷࡳࡵࠦࡤࡪࡴࡨࡧࡹࡵࡲࡺࠢ࠿ࡸࡴࡶࡤࡪࡴࡁࠤࡦࡴࡤࠡࡴࡸࡲࠥࢁ࠰ࡾࠢࡩࡶࡴࡳࠠࡵࡪࡨࡶࡪ࠴ࠍࠋࡋࡷࠤࡼ࡯࡬࡭ࠢࡪࡩࡳ࡫ࡲࡢࡶࡨࠤࡦࡴࠠࡰࡤࡩࡹࡸࡩࡡࡵ࡫ࡲࡲࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹࠡ࠾ࡷࡳࡵࡪࡩࡳࡀ࠲࠲࠳࠵࠼ࡵࡱࡳࡨ࡮ࡸ࠾ࡠࡽ࠴ࢁࠒࠐࠍࠋࡃࡷࠤ࡫࡯ࡲࡴࡶࠣࡷࡴࡳࡥࠡ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࡸࠦ࡭ࡢࡻࠣࡦࡪࠦ࡯ࡣࡨࡸࡷࡨࡧࡴࡦࡦࠣࡸ࡭ࡧࡴࠡࡵ࡫ࡳࡺࡲࡤ࡯ࠩࡷࠤࡧ࡫ࠬࠡࡧ࠱࡫࠳ࠦࡳࡰ࡯ࡨࠤࡴ࡬ࠠࡵࡪࡲࡷࡪࠦࡩ࡮ࡲࡲࡶࡹ࡫ࡤࠡࡨࡵࡳࡲࠦࡥࡹࡶࡨࡶࡳࡧ࡬ࠡ࡯ࡲࡨࡺࡲࡥࡴ࠰ࠌࠑࠏࡇࡤࡢࡲࡷࠤࡾࡵࡵࡳࠢࡦࡳࡳ࡬ࡩࡨࠢࡩ࡭ࡱ࡫ࠠࡵࡱࠣࡥࡻࡵࡩࡥࠢࡷ࡬࡮ࡹࠬࠡࡧ࠱࡫࠳ࠦࡢࡺࠢࡤࡨࡩ࡯࡮ࡨࠢࡨࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡲࡵࡤࡶ࡮ࡨࠤࡳࡧ࡭ࡦࡵࠣࡸ࡭ࡧࡴࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡵࡩࡨࡻࡲࡴ࡫ࡹࡩࡱࡿࠠࡴࡥࡤࡲࡳ࡫ࡤࠡࡨࡲࡶࠥ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࡵ࠱ࠑࠏ࡟࡯ࡶࠢࡰࡥࡾࠦࡡ࡭ࡵࡲࠤࡪࡾࡣ࡭ࡷࡧࡩࠥࡩࡥࡳࡶࡤ࡭ࡳࠦࡷࡰࡴࡧࡷࠥࡵࡲࠡࡨ࡬ࡰࡪࡹࠠࡪࡰࠣࡽࡴࡻࡲࠡࡲࡵࡳ࡯࡫ࡣࡵࠢࡩࡶࡴࡳࠠࡰࡤࡩࡹࡸࡩࡡࡵ࡫ࡲࡲࠥ࡫ࡸࡱ࡮࡬ࡧ࡮ࡺ࡬ࡺ࠰ࠐࠎࡘࡵࡵࡳࡥࡨࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠬࠡࡱࡥࡪࡺࡹࡣࡢࡶ࡬ࡳࡳࠦࡤࡪࡴࡨࡧࡹࡵࡲࡺࠢࡤࡲࡩࠦࡣࡰࡰࡩ࡭࡬ࠦࡦࡪ࡮ࡨࠤࡵࡧࡴࡩࠢࡦࡥࡳࠦࡡ࡭ࡵࡲࠤࡧ࡫ࠠࡴࡷࡳࡴࡱ࡯ࡥࡥࠢࡤࡷࠥࡩ࡯࡮࡯ࡤࡲࡩࠦ࡬ࡪࡰࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡ࡫ࡱࠤࡹ࡮ࡡࡵࠢࡲࡶࡩ࡫ࡲ࠯ࠏࠍࡇࡴࡳ࡭ࡦࡰࡷࡷࠥࡧ࡮ࡥࠢࡶࡸࡷ࡯࡮ࡨࠢ࡯࡭ࡹ࡫ࡲࡢ࡮ࡶࠤࡨࡧ࡮ࠡࡤࡨࠤࡲࡧࡲ࡬ࡧࡧࠤࡦࡹࠠࡱ࡮ࡤ࡭ࡳ࠲ࠠࡣࡻࡳࡥࡸࡹࡩ࡯ࡩࠣࡳࡧ࡬ࡵࡴࡥࡤࡸ࡮ࡵ࡮ࠎࠌࠐࠎࡐࡴ࡯ࡸࡰࠣࡰ࡮ࡳࡩࡵࡣࡷ࡭ࡴࡴࡳ࠻ࠏࠍࡅࠥࡩ࡯࡮࡯ࡨࡲࡹࠦࡡࡧࡶࡨࡶࠥࡧࠠࡴࡶࡵ࡭ࡳ࡭ࠠ࡭࡫ࡷࡩࡷࡧ࡬ࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡵࡸࡥࡤࡧࡧࡩࡩࠦࡢࡺࠢࡺ࡬࡮ࡺࡥࡴࡲࡤࡧࡪࠓࠊࡂࠢࠪࠤࡴࡸࠠࠣࠢ࡬ࡲࡸ࡯ࡤࡦࠢࡤࠤࡸࡺࡲࡪࡰࡪࠤࡱ࡯ࡴࡦࡴࡤࡰࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡧࡶࡧࡦࡶࡥࡥࠢࡺ࡭ࡹ࡮ࠠ࡝ࠢࡵࡥࡹ࡮ࡥࡳࠢࡷ࡬ࡪࡴࠠࡥࡱࡸࡦࡱ࡫ࡤࠎࠌࡄࠤࢀ࠸ࡽࠡ࡫ࡱࠤࡦࠦࡳࡵࡴ࡬ࡲ࡬ࠦ࡬ࡪࡶࡨࡶࡦࡲࠠࡤࡣࡱࠤࡴࡴ࡬ࡺࠢࡥࡩࠥࡻࡳࡦࡦࠣࡥࡹࠦࡴࡩࡧࠣࡷࡹࡧࡲࡵ࠮ࠣࡷࡴࠦࡵࡴࡧࠣࠫࡵ࠭ࠧࡼ࠴ࢀࠫࠬࡸࠧࠡࡴࡤࡸ࡭࡫ࡲࠡࡶ࡫ࡥࡳࠦࠧࡱࡽ࠵ࢁࡷ࠭ࠍࠋࡑࡥࡪࡺࡹࡣࡢࡶ࡬ࡳࡳࠦ࡯ࡧࠢࡶࡸࡷ࡯࡮ࡨࠢ࡯࡭ࡹ࡫ࡲࡢ࡮ࡶࠤ࡮ࡹࠠࡶࡰࡶࡹ࡮ࡺࡡࡣ࡮ࡨࠤ࡫ࡵࡲࠡࡵࡨࡲࡸ࡯ࡴࡪࡸࡨࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯ࠢࡶ࡭ࡳࡩࡥࠡ࡫ࡷࠤࡨࡧ࡮ࠡࡤࡨࠤࡹࡸࡩࡷ࡫ࡤࡰࡱࡿࠠࡣࡴࡲ࡯ࡪࡴࠍࠋࡐࡲࠤࡷ࡫࡮ࡢ࡯࡬ࡲ࡬ࠦࡢࡢࡥ࡮ࡨࡴࡵࡲࠡࡵࡸࡴࡵࡵࡲࡵࠢࡩࡳࡷࠦ࡭ࡦࡶ࡫ࡳࡩࡹࠠࡴࡶࡤࡶࡹ࡯࡮ࡨࠢࡺ࡭ࡹ࡮ࠠࡠࡡࠣࠬࡳࡵ࡮࠮ࡱࡹࡩࡷࡸࡩࡥࡣࡥࡰࡪࠦ࡭ࡦࡶ࡫ࡳࡩࡹࠬࠡࡣ࡯ࡷࡴࠦ࡫࡯ࡱࡺࡲࠥࡧࡳࠡࡲࡵ࡭ࡻࡧࡴࡦࠢࡰࡩࡹ࡮࡯ࡥࡵࠬࠑࠏࠓࠊࡍ࡫ࡦࡩࡳࡩࡥ࠻ࠏࠍࡿ࠸ࢃࠍࠋࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭ࠑࠏࠏࠉࠨࠩࠪয").format (programName.capitalize (), programName, l1l1_cdax_ (u"ࡴࠪࠧࠬর"), license))
		exit (errorLevel)
	sourceRootDirectory = os.getcwd ()
	if len (sys.argv) > 2:
		targetRootDirectory = sys.argv [2]
	else:
		targetRootDirectory = l1l1_cdax_ (u"ࠪࡿ࠵ࢃ࡜࡝ࡽ࠴ࢁࡤࢁ࠲ࡾࠩ঱").format (* (sourceRootDirectory.rsplit (pathseparator, 1) + [programName]))
	if len (sys.argv) > 3:
		configFilePath = sys.argv [3]
	else:
		configFilePath = l1l1_cdax_ (u"ࠫࢀ࠶ࡽ࡝࡞ࡾ࠵ࢂࡥࡣࡰࡰࡩ࡭࡬࠴ࡴࡹࡶࠪল").format (sourceRootDirectory, programName)
	obfuscate_strings = False
	obfuscated_name_tail = l1l1_cdax_ (u"ࠬࡥࡻࡾࡡࠪ঳").format (programName)
	plain_marker = l1l1_cdax_ (u"࠭࡟ࡼࡿࡢࠫ঴").format (programName)
	source_extensions = l1l1_cdax_ (u"ࠧࠨ঵")
	skip_extensions = l1l1_cdax_ (u"ࠨࠩশ")
	external_modules = l1l1_cdax_ (u"ࠩࠪষ")
	plain_files = l1l1_cdax_ (u"ࠪࠫস")
	plain_names = l1l1_cdax_ (u"ࠫࠬহ")
	try:
		configFile = open (configFilePath)
	except Exception as exception:
		print (exception)
		printHelpAndExit (1)
	exec (configFile.read ())
	configFile.close ()
	try:
		obfuscateStrings = obfuscate_strings
	except:
		obfuscateStrings = False
	try:
		asciiStrings = l1l11111_cdax_
	except:
		asciiStrings = False
	try:
		obfuscatedNameTail = obfuscated_name_tail
	except:
		obfuscatedNameTail = l1l1_cdax_ (u"ࠬ࠭঺")
	try:
		plainMarker = plain_marker
	except:
		plainMarker = l1l1_cdax_ (u"࠭࡟ࡼ࠲ࢀࡣࠬ঻").format (programName)
	sourceFileNameExtensionList = source_extensions.split ()
	skipFileNameExtensionList = skip_extensions.split ()
	externalModuleNameList = external_modules.split ()
	plainFileRelPathList = plain_files.split ()
	extraPlainWordList = plain_names.split ()
	sourceFilePathList = [
		l1l1_cdax_ (u"ࠧࡼ࠲ࢀࡠࡡࢁ࠱ࡾ়ࠩ").format (directory.replace (l1l1_cdax_ (u"ࠨ࡞࡟ࠫঽ"), pathseparator), fileName)
		for directory, subDirectories, fileNames in os.walk (sourceRootDirectory)
		for fileName in fileNames
	]
	shebangCommentRegEx = re.compile (l1l1_cdax_ (u"ࡴࠪࡢࢀ࠶ࡽࠢࠩা").format (l1l1_cdax_ (u"ࡵࠫࠨ࠭ি")))
	codingCommentRegEx = re.compile (l1l1_cdax_ (u"ࠫࡨࡵࡤࡪࡰࡪ࡟࠿ࡃ࡝࡝ࡵ࠭ࠬࡠ࠳࡜ࡸ࠰ࡠ࠯࠮࠭ী"))
	keepCommentRegEx = re.compile (l1l1_cdax_ (u"ࠬ࠴ࠪࡼ࠲ࢀ࠲࠯࠭ু").format (plainMarker), re.DOTALL)
	def getCommentPlaceholderAndRegister (matchObject):
		comment = matchObject.group (0)
		if keepCommentRegEx.search (comment):
			l1l1llll_cdax_.append (comment.replace (plainMarker, l1l1_cdax_ (u"࠭ࠧূ")))
			return commentPlaceholder
		else:
			return l1l1_cdax_ (u"ࠧࠨৃ")
	def getComment (matchObject):
		global l1ll1l11_cdax_
		l1ll1l11_cdax_ += 1
		return l1l1llll_cdax_ [l1ll1l11_cdax_]
	commentRegEx = re.compile (l1l1_cdax_ (u"ࡳࠩࡾ࠴ࢂࢁ࠱ࡾࡽ࠵ࢁ࠳࠰࠿ࠥࠩৄ").format (
		l1l1_cdax_ (u"ࡴࠥࠬࡄࡂࠡࠨࠫࠥ৅"),
		l1l1_cdax_ (u"ࡵࠫ࠭ࡅ࠼ࠢࠤࠬࠫ৆"),
		l1l1_cdax_ (u"ࡶࠬࠩࠧে")
	), re.MULTILINE)
	commentPlaceholder = l1l1_cdax_ (u"ࠬࡥࡻ࠱ࡿࡢࡧࡤ࠭ৈ").format (programName)
	commentPlaceholderRegEx = re.compile (l1l1_cdax_ (u"ࡸࠧࡼ࠲ࢀࠫ৉").format (commentPlaceholder))
	keepStringRegEx = re.compile (l1l1_cdax_ (u"ࡲࠨ࠰࠭ࡿ࠵ࢃ࠮ࠫࠩ৊").format (plainMarker))
	def getDecodedStringPlaceholderAndRegister (matchObject):
		string = matchObject.group (0)
		if obfuscateStrings:
			if keepStringRegEx.search (string):
				l1ll11l1_cdax_.append (string.replace (plainMarker, l1l1_cdax_ (u"ࠨࠩো")))
				return stringPlaceholder
			else:
				l1ll11l1_cdax_.append (scramble (string))
				return l1l1_cdax_ (u"ࠩࡸࡲࡘࡩࡲࡢ࡯ࡥࡰࡪࢁ࠰ࡾࠢࠫࡿ࠶ࢃࠩࠨৌ").format (plainMarker, stringPlaceholder)
		else:
			l1ll11l1_cdax_.append (string)
			return stringPlaceholder
	def getString (matchObject):
		global l1l11l1l_cdax_
		l1l11l1l_cdax_ += 1
		return l1ll11l1_cdax_ [l1l11l1l_cdax_]
	stringRegEx = re.compile (l1l1_cdax_ (u"ࡵࠫ࠭ࡡࡲࡶ࡟ࡿࡶࡺࢂࡵࡳࠫࡂࠬ࠭ࢁ࠰ࡾࠫࡿࠬࢀ࠷ࡽࠪࡾࠫࡿ࠷ࢃࠩࡽࠪࡾ࠷ࢂ࠯ࠩࠨ্").format (
		l1l1_cdax_ (u"ࡶࠧ࠭ࠧࠨ࠰࠭ࡃ࠭ࡅ࠼ࠢ࡝ࡡࡠࡡࡣ࡜࡝ࠫࠫࡃࡁ࡛ࠧ࡟࡞࡟ࡡࡡ࠭ࠩࠨࠩࠪࠦৎ"),
		l1l1_cdax_ (u"ࡷ࠭ࠢࠣࠤ࠱࠮ࡄ࠮࠿࠽ࠣ࡞ࡢࡡࡢ࡝࡝࡞ࠬࠬࡄࡂࠡ࡜ࡠ࡟ࡠࡢࡢࠢࠪࠤࠥࠦࠬ৏"),
		l1l1_cdax_ (u"ࡸࠢࠨ࠰࠭ࡃ࠭ࡅ࠼ࠢ࡝ࡡࡠࡡࡣ࡜࡝ࠫࠪࠦ৐"),
		l1l1_cdax_ (u"ࡲࠨࠤ࠱࠮ࡄ࠮࠿࠽ࠣ࡞ࡢࡡࡢ࡝࡝࡞ࠬࠦࠬ৑")
	), re.MULTILINE | re.DOTALL | re.VERBOSE)
	stringPlaceholder = l1l1_cdax_ (u"ࠨࡡࡾ࠴ࢂࡥࡳࡠࠩ৒").format (programName)
	stringPlaceholderRegEx = re.compile (l1l1_cdax_ (u"ࡴࠪࡿ࠵ࢃࠧ৓").format (stringPlaceholder))
	def moveFromFuture (matchObject):
		fromFuture = matchObject.group (0)
		if fromFuture:
			global l1l1ll1l_cdax_
			l1l1l11l_cdax_ [l1l1ll1l_cdax_:l1l1ll1l_cdax_] = [fromFuture]
			l1l1ll1l_cdax_ += 1
		return l1l1_cdax_ (u"ࠪࠫ৔")
	fromFutureRegEx = re.compile (l1l1_cdax_ (u"ࠫ࡫ࡸ࡯࡮࡞ࡶ࠮ࡤࡥࡦࡶࡶࡸࡶࡪࡥ࡟࡝ࡵ࠭࡭ࡲࡶ࡯ࡳࡶ࡟ࡷ࠯ࡢࡷࠬ࠰࠭ࠨࠬ৕"), re.MULTILINE)
	identifierRegEx = re.compile (l1l1_cdax_ (u"ࡷ࠭ࠧࠨࠏࠍࠍࠎࡢࡢࠊࠋࠌࠎࠎࠏࠨࡀࠣࡾ࠴ࢂ࠯ࠉࠊࠌࠌࠍ࠭ࡅࠡࡼ࠳ࢀ࠭ࠎࠏࠊࠊࠋ࡞ࡢࡡࡪ࡜ࡘ࡟ࠌࠍࠏࠏࠉ࡝ࡹ࠭ࠍࠎࠏࠊࠊࠋࠫࡃࡁࠧ࡟ࡠࠫࠌࠍࠏࠏࠉࠩࡁ࠿ࠥࢀ࠶ࡽࠪࠋࠍࠍࠎ࠮࠿࠽ࠣࡾ࠵ࢂ࠯ࠉࠋࠋࠌࡠࡧࠏࠉࠊࠌࠌࠫࠬ࠭৖").format (commentPlaceholder, stringPlaceholder), re.VERBOSE)
	chrRegEx = re.compile (l1l1_cdax_ (u"ࡸࠧ࡝ࡤࡦ࡬ࡷࡢࡢࠨৗ"))
	skipWordSet = set (keyword.kwlist + [l1l1_cdax_ (u"ࠧࡠࡡ࡬ࡲ࡮ࡺ࡟ࡠࠩ৘")] + extraPlainWordList)
	plainFilePathList = [l1l1_cdax_ (u"ࠨࡽ࠳ࢁࡡࡢࡻ࠲ࡿࠪ৙").format (sourceRootDirectory, plainFileRelPath) for plainFileRelPath in plainFileRelPathList]
	for plainFilePath in plainFilePathList:
		plainFile = open (plainFilePath)
		content = plainFile.read ()
		plainFile.close ()
		content = commentRegEx.sub (l1l1_cdax_ (u"ࠩࠪ৚"), content)
		content = stringRegEx.sub (l1l1_cdax_ (u"ࠪࠫ৛"), content)
		skipWordSet.update (re.findall (identifierRegEx, content))
	class ExternalModules:
		def __init__ (self):
			for externalModuleName in externalModuleNameList:
				attributeName = externalModuleName.replace (l1l1_cdax_ (u"ࠫ࠳࠭ড়"), plainMarker)
				try:
					exec (
						l1l1_cdax_ (u"ࠬ࠭ࠧࠎࠌ࡬ࡱࡵࡵࡲࡵࠢࡾ࠴ࢂࠦࡡࡴࠢࡦࡹࡷࡸࡥ࡯ࡶࡐࡳࡩࡻ࡬ࡦࠏࠍࠍࠎࠏࠉࠊࠋࠪࠫࠬঢ়").format (externalModuleName),
						globals ()
					)
					setattr (self, attributeName, currentModule)
				except Exception as exception:
					print (exception)
					setattr (self, attributeName, None)
					print (l1l1_cdax_ (u"࠭ࡗࡢࡴࡱ࡭ࡳ࡭࠺ࠡࡥࡲࡹࡱࡪࠠ࡯ࡱࡷࠤ࡮ࡴࡳࡱࡧࡦࡸࠥ࡫ࡸࡵࡧࡵࡲࡦࡲࠠ࡮ࡱࡧࡹࡱ࡫ࠠࡼ࠲ࢀࠫ৞").format (externalModuleName))
	externalModules = ExternalModules ()
	externalObjects = set ()
	def addExternalNames (anObject):
		if anObject in externalObjects:
			return
		else:
			externalObjects.update ([anObject])
		try:
			attributeNameList = list (anObject.__dict__)
		except:
			attributeNameList = []
		try:
			if isPython2:
				parameterNameList = list (anObject.func_code.co_varnames)
			else:
				parameterNameList = list (anObject.__code__.co_varnames)
		except:
			parameterNameList = []
		attributeList = [getattr (anObject, attributeName) for attributeName in attributeNameList]
		attributeSkipWordList = (plainMarker.join (attributeNameList)) .split (plainMarker)
		updateSet = set ([entry for entry in (parameterNameList + attributeSkipWordList) if not (entry.startswith (l1l1_cdax_ (u"ࠧࡠࡡࠪয়")) and entry.endswith (l1l1_cdax_ (u"ࠨࡡࡢࠫৠ")))])
		skipWordSet.update (updateSet)
		for attribute in attributeList:
			try:
				addExternalNames (attribute)
			except:
				pass
	addExternalNames (__builtins__)
	addExternalNames (externalModules)
	l1l111l1_cdax_ = list (skipWordSet)
	l1l111l1_cdax_.sort (key = lambda s: s.lower ())
	l1l1ll11_cdax_ = []
	l11lllll_cdax_ = []
	for l11ll1l1_cdax_ in sourceFilePathList:
		if l11ll1l1_cdax_ == configFilePath:
			continue
		l1l11lll_cdax_, l11ll11l_cdax_ = l11ll1l1_cdax_.rsplit (pathseparator, 1)
		l1l111ll_cdax_, l1ll111l_cdax_ = (l11ll11l_cdax_.rsplit (l1l1_cdax_ (u"ࠩ࠱ࠫৡ"), 1) + [l1l1_cdax_ (u"ࠪࠫৢ")]) [ : 2]
		l11lll11_cdax_ =  l11ll1l1_cdax_ [len (sourceRootDirectory) : ]
		if l1ll111l_cdax_ in sourceFileNameExtensionList and not l11ll1l1_cdax_ in plainFilePathList:
			stringBase = random.randrange (64)
			l11lll1l_cdax_ = codecs.open (l11ll1l1_cdax_, encoding = l1l1_cdax_ (u"ࠫࡺࡺࡦ࠮࠺ࠪৣ"))
			content = l11lll1l_cdax_.read ()
			l11lll1l_cdax_.close ()
			l1l1llll_cdax_ = []
			l1l1l11l_cdax_ = content.split (l1l1_cdax_ (u"ࠬࡢ࡮ࠨ৤"), 2)
			l1l1ll1l_cdax_ = 0
			l1l1l111_cdax_ = True
			if len (l1l1l11l_cdax_) > 0:
				if shebangCommentRegEx.search (l1l1l11l_cdax_ [0]):
					l1l1ll1l_cdax_ += 1
					if len (l1l1l11l_cdax_) > 1 and codingCommentRegEx.search (l1l1l11l_cdax_ [1]):
						l1l1ll1l_cdax_ += 1
						l1l1l111_cdax_ = False
				elif codingCommentRegEx.search (l1l1l11l_cdax_ [0]):
					l1l1ll1l_cdax_ += 1
					l1l1l111_cdax_ = False
			if obfuscateStrings and l1l1l111_cdax_:
				l1l1l11l_cdax_ [l1l1ll1l_cdax_:l1l1ll1l_cdax_] = [l1l1_cdax_ (u"࠭ࠣࠡࡥࡲࡨ࡮ࡴࡧ࠻ࠢࡘࡘࡋ࠳࠸ࠨ৥")]
				l1l1ll1l_cdax_ += 1
			if obfuscateStrings:
				l1ll1111_cdax_ = l1l1_cdax_ (u"ࠧ࡝ࡰࠪ০").join ([getUnScrambler (stringBase)] + l1l1l11l_cdax_ [l1l1ll1l_cdax_:])
			else:
				l1ll1111_cdax_ = l1l1_cdax_ (u"ࠨ࡞ࡱࠫ১").join (l1l1l11l_cdax_ [l1l1ll1l_cdax_:])
			l1ll1111_cdax_ = commentRegEx.sub (getCommentPlaceholderAndRegister, l1ll1111_cdax_)
			l1ll11l1_cdax_ = []
			l1ll1111_cdax_ = stringRegEx.sub (getDecodedStringPlaceholderAndRegister, l1ll1111_cdax_)
			l1ll1111_cdax_ = fromFutureRegEx.sub (moveFromFuture, l1ll1111_cdax_)
			l1ll1l1l_cdax_ = set (re.findall (identifierRegEx, l1ll1111_cdax_) + [l1l111ll_cdax_])
			l1l1lll1_cdax_ = l1ll1l1l_cdax_.difference (l1l1ll11_cdax_).difference (skipWordSet)
			l1l11ll1_cdax_ = list (l1l1lll1_cdax_)
			l11llll1_cdax_ = [re.compile (l1l1_cdax_ (u"ࡴࠪࡠࡧࢁ࠰ࡾ࡞ࡥࠫ২").format (l1l1l1ll_cdax_)) for l1l1l1ll_cdax_ in l1l11ll1_cdax_]
			l1l1ll11_cdax_ += l1l11ll1_cdax_
			l11lllll_cdax_ += l11llll1_cdax_
			for obfuscationIndex, l1l11l11_cdax_ in enumerate (l11lllll_cdax_):
				l1ll1111_cdax_ = l1l11l11_cdax_.sub (
					getObfuscatedName (obfuscationIndex, l1l1ll11_cdax_ [obfuscationIndex]),
					l1ll1111_cdax_
				)
			l1l11l1l_cdax_ = -1
			l1ll1111_cdax_ = stringPlaceholderRegEx.sub (getString, l1ll1111_cdax_)
			l1ll1l11_cdax_ = -1
			l1ll1111_cdax_ = commentPlaceholderRegEx.sub (getComment, l1ll1111_cdax_)
			content = l1l1_cdax_ (u"ࠪࡠࡳ࠭৩").join (l1l1l11l_cdax_ [:l1l1ll1l_cdax_] + [l1ll1111_cdax_])
			content = l1l1_cdax_ (u"ࠫࡡࡴࠧ৪").join ([line for line in [line.rstrip () for line in content.split (l1l1_cdax_ (u"ࠬࡢ࡮ࠨ৫"))] if line])
			try:
				l11ll111_cdax_ = getObfuscatedName (l1l1ll11_cdax_.index (l1l111ll_cdax_), l1l111ll_cdax_)
			except:
				l11ll111_cdax_ = l1l111ll_cdax_
			l1l1111l_cdax_ = l11lll11_cdax_.split (pathseparator)
			for index in range (len (l1l1111l_cdax_)):
				try:
					l1l1111l_cdax_ [index] = getObfuscatedName (l1l1ll11_cdax_.index (l1l1111l_cdax_ [index]), l1l1111l_cdax_ [index])
				except:
					pass
			l11lll11_cdax_ = pathseparator.join (l1l1111l_cdax_)
			l1l1l1l1_cdax_ = l1l1_cdax_ (u"࠭ࡻ࠱ࡿࡾ࠵ࢂ࠭৬").format (targetRootDirectory, l11lll11_cdax_) .rsplit (pathseparator, 1) [0]
			l11ll1ll_cdax_ = createFilePath (l1l1_cdax_ (u"ࠧࡼ࠲ࢀࡠࡡࢁ࠱ࡾ࠰ࡾ࠶ࢂ࠭৭").format (l1l1l1l1_cdax_, l11ll111_cdax_, l1ll111l_cdax_), open = True)
			l11ll1ll_cdax_.write (content)
			l11ll1ll_cdax_.close ()
		elif not l1ll111l_cdax_ in skipFileNameExtensionList:
			l1l1l1l1_cdax_ = l1l1_cdax_ (u"ࠨࡽ࠳ࢁࢀ࠷ࡽࠨ৮").format (targetRootDirectory, l11lll11_cdax_) .rsplit (pathseparator, 1) [0]
			l1ll11ll_cdax_ = l1l1_cdax_ (u"ࠩࡾ࠴ࢂࡢ࡜ࡼ࠳ࢀࠫ৯").format (l1l1l1l1_cdax_, l11ll11l_cdax_)
			createFilePath (l1ll11ll_cdax_)
			shutil.copyfile (l11ll1l1_cdax_, l1ll11ll_cdax_)
	print (l1l1_cdax_ (u"ࠪࡓࡧ࡬ࡵࡴࡥࡤࡸࡪࡪࠠࡸࡱࡵࡨࡸࡀࠠࡼ࠲ࢀࠫৰ").format (len (l1l1ll11_cdax_)))