#! /usr/bin/python
# coding: UTF-8
import sys
l1l11l_fo_ = sys.version_info [0] == 2
l1llll_fo_ = 2048
l11l_fo_ = 7
def l11ll_fo_ (ll_fo_):
	global l1ll11_fo_
	l1l1l1_fo_ = ord (ll_fo_ [-1])
	l1l11_fo_ = ll_fo_ [:-1]
	l1l_fo_ = l1l1l1_fo_ % len (l1l11_fo_)
	l11_fo_ = l1l11_fo_ [:l1l_fo_] + l1l11_fo_ [l1l_fo_:]
	if l1l11l_fo_:
		l1111_fo_ = unicode () .join ([unichr (ord (char) - l1llll_fo_ - (l1l1l_fo_ + l1l1l1_fo_) % l11l_fo_) for l1l1l_fo_, char in enumerate (l11_fo_)])
	else:
		l1111_fo_ = str () .join ([chr (ord (char) - l1llll_fo_ - (l1l1l_fo_ + l1l1l1_fo_) % l11l_fo_) for l1l1l_fo_, char in enumerate (l11_fo_)])
	return eval (l1111_fo_)
license = (
l11ll_fo_ (u"ࠩࠪࠫࡤࡵࡰࡺࡡࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥ࠸࠰࠲࠶࠯ࠤ࠷࠶࠱࠶࠮ࠣ࠶࠵࠷࠶ࠡࡌࡤࡧࡶࡻࡥࡴࠢࡧࡩࠥࡎ࡯ࡰࡩࡨ࠰ࠥࡍࡅࡂࡖࡈࡇࠥ࡫࡮ࡨ࡫ࡱࡩࡪࡸࡩ࡯ࡩ࠯ࠤࡼࡽࡷ࠯ࡩࡨࡥࡹ࡫ࡣ࠯ࡥࡲࡱࠒࠐࠍࠋࡎ࡬ࡧࡪࡴࡳࡦࡦࠣࡹࡳࡪࡥࡳࠢࡷ࡬ࡪࠦࡁࡱࡣࡦ࡬ࡪࠦࡌࡪࡥࡨࡲࡸ࡫ࠬࠡࡘࡨࡶࡸ࡯࡯࡯ࠢ࠵࠲࠵ࠦࠨࡵࡪࡨࠤࠧࡒࡩࡤࡧࡱࡷࡪࠨࠩ࠼ࠏࠍࡽࡴࡻࠠ࡮ࡣࡼࠤࡳࡵࡴࠡࡷࡶࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡧࡻࡧࡪࡶࡴࠡ࡫ࡱࠤࡨࡵ࡭ࡱ࡮࡬ࡥࡳࡩࡥࠡࡹ࡬ࡸ࡭ࠦࡴࡩࡧࠣࡐ࡮ࡩࡥ࡯ࡵࡨ࠲ࠒࠐ࡙ࡰࡷࠣࡱࡦࡿࠠࡰࡤࡷࡥ࡮ࡴࠠࡢࠢࡦࡳࡵࡿࠠࡰࡨࠣࡸ࡭࡫ࠠࡍ࡫ࡦࡩࡳࡹࡥࠡࡣࡷࠑࠏࠓࠊࠡࠢࠣࠤ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡳࡥࡨ࡮ࡥ࠯ࡱࡵ࡫࠴ࡲࡩࡤࡧࡱࡷࡪࡹ࠯ࡍࡋࡆࡉࡓ࡙ࡅ࠮࠴࠱࠴ࠒࠐࠍࠋࡗࡱࡰࡪࡹࡳࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡦࡾࠦࡡࡱࡲ࡯࡭ࡨࡧࡢ࡭ࡧࠣࡰࡦࡽࠠࡰࡴࠣࡥ࡬ࡸࡥࡦࡦࠣࡸࡴࠦࡩ࡯ࠢࡺࡶ࡮ࡺࡩ࡯ࡩ࠯ࠤࡸࡵࡦࡵࡹࡤࡶࡪࠓࠊࡥ࡫ࡶࡸࡷ࡯ࡢࡶࡶࡨࡨࠥࡻ࡮ࡥࡧࡵࠤࡹ࡮ࡥࠡࡎ࡬ࡧࡪࡴࡳࡦࠢ࡬ࡷࠥࡪࡩࡴࡶࡵ࡭ࡧࡻࡴࡦࡦࠣࡳࡳࠦࡡ࡯ࠢࠥࡅࡘࠦࡉࡔࠤࠣࡆࡆ࡙ࡉࡔ࠮ࠐࠎ࡜ࡏࡔࡉࡑࡘࡘࠥ࡝ࡁࡓࡔࡄࡒ࡙ࡏࡅࡔࠢࡒࡖࠥࡉࡏࡏࡆࡌࡘࡎࡕࡎࡔࠢࡒࡊࠥࡇࡎ࡚ࠢࡎࡍࡓࡊࠬࠡࡧ࡬ࡸ࡭࡫ࡲࠡࡧࡻࡴࡷ࡫ࡳࡴࠢࡲࡶࠥ࡯࡭ࡱ࡮࡬ࡩࡩ࠴ࠍࠋࡕࡨࡩࠥࡺࡨࡦࠢࡏ࡭ࡨ࡫࡮ࡴࡧࠣࡪࡴࡸࠠࡵࡪࡨࠤࡸࡶࡥࡤ࡫ࡩ࡭ࡨࠦ࡬ࡢࡰࡪࡹࡦ࡭ࡥࠡࡩࡲࡺࡪࡸ࡮ࡪࡰࡪࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮ࡴࠢࡤࡲࡩࠓࠊ࡭࡫ࡰ࡭ࡹࡧࡴࡪࡱࡱࡷࠥࡻ࡮ࡥࡧࡵࠤࡹ࡮ࡥࠡࡎ࡬ࡧࡪࡴࡳࡦ࠰ࠪࠫࠬ৶")
)
import re
import os
import sys
import errno
import keyword
import importlib
import random
import codecs
import shutil
l1lllllll_fo_ = l11ll_fo_ (u"ࠪࡳࡵࡿࠧ৷")
l1lll1l11_fo_ = l11ll_fo_ (u"ࠫ࠶࠴࠱࠯࠴࠵ࠫ৸")
if __name__ == l11ll_fo_ (u"ࠬࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠧ৹"):
	print (l11ll_fo_ (u"࠭ࡻࡾࠢࠫࡘࡒ࠯ࠠࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡥࡰࡪࠦࡍࡶ࡮ࡷ࡭ࠥࡓ࡯ࡥࡷ࡯ࡩࠥࡖࡹࡵࡪࡲࡲࠥࡕࡢࡧࡷࡶࡧࡦࡺ࡯ࡳ࡙ࠢࡩࡷࡹࡩࡰࡰࠣࡿࢂ࠭৺").format (l1lllllll_fo_.capitalize (), l1lll1l11_fo_))
	print (l11ll_fo_ (u"ࠧࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࠬࡈ࠯ࠠࡈࡧࡤࡸࡪࡩࠠࡆࡰࡪ࡭ࡳ࡫ࡥࡳ࡫ࡱ࡫࠳ࠦࡌࡪࡥࡨࡲࡸ࡫࠺ࠡࡃࡳࡥࡨ࡮ࡥࠡ࠴࠱࠴ࠥࡧࡴࠡࠢ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡱࡣࡦ࡬ࡪ࠴࡯ࡳࡩ࠲ࡰ࡮ࡩࡥ࡯ࡵࡨࡷ࠴ࡒࡉࡄࡇࡑࡗࡊ࠳࠲࠯࠲࡟ࡲࠬ৻"))
	random.seed ()
	l1l1ll1ll_fo_ = sys.version_info [0] == 2
	l11111ll_fo_ = 2048
	l1l1l1_fo_ = l11111ll_fo_
	l1l11ll1l_fo_ = 7
	l111111l_fo_ = os.path.sep
	def l1lllll1l_fo_ (l11l1ll1_fo_, open = False):
		print l11ll_fo_ (u"ࠨࡥࡵࡩࡦࡺࡥࡇ࡫࡯ࡩࡕࡧࡴࡩࠢࠨࡷࠬৼ")%l11l1ll1_fo_
		try:
			os.makedirs (l11l1ll1_fo_.rsplit (l111111l_fo_, 1) [0])
		except OSError as l1ll111ll_fo_:
			print l11ll_fo_ (u"ࠩࡈࡖࡗࡕࡒ࠻ࠢࡦࡶࡪࡧࡴࡦࡈ࡬ࡰࡪࡖࡡࡵࡪࠪ৽")
			if l1ll111ll_fo_.errno != errno.EEXIST:
				raise
		if open:
			return codecs.open (l11l1ll1_fo_, encoding = l11ll_fo_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ৾"), mode = l11ll_fo_ (u"ࠫࡼ࠭৿"))
	def l1111ll1_fo_ (l1l11l111_fo_, name):
		return l11ll_fo_ (u"ࠬࢁ࠰ࡾࡽ࠴ࢁࢀ࠸ࡽࠨ਀").format (
			l11ll_fo_ (u"࠭࡟ࡠࠩਁ") if name.startswith (l11ll_fo_ (u"ࠧࡠࡡࠪਂ")) else l11ll_fo_ (u"ࠨࡡࠪਃ") if name.startswith (l11ll_fo_ (u"ࠩࡢࠫ਄")) else l11ll_fo_ (u"ࠪࡰࠬਅ"),
			bin (l1l11l111_fo_) [2:] .replace (l11ll_fo_ (u"ࠫ࠵࠭ਆ"), l11ll_fo_ (u"ࠬࡲࠧਇ")),
			l1l1l11ll_fo_
		)
	def l1l1ll11l_fo_ (l1111_fo_):
		global l1l1l1_fo_
		if l1l1ll1ll_fo_:
			l11_fo_ = unicode () .join ([unichr (l11111ll_fo_ + ord (char) + (l1l1l_fo_ + l1l1l1_fo_) % l1l11ll1l_fo_) for l1l1l_fo_, char in enumerate (l1111_fo_)])
			l1l111l1l_fo_ = unichr (l1l1l1_fo_)
		else:
			l11_fo_ = str () .join ([chr (l11111ll_fo_ + ord (char) + (l1l1l_fo_ + l1l1l1_fo_) % l1l11ll1l_fo_) for l1l1l_fo_, char in enumerate (l1111_fo_)])
			l1l111l1l_fo_ = chr (l1l1l1_fo_)
		l1l_fo_ = l1l1l1_fo_ % len (l1111_fo_)
		l1l11_fo_ = l11_fo_ [:-l1l_fo_] + l11_fo_ [-l1l_fo_:]
		ll_fo_ = l1l11_fo_ + l1l111l1l_fo_
		l1l1l1_fo_ += 1
		return l11ll_fo_ (u"࠭ࡵࠣࠩਈ") + ll_fo_ + l11ll_fo_ (u"ࠧࠣࠩਉ")
	def l1l111ll_fo_ (l111l111_fo_):
		return l11ll_fo_ (u"ࠨࠩࠪࠑࠏ࡯࡭ࡱࡱࡵࡸࠥࡹࡹࡴࠏࠍࠑࠏ࡯ࡳࡑࡻࡷ࡬ࡴࡴ࠲ࡼ࠲ࢀࠤࡂࠦࡳࡺࡵ࠱ࡺࡪࡸࡳࡪࡱࡱࡣ࡮ࡴࡦࡰࠢ࡞࠴ࡢࠦ࠽࠾ࠢ࠵ࠑࠏࡩࡨࡢࡴࡅࡥࡸ࡫ࡻ࠱ࡿࠣࡁࠥࢁ࠱ࡾࠏࠍࡧ࡭ࡧࡲࡎࡱࡧࡹࡱࡻࡳࡼ࠲ࢀࠤࡂࠦࡻ࠳ࡿࠐࠎࠒࠐࡤࡦࡨࠣࡹࡳ࡙ࡣࡳࡣࡰࡦࡱ࡫ࡻ࠱ࡿࠣࠬࡰ࡫ࡹࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠫ࠽ࠑࠏࠏࡧ࡭ࡱࡥࡥࡱࠦࡳࡵࡴ࡬ࡲ࡬ࡔࡲࡼ࠲ࢀࠑࠏࠏࠍࠋࠋࡶࡸࡷ࡯࡮ࡨࡐࡵࠤࡂࠦ࡯ࡳࡦࠣࠬࡰ࡫ࡹࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢ࡞࠱࠶ࡣࠩࠎࠌࠌࡶࡴࡺࡡࡵࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣࡁࠥࡱࡥࡺࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣ࡟࠿࠳࠱࡞ࠏࠍࠍࠒࠐࠉࡳࡱࡷࡥࡹ࡯࡯࡯ࡆ࡬ࡷࡹࡧ࡮ࡤࡧࠣࡁࠥࡹࡴࡳ࡫ࡱ࡫ࡓࡸࠠࠦࠢ࡯ࡩࡳࠦࠨࡳࡱࡷࡥࡹ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠩࠎࠌࠌࡶࡪࡩ࡯ࡥࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣࡁࠥࡸ࡯ࡵࡣࡷࡩࡩ࡙ࡴࡳ࡫ࡱ࡫ࡑ࡯ࡴࡦࡴࡤࡰࠥࡡ࠺ࡳࡱࡷࡥࡹ࡯࡯࡯ࡆ࡬ࡷࡹࡧ࡮ࡤࡧࡠࠤ࠰ࠦࡲࡰࡶࡤࡸࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࡛ࠦࡳࡱࡷࡥࡹ࡯࡯࡯ࡆ࡬ࡷࡹࡧ࡮ࡤࡧ࠽ࡡࠒࠐࠉࠊࠏࠍࠍ࡮࡬ࠠࡪࡵࡓࡽࡹ࡮࡯࡯࠴ࡾ࠴ࢂࡀࠍࠋࠋࠌࡷࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣࡁࠥࡻ࡮ࡪࡥࡲࡨࡪࠦࠨࠪࠢ࠱࡮ࡴ࡯࡮ࠡࠪ࡞ࡹࡳ࡯ࡣࡩࡴࠣࠬࡴࡸࡤࠡࠪࡦ࡬ࡦࡸࠩࠡ࠯ࠣࡧ࡭ࡧࡲࡃࡣࡶࡩࢀ࠶ࡽࠡ࠯ࠣࠬࡨ࡮ࡡࡳࡋࡱࡨࡪࡾࠠࠬࠢࡶࡸࡷ࡯࡮ࡨࡐࡵ࠭ࠥࠫࠠࡤࡪࡤࡶࡒࡵࡤࡶ࡮ࡸࡷࢀ࠶ࡽࠪࠢࡩࡳࡷࠦࡣࡩࡣࡵࡍࡳࡪࡥࡹ࠮ࠣࡧ࡭ࡧࡲࠡ࡫ࡱࠤࡪࡴࡵ࡮ࡧࡵࡥࡹ࡫ࠠࠩࡴࡨࡧࡴࡪࡥࡥࡕࡷࡶ࡮ࡴࡧࡍ࡫ࡷࡩࡷࡧ࡬ࠪ࡟ࠬࠑࠏࠏࡥ࡭ࡵࡨ࠾ࠒࠐࠉࠊࡵࡷࡶ࡮ࡴࡧࡍ࡫ࡷࡩࡷࡧ࡬ࠡ࠿ࠣࡷࡹࡸࠠࠩࠫࠣ࠲࡯ࡵࡩ࡯ࠢࠫ࡟ࡨ࡮ࡲࠡࠪࡲࡶࡩࠦࠨࡤࡪࡤࡶ࠮ࠦ࠭ࠡࡥ࡫ࡥࡷࡈࡡࡴࡧࡾ࠴ࢂࠦ࠭ࠡࠪࡦ࡬ࡦࡸࡉ࡯ࡦࡨࡼࠥ࠱ࠠࡴࡶࡵ࡭ࡳ࡭ࡎࡳࠫࠣࠩࠥࡩࡨࡢࡴࡐࡳࡩࡻ࡬ࡶࡵࡾ࠴ࢂ࠯ࠠࡧࡱࡵࠤࡨ࡮ࡡࡳࡋࡱࡨࡪࡾࠬࠡࡥ࡫ࡥࡷࠦࡩ࡯ࠢࡨࡲࡺࡳࡥࡳࡣࡷࡩࠥ࠮ࡲࡦࡥࡲࡨࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࠯࡝ࠪࠏࠍࠍࠎࠓࠊࠊࡴࡨࡸࡺࡸ࡮ࠡࡧࡹࡥࡱࠦࠨࡴࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠩࠎࠌࠌࠫࠬ࠭ਊ").format (l111llll_fo_, l11111ll_fo_, l1l11ll1l_fo_)
	def l1l1lllll_fo_ (l1ll11111_fo_):
		print (l11ll_fo_ (u"ࡴࠪࠫࠬࠓࠊࠎࠌ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮ࠒࠐࡻ࠱ࡿࠣࡻ࡮ࡲ࡬ࠡࡱࡥࡪࡺࡹࡣࡢࡶࡨࠤࡾࡵࡵࡳࠢࡨࡼࡹ࡫࡮ࡴ࡫ࡹࡩ࠱ࠦࡲࡦࡣ࡯ࠤࡼࡵࡲ࡭ࡦ࠯ࠤࡲࡻ࡬ࡵ࡫ࠣࡱࡴࡪࡵ࡭ࡧࠣࡔࡾࡺࡨࡰࡰࠣࡷࡴࡻࡲࡤࡧࠣࡧࡴࡪࡥࠡࡨࡲࡶࠥ࡬ࡲࡦࡧࠤࠑࠏࡇ࡮ࡥࠢ࡜ࡓ࡚ࠦࡣࡩࡱࡲࡷࡪࠦࡰࡦࡴࠣࡴࡷࡵࡪࡦࡥࡷࠤࡼ࡮ࡡࡵࠢࡷࡳࠥࡵࡢࡧࡷࡶࡧࡦࡺࡥࠡࡣࡱࡨࠥࡽࡨࡢࡶࠣࡲࡴࡺࠬࠡࡤࡼࠤࡪࡪࡩࡵࡶ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡧࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥ࠯ࠏࠍࠑࠏࡈࡁࡄࡍࡘࡔࠥ࡟ࡏࡖࡔࠣࡇࡔࡊࡅࠡࡃࡑࡈࠥ࡜ࡁࡍࡗࡄࡆࡑࡋࠠࡅࡃࡗࡅ࡚ࠥࡏࠡࡃࡑࠤࡔࡌࡆ࠮ࡎࡌࡒࡊࠦࡍࡆࡆࡌ࡙ࡒࠦࡆࡊࡔࡖࡘ࡚ࠥࡏࠡࡒࡕࡉ࡛ࡋࡎࡕࠢࡄࡇࡈࡏࡄࡆࡐࡗࡅࡑࠦࡌࡐࡕࡖࠤࡔࡌࠠࡘࡑࡕࡏࠦࠧࠡࠎࠌࠐࠎ࡙࡮ࡥ࡯ࠢࡦࡳࡵࡿࠠࡵࡪࡨࠤࡩ࡫ࡦࡢࡷ࡯ࡸࠥࡩ࡯࡯ࡨ࡬࡫ࠥ࡬ࡩ࡭ࡧࠣࡸࡴࠦࡴࡩࡧࠣࡷࡴࡻࡲࡤࡧࠣࡸࡴࡶࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠣࡀࡹࡵࡰࡥ࡫ࡵࡂࠥࡧ࡮ࡥࠢࡵࡹࡳࠦࡻ࠱ࡿࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࡷ࡫࠮ࠎࠌࡌࡸࠥࡽࡩ࡭࡮ࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࠥࡧ࡮ࠡࡱࡥࡪࡺࡹࡣࡢࡶ࡬ࡳࡳࠦࡤࡪࡴࡨࡧࡹࡵࡲࡺࠢ࠿ࡸࡴࡶࡤࡪࡴࡁ࠳࠳࠴࠯࠽ࡶࡲࡴࡩ࡯ࡲ࠿ࡡࡾ࠵ࢂࠓࠊࠎࠌࡄࡸࠥ࡬ࡩࡳࡵࡷࠤࡸࡵ࡭ࡦࠢ࡬ࡨࡪࡴࡴࡪࡨ࡬ࡩࡷࡹࠠ࡮ࡣࡼࠤࡧ࡫ࠠࡰࡤࡩࡹࡸࡩࡡࡵࡧࡧࠤࡹ࡮ࡡࡵࠢࡶ࡬ࡴࡻ࡬ࡥࡰࠪࡸࠥࡨࡥ࠭ࠢࡨ࠲࡬࠴ࠠࡴࡱࡰࡩࠥࡵࡦࠡࡶ࡫ࡳࡸ࡫ࠠࡪ࡯ࡳࡳࡷࡺࡥࡥࠢࡩࡶࡴࡳࠠࡦࡺࡷࡩࡷࡴࡡ࡭ࠢࡰࡳࡩࡻ࡬ࡦࡵ࠱ࠍࠒࠐࡁࡥࡣࡳࡸࠥࡿ࡯ࡶࡴࠣࡧࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡶࡲࠤࡦࡼ࡯ࡪࡦࠣࡸ࡭࡯ࡳ࠭ࠢࡨ࠲࡬࠴ࠠࡣࡻࠣࡥࡩࡪࡩ࡯ࡩࠣࡩࡽࡺࡥࡳࡰࡤࡰࠥࡳ࡯ࡥࡷ࡯ࡩࠥࡴࡡ࡮ࡧࡶࠤࡹ࡮ࡡࡵࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡶࡪࡩࡵࡳࡵ࡬ࡺࡪࡲࡹࠡࡵࡦࡥࡳࡴࡥࡥࠢࡩࡳࡷࠦࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࡶ࠲ࠒࠐ࡙ࡰࡷࠣࡱࡦࡿࠠࡢ࡮ࡶࡳࠥ࡫ࡸࡤ࡮ࡸࡨࡪࠦࡣࡦࡴࡷࡥ࡮ࡴࠠࡸࡱࡵࡨࡸࠦ࡯ࡳࠢࡩ࡭ࡱ࡫ࡳࠡ࡫ࡱࠤࡾࡵࡵࡳࠢࡳࡶࡴࡰࡥࡤࡶࠣࡪࡷࡵ࡭ࠡࡱࡥࡪࡺࡹࡣࡢࡶ࡬ࡳࡳࠦࡥࡹࡲ࡯࡭ࡨ࡯ࡴ࡭ࡻ࠱ࠑࠏ࡙࡯ࡶࡴࡦࡩࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹ࠭ࠢࡲࡦ࡫ࡻࡳࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠣࡥࡳࡪࠠࡤࡱࡱࡪ࡮࡭ࠠࡧ࡫࡯ࡩࠥࡶࡡࡵࡪࠣࡧࡦࡴࠠࡢ࡮ࡶࡳࠥࡨࡥࠡࡵࡸࡴࡵࡲࡩࡦࡦࠣࡥࡸࠦࡣࡰ࡯ࡰࡥࡳࡪࠠ࡭࡫ࡱࡩࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࡬ࡲࠥࡺࡨࡢࡶࠣࡳࡷࡪࡥࡳ࠰ࠐࠎࡈࡵ࡭࡮ࡧࡱࡸࡸࠦࡡ࡯ࡦࠣࡷࡹࡸࡩ࡯ࡩࠣࡰ࡮ࡺࡥࡳࡣ࡯ࡷࠥࡩࡡ࡯ࠢࡥࡩࠥࡳࡡࡳ࡭ࡨࡨࠥࡧࡳࠡࡲ࡯ࡥ࡮ࡴࠬࠡࡤࡼࡴࡦࡹࡳࡪࡰࡪࠤࡴࡨࡦࡶࡵࡦࡥࡹ࡯࡯࡯ࠏࠍࠑࠏࡑ࡮ࡰࡹࡱࠤࡱ࡯࡭ࡪࡶࡤࡸ࡮ࡵ࡮ࡴ࠼ࠐࠎࡆࠦࡣࡰ࡯ࡰࡩࡳࡺࠠࡢࡨࡷࡩࡷࠦࡡࠡࡵࡷࡶ࡮ࡴࡧࠡ࡮࡬ࡸࡪࡸࡡ࡭ࠢࡶ࡬ࡴࡻ࡬ࡥࠢࡥࡩࠥࡶࡲࡦࡥࡨࡨࡪࡪࠠࡣࡻࠣࡻ࡭࡯ࡴࡦࡵࡳࡥࡨ࡫ࠍࠋࡃࠣࠫࠥࡵࡲࠡࠤࠣ࡭ࡳࡹࡩࡥࡧࠣࡥࠥࡹࡴࡳ࡫ࡱ࡫ࠥࡲࡩࡵࡧࡵࡥࡱࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡨࡷࡨࡧࡰࡦࡦࠣࡻ࡮ࡺࡨࠡ࡞ࠣࡶࡦࡺࡨࡦࡴࠣࡸ࡭࡫࡮ࠡࡦࡲࡹࡧࡲࡥࡥࠏࠍࡅࠥࢁ࠲ࡾࠢ࡬ࡲࠥࡧࠠࡴࡶࡵ࡭ࡳ࡭ࠠ࡭࡫ࡷࡩࡷࡧ࡬ࠡࡥࡤࡲࠥࡵ࡮࡭ࡻࠣࡦࡪࠦࡵࡴࡧࡧࠤࡦࡺࠠࡵࡪࡨࠤࡸࡺࡡࡳࡶ࠯ࠤࡸࡵࠠࡶࡵࡨࠤࠬࡶࠧࠨࡽ࠵ࢁࠬ࠭ࡲࠨࠢࡵࡥࡹ࡮ࡥࡳࠢࡷ࡬ࡦࡴࠠࠨࡲࡾ࠶ࢂࡸࠧࠎࠌࡒࡦ࡫ࡻࡳࡤࡣࡷ࡭ࡴࡴࠠࡰࡨࠣࡷࡹࡸࡩ࡯ࡩࠣࡰ࡮ࡺࡥࡳࡣ࡯ࡷࠥ࡯ࡳࠡࡷࡱࡷࡺ࡯ࡴࡢࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡶࡩࡳࡹࡩࡵ࡫ࡹࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰࠣࡷ࡮ࡴࡣࡦࠢ࡬ࡸࠥࡩࡡ࡯ࠢࡥࡩࠥࡺࡲࡪࡸ࡬ࡥࡱࡲࡹࠡࡤࡵࡳࡰ࡫࡮ࠎࠌࡑࡳࠥࡸࡥ࡯ࡣࡰ࡭ࡳ࡭ࠠࡣࡣࡦ࡯ࡩࡵ࡯ࡳࠢࡶࡹࡵࡶ࡯ࡳࡶࠣࡪࡴࡸࠠ࡮ࡧࡷ࡬ࡴࡪࡳࠡࡵࡷࡥࡷࡺࡩ࡯ࡩࠣࡻ࡮ࡺࡨࠡࡡࡢࠤ࠭ࡴ࡯࡯࠯ࡲࡺࡪࡸࡲࡪࡦࡤࡦࡱ࡫ࠠ࡮ࡧࡷ࡬ࡴࡪࡳ࠭ࠢࡤࡰࡸࡵࠠ࡬ࡰࡲࡻࡳࠦࡡࡴࠢࡳࡶ࡮ࡼࡡࡵࡧࠣࡱࡪࡺࡨࡰࡦࡶ࠭ࠒࠐࠍࠋࡎ࡬ࡧࡪࡴࡣࡦ࠼ࠐࠎࢀ࠹ࡽࠎࠌ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮ࠒࠐࠉࠊࠩࠪࠫ਋").format (l1lllllll_fo_.capitalize (), l1lllllll_fo_, l11ll_fo_ (u"ࡵࠫࠨ࠭਌"), license))
		exit (l1ll11111_fo_)
	if len (sys.argv) > 1:
		if l11ll_fo_ (u"ࠫࡄ࠭਍") in sys.argv [1]:
			l1l1lllll_fo_ (0)
		l11lll1l_fo_ = sys.argv [1]
	else:
		l11lll1l_fo_ = os.getcwd ()
	if len (sys.argv) > 2:
		l1l1111l1_fo_ = sys.argv [2]
	else:
		l1l1111l1_fo_ = l11ll_fo_ (u"ࠬࢁ࠰ࡾ࡞࡟ࡿ࠶ࢃ࡟ࡼ࠴ࢀࠫ਎").format (* (l11lll1l_fo_.rsplit (l111111l_fo_, 1) + [l1lllllll_fo_]))
	if len (sys.argv) > 3:
		l1l11lll1_fo_ = sys.argv [3]
	else:
		l1l11lll1_fo_ = l11ll_fo_ (u"࠭ࡻ࠱ࡿ࡟ࡠࢀ࠷ࡽࡠࡥࡲࡲ࡫࡯ࡧ࠯ࡶࡻࡸࠬਏ").format (l11lll1l_fo_, l1lllllll_fo_)
	obfuscate_strings = False
	obfuscated_name_tail = l11ll_fo_ (u"ࠧࡠࡽࢀࡣࠬਐ").format (l1lllllll_fo_)
	plain_marker = l11ll_fo_ (u"ࠨࡡࡾࢁࡤ࠭਑").format (l1lllllll_fo_)
	source_extensions = l11ll_fo_ (u"ࠩࠪ਒")
	skip_extensions = l11ll_fo_ (u"ࠪࠫਓ")
	external_modules = l11ll_fo_ (u"ࠫࠬਔ")
	plain_files = l11ll_fo_ (u"ࠬ࠭ਕ")
	plain_names = l11ll_fo_ (u"࠭ࠧਖ")
	try:
		l1ll1l1ll_fo_ = open (l1l11lll1_fo_)
	except Exception as l1ll111ll_fo_:
		print (l1ll111ll_fo_)
		l1l1lllll_fo_ (1)
	exec (l1ll1l1ll_fo_.read ())
	l1ll1l1ll_fo_.close ()
	try:
		l11lll11_fo_ = obfuscate_strings
	except:
		l11lll11_fo_ = False
	try:
		l1ll11lll_fo_ = l1ll111l1_fo_
	except:
		l1ll11lll_fo_ = False
	try:
		l1l1l11ll_fo_ = obfuscated_name_tail
	except:
		l1l1l11ll_fo_ = l11ll_fo_ (u"ࠧࠨਗ")
	try:
		l111llll_fo_ = plain_marker
	except:
		l111llll_fo_ = l11ll_fo_ (u"ࠨࡡࡾ࠴ࢂࡥࠧਘ").format (l1lllllll_fo_)
	l1111111_fo_ = source_extensions.split ()
	l1l111lll_fo_ = skip_extensions.split ()
	l11llllll_fo_ = external_modules.split ()
	l1ll1ll1l_fo_ = plain_files.split ()
	l1l1l1lll_fo_ = plain_names.split ()
	l11ll11l_fo_ = [
		l11ll_fo_ (u"ࠩࡾ࠴ࢂࡢ࡜ࡼ࠳ࢀࠫਙ").format (l11lllll1_fo_.replace (l11ll_fo_ (u"ࠪࡠࡡ࠭ਚ"), l111111l_fo_), l11l1l11_fo_)
		for l11lllll1_fo_, l1l1111ll_fo_, l1l1l1111_fo_ in os.walk (l11lll1l_fo_)
		for l11l1l11_fo_ in l1l1l1111_fo_
	]
	l1ll1lll1_fo_ = re.compile (l11ll_fo_ (u"ࡶࠬࡤࡻ࠱ࡿࠤࠫਛ").format (l11ll_fo_ (u"ࡷ࠭ࠣࠨਜ")))
	l1ll11ll1_fo_ = re.compile (l11ll_fo_ (u"࠭ࡣࡰࡦ࡬ࡲ࡬ࡡ࠺࠾࡟࡟ࡷ࠯࠮࡛࠮࡞ࡺ࠲ࡢ࠱ࠩࠨਝ"))
	l11ll1l1_fo_ = re.compile (l11ll_fo_ (u"ࠧ࠯ࠬࡾ࠴ࢂ࠴ࠪࠨਞ").format (l111llll_fo_), re.DOTALL)
	def l1llll111_fo_ (l1l11l1l1_fo_):
		comment = l1l11l1l1_fo_.group (0)
		if l11ll1l1_fo_.search (comment):
			l1lll11l1_fo_.append (comment.replace (l111llll_fo_, l11ll_fo_ (u"ࠨࠩਟ")))
			return l1ll1l11l_fo_
		else:
			return l11ll_fo_ (u"ࠩࠪਠ")
	def l11l11ll_fo_ (l1l11l1l1_fo_):
		global l111lll1_fo_
		l111lll1_fo_ += 1
		return l1lll11l1_fo_ [l111lll1_fo_]
	l1l111ll1_fo_ = re.compile (l11ll_fo_ (u"ࡵࠫࢀ࠶ࡽࡼ࠳ࢀࡿ࠷ࢃ࠮ࠫࡁࠧࠫਡ").format (
		l11ll_fo_ (u"ࡶࠧ࠮࠿࠽ࠣࠪ࠭ࠧਢ"),
		l11ll_fo_ (u"ࡷ࠭ࠨࡀ࠾ࠤࠦ࠮࠭ਣ"),
		l11ll_fo_ (u"ࡸࠧࠤࠩਤ")
	), re.MULTILINE)
	l1ll1l11l_fo_ = l11ll_fo_ (u"ࠧࡠࡽ࠳ࢁࡤࡩ࡟ࠨਥ").format (l1lllllll_fo_)
	l1l1ll111_fo_ = re.compile (l11ll_fo_ (u"ࡳࠩࡾ࠴ࢂ࠭ਦ").format (l1ll1l11l_fo_))
	l11ll1ll_fo_ = re.compile (l11ll_fo_ (u"ࡴࠪ࠲࠯ࢁ࠰ࡾ࠰࠭ࠫਧ").format (l111llll_fo_))
	def l1l11ll11_fo_ (l1l11l1l1_fo_):
		string = l1l11l1l1_fo_.group (0)
		if l11lll11_fo_:
			if l11ll1ll_fo_.search (string):
				l111ll1l_fo_.append (string.replace (l111llll_fo_, l11ll_fo_ (u"ࠪࠫਨ")))
				return l1l1llll1_fo_
			else:
				l111ll1l_fo_.append (l1l1ll11l_fo_ (string))
				return l11ll_fo_ (u"ࠫࡺࡴࡓࡤࡴࡤࡱࡧࡲࡥࡼ࠲ࢀࠤ࠭ࢁ࠱ࡾࠫࠪ਩").format (l111llll_fo_, l1l1llll1_fo_)
		else:
			l111ll1l_fo_.append (string)
			return l1l1llll1_fo_
	def l1ll1llll_fo_ (l1l11l1l1_fo_):
		global l1111l1l_fo_
		l1111l1l_fo_ += 1
		return l111ll1l_fo_ [l1111l1l_fo_]
	l1l11l1ll_fo_ = re.compile (l11ll_fo_ (u"ࡷ࠭ࠨ࡜ࡴࡸࡡࢁࡸࡵࡽࡷࡵ࠭ࡄ࠮ࠨࡼ࠲ࢀ࠭ࢁ࠮ࡻ࠲ࡿࠬࢀ࠭ࢁ࠲ࡾࠫࡿࠬࢀ࠹ࡽࠪࠫࠪਪ").format (
		l11ll_fo_ (u"ࡸࠢࠨࠩࠪ࠲࠯ࡅࠨࡀ࠾ࠤ࡟ࡣࡢ࡜࡞࡞࡟࠭࠭ࡅ࠼ࠢ࡝ࡡࡠࡡࡣ࡜ࠨࠫࠪࠫࠬࠨਫ"),
		l11ll_fo_ (u"ࡲࠨࠤࠥࠦ࠳࠰࠿ࠩࡁ࠿ࠥࡠࡤ࡜࡝࡟࡟ࡠ࠮࠮࠿࠽ࠣ࡞ࡢࡡࡢ࡝࡝ࠤࠬࠦࠧࠨࠧਬ"),
		l11ll_fo_ (u"ࡳࠤࠪ࠲࠯ࡅࠨࡀ࠾ࠤ࡟ࡣࡢ࡜࡞࡞࡟࠭ࠬࠨਭ"),
		l11ll_fo_ (u"ࡴࠪࠦ࠳࠰࠿ࠩࡁ࠿ࠥࡠࡤ࡜࡝࡟࡟ࡠ࠮ࠨࠧਮ")
	), re.MULTILINE | re.DOTALL | re.VERBOSE)
	l1l1llll1_fo_ = l11ll_fo_ (u"ࠪࡣࢀ࠶ࡽࡠࡵࡢࠫਯ").format (l1lllllll_fo_)
	l1lll1l1l_fo_ = re.compile (l11ll_fo_ (u"ࡶࠬࢁ࠰ࡾࠩਰ").format (l1l1llll1_fo_))
	def l1l1111l_fo_ (l1l11l1l1_fo_):
		l1l1ll1l1_fo_ = l1l11l1l1_fo_.group (0)
		if l1l1ll1l1_fo_:
			global l1lll111l_fo_
			l1ll1ll11_fo_ [l1lll111l_fo_:l1lll111l_fo_] = [l1l1ll1l1_fo_]
			l1lll111l_fo_ += 1
		return l11ll_fo_ (u"ࠬ࠭਱")
	l1l1l1ll1_fo_ = re.compile (l11ll_fo_ (u"࠭ࡦࡳࡱࡰࡠࡸ࠰࡟ࡠࡨࡸࡸࡺࡸࡥࡠࡡ࡟ࡷ࠯࡯࡭ࡱࡱࡵࡸࡡࡹࠪ࡝ࡹ࠮࠲࠯ࠪࠧਲ"), re.MULTILINE)
	l111l1ll_fo_ = re.compile (l11ll_fo_ (u"ࡲࠨࠩࠪࠑࠏࠏࠉ࡝ࡤࠌࠍࠎࠐࠉࠊࠪࡂࠥࢀ࠶ࡽࠪࠋࠌࠎࠎࠏࠨࡀࠣࡾ࠵ࢂ࠯ࠉࠊࠌࠌࠍࡠࡤ࡜ࡥ࡞࡚ࡡࠎࠏࠊࠊࠋ࡟ࡻ࠯ࠏࠉࠊࠌࠌࠍ࠭ࡅ࠼ࠢࡡࡢ࠭ࠎࠏࠊࠊࠋࠫࡃࡁࠧࡻ࠱ࡿࠬࠍࠏࠏࠉࠩࡁ࠿ࠥࢀ࠷ࡽࠪࠋࠍࠍࠎࡢࡢࠊࠋࠌࠎࠎ࠭ࠧࠨਲ਼").format (l1ll1l11l_fo_, l1l1llll1_fo_), re.VERBOSE)
	l1ll11l1l_fo_ = re.compile (l11ll_fo_ (u"ࡳࠩ࡟ࡦࡨ࡮ࡲ࡝ࡤࠪ਴"))
	l1lll1ll1_fo_ = set (keyword.kwlist + [l11ll_fo_ (u"ࠩࡢࡣ࡮ࡴࡩࡵࡡࡢࠫਵ")] + l1l1l1lll_fo_)
	l1l1l111l_fo_ = [l11ll_fo_ (u"ࠪࡿ࠵ࢃ࡜࡝ࡽ࠴ࢁࠬਸ਼").format (l11lll1l_fo_, l1llll1ll_fo_) for l1llll1ll_fo_ in l1ll1ll1l_fo_]
	for l11l111l_fo_ in l1l1l111l_fo_:
		l1l1l11l1_fo_ = open (l11l111l_fo_)
		content = l1l1l11l1_fo_.read ()
		l1l1l11l1_fo_.close ()
		content = l1l111ll1_fo_.sub (l11ll_fo_ (u"ࠫࠬ਷"), content)
		content = l1l11l1ll_fo_.sub (l11ll_fo_ (u"ࠬ࠭ਸ"), content)
		l1lll1ll1_fo_.update (re.findall (l111l1ll_fo_, content))
	class l1ll11l11_fo_:
		def __init__ (self):
			for l11111l1_fo_ in l11llllll_fo_:
				l11l1l1l_fo_ = l11111l1_fo_.replace (l11ll_fo_ (u"࠭࠮ࠨਹ"), l111llll_fo_)
				try:
					exec (
						l11ll_fo_ (u"ࠧࠨࠩࠐࠎ࡮ࡳࡰࡰࡴࡷࠤࢀ࠶ࡽࠡࡣࡶࠤࡨࡻࡲࡳࡧࡱࡸࡒࡵࡤࡶ࡮ࡨࠑࠏࠏࠉࠊࠋࠌࠍࠬ࠭ࠧ਺").format (l11111l1_fo_),
						globals ()
					)
					setattr (self, l11l1l1l_fo_, currentModule)
				except Exception as l1ll111ll_fo_:
					print (l1ll111ll_fo_)
					setattr (self, l11l1l1l_fo_, None)
					print (l11ll_fo_ (u"ࠨ࡙ࡤࡶࡳ࡯࡮ࡨ࠼ࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡩ࡯ࡵࡳࡩࡨࡺࠠࡦࡺࡷࡩࡷࡴࡡ࡭ࠢࡰࡳࡩࡻ࡬ࡦࠢࡾ࠴ࢂ࠭਻").format (l11111l1_fo_))
	l11l1lll_fo_ = l1ll11l11_fo_ ()
	l1llllll1_fo_ = set ()
	def l1111l11_fo_ (l1lll1lll_fo_):
		if l1lll1lll_fo_ in l1llllll1_fo_:
			return
		else:
			l1llllll1_fo_.update ([l1lll1lll_fo_])
		try:
			l11lllll_fo_ = list (l1lll1lll_fo_.__dict__)
		except:
			l11lllll_fo_ = []
		try:
			if l1l1ll1ll_fo_:
				l111ll11_fo_ = list (l1lll1lll_fo_.func_code.co_varnames)
			else:
				l111ll11_fo_ = list (l1lll1lll_fo_.__code__.co_varnames)
		except:
			l111ll11_fo_ = []
		l1ll1l111_fo_ = [getattr (l1lll1lll_fo_, l11l1l1l_fo_) for l11l1l1l_fo_ in l11lllll_fo_]
		l1l11llll_fo_ = (l111llll_fo_.join (l11lllll_fo_)) .split (l111llll_fo_)
		l11llll11_fo_ = set ([l11llll1l_fo_ for l11llll1l_fo_ in (l111ll11_fo_ + l1l11llll_fo_) if not (l11llll1l_fo_.startswith (l11ll_fo_ (u"ࠩࡢࡣ਼ࠬ")) and l11llll1l_fo_.endswith (l11ll_fo_ (u"ࠪࡣࡤ࠭਽")))])
		l1lll1ll1_fo_.update (l11llll11_fo_)
		for l1l1l1l11_fo_ in l1ll1l111_fo_:
			try:
				l1111l11_fo_ (l1l1l1l11_fo_)
			except:
				pass
	l1111l11_fo_ (__builtins__)
	l1111l11_fo_ (l11l1lll_fo_)
	l11l11l1_fo_ = list (l1lll1ll1_fo_)
	l11l11l1_fo_.sort (key = lambda s: s.lower ())
	l1lll1111_fo_ = []
	l1ll1111l_fo_ = []
	for l1l111111_fo_ in l11ll11l_fo_:
		if l1l111111_fo_ == l1l11lll1_fo_:
			continue
		l11ll111_fo_, l1l1lll1l_fo_ = l1l111111_fo_.rsplit (l111111l_fo_, 1)
		l1l111l11_fo_, l1lll11ll_fo_ = (l1l1lll1l_fo_.rsplit (l11ll_fo_ (u"ࠫ࠳࠭ਾ"), 1) + [l11ll_fo_ (u"ࠬ࠭ਿ")]) [ : 2]
		l1llll1l1_fo_ =  l1l111111_fo_ [len (l11lll1l_fo_) : ]
		if l1lll11ll_fo_ in l1111111_fo_ and not l1l111111_fo_ in l1l1l111l_fo_:
			l111l111_fo_ = random.randrange (64)
			l11l1111_fo_ = codecs.open (l1l111111_fo_, encoding = l11ll_fo_ (u"࠭ࡵࡵࡨ࠰࠼ࠬੀ"))
			content = l11l1111_fo_.read ()
			l11l1111_fo_.close ()
			l1lll11l1_fo_ = []
			l1ll1ll11_fo_ = content.split (l11ll_fo_ (u"ࠧ࡝ࡰࠪੁ"), 2)
			l1lll111l_fo_ = 0
			l1ll1l1l1_fo_ = True
			if len (l1ll1ll11_fo_) > 0:
				if l1ll1lll1_fo_.search (l1ll1ll11_fo_ [0]):
					l1lll111l_fo_ += 1
					if len (l1ll1ll11_fo_) > 1 and l1ll11ll1_fo_.search (l1ll1ll11_fo_ [1]):
						l1lll111l_fo_ += 1
						l1ll1l1l1_fo_ = False
				elif l1ll11ll1_fo_.search (l1ll1ll11_fo_ [0]):
					l1lll111l_fo_ += 1
					l1ll1l1l1_fo_ = False
			if l11lll11_fo_ and l1ll1l1l1_fo_:
				l1ll1ll11_fo_ [l1lll111l_fo_:l1lll111l_fo_] = [l11ll_fo_ (u"ࠨࠥࠣࡧࡴࡪࡩ࡯ࡩ࠽ࠤ࡚࡚ࡆ࠮࠺ࠪੂ")]
				l1lll111l_fo_ += 1
			if l11lll11_fo_:
				l1l111l1_fo_ = l11ll_fo_ (u"ࠩ࡟ࡲࠬ੃").join ([l1l111ll_fo_ (l111l111_fo_)] + l1ll1ll11_fo_ [l1lll111l_fo_:])
			else:
				l1l111l1_fo_ = l11ll_fo_ (u"ࠪࡠࡳ࠭੄").join (l1ll1ll11_fo_ [l1lll111l_fo_:])
			l1l111l1_fo_ = l1l111ll1_fo_.sub (l1llll111_fo_, l1l111l1_fo_)
			l111ll1l_fo_ = []
			l1l111l1_fo_ = l1l11l1ll_fo_.sub (l1l11ll11_fo_, l1l111l1_fo_)
			l1l111l1_fo_ = l1l1l1ll1_fo_.sub (l1l1111l_fo_, l1l111l1_fo_)
			l11llll1_fo_ = set (re.findall (l111l1ll_fo_, l1l111l1_fo_) + [l1l111l11_fo_])
			l111l11l_fo_ = l11llll1_fo_.difference (l1lll1111_fo_).difference (l1lll1ll1_fo_)
			l1111lll_fo_ = list (l111l11l_fo_)
			l1l11111l_fo_ = [re.compile (l11ll_fo_ (u"ࡶࠬࡢࡢࡼ࠲ࢀࡠࡧ࠭੅").format (l111l1l1_fo_)) for l111l1l1_fo_ in l1111lll_fo_]
			l1lll1111_fo_ += l1111lll_fo_
			l1ll1111l_fo_ += l1l11111l_fo_
			for l1l11l111_fo_, l1l11l11l_fo_ in enumerate (l1ll1111l_fo_):
				l1l111l1_fo_ = l1l11l11l_fo_.sub (
					l1111ll1_fo_ (l1l11l111_fo_, l1lll1111_fo_ [l1l11l111_fo_]),
					l1l111l1_fo_
				)
			l1111l1l_fo_ = -1
			l1l111l1_fo_ = l1lll1l1l_fo_.sub (l1ll1llll_fo_, l1l111l1_fo_)
			l111lll1_fo_ = -1
			l1l111l1_fo_ = l1l1ll111_fo_.sub (l11l11ll_fo_, l1l111l1_fo_)
			content = l11ll_fo_ (u"ࠬࡢ࡮ࠨ੆").join (l1ll1ll11_fo_ [:l1lll111l_fo_] + [l1l111l1_fo_])
			content = l11ll_fo_ (u"࠭࡜࡯ࠩੇ").join ([line for line in [line.rstrip () for line in content.split (l11ll_fo_ (u"ࠧ࡝ࡰࠪੈ"))] if line])
			try:
				l1l1lll11_fo_ = l1111ll1_fo_ (l1lll1111_fo_.index (l1l111l11_fo_), l1l111l11_fo_)
			except:
				l1l1lll11_fo_ = l1l111l11_fo_
			l1lllll11_fo_ = l1llll1l1_fo_.split (l111111l_fo_)
			for index in range (len (l1lllll11_fo_)):
				try:
					l1lllll11_fo_ [index] = l1111ll1_fo_ (l1lll1111_fo_.index (l1lllll11_fo_ [index]), l1lllll11_fo_ [index])
				except:
					pass
			l1llll1l1_fo_ = l111111l_fo_.join (l1lllll11_fo_)
			l1l11111_fo_ = l11ll_fo_ (u"ࠨࡽ࠳ࢁࢀ࠷ࡽࠨ੉").format (l1l1111l1_fo_, l1llll1l1_fo_) .rsplit (l111111l_fo_, 1) [0]
			l1llll11l_fo_ = l1lllll1l_fo_ (l11ll_fo_ (u"ࠩࡾ࠴ࢂࡢ࡜ࡼ࠳ࢀ࠲ࢀ࠸ࡽࠨ੊").format (l1l11111_fo_, l1l1lll11_fo_, l1lll11ll_fo_), open = True)
			l1llll11l_fo_.write (content)
			l1llll11l_fo_.close ()
		elif not l1lll11ll_fo_ in l1l111lll_fo_:
			l1l11111_fo_ = l11ll_fo_ (u"ࠪࡿ࠵ࢃࡻ࠲ࡿࠪੋ").format (l1l1111l1_fo_, l1llll1l1_fo_) .rsplit (l111111l_fo_, 1) [0]
			l1l1l1l1l_fo_ = l11ll_fo_ (u"ࠫࢀ࠶ࡽ࡝࡞ࡾ࠵ࢂ࠭ੌ").format (l1l11111_fo_, l1l1lll1l_fo_)
			l1lllll1l_fo_ (l1l1l1l1l_fo_)
			shutil.copyfile (l1l111111_fo_, l1l1l1l1l_fo_)
	print (l11ll_fo_ (u"ࠬࡕࡢࡧࡷࡶࡧࡦࡺࡥࡥࠢࡺࡳࡷࡪࡳ࠻ࠢࡾ࠴ࢂ੍࠭").format (len (l1lll1111_fo_)))