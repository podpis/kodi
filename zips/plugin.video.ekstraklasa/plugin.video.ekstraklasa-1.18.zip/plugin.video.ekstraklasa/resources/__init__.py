# coding: UTF-8
import sys
l1l11l_fo_ = sys.version_info [0] == 2
l1llll_fo_ = 2048
l11l_fo_ = 7
def l11ll_fo_ (ll_fo_):
	global l1ll11_fo_
	l1l1l1_fo_ = ord (ll_fo_ [-1])
	l1l11_fo_ = ll_fo_ [:-1]
	l1l_fo_ = l1l1l1_fo_ % len (l1l11_fo_)
	l11_fo_ = l1l11_fo_ [:l1l_fo_] + l1l11_fo_ [l1l_fo_:]
	if l1l11l_fo_:
		l1111_fo_ = unicode () .join ([unichr (ord (char) - l1llll_fo_ - (l1l1l_fo_ + l1l1l1_fo_) % l11l_fo_) for l1l1l_fo_, char in enumerate (l11_fo_)])
	else:
		l1111_fo_ = str () .join ([chr (ord (char) - l1llll_fo_ - (l1l1l_fo_ + l1l1l1_fo_) % l11l_fo_) for l1l1l_fo_, char in enumerate (l11_fo_)])
	return eval (l1111_fo_)