# -*- coding: utf-8 -*-

import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib

BASEURL= "http://www.footballorgin.com"
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

def getUrl(url,data=None,cookies=None):

    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link

url='http://www.footballorgin.com/category/motd/'    
def getFullMatch(url,page='1'):
    if url:
        content = getUrl(url)
        data = False
    if not url:
        url='http://www.footballorgin.com/wp-admin/admin-ajax.php'
        data='action=infinite_scroll&page_no=%d'%int(page)
        content = getUrl(url,data)
        
    ids = [(a.start(), a.end()) for a in re.finditer('<article id="post', content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ]
        
        img = re.compile('src="(.*?)"').findall(subset)
        href_title = re.compile('<h2 class="entry-title" itemprop="headline"><a href="(.*?)".*?>(.*?)</a>').findall(subset)
        code = re.compile('rel="category tag">(.*?)<').findall(subset)
        
        if href_title and img:
            h = href_title[0][0]
            t = href_title[0][1].strip()
            c = code[-1] if code else ''
            out.append({'url':h,'title':unicodePLchar(t),'img':img[0],'code':c})
    
    nextPage = {'page':int(page)+1} if len(out)==10 and data else False
    prevPage = {'page':int(page)-1} if int(page)>1 and data else False
    return out,(prevPage,nextPage)

url='http://www.footballorgin.com/world-cup-2018-qualifiers-armenia-vs-romania-full-match-replay/'
url='http://www.footballorgin.com/ufc-204-michael-bisping-vs-dan-henderson-full-fight-replay/'
def getVideos(url):
    content = getUrl(url)
    out=[]
    subpages = re.compile('<li class="subpage-.*?"><a href="(.*?)">(.*?)</a></li>').findall(content)
    src = re.compile('data-config="(//.*\.json)"').findall(content)
    if subpages:
        for sp in subpages:
            if sp[0] == url and src:
                pass
            else:
                content2 = getUrl(sp[0])
                src = re.compile('data-config="(//.*\.json)"').findall(content2)
            src = src[0] if src else ''                
            out.append({'url':src,'title':sp[1]})
            src=[]
    elif src:
        out=[{'url':src[0],'title':'video'}]
    return out
    
            
def unicodePLchar(txt):
    txt = txt.replace('#038;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8217;','\'')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    #txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt            