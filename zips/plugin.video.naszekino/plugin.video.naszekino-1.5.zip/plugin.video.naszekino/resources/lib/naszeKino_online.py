# -*- coding: utf-8 -*-

import sys,os,re
import urllib,urllib2
import urlparse

BASEURL='http://nasze-kino.online'

def getUrl(url,post_data=None):
    if post_data:
        dataPost = urllib.urlencode(post_data)
        req = urllib2.Request(url,dataPost)
    else:
        req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20100101 Firefox/22.0')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link
    

# def getForum():
#     content = getUrl(BASEURL)
#     ids = [(a.start(), a.end()) for a in re.finditer('<li class="forumbit_nopost old L1"', content)]
#     ids.append( (-1,-1) )
#     out=[]
#     for i in range(len(ids[:-1])):
#         #print content[ ids[i][1]:ids[i+1][0] ]
#         subset = content[ ids[i][1]:ids[i+1][0] ]
#         if 'id="cat19"' in subset[:15]:
#             dane=re.compile('<a href="(.*?)"><span style=".*?">(.*?)</span></a><span class="shade" style="font-size:10px;" title="Wątków/Postów">(.*?)</span>').findall(subset)
#             for one in dane:
#                 title = '%s [COLOR blue]Wątków/Postów:%s[/COLOR]'%(one[1] ,one[2] )
#                 out.append({'url':urlparse.urljoin(BASEURL,one[0]),'title':unicodePLchar(title)})
#             break
#     return out,(False,False)

def getForum():
    out=[
        {'title':'Filmy','url':'http://nasze-kino.online/forumdisplay.php/57-Filmy-Online','img':'http://nasze-kino.online/images/filmy.png'},
        {'title':'Seriale','url':'http://nasze-kino.online/forumdisplay.php/58-Seriale-Online','img':'http://nasze-kino.online/images/seriale.png'},
        {'title':'Rozrywka','url':'http://nasze-kino.online/forumdisplay.php/59-Rozrywka-Online','img':'http://nasze-kino.online/images/rozrywka.png'},
        {'title':'Sport','url':'http://nasze-kino.online/forumdisplay.php/60-Sport-Online','img':'http://nasze-kino.online/images/sport.png'},
    ]
    return out,(False,False)
    
url='http://nasze-kino.online/forumdisplay.php/57-Filmy-Online'
def getForumEntry(url):
    content = getUrl(url)
    
    ids = [(a.start(), a.end()) for a in re.finditer('<table class="vbs_forumrow threadbit', content)]
    ids.append( (-1,-1) )
    out=[]
    next=False
    prev=False
    
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ]
        
        img = re.compile('<img class="preview" src="(.*?)"').findall(subset)
        href = re.compile('href="(.*?)" id="thread_title_.*?">(.*?)</a>').findall(subset)
        if href:
            h=urlparse.urljoin(BASEURL,href[0][0])
            t=unicodePLchar(href[0][1])
            i=img[0] if img else ''
            out.append({'title':t,'url':h,'img':i})
    if out:
        nextPage=re.compile('<a rel="next" href="(.*?)" title="(.*?)"><img src="(.*?)"').search(content)
        if nextPage:
            next={'url':urlparse.urljoin(BASEURL,nextPage.group(1)),'title':unicodePLchar(nextPage.group(2)),'img':''}
        prevPage=re.compile('<a rel="prev" href="(.*?)" title="(.*?)"><img src="(.*?)"').search(content)
        if prevPage:
            prev={'url':urlparse.urljoin(BASEURL,prevPage.group(1)),'title':unicodePLchar(prevPage.group(2)),'img':''}
    
    return out,(prev,next)

# url='http://nasze-kino.online/showthread.php/3745-Snajper-Duch-Wojownika-Sniper-Ghost-Shooter-(2016)'
def getThreadLinks(url):
    content = getUrl(url)
    out=[]
    #codes = re.compile('<pre class="bbcode_code"(.*?)</pre>',re.DOTALL).findall(content)
    #if not codes:
    codes = re.compile('<div id="post_message_(.*?)</blockquote>',re.DOTALL).findall(content)
    for code in codes:
        links=re.compile('<a href="(http.*?)" target="_blank">(.*?)</a>').findall(code)
        for link in links:
            out.append({'title':urlparse.urlsplit(link[0]).netloc,'url':link[0]})
    return out
    
def unicodePLchar(txt):
    txt = txt.replace('#038;','')
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    #txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt