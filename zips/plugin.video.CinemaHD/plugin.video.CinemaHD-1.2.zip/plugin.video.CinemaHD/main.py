# -*- coding: utf-8 -*-

import sys,re,os,json
import urllib,urllib2
import urlparse

import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver
import resources.lib.kaddon as ka

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')

PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

FANART=RESOURCES+'fanart.png'
datapath = my_addon.getSetting('datapath')

## COMMON Functions


def add_Item(name, url, mode, iconImage=None, infoLabels=False, IsPlayable=False,fanart=None,totalItems=1,json_file=''):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'json_file' : json_file})
    if iconImage==None: iconImage='DefaultFolder.png'
    if not infoLabels: infoLabels={"title": name}
    liz = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    liz.setArt({ 'poster': iconImage, 'thumb' : iconImage, 'icon' : iconImage ,'fanart':fanart,'banner':iconImage})
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:liz.setProperty('IsPlayable', 'True')
    if fanart:liz.setProperty('fanart_image',fanart)
    contextMenuItems = []
    contextMenuItems.append(('[COLOR blue]Informacja[/COLOR]', 'XBMC.Action(Info)'))
    contextMenuItems.append(('[COLOR blue]Zwiastun[/COLOR]', 'XBMC.PlayMedia(%s)'%infoLabels.get('trailer')))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)           
    return (u, liz, False)

def addDir(name,ex_link=None,json_file='', mode='walk',iconImage=None,fanart='',infoLabels=False,totalItems=1):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'json_file' : json_file})
    if iconImage==None:
        iconImage='DefaultFolder.png'
    li = xbmcgui.ListItem(label=name,iconImage=iconImage)
    li = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    li.setArt({ 'poster': iconImage, 'thumb' : iconImage, 'icon' : iconImage,'banner':iconImage})
    if fanart:li.setProperty('fanart_image', fanart )
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)


def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))


def getLinks(links):
    links=eval(links.decode('base64'))
    stream_url=''
    hosts = [urlparse.urlparse(x).netloc for x in links]
    selection = xbmcgui.Dialog().select("Dostępne hosty", hosts)
    if selection>-1:
        #xbmcgui.Dialog().ok('link',links[selection])
        try:
            stream_url = urlresolver.resolve(links[selection])
            ka.go()
        except Exception,e:
            stream_url=''
            s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','URLresolver ERROR: [%s]'%str(e))
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def addMovies(ex_link):
    fname=xbmcgui.Dialog().browse(1, 'Wybierz plik z linkami', 'files', '', False, False, os.path.dirname(ex_link), False)
    if fname and os.path.exists(fname):
        pDialog = xbmcgui.DialogProgressBG()
        cnt_add=0
        cnt_upd=0
        cnt_mis=0
        items=[]
        f= os.path.basename(fname)
        if '_missed.json' in f: items = ka.readJsonFile(fname)
        elif 'Uptobox.com' in f: items = ka.read_Uptobox(fname)
        elif 'Rapidvideo.com' in f: items = ka.read_Rapidvideo(fname)
        pDialog.create('Aktualizacja %d'%len(items), f)
        if len(items)>0:
            items=ka.ExtractfromFilmweb(items,poolSize=10,pDialog=pDialog) 
            notfound =[ x for x in items if not x.has_key('filmweb')]
            if notfound:
                cnt_mis = len(notfound)
                pDialog.update(99, message='Do poprawki: %d'%len(notfound))
                ka.writeJsonFile(notfound,fname+'_missed.json')
            pDialog.update(100, message='Zapisywanie [data.json]')
            cnt_add,cnt_upd = ka.UpdateJsonFile_with_jdata(ex_link,items,replace = True ) 
        pDialog.close()
        xbmcgui.Dialog().ok('Status','DODANO %d, UAKTUALNIONO %d'%(cnt_add,cnt_upd),'Do poprawki (_missed.json): %d'%cnt_mis)
    

def mainWalk(ex_link='',json_file=''):
    items=[]
    folders=[]
    json_file = json_file if json_file else ka.jf
    if json_file:
        data = ka.ReadJsonFile(json_file)
        items,folders = ka.jsconWalk(data,ex_link)
    for f in folders:
        addDir(f.get('title'),ex_link=f.get('url'), json_file=f.get('jsonfile',json_file), mode='walk', iconImage=f.get('img',''),infoLabels=f,fanart=f.get('fanart',FANART),totalItems=len(folders))
    list_of_items=[]
    for item in items:
        list_of_items.append( add_Item(name=item.get('title').encode("utf-8"), url=str(item.get('links')).encode('base64'), mode='decodeVideo', iconImage=item.get('img'), infoLabels=item, IsPlayable=True,fanart=item.get('img')) )
    if datapath and os.path.exists(datapath):
        folders = ka.get_dataJsonPaths(datapath)
        data = folders.get(fname) if fname in folders.keys() else None
        if data:
           list_of_items.insert(0, add_Item(name='[COLOR red]DODAJ do: [B]%s[/B][/COLOR]'%data, url=data, mode='dodaj', IsPlayable=False))

    xbmcplugin.addDirectoryItems(handle=addon_handle, items = list_of_items ,totalItems=len(items))
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = "%D, %P, %R")
    if list_of_items:
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE )
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE )
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_YEAR  )
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_GENRE )
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_STUDIO  )
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
        
## ######################
## MAIN
## ######################
            
xbmcplugin.setContent(addon_handle, 'movies')
    
# Get passed arguments
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
json_file = args.get('json_file',[''])[0]

if mode is None: mainWalk()
elif mode[0] == 'walk': mainWalk(ex_link,json_file) 
elif mode[0] == 'decodeVideo': getLinks(ex_link)
elif mode[0] == 'dodaj':addMovies(ex_link)
else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))        
xbmcplugin.endOfDirectory(addon_handle)

