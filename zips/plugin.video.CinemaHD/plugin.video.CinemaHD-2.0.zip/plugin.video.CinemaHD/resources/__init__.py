# coding: UTF-8
import sys
l1ll1_hd_ = sys.version_info [0] == 2
l1l11_hd_ = 2048
l1lll_hd_ = 7
def l111_hd_ (keyedStringLiteral):
	global ll_hd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll1_hd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l11_hd_ - (charIndex + stringNr) % l1lll_hd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l11_hd_ - (charIndex + stringNr) % l1lll_hd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)