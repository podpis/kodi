# coding: UTF-8
import sys
l1ll_hd_ = sys.version_info [0] == 2
l1llll_hd_ = 2048
l1ll1l_hd_ = 7
def l1l1l1_hd_ (ll_hd_):
	global l111_hd_
	l1l11l_hd_ = ord (ll_hd_ [-1])
	l11ll_hd_ = ll_hd_ [:-1]
	l1l_hd_ = l1l11l_hd_ % len (l11ll_hd_)
	l11_hd_ = l11ll_hd_ [:l1l_hd_] + l11ll_hd_ [l1l_hd_:]
	if l1ll_hd_:
		l1111_hd_ = unicode () .join ([unichr (ord (char) - l1llll_hd_ - (l1l11_hd_ + l1l11l_hd_) % l1ll1l_hd_) for l1l11_hd_, char in enumerate (l11_hd_)])
	else:
		l1111_hd_ = str () .join ([chr (ord (char) - l1llll_hd_ - (l1l11_hd_ + l1l11l_hd_) % l1ll1l_hd_) for l1l11_hd_, char in enumerate (l11_hd_)])
	return eval (l1111_hd_)