# coding: UTF-8
import sys
l1l11_hd_ = sys.version_info [0] == 2
l111l_hd_ = 2048
l1ll1_hd_ = 7
def l111_hd_ (keyedStringLiteral):
	global l1l1l_hd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11_hd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111l_hd_ - (charIndex + stringNr) % l1ll1_hd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111l_hd_ - (charIndex + stringNr) % l1ll1_hd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)