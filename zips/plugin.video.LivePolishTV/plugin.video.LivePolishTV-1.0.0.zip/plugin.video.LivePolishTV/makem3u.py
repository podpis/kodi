# -*- coding: utf-8 -*-
"""
Created on Tue Jan 05 19:15:01 2016

@author: ramic
"""

print 'makem3u'