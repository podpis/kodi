# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import sys
from Queue import Queue
from threading import Thread
class l1l111ll1l1l11l111_tv_(Thread):
    Variable4 (u"ࠥࠦࠧࠦࡔࡩࡴࡨࡥࡩࠦࡥࡹࡧࡦࡹࡹ࡯࡮ࡨࠢࡷࡥࡸࡱࡳࠡࡨࡵࡳࡲࠦࡡࠡࡩ࡬ࡺࡪࡴࠠࡵࡣࡶ࡯ࡸࠦࡱࡶࡧࡸࡩࠥࠨࠢࠣὄ")
    def __init__(self, l1l111ll1lll11l111_tv_):
        Thread.__init__(self)
        self.l1l111ll1lll11l111_tv_ = l1l111ll1lll11l111_tv_
        self.daemon = True
        self.start()
    def run(self):
        while True:
            func, args, kargs = self.l1l111ll1lll11l111_tv_.get()
            try:
                func(*args, **kargs)
            except Exception as e:
                print(e)
            finally:
                self.l1l111ll1lll11l111_tv_.task_done()
class ThreadPool:
    Variable4 (u"ࠦࠧࠨࠠࡑࡱࡲࡰࠥࡵࡦࠡࡶ࡫ࡶࡪࡧࡤࡴࠢࡦࡳࡳࡹࡵ࡮࡫ࡱ࡫ࠥࡺࡡࡴ࡭ࡶࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡶࡻࡥࡶࡧࠣࠦࠧࠨὅ")
    def __init__(self, l1l111lll11l11l111_tv_):
        self.l1l111ll1lll11l111_tv_ = Queue(l1l111lll11l11l111_tv_)
        for _ in range(l1l111lll11l11l111_tv_):
            l1l111ll1l1l11l111_tv_(self.l1l111ll1lll11l111_tv_)
    def l1ll11l1lll11l111_tv_(self, func, *args, **kargs):
        Variable4 (u"ࠧࠨࠢࠡࡃࡧࡨࠥࡧࠠࡵࡣࡶ࡯ࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡷࡵࡦࡷࡨࠤࠧࠨࠢ὆")
        self.l1l111ll1lll11l111_tv_.put((func, args, kargs))
    def map(self, func, l1l111ll11ll11l111_tv_):
        Variable4 (u"ࠨࠢࠣࠢࡄࡨࡩࠦࡡࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡷࡥࡸࡱࡳࠡࡶࡲࠤࡹ࡮ࡥࠡࡳࡸࡩࡺ࡫ࠠࠣࠤࠥ὇")
        for args in l1l111ll11ll11l111_tv_:
            self.l1ll11l1lll11l111_tv_(func, args)
    def l1ll11111ll11l111_tv_(self):
        Variable4 (u"ࠢࠣࠤ࡛ࠣࡦ࡯ࡴࠡࡨࡲࡶࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡯࡯࡯ࠢࡲࡪࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡴࡢࡵ࡮ࡷࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡷࡵࡦࡷࡨࠤࠧࠨࠢὈ")
        self.l1l111ll1lll11l111_tv_.join()
