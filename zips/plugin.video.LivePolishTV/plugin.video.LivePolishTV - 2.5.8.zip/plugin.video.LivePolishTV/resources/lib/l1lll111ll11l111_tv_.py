# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,time
import cookielib
l1llll111ll11l111_tv_=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧ࡭ࡪࡩࡲࡷࡹࡼ࠮ࡦࡷ࠲ࠫ૿")
l1lll1ll1ll11l111_tv_=20
l1lll1l1lll11l111_tv_=Variable4 (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠹࠲࠵࠴࠲࠺࠴࠷࠲࠽࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ଀")
__all__=[Variable4 (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨଁ"),Variable4 (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡗ࡫ࡧࡩࡴ࠭ଂ")]
fix={
Variable4 (u"ࠬࡧࡸ࡯ࠩଃ"):Variable4 (u"࠭ࡁ࡙ࡐࠪ଄"),
Variable4 (u"ࠧࡣࡤࡦ࡬ࡩ࠭ଅ"):Variable4 (u"ࠨࡄࡅࡇࠬଆ"),
Variable4 (u"ࠩࡦࡲ࡭ࡪࠧଇ"):Variable4 (u"ࠪࡇࡦࡸࡴࡰࡱࡱࠤࡓ࡫ࡴࡸࡱࡵ࡯ࠬଈ"),
Variable4 (u"ࠫࡪࡲࡥࡷࡧࡱ࡬ࡩ࠭ଉ"):Variable4 (u"ࠬࡋ࡬ࡦࡸࡨࡲࠬଊ"),
Variable4 (u"࠭ࡦࡪ࡮ࡰࡦࡴࡾࠧଋ"):Variable4 (u"ࠧࡇ࡫࡯ࡱࡧࡵࡸࠨଌ"),
Variable4 (u"ࠨࡪࡥࡳ࡭ࡪࠧ଍"):Variable4 (u"ࠩࡋࡆࡔ࠭଎"),
Variable4 (u"ࠪࡸࡻ࠺ࠧଏ"):Variable4 (u"࡙ࠫ࡜ࠠ࠵ࠩଐ"),
Variable4 (u"ࠬࡺࡶࡱࡷ࡯ࡷࠬ଑"):Variable4 (u"࠭ࡔࡗࠢࡓࡹࡱࡹࠧ଒"),
Variable4 (u"ࠧࡵࡸࡱࡷࡹࡿ࡬ࡦࠩଓ"):Variable4 (u"ࠨࡖ࡙ࡒ࡙ࠥࡴࡺ࡮ࡨࠫଔ"),
Variable4 (u"ࠩࡷࡺࡵ࠷ࡨࡥࠩକ"):Variable4 (u"ࠪࡘ࡛ࡖࠠ࠲ࠩଖ"),
Variable4 (u"ࠫࡹࡼࡰ࠳ࡪࡧࠫଗ"):Variable4 (u"࡚ࠬࡖࡑࠢ࠵ࠫଘ"),
Variable4 (u"࠭ࡴࡷࡲ࡬ࡲ࡫ࡵࠧଙ"):Variable4 (u"ࠧࡕࡘࡓࠤࡎࡴࡦࡰࠩଚ"),
Variable4 (u"ࠨࡥࡩࡥࡲ࡯࡬ࡺࠩଛ"):Variable4 (u"ࠩࡆࡳࡲ࡫ࡤࡺࠢࡆࡩࡳࡺࡲࡢ࡮ࠣࡊࡦࡳࡩ࡭ࡻࠪଜ"),
Variable4 (u"ࠪࡪ࡮ࡲ࡭ࡣࡱࡻࡴࡷ࡫࡭ࡪࡷࡰࠫଝ"):Variable4 (u"ࠫࡋ࡯࡬࡮ࡤࡲࡼࠬଞ"),
Variable4 (u"ࠬ࡬࡯ࡹࡪࡧࠫଟ"): Variable4 (u"࠭ࡆࡰࡺࠪଠ"),
Variable4 (u"ࠧ࡯ࡩࡨࡳࡵ࡫࡯ࡱ࡮ࡨࠫଡ"): Variable4 (u"ࠨࡐࡤࡸࠥࡍࡥࡰࠢࡓࡩࡴࡶ࡬ࡦࠩଢ"),
Variable4 (u"ࠩࡳࡰࡦࡴࡥࡵࡧࠪଣ"):Variable4 (u"ࠪࡔࡱࡧ࡮ࡦࡶࡨࠫତ"),
Variable4 (u"ࠫࡵࡵ࡬ࡴࡣࡷࡷࡵࡵࡲࡵࠩଥ"):Variable4 (u"ࠬࡖ࡯࡭ࡵࡤࡸࠥࡹࡰࡰࡴࡷࠫଦ"),
Variable4 (u"࠭ࡰࡰ࡮ࡶࡥࡹࡹࡰࡰࡴࡷࡲࡪࡽࡳࠨଧ"):Variable4 (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡴࡲࡲࡶࡹࠦ࡮ࡦࡹࡶࠫନ"),
Variable4 (u"ࠨࡵࡸࡴࡪࡸࡳࡵࡣࡦ࡮ࡦ࠭଩"):Variable4 (u"ࠩࡖࡹࡵ࡫ࡲࡴࡶࡤࡧ࡯ࡧࠧପ"),
Variable4 (u"ࠪࡸࡻࡴࡨࡥࠩଫ"):Variable4 (u"࡙ࠫ࡜ࡎࠨବ"),
Variable4 (u"ࠬࡺࡶࡱ࠳ࠪଭ"):Variable4 (u"࠭ࡔࡗࡒࠣ࠵ࠬମ"),
Variable4 (u"ࠧࡵࡸࡳࡴࡴࡲ࡯࡯࡫ࡤࠫଯ"):Variable4 (u"ࠨࡖ࡙ࡔࠥࡶ࡯࡭ࡱࡱ࡭ࡦ࠭ର"),
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡷࡺ࡮ࡪࠧ଱")),Variable4 (u"ࠪࠫଲ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪଳ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"ࠬࡺࡶࡪࡦࠪ଴")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"࠭ࠧଵ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଶ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
    except:
        print Variable4 (u"ࠨࡷࡵࡰࡱ࡯ࡢ࠳࠰ࡸࡶࡱࡵࡰࡦࡰࠣࡉࡗࡘࡏࡓࠩଷ")
        l11ll11ll11l111_tv_ = Variable4 (u"ࠩࠪସ")
    l1llll1l11l11l111_tv_ = Variable4 (u"ࠪࠫହ").join([Variable4 (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫ଺")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,l1llll1l11l11l111_tv_ = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠺ࠥࡩ࡯࡭࠯ࡰࡨ࠲࠹ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡠࡸ࠰࠼࠰ࡦ࡬ࡺࡃ࠭଻"),re.DOTALL).findall(content)
    for ch in l1lll1lllll11l111_tv_:
        href = re.search(Variable4 (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁ଼ࠬࠦࠬ"),ch)
        l1llll11lll11l111_tv_ = re.search(Variable4 (u"ࠧࡥࡣࡷࡥ࠲ࡵࡲࡪࡩ࡬ࡲࡦࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨଽ"),ch)
        if href:
            href = href.group(1)
            title = href.split(Variable4 (u"ࠨ࠱ࠪା"))[-1]
            l1llll11lll11l111_tv_ = l1llll111ll11l111_tv_+l1llll11lll11l111_tv_.group(1) if l1llll11lll11l111_tv_ else Variable4 (u"ࠩࠪି")
            out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩୀ"):title.strip(),Variable4 (u"ࠫࡹࡼࡩࡥࠩୁ"):title.strip(),Variable4 (u"ࠬ࡯࡭ࡨࠩୂ"):l1llll11lll11l111_tv_,Variable4 (u"࠭ࡵࡳ࡮ࠪୃ"):l1llll111ll11l111_tv_+href+Variable4 (u"ࠧࡽࠧࡶࠫୄ")%l1llll1l11l11l111_tv_,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧ୅"):Variable4 (u"ࠩࠪ୆"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪେ"):Variable4 (u"ࠫࠬୈ")}))
    if addheader and len(out):
        t=Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡦࡳࡩࡨࡱࡶࡸࡻ࠴ࡥࡶࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ୉") %time.strftime(Variable4 (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦ୊"))
        out.insert(0,{Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ୋ"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ୌ"):Variable4 (u"୍ࠩࠪ"),Variable4 (u"ࠪ࡭ࡲ࡭ࠧ୎"):Variable4 (u"ࠫࠬ୏"),Variable4 (u"ࠬࡻࡲ࡭ࠩ୐"):l1llll111ll11l111_tv_,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬ୑"):Variable4 (u"ࠧࠨ୒"),Variable4 (u"ࠨࡷࡵࡰࡪࡶࡧࠨ୓"):Variable4 (u"ࠩࠪ୔")})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    print Variable4 (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡖࡪࡦࡨࡳࠬ୕"),url
    if Variable4 (u"ࠫࡦࡳࡩࡨࡱࡶࡸࡻ࠭ୖ") in url:
        l1lll1lll1l11l111_tv_,l1llll1l11l11l111_tv_=url.split(Variable4 (u"ࠬࢂࠧୗ"))
        header = {Variable4 (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ୘"):l1lll1l1lll11l111_tv_,Variable4 (u"ࠧࡉࡱࡶࡸࠬ୙"):Variable4 (u"ࠨࡣࡰ࡭࡬ࡵࡳࡵࡸ࠱ࡩࡺ࠭୚"),Variable4 (u"ࠩࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳ࠭୛"):Variable4 (u"ࠪ࡯ࡪ࡫ࡰ࠮ࡣ࡯࡭ࡻ࡫ࠧଡ଼"),Variable4 (u"࡚ࠫࡶࡧࡳࡣࡧࡩ࠲ࡏ࡮ࡴࡧࡦࡹࡷ࡫࠭ࡓࡧࡴࡹࡪࡹࡴࡴࠩଢ଼"):Variable4 (u"ࠬ࠷ࠧ୞")}
        print Variable4 (u"࠭࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡶࡴ࡯ࠫୟ"),l1lll1lll1l11l111_tv_
        print Variable4 (u"ࠧࡰࡲࡨࡲ࡮ࡴࡧࠡࡷࡵࡰࠬୠ"),l1lll1lll1l11l111_tv_
        c1,c=l111111l11l111_tv_(Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡰ࡭࡬ࡵࡳࡵࡸ࠱ࡩࡺ࠵ࠧୡ"),l1llll1111l11l111_tv_=True)
        content,c = l111111l11l111_tv_(l1lll1lll1l11l111_tv_,header=header,l1llll1111l11l111_tv_=True)
        src = re.compile(Variable4 (u"ࠩࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡲ࡯ࡧࡰࡵࡷࡺ࠳࡫ࡵ࠰࠰࠭ࡃࡡ࠴࡭࠴ࡷ࠻࠭ࠬୢ")).findall(content)
        if src:
            print src
            l1llll1l1ll11l111_tv_=src[0]
            content,C=l111111l11l111_tv_(l1llll1l1ll11l111_tv_,header=header,l1llll1111l11l111_tv_=True)
            l1llll1l1ll11l111_tv_ += Variable4 (u"ࠪࢀࡈࡵ࡯࡬࡫ࡨࡁࠪࡹࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠪࡹࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠧࡶࠫୣ")%(c,l1lll1l1lll11l111_tv_,l1lll1lll1l11l111_tv_)
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠫࡺࡸ࡬ࠨ୤"):l1llll1l1ll11l111_tv_}]
        else:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠬࡳࡳࡨࠩ୥"):Variable4 (u"࠭ࡎࡪࡧࠣࡾࡳࡧ࡬ࡢࡼॅࡩࡲࠦ࡬ࡪࡰ࡮ࡹࠬ୦")}]
    print l1lll1ll11l11l111_tv_
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
    for o in out:
        print o[Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭୧")]
        print l111l1lll11l111_tv_(o[Variable4 (u"ࠨࡷࡵࡰࠬ୨")])
