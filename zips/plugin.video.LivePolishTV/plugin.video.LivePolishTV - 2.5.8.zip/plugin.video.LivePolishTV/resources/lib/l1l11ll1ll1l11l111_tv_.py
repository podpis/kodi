# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷࡲ࠴࠱ࡴࡴ࡬ࡪࡰࡨ࠲ࡧࡲ࡯ࡨࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲ࡴ࠴ࡺࡶࡱ࠯࠴࠱ࡴࡴ࡬ࡪࡰࡨ࠱ࡰࡧ࡮ࡢ࡮ࡼ࠲࡭ࡺ࡭࡭ࠩ᳑")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭᳒")
__all__=[Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭᳓"),Variable4 (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱ࡜ࡩࡥࡧࡲ᳔ࠫ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ᳕ࠧ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"᳖ࠫࠬ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    data=False
    out=[]
    l1111l111ll11l111_tv_ = re.compile(Variable4 (u"ࠬࡪ࡯ࡤࡷࡰࡩࡳࡺ࠮ࡸࡴ࡬ࡸࡪࡢࠨࡶࡰࡨࡷࡨࡧࡰࡦ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡢࠩࠨ᳗")).findall(content)
    if l1111l111ll11l111_tv_:
        data = urllib.unquote(l1111l111ll11l111_tv_[0])
    l1111l111ll11l111_tv_=re.compile(Variable4 (u"࠭ࡤࡰࡥࡸࡱࡪࡴࡴ࠯ࡹࡵ࡭ࡹ࡫࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮᳘࠭")).findall(content)
    if l1111l111ll11l111_tv_:
        data= l1111l111ll11l111_tv_[0].replace(Variable4 (u"ࠧ࡝࡞ࡸ࠴࠵᳙࠭"),Variable4 (u"ࠨࠩ᳚")).decode(Variable4 (u"ࠩ࡫ࡩࡽ࠭᳛"))
    if data:
        l1l11ll1l1ll11l111_tv_=re.compile(Variable4 (u"ࠪࡀࡧࡻࡴࡵࡱࡱࠤࡨࡲࡡࡴࡵࡀࠦࡧࡻࡴࡵࡱࡱ࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡡ࡞࠿࡟࠭࠳ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ᳜࠭")).findall(data)
        for href,title in l1l11ll1l1ll11l111_tv_:
            h = href
            t = title.strip()
            if h and t:
                out.append({Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧ᳝ࠪ"):t,Variable4 (u"ࠬࡺࡶࡪࡦ᳞ࠪ"):t,Variable4 (u"࠭ࡩ࡮ࡩ᳟ࠪ"):Variable4 (u"ࠧࠨ᳠"),Variable4 (u"ࠨࡷࡵࡰࠬ᳡"):h,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨ᳢"):Variable4 (u"᳣ࠪࠫ"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪ᳤ࠫ"):Variable4 (u"᳥ࠬ࠭")})
    if addheader and len(out):
        t=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡩࡩ࡯ࡧࡰࡥ࠲ࡺࡶࠪ࡝࠲ࡇࡔࡒࡏࡓ࡟᳦ࠪ") %time.strftime(Variable4 (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗ᳧ࠧ"))
        out.insert(0,{Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫᳨ࠧ"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧᳩ"):Variable4 (u"ࠪࠫᳪ"),Variable4 (u"ࠫ࡮ࡳࡧࠨᳫ"):Variable4 (u"ࠬ࠭ᳬ"),Variable4 (u"࠭ࡵࡳ࡮᳭ࠪ"):l1llll111ll11l111_tv_,Variable4 (u"ࠧࡨࡴࡲࡹࡵ࠭ᳮ"):Variable4 (u"ࠨࠩᳯ"),Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᳰ"):Variable4 (u"ࠪࠫᳱ")})
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡶ࡯ࡳࡶࡼ࠵࠹࠴ࡢ࡭ࡱࡪࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴ࡶ࠯ࡵࡲ࠴ࡥ࠳࡮ࡴ࡮࡮ࠪᳲ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧᳳ") in url:
        content = l111111l11l111_tv_(url)
        l111111llll11l111_tv_ = re.compile(Variable4 (u"࠭ࠢࠩࡴࡷࡱࡵࡀ࠯࠰࠰࠭ࡃ࠮ࠨࠧ᳴")).findall(content)
        l1l1ll1ll1l11l111_tv_=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡱ࠰࡭ࡻࡵࡩࡤ࡯࠰ࡦࡳࡲ࠵࠶࠰࠳࠵࠳࡯ࡽࡰ࡭ࡣࡼࡩࡷ࠴ࡦ࡭ࡣࡶ࡬࠳ࡹࡷࡧࠩᳵ")
        if l111111llll11l111_tv_:
            href = l111111llll11l111_tv_[0]+ Variable4 (u"ࠨࠢࡶࡻ࡫࡛ࡲ࡭࠿ࠨࡷࠥࡶࡡࡨࡧࡘࡶࡱࡃࠥࡴࠢ࡯࡭ࡻ࡫࠽࠲ࠢࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠭ᳶ")%(l1l1ll1ll1l11l111_tv_,url)
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠩࡸࡶࡱ࠭᳷"):href}]
        l1111l111ll11l111_tv_=re.compile(Variable4 (u"ࠪࡨࡴࡩࡵ࡮ࡧࡱࡸ࠳ࡽࡲࡪࡶࡨࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪ᳸")).findall(content)
        if l1111l111ll11l111_tv_:
            data= l1111l111ll11l111_tv_[0].replace(Variable4 (u"ࠫࡡࡢࡵ࠱࠲ࠪ᳹"),Variable4 (u"ࠬ࠭ᳺ")).decode(Variable4 (u"࠭ࡨࡦࡺࠪ᳻"))
            l1111l111ll11l111_tv_ = re.compile(Variable4 (u"ࠧࡥࡱࡦࡹࡲ࡫࡮ࡵ࠰ࡺࡶ࡮ࡺࡥ࡝ࠪࡸࡲࡪࡹࡣࡢࡲࡨࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪ᳼")).findall(data)
            if l1111l111ll11l111_tv_:
                data = urllib.unquote(l1111l111ll11l111_tv_[0])
                href = l1ll11ll1ll11l111_tv_.decode(url,data)
                if href: l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠨࡷࡵࡰࠬ᳽"):href}]
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_()
    for o in out:
        l11ll11ll11l111_tv_ = l111l1lll11l111_tv_(o.get(Variable4 (u"ࠩࡸࡶࡱ࠭᳾")))
        print l11ll11ll11l111_tv_
