# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import time
import l1ll11ll1ll11l111_tv_
import cookielib
import urlparse
import threading
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡫ࡩ࡯ࡧ࠮ࡵࡸ࠲ࠫᯟ")
l1lll1l1lll11l111_tv_ = Variable4 (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤࡷࡼ࠺࠳࠴࠱࠴࠮ࠦࡇࡦࡥ࡮ࡳ࠴࠸࠰࠲࠲࠳࠵࠵࠷ࠠࡇ࡫ࡵࡩ࡫ࡵࡸ࠰࠴࠵࠲࠵࠭ᯠ")
l1lll1ll1ll11l111_tv_=15
fix={}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡹࡼࡩࡥࠩᯡ")),Variable4 (u"ࠬ࠭ᯢ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᯣ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"ࠧࡵࡸ࡬ࡨࠬᯤ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"ࠨࠩᯥ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ᯦࠭"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = Variable4 (u"ࠪࠫᯧ").join([Variable4 (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫᯨ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠬ࠭ᯩ")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l1l1lll111l11l111_tv_(url, l1ll111l1ll11l111_tv_, index):
    out = l1l1l1lllll11l111_tv_(url)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    l1l111lllll11l111_tv_ = list()
    l1l1llll111l11l111_tv_=[Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷ࠰ࡲࡴࡪࡴ࡫ࡢࡶࡤࡰࡴ࡭࠮࡮࡮࠲ࡳ࡬ࡵ࡬࡯ࡧࠪᯪ"),Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡸ࠱ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯࡯࡯࠳࡮ࡴࡦࡰࡴࡰࡥࡨࡿࡪ࡯ࡧࠪᯫ"),Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠲ࡴࡶࡥ࡯࡭ࡤࡸࡦࡲ࡯ࡨ࠰ࡰࡰ࠴࡬ࡩ࡭࡯ࡲࡻࡪ࠵ࠧᯬ"),
            Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡺ࠳ࡵࡰࡦࡰ࡮ࡥࡹࡧ࡬ࡰࡩ࠱ࡱࡱ࠵࡮ࡢࡷ࡮ࡳࡼ࡫ࠧᯭ"),Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻ࠴࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡲࡲ࠯ࡣࡣ࡭࡯ࡴࡽࡥࠨᯮ"),Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼ࠮ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡳ࡬࠰ࡵࡳࡳࡷࡺ࡯ࡸࡧࠪᯯ")]
    l1ll111l1ll11l111_tv_ = [[] for x in l1l1llll111l11l111_tv_]
    for i,url in enumerate(l1l1llll111l11l111_tv_):
        thread = threading.Thread(name=Variable4 (u"࡚ࠬࡨࡳࡧࡤࡨࠪࡪࠧᯰ")%i, target = l1l1lll111l11l111_tv_, args=[url,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if addheader and len(out):
        t=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᯱ") %time.strftime(Variable4 (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗ᯲ࠧ"))
        out.insert(0,{Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫᯳ࠧ"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧ᯴"):Variable4 (u"ࠪࠫ᯵"),Variable4 (u"ࠫ࡮ࡳࡧࠨ᯶"):Variable4 (u"ࠬ࠭᯷"),Variable4 (u"࠭ࡵࡳ࡮ࠪ᯸"):l1llll111ll11l111_tv_,Variable4 (u"ࠧࡨࡴࡲࡹࡵ࠭᯹"):Variable4 (u"ࠨࠩ᯺"),Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩ᯻"):Variable4 (u"ࠪࠫ᯼")})
    out = l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local)
    return out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    content,c = l111111l11l111_tv_(Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡭࡫ࡪࡢ࠰ࡷࡺ࠴࠭᯽"))
    ids = [(a.start(), a.end()) for a in re.finditer(Variable4 (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡧࡵࡸࠨ᯾"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        href  = re.compile(Variable4 (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᯿")).findall(l1l1lll1lll11l111_tv_)
        l1llll11lll11l111_tv_ = re.compile(Variable4 (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᰀ")).findall(l1l1lll1lll11l111_tv_)
        title = re.compile(Variable4 (u"ࠨ࠾࡫࠸ࠥࡩ࡬ࡢࡵࡶࡁࠧࡶ࡯ࡴࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᰁ")).findall(l1l1lll1lll11l111_tv_)
        if re.search(Variable4 (u"ࠩ࠿࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰ࠰ࡩࡾ࡫࠭ࡰࡲࡨࡲࠧࡄࠧᰂ"),l1l1lll1lll11l111_tv_) and href:
            t = title[0]
            i = l1llll11lll11l111_tv_[0] if l1llll11lll11l111_tv_ else Variable4 (u"ࠪࠫᰃ")
            h = href[0]
            out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᰄ"):t,Variable4 (u"ࠬࡺࡶࡪࡦࠪᰅ"):t,Variable4 (u"࠭ࡩ࡮ࡩࠪᰆ"):i,Variable4 (u"ࠧࡶࡴ࡯ࠫᰇ"):h,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧᰈ"):Variable4 (u"ࠩࠪᰉ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪᰊ"):Variable4 (u"ࠫࠬᰋ"),Variable4 (u"ࠬࡩ࡯ࡥࡧࠪᰌ"):Variable4 (u"࠭ࠧᰍ")}))
    if addheader and len(out):
        t=Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡨࡦ࡬ࡤ࠲ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᰎ") %time.strftime(Variable4 (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᰏ"))
        out.insert(0,{Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᰐ"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨᰑ"):Variable4 (u"ࠫࠬᰒ"),Variable4 (u"ࠬ࡯࡭ࡨࠩᰓ"):Variable4 (u"࠭ࠧᰔ"),Variable4 (u"ࠧࡶࡴ࡯ࠫᰕ"):l1llll111ll11l111_tv_,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧᰖ"):Variable4 (u"ࠩࠪᰗ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪᰘ"):Variable4 (u"ࠫࠬᰙ")})
    out = l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local)
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡮ࡥ࡫ࡣ࠱ࡸࡻ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࡷ࡫ࡨࡻ࠴ࡩࡡ࡯ࡣ࡯࠱࠷࠭ᰚ")):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    l1l1ll11lll11l111_tv_ = re.compile(Variable4 (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡆ࡮ࡵࡘࡶࡱࡃࠨࡳࡶࡰࡴࡠࡤࠦ࡞ࠬࠬࠫᰛ")).findall(content)
    l1l1lll1l1l11l111_tv_ = re.compile(Variable4 (u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࡀࠬࡠࡤࠦ࡞ࠬࠬࠫᰜ")).findall(content)
    l1l1ll1ll1l11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾ࡲࡦ࡯࡫ࡣࡵࠢ࠱࠮ࠥࡪࡡࡵࡣࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࠴ࠪࡀࡵࡺࡪ࠮ࠨࠧᰝ")).findall(content)
    l1l1ll1ll1l11l111_tv_ = l1l1ll1ll1l11l111_tv_[0] if l1l1ll1ll1l11l111_tv_ else Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡫ࡩ࡯ࡧ࠮ࡵࡸ࠲ࡺ࡮࡫ࡷࡦࡴࡑࡳࡈ࡮ࡡࡵ࠰ࡶࡻ࡫࠭ᰞ")
    if l1l1ll11lll11l111_tv_ and l1l1lll1l1l11l111_tv_:
        src = urllib.unquote(l1l1ll11lll11l111_tv_[0])
        l1l1ll1111l11l111_tv_ = l1l1lll1l1l11l111_tv_[0]
        l1ll11lll1l11l111_tv_ =src+l1l1ll1111l11l111_tv_+Variable4 (u"ࠪࠤࡵࡲࡡࡺࡲࡤࡸ࡭ࡃࡳࡵࡴࡨࡥࡲࠦࡳࡸࡨࡘࡶࡱࡃࠧᰟ")+l1l1ll1ll1l11l111_tv_ + Variable4 (u"ࠫࠥࡹࡷࡧࡘࡩࡽࡂ࠷ࠠ࡭࡫ࡹࡩࡂ࠷ࠠࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠶ࠤࡵࡧࡧࡦࡗࡵࡰࡂ࠭ᰠ")+url
        l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠬࡻࡲ࡭ࠩᰡ"):l1ll11lll1l11l111_tv_,Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᰢ"):Variable4 (u"ࠧࠨᰣ"),Variable4 (u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࠪᰤ"):1})
    else:
        src=Variable4 (u"ࠩࡵࡸࡲࡶ࠺࠰࠱࠻࠻࠳࠷࠲࠱࠰࠶࠺࠳࠿࠷࠰ࡸ࡬ࡨࡪࡵ࠯ࠨᰥ")
        l1l1ll1111l11l111_tv_=url.split(Variable4 (u"ࠪ࠱ࠬᰦ"))[-1]
        l1ll11lll1l11l111_tv_ =src+l1l1ll1111l11l111_tv_+Variable4 (u"ࠫࠥࡶ࡬ࡢࡻࡳࡥࡹ࡮࠽ࡴࡶࡵࡩࡦࡳࠠࡴࡹࡩ࡙ࡷࡲ࠽ࠨᰧ")+l1l1ll1ll1l11l111_tv_ + Variable4 (u"ࠬࠦࡳࡸࡨ࡙ࡪࡾࡃ࠱ࠡ࡮࡬ࡺࡪࡃ࠱ࠡࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠷ࠥࡶࡡࡨࡧࡘࡶࡱࡃࠧᰨ")+url
        l1lll1ll11l11l111_tv_.append({Variable4 (u"࠭ࡵࡳ࡮ࠪᰩ"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᰪ"):Variable4 (u"ࠨࠩᰫ"),Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᰬ"):1})
    return l1lll1ll11l11l111_tv_
def l1l1ll1l1ll11l111_tv_(url=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻ࠴࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡲࡲ࠯ࡰࡩࡲࡰࡳ࡫࠯ࡱࡱ࡯ࡷࡦࡺ࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠨᰭ")):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬᰮ"),re.DOTALL).findall(content)
    for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᰯ")).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_.append({Variable4 (u"࠭ࡵࡳ࡮ࠪᰰ"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᰱ"):Variable4 (u"ࠨࡎ࡬ࡺࡪࠦࠧᰲ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᰳ"):1})
                break
            else:
                l1ll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠪ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫࡁ࡟࠲ࡲ࠹ࡵ࡜࠺ࡠ࠭ࡠࠨ࡜ࠨ࡟ࠪᰴ")).findall(data)
                if l1ll1l1l11l11l111_tv_:
                    l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠫࡺࡸ࡬ࠨᰵ"):l1ll1l1l11l11l111_tv_[0],Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᰶ"):Variable4 (u"࠭ࡌࡪࡸࡨࠤ࠭ࡳ࠳ࡶ᰷ࠫࠪ"),Variable4 (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩ᰸"):1})
                    break
                else:
                    l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩ᰹"),re.DOTALL).findall(data)
                    l1ll1l1111l11l111_tv_ = l1ll1l1111l11l111_tv_[0] if l1ll1l1111l11l111_tv_ else Variable4 (u"ࠩࠪ᰺")
                    l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᰻")).findall(l1ll1l1111l11l111_tv_)
                    if l1ll1l11l1l11l111_tv_:
                        data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                    l1ll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠫࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂࡠ࠳ࡳ࠳ࡶ࡝࠻ࡡ࠮ࡡࠢ࡝ࠩࡠࠫ᰼")).findall(data)
                    if l1ll1l1l11l11l111_tv_:
                        l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠬࡻࡲ࡭ࠩ᰽"):l1ll1l1l11l11l111_tv_[0],Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬ᰾"):Variable4 (u"ࠧࡍ࡫ࡹࡩࠥ࠮࡭࠴ࡷࠬࠫ᰿"),Variable4 (u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࠪ᱀"):1})
                        break
                    else:
                        l1l1l1ll11l11l111_tv_ = [x.strip() for x in re.findall(Variable4 (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡟ࡷ࠯࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰ࡦࡳࡲ࠵ࡺࡢࡲࡤࡷ࠳࠰࠿ࠪࠤࠪ᱁"),content)]
                        for l1l1ll111ll11l111_tv_ in l1l1l1ll11l11l111_tv_:
                            print Variable4 (u"ࠪࡾࡦࡶࡡࡴࠩ᱂")
                            data,c = l111111l11l111_tv_( l1l1ll111ll11l111_tv_ )
                            l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ᱃"),re.DOTALL).findall(data)
                            for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
                                l1ll11lll1l11l111_tv_=Variable4 (u"ࠬ࠭᱄")
                                l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᱅")).findall(l1ll1l1111l11l111_tv_)
                                if l1ll1l11l1l11l111_tv_:
                                    data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
                                if l1ll11lll1l11l111_tv_:
                                    l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠧࡶࡴ࡯ࠫ᱆"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ᱇"):Variable4 (u"ࠩࡏ࡭ࡻ࡫ࠠࠨ᱈")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ᱉"):1})
                                    break
    return l1lll1ll11l11l111_tv_
def l1l1l1lll1l11l111_tv_():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        url=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡺࡸ࡬ࠨ᱊"))
        print Variable4 (u"ࠬࡢ࡮ࠨ᱋"),l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬ᱌"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡶࡴ࡯ࠫᱍ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᱎ")))
        print l1lll1ll11l11l111_tv_
