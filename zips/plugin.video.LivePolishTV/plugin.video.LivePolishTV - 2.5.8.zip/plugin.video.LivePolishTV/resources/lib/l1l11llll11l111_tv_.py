# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import time
import threading
import l1ll11ll1ll11l111_tv_
__all__=[Variable4 (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨ໕"),Variable4 (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡗ࡫ࡧࡩࡴ࠭໖")]
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ໗"), Variable4 (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠹࠲࠶ࡁࠠࡳࡸ࠽࠶࠷࠴࠰ࠪࠢࡊࡩࡨࡱ࡯࠰࠴࠳࠵࠵࠶࠱࠱࠳ࠣࡊ࡮ࡸࡥࡧࡱࡻ࠳࠷࠸࠮࠱ࠩ໘"))
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=Variable4 (u"ࠧࠨ໙")
    return l11ll11ll11l111_tv_
def l1l1lll111l11l111_tv_(url, l1ll111l1ll11l111_tv_, index):
    out = l1l1l1lllll11l111_tv_(url)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    url=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫࡮ࡰࡺࡨ࠮ࡪࡰࡩࡳ࠴࠭໚")
    content = l111111l11l111_tv_(url)
    items=re.compile(Variable4 (u"ࠩ࠿ࡰ࡮ࠦࡩࡥ࠿ࠥࡱࡪࡴࡵ࠮࡫ࡷࡩࡲ࠳࡜ࡥ࠭ࠥࠤࡨࡲࡡࡴࡵࡀࠦ࠳࠰ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠫ໛")).findall(content)
    for h,t in items:
        out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩໜ"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩໝ"):t,Variable4 (u"ࠬ࡯࡭ࡨࠩໞ"):Variable4 (u"࠭ࠧໟ"),Variable4 (u"ࠧࡶࡴ࡯ࠫ໠"):h,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧ໡"):Variable4 (u"ࠩࠪ໢"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪ໣"):Variable4 (u"ࠫࠬ໤"),Variable4 (u"ࠬࡩ࡯ࡥࡧࠪ໥"):Variable4 (u"࠭ࠧ໦")}))
    if addheader and len(out):
        t=Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡩ࡬࡮ࡸࡦ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ໧") %time.strftime(Variable4 (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ໨"))
        out.insert(0,{Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ໩"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨ໪"):Variable4 (u"ࠫࠬ໫"),Variable4 (u"ࠬ࡯࡭ࡨࠩ໬"):Variable4 (u"࠭ࠧ໭"),Variable4 (u"ࠧࡶࡴ࡯ࠫ໮"):Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫࡮ࡰࡺࡨ࠮࡯ࡧࡷࠫ໯"),Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨ໰"):Variable4 (u"ࠪࠫ໱"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫ໲"):Variable4 (u"ࠬ࠭໳")})
    return out
def l1l1l1lllll11l111_tv_(url=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩ࡬࡮ࡸࡦ࠳ࡴࡥࡵ࠱࡬ࡲ࡫ࡵ࠯ࠨ໴")):
    out=[]
    content = l111111l11l111_tv_(url)
    code=url[:-1].split(Variable4 (u"ࠧ࠰ࠩ໵"))[-1]
    l1l11l111ll11l111_tv_=content.find(Variable4 (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡱࡸࡷࡿ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ໶"))
    l1l11l11l1l11l111_tv_=content[l1l11l111ll11l111_tv_:].find(Variable4 (u"ࠩ࠱ࡩࡳࡺࡲࡺ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠪ໷"))
    content = content[l1l11l111ll11l111_tv_:l1l11l111ll11l111_tv_+l1l11l11l1l11l111_tv_]
    href=re.compile(Variable4 (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵ࡩ࡬࡮ࡸࡦ࠳ࡴࡥࡵ࠱࠱࠮ࡄ࠯ࠢࠨ໸")).findall(content)
    title = re.compile(Variable4 (u"ࠫࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ໹")).findall(content)
    l1llll11lll11l111_tv_ = re.compile(Variable4 (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ໺")).findall(content)
    for h,t,i in zip(href,title,l1llll11lll11l111_tv_):
        t = t.replace(Variable4 (u"࠭ࡔࡦ࡮ࡨࡻ࡮ࢀࡪࡢࠢࡲࡲࡱ࡯࡮ࡦࠢ࠰ࠤࠬ໻"),Variable4 (u"ࠧࠨ໼")).replace(Variable4 (u"ࠨࡡࠪ໽"),Variable4 (u"ࠩࠣࠫ໾")).strip()
        out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ໿"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩༀ"):t,Variable4 (u"ࠬ࡯࡭ࡨࠩ༁"):i,Variable4 (u"࠭ࡵࡳ࡮ࠪ༂"):h,Variable4 (u"ࠧࡨࡴࡲࡹࡵ࠭༃"):Variable4 (u"ࠨࠩ༄"),Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩ༅"):Variable4 (u"ࠪࠫ༆"),Variable4 (u"ࠫࡨࡵࡤࡦࠩ༇"):code}))
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯࡫࡭ࡷࡥ࠲࡮ࡴࡦࡰ࠱ࡷࡺࡳ࠳࠲࠵ࠩ༈")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"࠭ࡩ࡬࡮ࡸࡦࠬ༉") in url:
        l1l111l1lll11l111_tv_ = l111111l11l111_tv_(url)
        l1l1lll11ll11l111_tv_ = re.compile(Variable4 (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨ༊")).findall(l1l111l1lll11l111_tv_)
        l1l1ll111ll11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨ࠮ࠫࡁࠥࠤࡦࡲࡴ࠾ࠤ࡝ࡥࡵࡧࡳࡰࡹࡼࠤࡕࡲࡡࡺࡧࡵࠦࠬ་")).findall(l1l111l1lll11l111_tv_)
        if l1l1ll111ll11l111_tv_:
            l1l11lll1ll11l111_tv_ = l111111l11l111_tv_(l1l1ll111ll11l111_tv_[0])
            l1l111lll1l11l111_tv_ = re.compile(Variable4 (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪ༌")).findall(l1l11lll1ll11l111_tv_)
            if l1l111lll1l11l111_tv_:
                l1l1lll11ll11l111_tv_.extend(l1l111lll1l11l111_tv_)
        l1l111lllll11l111_tv_ = []
        l1ll111l1ll11l111_tv_ = [[] for x in l1l1lll11ll11l111_tv_]
        for i,l1ll1l1111l11l111_tv_ in enumerate(l1l1lll11ll11l111_tv_):
            thread = threading.Thread(name=Variable4 (u"ࠪࡘ࡭ࡸࡥࡢࡦࠨࡨࠬ།")%i, target = l1l1l11111l11l111_tv_, args=[l1ll1l1111l11l111_tv_,l1ll111l1ll11l111_tv_,i])
            l1l111lllll11l111_tv_.append(thread)
            thread.start()
        while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
        del l1l111lllll11l111_tv_[:]
        for i,l1l1l1ll11l111_tv_ in enumerate(l1ll111l1ll11l111_tv_):
            if l1l1l1ll11l111_tv_:
                l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠫࡺࡸ࡬ࠨ༎"):l1l1l1ll11l111_tv_,Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ༏"):Variable4 (u"࠭ࡌࡪࡰ࡮ࠤࠪࡪࠧ༐")%(i+1),Variable4 (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩ༑"):1})
    return l1lll1ll11l11l111_tv_
def l1l1l11111l11l111_tv_(l1ll1l1111l11l111_tv_, l1ll111l1ll11l111_tv_, index):
    out = l1l11ll11ll11l111_tv_(l1ll1l1111l11l111_tv_)
    l1ll111l1ll11l111_tv_[index]=out
def l1l11ll11ll11l111_tv_(l1ll1l1111l11l111_tv_):
    l1l11llllll11l111_tv_=Variable4 (u"ࠨࠩ༒")
    l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ༓")).findall(l1ll1l1111l11l111_tv_)
    if l1ll1l11l1l11l111_tv_:
        data=l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
        l1l11llllll11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(l1ll1l11l1l11l111_tv_[0],data)
    return l1l11llllll11l111_tv_
def _1l1l11l11l11l111_tv_(url=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡰࡲࡵࡣ࠰࡬ࡲ࡫ࡵ࠯ࡴࡶࡵࡩࡦࡳ࠯ࡵࡸࡱ࠶࠹࠴ࡨࡵ࡯࡯ࠫ༔")):
    l1l11llllll11l111_tv_=Variable4 (u"ࠫࠬ༕")
    content=l111111l11l111_tv_(url)
    l1l11l1llll11l111_tv_ = re.compile(Variable4 (u"ࠬ࡫ࡶࡢ࡮࡟ࠬࡺࡴࡥࡴࡥࡤࡴࡪࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠭ࡡ࠯࠻࡝ࡰࠪ༖")).findall(content)
    code = re.search(Variable4 (u"࠭࡜ࠬࠢ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠥࡢࠫࠨ༗"),content)
    code = urllib.unquote(code.group(1)) if code else Variable4 (u"ࠧࠨ༘")
    l1l11l11lll11l111_tv_ = Variable4 (u"ࠨ༙ࠩ")
    if l1l11l1llll11l111_tv_ and code:
        l1l111ll11l11l111_tv_ = urllib.unquote(l1l11l1llll11l111_tv_[0])
        _split = re.compile(Variable4 (u"ࠩࡶࡠ࠳ࡹࡰ࡭࡫ࡷࡠ࠭ࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ༚")).findall(l1l111ll11l11l111_tv_)[0]
        _1l11llll1l11l111_tv_ = re.compile(Variable4 (u"ࠪࡹࡳ࡫ࡳࡤࡣࡳࡩࡡ࠮ࡴ࡮ࡲ࡟࡟࠶ࡢ࡝ࠡ࡞࠮ࠤࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢࡢࠩࠨ༛")).findall(l1l111ll11l11l111_tv_)[0]
        _1l11lll11l11l111_tv_ = re.compile(Variable4 (u"ࠫࡨ࡮ࡡࡳࡅࡲࡨࡪࡇࡴ࡝ࠪ࡬ࡠ࠮ࡢࠩ࡝࠭ࠫ࠲࠯ࡅࠩ࡝ࠫ࡟࠿ࠬ༜")).findall(l1l111ll11l11l111_tv_)[0]
        tmp = code.split(str(_split))
        l1l11ll111l11l111_tv_ = tmp[1] + str(_1l11llll1l11l111_tv_)
        table=[]
        for i in range(0, len(code)):
            a = ord(code[i])
            b = int(l1l11ll111l11l111_tv_[i % len(l1l11ll111l11l111_tv_)])
            table.append((b ^ a) + int(_1l11lll11l11l111_tv_))
            l1l11l11lll11l111_tv_ = Variable4 (u"ࠬ࠭༝").join(map(chr, table))
    src = re.search(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ༞"),l1l11l11lll11l111_tv_)
    if src:
        src=src.group(1)
        if src.startswith(Variable4 (u"ࠧ࠰࠱ࠪ༟")):
            src=Variable4 (u"ࠨࡪࡷࡸࡵࡀࠧ༠")+src
    else:
        src=Variable4 (u"ࠩࠪ༡")
    if l1l11l11lll11l111_tv_.find(Variable4 (u"ࠪࡺࡦࡸࠠࡢࠢࡀࠫ༢"))>0:
        a=int(re.search(Variable4 (u"ࠫࡦࠦ࠽ࠡࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ༣"),l1l11l11lll11l111_tv_).group(1))
        b=int(re.search(Variable4 (u"ࠬࡨࠠ࠾ࠢࠫ࡟࠵࠳࠹࡞࠭ࠬࠫ༤"),l1l11l11lll11l111_tv_).group(1))
        c=int(re.search(Variable4 (u"࠭ࡣࠡ࠿ࠣࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ༥"),l1l11l11lll11l111_tv_).group(1))
        d=int(re.search(Variable4 (u"ࠧࡥࠢࡀࠤ࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭༦"),l1l11l11lll11l111_tv_).group(1))
        f=int(re.search(Variable4 (u"ࠨࡨࠣࡁࠥ࠮࡛࠱࠯࠼ࡡ࠰࠯ࠧ༧"),l1l11l11lll11l111_tv_).group(1))
        l1l11l1ll1l11l111_tv_ = re.search(Variable4 (u"ࠩࡹࡣࡵࡧࡲࡵࠢࡀࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠻ࠨ༨"),l1l11l11lll11l111_tv_).group(1)
        l11ll11ll11l111_tv_ = Variable4 (u"ࠪࡶࡹࡳࡰ࠻࠱࠲ࠩࡩ࠴ࠥࡥ࠰ࠨࡨ࠳ࠫࡤ࠰ࠩ༩")%(a/f,b/f,c/f,d/f) + l1l11l1ll1l11l111_tv_.split(Variable4 (u"ࠫ࠴࠭༪"))[1]+Variable4 (u"ࠬ࠵ࠧ༫")+Variable4 (u"࠭ࠠࡱ࡮ࡤࡽࡵࡧࡴࡩ࠿ࠪ༬")+l1l11l1ll1l11l111_tv_.split(Variable4 (u"ࠧ࠰ࠩ༭"))[-1]
        l1l1ll1ll1l11l111_tv_=re.compile(Variable4 (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭༮")).findall(l1l11l11lll11l111_tv_)[-1]
        l1l1ll1ll1l11l111_tv_=l1l1ll1ll1l11l111_tv_.replace(Variable4 (u"ࠩ࠱࡮ࡸ࠭༯"),Variable4 (u"ࠪ࠲࡫ࡲࡡࡴࡪ࠱ࡷࡼ࡬ࠧ༰")).replace(Variable4 (u"ࠫࡤࡸࡥ࡮ࡱࡷࡩࠬ༱"),Variable4 (u"ࠬ࠭༲"))
        l1l11llllll11l111_tv_ = l11ll11ll11l111_tv_ + Variable4 (u"࠭ࠠࡴࡹࡩ࡙ࡷࡲ࠽ࠨ༳")+l1l1ll1ll1l11l111_tv_ + Variable4 (u"ࠧࠡࡵࡺࡪ࡛࡬ࡹ࠾࠳ࠣࡰ࡮ࡼࡥ࠾࠳ࠣࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠹ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩ༴")+url
    elif Variable4 (u"ࠨࡵࡷࡥࡹ࡯ࡣ࠯ࡷ࠰ࡴࡷࡵ࠮ࡧࡴ༵ࠪ") in src:
        source = re.compile(Variable4 (u"ࠩࡶࡳࡺࡸࡣࡦ࠿ࠫࡶࡹࡳࡰ࠯ࠬࡂ࡟ࡣࠬ࡝ࠫࠫࠪ༶")).findall(src)
        if source:
            l1l11llllll11l111_tv_=source[0]
    else:
        data = l111111l11l111_tv_(src)
        l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,l1l11l11lll11l111_tv_.replace(Variable4 (u"ࠪࡠࡡ༷࠭"),Variable4 (u"ࠫࠬ༸")))
        if l1ll11lll1l11l111_tv_:
            l1l11llllll11l111_tv_=l1ll11lll1l11l111_tv_
        elif data:
            idx = data.find(Variable4 (u"ࠬࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡦࠢࡳࡰࡦࡿࡥࡳ༹ࠩ"))
            if idx<0:
                src = re.search(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ༺"),data)
                if src:
                    src=src.group(1)
                    if src.startswith(Variable4 (u"ࠧ࠰࠱ࠪ༻")):
                        src=Variable4 (u"ࠨࡪࡷࡸࡵࡀࠧ༼")+src
                    data = l111111l11l111_tv_(src)
                    idx = data.find(Variable4 (u"ࠩࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡪࠦࡰ࡭ࡣࡼࡩࡷ࠭༽"))
            data = data[idx:]
            l1l1ll1ll1l11l111_tv_ = re.search(Variable4 (u"ࠪࠦ࡫ࡲࡡࡴࡪࡳࡰࡦࡿࡥࡳࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ༾"),data)
            if l1l1ll1ll1l11l111_tv_:
                l1l1ll1ll1l11l111_tv_=l1l1ll1ll1l11l111_tv_.group(1)
                if l1l1ll1ll1l11l111_tv_.startswith(Variable4 (u"ࠫ࠴࠵ࠧ༿")):
                    l1l1ll1ll1l11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽ࠫཀ")+l1l1ll1ll1l11l111_tv_
            file = re.search(Variable4 (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠭࡝࡟ࡲࡡࡺࠠ࡞࠭ࠥࡸࡾࡶࡥࠣࠩཁ"),data)
            if file:
                file=file.group(1)
                if file.endswith(Variable4 (u"ࠧ࡮࠵ࡸ࠼ࠬག")):
                    l1l11llllll11l111_tv_ = file
                else:
                    l1l11llllll11l111_tv_ = file + Variable4 (u"ࠨࠢࡶࡻ࡫࡛ࡲ࡭࠿ࠪགྷ")+l1l1ll1ll1l11l111_tv_ + Variable4 (u"ࠩࠣࡷࡼ࡬ࡖࡧࡻࡀ࠵ࠥࡲࡩࡷࡧࡀ࠵ࠥࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠴ࠢࡳࡥ࡬࡫ࡕࡳ࡮ࡀࠫང")+url
    return l1l11llllll11l111_tv_
def l1l11l1l11l11l111_tv_(out,):
    l1l11ll1lll11l111_tv_=[]
    for l1l1l1ll11l111_tv_ in out:
        print l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩཅ")),Variable4 (u"ࠫ࠿ࠦࠧཆ"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬࡻࡲ࡭ࠩཇ"),Variable4 (u"࠭ࠧ཈"))
        l1ll11lll1l11l111_tv_ = l1l11l1111l11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡶࡴ࡯ࠫཉ"),Variable4 (u"ࠨࠩཊ")))
        if l1ll11lll1l11l111_tv_:
            l1l11l1l1ll11l111_tv_ (u"ࠩ࡟ࡸࠬཋ"),l1ll11lll1l11l111_tv_
            l1l1l1ll11l111_tv_[Variable4 (u"ࠪࡹࡷࡲࠧཌ")]=l1ll11lll1l11l111_tv_
            l1l11ll1lll11l111_tv_.append(l1l1l1ll11l111_tv_)
    return l1l11ll1lll11l111_tv_
def l11l1l1ll11l111_tv_(out,fname=Variable4 (u"ࠫ࡮ࡱ࡬ࡶࡤ࠱ࡱ࠸ࡻࠧཌྷ")):
    l1lllllllll11l111_tv_=Variable4 (u"ࠬࠩࡅ࡙ࡖࡌࡒࡋࡀ࠭࠲ࠢࡷࡺ࡬࠳ࡩࡥ࠿ࠥࡿࡹࡼࡩࡥࡿࠥࠤࡹࡼࡧ࠮࡮ࡲ࡫ࡴࡃࠢࡼ࡫ࡰ࡫ࢂࠨࠠࡶࡴ࡯࠱ࡪࡶࡧ࠾ࠤࡾࡹࡷࡲࡥࡱࡩࢀࠦࠥ࡭ࡲࡰࡷࡳ࠱ࡹ࡯ࡴ࡭ࡧࡀࠦࢀ࡭ࡲࡰࡷࡳࢁࠧ࠲ࡻࡵ࡫ࡷࡰࡪࢃ࡜࡯ࡽࡸࡶࡱࢃ࡜࡯࡞ࡱࠫཎ")
    l1l11ll1l1l11l111_tv_=Variable4 (u"࠭ࠣࡆ࡚ࡗࡑ࠸࡛࡜࡯ࠩཏ")
    for l1l1l1ll11l111_tv_ in out:
        l1l11ll1l1l11l111_tv_=l1l11ll1l1l11l111_tv_+l1lllllllll11l111_tv_.format(**l1l1l1ll11l111_tv_)
    l1l111ll1ll11l111_tv_ = open(fname,Variable4 (u"ࠧࡸࠩཐ"))
    l1l111ll1ll11l111_tv_.write(l1l11ll1l1l11l111_tv_)
    l1l111ll1ll11l111_tv_.close()
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
    for l1l1l1ll11l111_tv_ in out:
        print l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧད")),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡸࡶࡱ࠭དྷ")),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪ࡭ࡲ࡭ࠧན"))
        l1ll11lll1l11l111_tv_ = l111l1lll11l111_tv_(url=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡺࡸ࡬ࠨཔ")))
        print l1ll11lll1l11l111_tv_
