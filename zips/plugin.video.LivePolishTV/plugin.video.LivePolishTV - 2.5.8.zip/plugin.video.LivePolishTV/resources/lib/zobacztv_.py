# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,json,time
import cookielib
import l1ll11ll1ll11l111_tv_
import l1lll11111l11l111_tv_
import os
import urlparse
l1llll111ll11l111_tv_=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬࡬ࡴࡲࡡ࡯ࡦ࡬ࡥ࠳ࡺࡶ࠰ࠩຕ")
l1lll1ll1ll11l111_tv_=10
l1lll1l1lll11l111_tv_=Variable4 (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩຖ")
__all__=[Variable4 (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩທ"),Variable4 (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡘ࡬ࡨࡪࡵࠧຘ")]
l11ll111l11l111_tv_=Variable4 (u"ࡸࠧࡅ࠼࡟ࡪ࡮ࡲ࡭ࡺࡶࡲ࠲ࡨࡵ࡯࡬࡫ࡨࠫນ")
def _1l1l11l11l11l111_tv_(url,data=None,header={},l1llll1l11l11l111_tv_=Variable4 (u"ࠧࠨບ")):
    if not header:
        header = {Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬປ"):l1lll1l1lll11l111_tv_}
    if l1llll1l11l11l111_tv_:
        header[Variable4 (u"ࠩࡦࡳࡴࡱࡩࡦࠩຜ")]=l1llll1l11l11l111_tv_
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫຝ")
    return l11ll11ll11l111_tv_
def l1l1l1l1lll11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"ࠫࠬພ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩຟ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = Variable4 (u"࠭ࠧຠ").join([Variable4 (u"ࠧࠦࡵࡀࠩࡸࡁࠧມ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠨࠩຢ")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def _1l1l1l11ll11l111_tv_(url,data=None,header={},l1llll1l11l11l111_tv_=Variable4 (u"ࠩࠪຣ"), l1llll1l1l11l111_tv_=True,l1l1l11llll11l111_tv_=True):
    if l11ll111l11l111_tv_ and l1llll1l1l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        try:
            l1llll1ll1l11l111_tv_.load(l11ll111l11l111_tv_)
        except:
            l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ຤"):l1lll1l1lll11l111_tv_}
    if l1llll1l11l11l111_tv_:
        header
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        if l11ll111l11l111_tv_ and l1l1l11llll11l111_tv_ and l1llll1l1l11l111_tv_:
            l1l1l11l1ll11l111_tv_=os.path.dirname(l11ll111l11l111_tv_)
            if not os.path.exists(l1l1l11l1ll11l111_tv_): os.makedirs(l1l1l11l1ll11l111_tv_)
            if l1llll1ll1l11l111_tv_: l1llll1ll1l11l111_tv_.save(l11ll111l11l111_tv_, ignore_discard = True)
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠫࠬລ")
    return l11ll11ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1l1l11l111_tv_=True):
    cookies=l1lll11111l11l111_tv_.l1lll1l11ll11l111_tv_(l11ll111l11l111_tv_)
    content=_1l1l11l11l11l111_tv_(url,data,header,cookies)
    if content==Variable4 (u"ࠬ࠭຦"):
        cookies=l1l1l11ll1l11l111_tv_(Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡩࡱ࡯ࡥࡳࡪࡩࡢ࠰ࡷࡺ࠴࠭ວ"),l11ll111l11l111_tv_)
        content=_1l1l11l11l11l111_tv_(url,data,header,cookies)
    return content
def l1l1l11ll1l11l111_tv_(l11ll11ll11l111_tv_,l1l1l1l1l1l11l111_tv_):
    l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
    l11ll11ll11l111_tv_=l1llll111ll11l111_tv_
    l1l1l1l111l11l111_tv_ = l1lll11111l11l111_tv_.l1ll1llllll11l111_tv_(Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡪࡲࡰࡦࡴࡤࡪࡣ࠱ࡸࡻ࠵ࠧຨ"),l1llll1ll1l11l111_tv_,l1lll1l1lll11l111_tv_)
    l1llll1l11l11l111_tv_ =Variable4 (u"ࠨࠩຩ").join([Variable4 (u"ࠩࠨࡷࡂࠫࡳ࠼ࠩສ")%(c.name, c.value) for c in l1l1l1l111l11l111_tv_])
    l1l1l11l1ll11l111_tv_=os.path.dirname(l1l1l1l1l1l11l111_tv_)
    if l1llll1ll1l11l111_tv_:
        try:
            l1llll1ll1l11l111_tv_.save(l1l1l1l1l1l11l111_tv_, ignore_discard = True)
        except:
            pass
    return l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭࡭ࡵ࡬ࡢࡰࡧ࡭ࡦ࠴ࡴࡷ࠱࡬ࡲࡩ࡫ࡸ࠯ࡲ࡫ࡴ࠴ࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢ࠯ࡲࡲࡱ࡯࡮ࡦ࠱ࠪຫ"))
    l1l1l111l1l11l111_tv_=re.compile(Variable4 (u"ࠫࡁࡺࡤࠡࡵࡷࡽࡱ࡫࠽ࠣࡹ࡬ࡨࡹ࡮࠺ࠡ࡞ࡧ࠯ࡵࡾ࠻ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠭ຬ"),re.DOTALL).findall(content)
    out=[]
    for l1l1l1111ll11l111_tv_ in l1l1l111l1l11l111_tv_:
        h = re.compile(Variable4 (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫອ")).findall(l1l1l1111ll11l111_tv_)
        i= re.compile(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫຮ")).findall(l1l1l1111ll11l111_tv_)
        if h:
            title=h[0].split(Variable4 (u"ࠧ࠰ࠩຯ"))[-2].replace(Variable4 (u"ࠨ࠯ࠪະ"),Variable4 (u"ࠩࠣࠫັ"))
            href=urlparse.urljoin(l1llll111ll11l111_tv_,h[0])
            l1llll11lll11l111_tv_ = i[0] if i else Variable4 (u"ࠪࠫາ")
            out.append({Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪຳ"):title.strip(),Variable4 (u"ࠬࡺࡶࡪࡦࠪິ"):title.strip(),Variable4 (u"࠭ࡩ࡮ࡩࠪີ"):l1llll11lll11l111_tv_,Variable4 (u"ࠧࡶࡴ࡯ࠫຶ"):href,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧື"):Variable4 (u"ຸࠩࠪ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩູࠪ"):Variable4 (u"຺ࠫࠬ")})
    if addheader and len(out):
        t=Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧົ") %time.strftime(Variable4 (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦຼ"))
        out.insert(0,{Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ຽ"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭຾"):Variable4 (u"ࠩࠪ຿"),Variable4 (u"ࠪ࡭ࡲ࡭ࠧເ"):Variable4 (u"ࠫࠬແ"),Variable4 (u"ࠬࡻࡲ࡭ࠩໂ"):l1llll111ll11l111_tv_,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬໃ"):Variable4 (u"ࠧࠨໄ"),Variable4 (u"ࠨࡷࡵࡰࡪࡶࡧࠨ໅"):Variable4 (u"ࠩࠪໆ")})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1ll1l111ll11l111_tv_ = re.compile(Variable4 (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠬ࠳࠰࠿ࠪ࠾࠲࡭࡫ࡸࡡ࡮ࡧࠪ໇"),re.DOTALL).findall(content)
    if l1ll1l111ll11l111_tv_:
        src = re.compile(Variable4 (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅ່ࠩࠣࠩ")).findall(l1ll1l111ll11l111_tv_[0])
        if src:
            src = src[0]
            if src.startswith(Variable4 (u"ࠬ࠵࠯ࠨ້")):
                src = Variable4 (u"࠭ࡨࡵࡶࡳ࠾໊ࠬ")+src
            data=Variable4 (u"ࠧࡴࡴࡦࡁࠧࠫࡳ໋ࠣࠩ")%src
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,data)
            if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠨࡷࡵࡰࠬ໌"):l1ll11lll1l11l111_tv_}]
    l1l1l111lll11l111_tv_ = re.compile(Variable4 (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃࡡ࠴࡭࠴ࡷ࠻࠲࠯࠯ࠢࠨໍ")).findall(content)
    if l1l1l111lll11l111_tv_:
        src = l1l1l111lll11l111_tv_[0]
        l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠪࡹࡷࡲࠧ໎"):src}]
    if not l1lll1ll11l11l111_tv_:
        l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠫࡲࡹࡧࠨ໏"):Variable4 (u"ࠬ࡝ࡥࠡࡣࡵࡩࠥ࡮ࡡࡷ࡫ࡱ࡫ࠥࡧࠠࡱࡴࡲࡦࡱ࡫࡭ࠨ໐")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"࠭࡜࡯ࠩ໑"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭໒"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡷࡵࡰࠬ໓")))
        print l1lll1ll11l11l111_tv_
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ໔")))
        print l1lll1ll11l11l111_tv_
