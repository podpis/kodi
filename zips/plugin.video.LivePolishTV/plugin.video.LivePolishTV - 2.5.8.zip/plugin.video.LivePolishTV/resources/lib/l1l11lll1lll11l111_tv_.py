# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,time
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮࡮࡮ࠪ᮷")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠺࠶࠮࠱࠰࠵࠺࠻࠷࠮࠲࠲࠵ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ᮸")
__all__=[Variable4 (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ᮹"),Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯࡚࡮ࡪࡥࡰࠩᮺ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᮻ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠩࠪᮼ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠴࡭࡭࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶ࠳ࠬᮽ"))
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࠱ࡤࡂࡁ࠵ࡤࡪࡸࡁࠫᮾ")).findall(content)
    for href,_1l11lll1l1l11l111_tv_,l1llll11lll11l111_tv_,title in l1lll1lllll11l111_tv_:
        out.append({Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫᮿ"):title.strip(),Variable4 (u"࠭ࡴࡷ࡫ࡧࠫᯀ"):title.strip(),Variable4 (u"ࠧࡪ࡯ࡪࠫᯁ"):l1llll11lll11l111_tv_,Variable4 (u"ࠨࡷࡵࡰࠬᯂ"):href,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨᯃ"):Variable4 (u"ࠪࠫᯄ"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᯅ"):Variable4 (u"ࠬ࠭ᯆ")})
    if addheader and len(out):
        t=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠯࡯࡯࠭ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᯇ") %time.strftime(Variable4 (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧᯈ"))
        out.insert(0,{Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᯉ"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧᯊ"):Variable4 (u"ࠪࠫᯋ"),Variable4 (u"ࠫ࡮ࡳࡧࠨᯌ"):Variable4 (u"ࠬ࠭ᯍ"),Variable4 (u"࠭ࡵࡳ࡮ࠪᯎ"):l1llll111ll11l111_tv_,Variable4 (u"ࠧࡨࡴࡲࡹࡵ࠭ᯏ"):Variable4 (u"ࠨࠩᯐ"),Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᯑ"):Variable4 (u"ࠪࠫᯒ")})
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮࡮࡮࠲ࡸࡻ࠵ࡴࡷࡲ࠰࠵࠴࠭ᯓ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠬࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠯࡯࡯ࠫᯔ") in url:
        content = l111111l11l111_tv_(url)
        l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧᯕ")).findall(content)
        if l1ll1l1111l11l111_tv_:
            src = re.compile(Variable4 (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᯖ"),re.IGNORECASE).findall(l1ll1l1111l11l111_tv_[0])
            if src:
                data = l111111l11l111_tv_(src[0])
                tmp = re.compile(Variable4 (u"ࠨࡵࡵࡧࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪᯗ")).findall(data)
                if tmp:
                    if Variable4 (u"ࠩࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠴ࡣࡰ࡯ࠪᯘ") in tmp[0] or Variable4 (u"ࠪࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠳࡬ࡪࡸࡨ࠲ࡨࡵ࡭ࠨᯙ") in tmp[0]:
                        data = l111111l11l111_tv_(tmp[0])
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
                if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠫࡺࡸ࡬ࠨᯚ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠬࡢ࡮ࠨᯛ"),l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᯜ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡶࡴ࡯ࠫᯝ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᯞ")))
        print l1lll1ll11l11l111_tv_
