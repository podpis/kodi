# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import time
import cookielib
import threading
l1llll111ll11l111_tv_=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡻ࠱ࡸࡻ࠵ࠧ὿")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᾀ")
l1lll1ll1ll11l111_tv_ = Variable4 (u"ࠨ࠳࠳ࠫᾁ")
__all__=[Variable4 (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧᾂ"),Variable4 (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡖࡪࡦࡨࡳࠬᾃ")]
fix={
Variable4 (u"ࠫ࠶࡚ࡖࡑࠩᾄ"):Variable4 (u"࡚ࠬࡖࡑࠢ࠴ࠫᾅ"),
Variable4 (u"࠭࠲ࡕࡘࡓࠫᾆ"):Variable4 (u"ࠧࡕࡘࡓࠤ࠷࠭ᾇ"),
Variable4 (u"ࠨࡒࡤࠤࡘࡧࡴࠨᾈ"):Variable4 (u"ࠩࡓࡳࡱࡹࡡࡵࠩᾉ"),
Variable4 (u"ࠪࡔࡦ࠳ࡓࡢࡶࠪᾊ"):Variable4 (u"ࠫࡕࡵ࡬ࡴࡣࡷࠫᾋ"),
Variable4 (u"ࠬࡖࡡ࠮ࡕࡤࡸࠥ࠸ࠧᾌ"):Variable4 (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦ࠲ࠨᾍ"),
Variable4 (u"ࠧࡄ࡫ࡱࡩࡲࡧࡸ࠳ࠩᾎ"):Variable4 (u"ࠨࡅ࡬ࡲࡪࡳࡡࡹࠢ࠵ࠫᾏ"),
Variable4 (u"ࠩࡋࡆࡔࠦ࠲ࠡࡊࡇࠫᾐ"):Variable4 (u"ࠪࡌࡇࡕ࠲ࠡࡊࡇࠫᾑ"),
Variable4 (u"ࠫࡕࡹࡡࡵࠢࡖࡴࡴࡸࡴࠡࡐࡨࡻࡸ࠭ᾒ"):Variable4 (u"ࠬࡖ࡯࡭ࡵࡤࡸ࡙ࠥࡰࡰࡴࡷࠤࡓ࡫ࡷࡴࠩᾓ"),
Variable4 (u"࠭ࡅࡹࡶࡵࡩࡲ࡫ࠠࡔࡲࡲࡶࡹࡹࠧᾔ"):Variable4 (u"ࠧࡆࡺࡷࡶࡪࡳࡥࠡࡕࡳࡳࡷࡺࠧᾕ"),
Variable4 (u"ࠨࡕࡷࡳࡵࡱ࡬ࡢࡶ࡮ࡥࠬᾖ"):Variable4 (u"ࠩࡖࡸࡴࡶ࡫࡭ࡣࡷ࡯ࡦࠦࡔࡗࠩᾗ"),
Variable4 (u"ࠪࡇࡧࡹࠠࡓࡧࡤࡰ࡮ࡺࡹࠨᾘ"):Variable4 (u"ࠫࡈࡈࡓࠡࡔࡨࡥࡱ࡯ࡴࡺࠩᾙ"),
Variable4 (u"ࠬࡈࡂࡄࠢࡈࡥࡷࡺࡨࠡࡊࡇࠫᾚ"):Variable4 (u"࠭ࡂࡃࡅࠣࡉࡦࡸࡴࡩࠩᾛ"),
Variable4 (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡇࡱࡲࡨࠬᾜ"):Variable4 (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡈࡲࡳࡩࠦࡎࡦࡶࡺࡳࡷࡱࠧᾝ"),
Variable4 (u"ࠩࡉࡳࡰࡻࡳࠡࡖ࡙ࠫᾞ"):Variable4 (u"ࠪࡊࡴࡱࡵࡴࠢࡗ࡚ࠬᾟ"),
Variable4 (u"ࠫࡊࡹ࡫ࡢࠢࡗ࡚ࠬᾠ"):Variable4 (u"ࠬࡋࡳ࡬ࡣࠣࡘ࡛࠭ᾡ"),
Variable4 (u"࠭࠴ࡇࡷࡱࠤ࡙࡜ࠧᾢ"):Variable4 (u"ࠧ࠵ࡨࡸࡲ࡚ࠥࡖࠨᾣ"),
Variable4 (u"ࠨ࠶ࡉࡹࡳࠦࡈࡪࡶࡶࠫᾤ"):Variable4 (u"ࠩ࠷ࡪࡺࡴࠠࡉ࡫ࡷࡷࠬᾥ"),
Variable4 (u"ࠪ࠸ࡋࡻ࡮ࠡࡈ࡬ࡸࠫࡇ࡭ࡱ࠽ࡇࡥࡳࡩࡥࠨᾦ"):Variable4 (u"ࠫ࠹࡬ࡵ࡯ࠢࡉ࡭ࡹࠦࡄࡢࡰࡦࡩࠬᾧ"),
Variable4 (u"࡚ࠬࡖࡑࠢࡓࡳࡱࡵ࡮ࡪ࡫ࡤࠫᾨ"):Variable4 (u"࠭ࡔࡗࡒࠣࡔࡴࡲ࡯࡯࡫ࡤࠫᾩ"),
Variable4 (u"ࠧࡕࡘࡓࠤࡕࡻ࡬ࡴࠢ࠵ࠫᾪ"):Variable4 (u"ࠨࡒࡸࡰࡸࠦ࠲ࠨᾫ"),
Variable4 (u"ࠩࡗ࡚ࡕࠦࡁࡣࡥࠪᾬ"):Variable4 (u"ࠪࡘ࡛ࡖࠠࡂࡄࡆࠫᾭ"),
Variable4 (u"ࠫࡗࡵ࡭ࡢࡰࡦࡩ࡚ࠥࡖࠡࡊࡇࠫᾮ"):Variable4 (u"ࠬࡘ࡯࡮ࡣࡱࡧࡪࠦࡔࡗࠩᾯ"),
Variable4 (u"࠭ࡔࡗ࠶ࠪᾰ"):Variable4 (u"ࠧࡕࡘࠣ࠸ࠬᾱ"),
Variable4 (u"ࠨࡖࡵࡻࡦࡳࠧᾲ"):Variable4 (u"ࠩࡗ࡚࡚ࠥࡲࡸࡣࡰࠫᾳ"),
Variable4 (u"ࠪࡉࡺࡸ࡯ࡴࡲࡲࡶࡹࠦࠠ࠳ࠩᾴ"):Variable4 (u"ࠫࡊࡻࡲࡰࡵࡳࡳࡷࡺࠠ࠳ࠩ᾵"),
Variable4 (u"ࠬࡔࡩࡤ࡭࡭ࡶࠬᾶ"):Variable4 (u"࠭ࡎࡪࡥ࡮ࠤࡏࡸࠧᾷ"),
Variable4 (u"ࠧࡂ࡮ࡨ࡯࡮ࡴ࡯ࠨᾸ"):Variable4 (u"ࠨࡣ࡯ࡩࠥࡱࡩ࡯ࡱ࠮ࠫᾹ"),
Variable4 (u"ࠩࡆࡥࡳࡧ࡬ࠨᾺ"):Variable4 (u"ࠪࡇࡦࡴࡡ࡭࠭ࠪΆ"),
Variable4 (u"ࠫࡈࡧ࡮ࡢ࡮ࠣࡗࡵࡵࡲࡵࠩᾼ"):Variable4 (u"ࠬࡉࡡ࡯ࡣ࡯࠯࡙ࠥࡰࡰࡴࡷࠫ᾽"),
Variable4 (u"࠭ࡃࡢࡰࡤࡰ࡙ࠥࡰࡰࡴࡷࠤ࠷࠭ι"):Variable4 (u"ࠧࡄࡣࡱࡥࡱ࠱ࠠࡔࡲࡲࡶࡹࠦ࠲ࠨ᾿"),
Variable4 (u"ࠨࡅࡤࡲࡦࡲࠠࡅ࡫ࡶࡧࡴࡼࡥࡳࡻࠪ῀"):Variable4 (u"ࠩࡆࡥࡳࡧ࡬ࠬࠢࡇ࡭ࡸࡩ࡯ࡷࡧࡵࡽࠥࡎࡄࠨ῁"),
Variable4 (u"ࠪࡇࡦࡴࡡ࡭ࠢ࠴ࠫῂ"):Variable4 (u"ࠫࡈࡧ࡮ࡢ࡮࠮ࠤ࠶࠭ῃ"),
Variable4 (u"ࠬࡉࡡ࡯ࡣ࡯ࠤࡘ࡫ࡲࡪࡣ࡯ࡩࠬῄ"):Variable4 (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡓࡦࡴ࡬ࡥࡱ࡫ࠧ῅"),
Variable4 (u"ࠧࡄࡣࡱࡥࡱࠦࡆࡪ࡮ࡰࠫῆ"):Variable4 (u"ࠨࡅࡤࡲࡦࡲࠫࠡࡈ࡬ࡰࡲ࠭ῇ"),
Variable4 (u"ࠩࡑࡷࡵࡵࡲࡵࠩῈ"):Variable4 (u"ࠪࡲࡘࡶ࡯ࡳࡶࠪΈ"),
Variable4 (u"ࠫࡈࡧ࡮ࡢ࡮ࠣࡊࡦࡳࡩ࡭ࡻࠪῊ"):Variable4 (u"ࠬࡉࡡ࡯ࡣ࡯࠯ࠥࡌࡡ࡮࡫࡯ࡽࠬΉ"),
Variable4 (u"࠭ࡐ࡭ࡣࡱࡩࡹ࡫ࠧῌ"):Variable4 (u"ࠧࡑ࡮ࡤࡲࡪࡺࡥࠬࠩ῍"),
Variable4 (u"ࠨࡖࡨࡰࡪࡺ࡯ࡰࡰࠪ῎"):Variable4 (u"ࠩࡗࡩࡱ࡫ࡴࡰࡱࡱ࠯ࠬ῏"),
Variable4 (u"ࠪࡑ࡮ࡴࡩ࡮࡫ࡱ࡭ࠬῐ"):Variable4 (u"ࠫࡒ࡯࡮ࡪ࡯࡬ࡲ࡮࠱ࠧῑ"),
Variable4 (u"ࠬࡊ࡯࡮ࡱ࠮ࠫῒ"):Variable4 (u"࠭ࡄࡰ࡯ࡲ࠯ࠥࡎࡄࠨΐ"),
Variable4 (u"ࠧࡔࡶࡼࡰࡪࠦࡔࡗࡐࠪ῔"):Variable4 (u"ࠨࡖ࡙ࡒ࡙ࠥࡴࡺ࡮ࡨࠫ῕"),
Variable4 (u"ࠩࡄࡧࡹ࡯ࡶࡦࠢࡐࡩࡹ࡫࡯ࠡࡖ࡙ࡒࠬῖ"):Variable4 (u"ࠪࡘ࡛ࡔࠠࡎࡧࡷࡩࡴࠦࡁࡤࡶ࡬ࡺࡪ࠭ῗ"),
Variable4 (u"ࠫ࠷࠺ࠠࡕࡘࡑࠤࡇࡏࡓࠨῘ"):Variable4 (u"࡚ࠬࡖࡏࠢ࠵࠸ࠥࡈࡉࡔࠩῙ"),
Variable4 (u"࠭ࡔࡶࡴࡥࡳ࡚ࠥࡖࡏࠩῚ"):Variable4 (u"ࠧࡕࡘࡑࠤ࡙ࡻࡲࡣࡱࠪΊ"),
Variable4 (u"ࠨ࠴࠷ࠤ࡙࡜ࡎࠨ῜"):Variable4 (u"ࠩࡗ࡚ࡓࠦ࠲࠵ࠩ῝"),
Variable4 (u"ࠪ࠻࡚ࠥࡖࡏࠩ῞"):Variable4 (u"࡙ࠫ࡜ࡎࠡ࠹ࠪ῟"),
Variable4 (u"࡚ࠬࡖࡏ࠹ࠪῠ"):Variable4 (u"࠭ࡔࡗࡐࠣ࠻ࠬῡ"),
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡵࡸ࡬ࡨࠬῢ")),Variable4 (u"ࠨࠩΰ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨῤ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"ࠪࡸࡻ࡯ࡤࠨῥ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies=None,proxy={}):
    if proxy:
        urllib2.install_opener(urllib2.build_opener(urllib2.ProxyHandler(proxy)))
    if not header:
        header = {Variable4 (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨῦ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=10)
        if cookies==Variable4 (u"ࠬ࠭ῧ"):
            cookies=response.info()[Variable4 (u"࠭ࡓࡦࡶ࠰ࡇࡴࡵ࡫ࡪࡧࠪῨ")]
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠧࠨῩ")
    return l11ll11ll11l111_tv_
def l1l1lll111l11l111_tv_(l11ll1lllll11l111_tv_, l1ll111l1ll11l111_tv_, index):
    out,l1l111l1l1ll11l111_tv_ = l11lll11l1l11l111_tv_(l1l1l1llllll11l111_tv_=Variable4 (u"ࠨ࠳ࠪῪ"),l1l111l11lll11l111_tv_=Variable4 (u"ࠩ࠴࠸࠵࠭Ύ"),l11ll1lllll11l111_tv_=l11ll1lllll11l111_tv_)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(l1l1l1llllll11l111_tv_=Variable4 (u"ࠪ࠵ࠬῬ"),l1l111l11lll11l111_tv_=Variable4 (u"ࠫ࠶࠺࠰ࠨ῭"),addheader=False):
    out=[]
    l11lll1ll1l11l111_tv_ = range(10)
    l1l111lllll11l111_tv_ = []
    l1ll111l1ll11l111_tv_ = [[] for x in l11lll1ll1l11l111_tv_]
    for i,l11ll1lllll11l111_tv_ in enumerate(l11lll1ll1l11l111_tv_):
        thread = threading.Thread(name=Variable4 (u"࡚ࠬࡨࡳࡧࡤࡨࠪࡪࠧ΅")%i, target = l1l1lll111l11l111_tv_, args=[l11ll1lllll11l111_tv_+1,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if len(out)>0 and addheader:
        t=Variable4 (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡿ࡯ࡺ࠰ࡷࡺ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ`") %time.strftime(Variable4 (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧ῰"))
        out.insert(0,{Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ῱"):t,Variable4 (u"ࠩࡷࡺ࡮ࡪࠧῲ"):Variable4 (u"ࠪࠫῳ"),Variable4 (u"ࠫ࡮ࡳࡧࠨῴ"):Variable4 (u"ࠬ࠭῵"),Variable4 (u"࠭ࡵࡳ࡮ࠪῶ"):Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡼ࠲ࡹࡼ࠯ࠨῷ"),Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧῸ"):Variable4 (u"ࠩࠪΌ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪῺ"):Variable4 (u"ࠫࠬΏ")})
    return out
def l11lll11l1l11l111_tv_(l1l1l1llllll11l111_tv_=Variable4 (u"ࠬ࠷ࠧῼ"),l1l111l11lll11l111_tv_=Variable4 (u"࠭࠱࠵࠲ࠪ´"),l11ll1lllll11l111_tv_=4):
    url = Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡼ࠲ࡹࡼ࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࡁ࡯࡭ࡻ࡫࠽ࠦࡵࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࠪࡹࠦࡱࡣࡪࡩࡂࠫࡤࠨ῾")%(l1l1l1llllll11l111_tv_,l1l111l11lll11l111_tv_,l11ll1lllll11l111_tv_)
    content = l111111l11l111_tv_(url)
    out=[]
    lists=re.compile(Variable4 (u"ࠨ࠾࡯࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ῿"),re.DOTALL).findall(content)
    for li in lists:
        group=Variable4 (u"ࠩࠪ ")
        href = re.search(Variable4 (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡿ࠮ࡵࡸ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠴࠴ࠪࡀࠫࠥࠫ "),li)
        src = re.search(Variable4 (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ "),li)
        title = re.search(Variable4 (u"ࠬࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ "),li)
        l1l111l1ll1l11l111_tv_ = li.find(Variable4 (u"࠭࠾ࡏ࡫ࡨࠤࡹࡸࡡ࡯ࡵࡰ࡭ࡹࡻࡪࡦ࠾ࠪ "))
        if href and title and src:
            t = title.group(1).replace(Variable4 (u"ࠧ࠯ࠩ "),Variable4 (u"ࠨࠩ ")).title()
            for s in [Variable4 (u"ࠩࡗ࡚ࠬ "),Variable4 (u"ࠪࡘ࡛ࡔࠧ "),Variable4 (u"ࠫࡒ࡚ࡖࠨ "),Variable4 (u"࡚ࠬࡖࡑࠩ "),Variable4 (u"࠭ࡂࡊࡕࠪ​"),Variable4 (u"ࠧࡕࡘࡕࠫ‌"),Variable4 (u"ࠨࡖ࡙ࡗࠬ‍"),Variable4 (u"ࠩࡋࡆࡔ࠭‎"),Variable4 (u"ࠪࡆࡇࡉࠧ‏"),Variable4 (u"ࠫࡆ࡞ࡎࠨ‐"),Variable4 (u"ࠬࡇࡔࡎࠩ‑"),Variable4 (u"࠭ࡁࡎࡅࠪ‒"),Variable4 (u"ࠧࡉࡆࠪ–"),Variable4 (u"ࠨࡖࡏࡇࠬ—"),Variable4 (u"ࠩࡌࡈࠬ―"),Variable4 (u"ࠪ࡜ࡉ࠭‖"),Variable4 (u"࡙ࠫ࡜ࡔࠨ‗"),Variable4 (u"ࠬࡉࡂࡔࠩ‘")]:
                t = re.sub(Variable4 (u"ࠨࠨࠩࡁ࡬࠭ࠧ’")+s+Variable4 (u"ࠢࠪࠤ‚"),s.upper(), t)
            if l1l111l1ll1l11l111_tv_>0 :
                t +=Variable4 (u"ࠨࠢ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣ࡯ࡧࡨ࡯࡭ࡳ࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ‛")
            i = src.group(1)
            h = href.group(1)
            out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ“"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨ”"):t,Variable4 (u"ࠫ࡮ࡳࡧࠨ„"):i,Variable4 (u"ࠬࡻࡲ࡭ࠩ‟"):h,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬ†"):group,Variable4 (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧ‡"):Variable4 (u"ࠨࠩ•")}))
    l1l111l1l11l11l111_tv_ = Variable4 (u"ࡴࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡿ࠮ࡵࡸ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࡄࡲࡩࡷࡧࡀࠩࡸࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࠦࡵࠩࡴࡦ࡭ࡥ࠾ࠧࡧࠫ‣")%(l1l1l1llllll11l111_tv_,l1l111l11lll11l111_tv_,l11ll1lllll11l111_tv_+1)
    idx=content.find(l1l111l1l11l11l111_tv_)
    l1l111l1l1ll11l111_tv_ = l11ll1lllll11l111_tv_+1 if idx>-1 else None
    return out,l1l111l1l1ll11l111_tv_
l1lll1ll1lll11l111_tv_=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡴࡤࡱࡰࡧ࠮ࡱࡴࡲࡼࡾ࠴࡮ࡦࡶ࠱ࡴࡱ࠵ࠧ․")
l1lll1llllll11l111_tv_=Variable4 (u"ࠫࠬ‥")
def l1lll1l1llll11l111_tv_(url,header={}):
    l11ll11ll11l111_tv_=Variable4 (u"ࠬ࠭…")
    global l1lll1llllll11l111_tv_
    if not l1lll1llllll11l111_tv_:
        req = urllib2.Request(l1lll1ll1lll11l111_tv_,data=None,headers={Variable4 (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ‧"): l1lll1l1lll11l111_tv_,Variable4 (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬ "):1})
        response = urllib2.urlopen(req)
        cookies=response.headers.get(Variable4 (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬ "),Variable4 (u"ࠩࠣࠫ‪")).split(Variable4 (u"ࠪࠤࠬ‫"))[0]
        response.close()
        l1lll1llllll11l111_tv_ = cookies
    else:
        cookies=l1lll1llllll11l111_tv_
    data = Variable4 (u"ࠫࡺࡃࠥࡴࠨࡤࡰࡱࡵࡷࡄࡱࡲ࡯࡮࡫ࡳ࠾ࡱࡱࠫ‬")%urllib.quote_plus(url)
    l1lll1l1111l11l111_tv_ = l1lll1ll1lll11l111_tv_+Variable4 (u"ࠬ࠵ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡳ࠰ࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡳ࡬ࡵࡅࡡࡤࡶ࡬ࡳࡳࡃࡵࡱࡦࡤࡸࡪ࠭‭")
    headers={Variable4 (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ‮"): l1lll1l1lll11l111_tv_,Variable4 (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬ "):1,Variable4 (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ‰"):cookies}
    headers.update(header)
    req = urllib2.Request(l1lll1l1111l11l111_tv_,data,headers)
    response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
    l11ll11ll11l111_tv_=response.read()
    if Variable4 (u"ࠩࡶࡷࡱࡧࡧࡳࡧࡨࠫ‱") in l11ll11ll11l111_tv_:
        l1lll1l1111l11l111_tv_ = l1lll1ll1lll11l111_tv_+Variable4 (u"ࠪ࠳࡮ࡴࡣ࡭ࡷࡧࡩࡸ࠵ࡰࡳࡱࡦࡩࡸࡹ࠮ࡱࡪࡳࡃࡦࡩࡴࡪࡱࡱࡁࡸࡹ࡬ࡢࡩࡵࡩࡪ࠭′")
        req = urllib2.Request(l1lll1l1111l11l111_tv_,data,headers)
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_=response.read()
    response.close()
    print Variable4 (u"ࠫࡌࡇࡔࡆࠢ࡬ࡲ࡛ࠥࡓࡆࠩ″")
    return l11ll11ll11l111_tv_
def l1lll1l11l1l11l111_tv_():
    content=l111111l11l111_tv_(Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰࡬ࡨࡨࡲ࡯ࡢ࡭࠱ࡧࡴࡳ࠯ࡱࡴࡲࡼࡾࡲࡩࡴࡶ࠲ࡪࡷ࡫ࡥ࠮ࡲࡵࡳࡽࡿ࠭࡭࡫ࡶࡸ࠲ࡶ࡯࡭ࡣࡱࡨ࠳࡮ࡴ࡮࡮ࠪ‴"))
    l1lll1lll1ll11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡥ࡫ࡹࠤࡸࡺࡹ࡭ࡧࡀࠦࡼ࡯ࡤࡵࡪ࠽ࡠࡩ࠱ࠥࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫࡠࡩ࠱ࠩࠦࠤࡁࡀ࠴ࡪࡩࡷࡀࠪ‵")).findall(content)
    l1lll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠧ࠽ࡶࡧࡂ࠭࡮ࡴࡵࡲ࡞ࡷࡢ࠰ࠩ࠽࠱ࡷࡨࡃࡂࡴࡥࡀࠫࡠࡩ࠱ࠩ࠽࠱ࡷࡨࡃࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠭‶"),re.DOTALL).findall(content)
    proxies=[{x[0]: Variable4 (u"ࠨࠧࡶ࠾ࠪࡹࠧ‷")%(x[2],x[1])} for x in l1lll1l1l11l11l111_tv_]
    return proxies
def l111l1lll11l111_tv_(url=Variable4 (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡿ࠮ࡵࡸ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠴࠼࠶࠶࠻ࠪ‸")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠪࡽࡴࡿ࠮ࡵࡸࠪ‹") in url:
        content = l111111l11l111_tv_(url)
        l1l111l11l1l11l111_tv_ = re.compile(Variable4 (u"ࠫࡋࡲࡡࡴࡪ࡙ࡥࡷࡹࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ›")).findall(content)
        src = re.compile(Variable4 (u"ࠬࠨࡨࡵࡶࡳࠬ࠳࠰࠿ࠪ࠰ࡰ࠷ࡺ࠾ࠢࠨ※")).findall(content)
        if l1l111l11l1l11l111_tv_:
            l111111llll11l111_tv_ = re.search(Variable4 (u"࠭ࠨࡳࡶࡰࡴ࠿࠵࠯࠯ࠬࡂ࠭ࡡࠬࠧ‼"),l1l111l11l1l11l111_tv_[0])
            l11111lll1l11l111_tv_ = re.search(Variable4 (u"ࠧࡤ࡫ࡧࡁ࠭࠴ࠪࡀࠫ࡟ࠪࠬ‽"),l1l111l11l1l11l111_tv_[0])
            if l111111llll11l111_tv_:
                l1l111l1111l11l111_tv_ = map(int,re.compile(Variable4 (u"ࠨ࠱ࠫࡠࡩ࠱ࠩ࡝࠰ࠫࡠࡩ࠱ࠩ࡝࠰ࠫࡠࡩ࠱ࠩ࡝࠰ࠫࡠࡩ࠱ࠩ࠰ࠩ‾")).findall(l111111llll11l111_tv_.group(1))[0])
                l1l111l111ll11l111_tv_ = Variable4 (u"ࠩ࠱ࠫ‿").join([str(255-l1l111l1111l11l111_tv_[x]) for x in [3,2,0,1]])
                l1ll11lll1l11l111_tv_ = Variable4 (u"ࠪࡶࡹࡳࡰ࠻࠱࠲ࠫ⁀")+l1l111l111ll11l111_tv_+Variable4 (u"ࠫ࠴ࡿ࡯ࡺ࠱ࡢࡨࡪ࡬ࡩ࡯ࡵࡷࡣ࠴࠭⁁")+l11111lll1l11l111_tv_.group(1).strip() +Variable4 (u"ࠬࠦࡳࡸࡨࡘࡶࡱࡃࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡻ࠱ࡸࡻ࠵ࡰ࡭ࡣࡼࡩࡷࡼ࠳ࡢ࠰ࡶࡻ࡫ࠦࡳࡸࡨ࡙ࡪࡾࡃ࠱ࠡ࡮࡬ࡺࡪࡃ࠱ࠡࡶ࡬ࡱࡪࡵࡵࡵ࠿ࠪ⁂")+l1lll1ll1ll11l111_tv_+Variable4 (u"࠭ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩ⁃")+url
                l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠧࡶࡴ࡯ࠫ⁄"):l1ll11lll1l11l111_tv_})
        elif src:
            l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠨࡷࡵࡰࠬ⁅"):Variable4 (u"ࠩ࡫ࡸࡹࡶࠧ⁆")+src[0]+Variable4 (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ⁇")})
        else:
            p = l1lll1l11l1l11l111_tv_()
            print
            for proxy in p:
                content = l111111l11l111_tv_(url,proxy=proxy)
                src = re.compile(Variable4 (u"ࠫࠧ࡮ࡴࡵࡲࠫ࠲࠯ࡅࠩ࠯࡯࠶ࡹ࠽ࠨࠧ⁈")).findall(content)
                print(Variable4 (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡘ࡬ࡨࡪࡵࠧ⁉"),url,src)
                if src:
                    v = Variable4 (u"࠭ࡨࡵࡶࡳࠫ⁊")+src[0]+Variable4 (u"ࠧ࠯࡯࠶ࡹ࠽ࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠦࡵ࡙ࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠪ⁋")&(url,l1lll1l1lll11l111_tv_)
                    print(Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪ⁌"),url,v)
                    l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠩࡸࡶࡱ࠭⁍"):v})
                    break
        if not l1lll1ll11l11l111_tv_:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠪࡱࡸ࡭ࠧ⁎"):Variable4 (u"࡚ࠫࡺࡷࣴࡴࡽࠤࡱ࡯ࡳࡵछࠣࡱ࠸ࡻࠠࡪࠢࡸঀࡾࡰࠠࡑࡘࡕࠤࡨࡲࡩࡦࡰࡷࠤࡧࡿࠠࡰ࡯࡬ࡲऊऍࠠࡍࡋࡐࡍ࡙ࡕࡗࡂࡐ࡜ࠤࡔࡑࡒࡆࡕࠣࡇ࡟ࡇࡓࡖࠢࡒࡋࡑऊࡄࡂࡐࡌࡅࠥ࡭ࡤࡺࠢࡷࡽࡱࡱ࡯ࠡ࡝ࡅࡡॿࡸࣳࡥ࡮ࡤࠤࡧटࡤआࠢࡽࡲࣸࡽࠠࡥࡱࡶࡸञࡶ࡮ࡦࠣࠤ࡟࠴ࡈ࡝ࠨ⁏")}]
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_()
    for o in out:
        print o.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ⁐"))
