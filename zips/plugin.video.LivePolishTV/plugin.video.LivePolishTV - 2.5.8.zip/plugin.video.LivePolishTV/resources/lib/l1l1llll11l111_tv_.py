# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import xbmc,xbmcgui
import time,re,os,sys,threading
try: from shutil import rmtree
except: rmtree = False
#import ramic
def Variable14(l1l1l1l11l111_tv_,l11ll11l111_tv_=[Variable4 (u"ࠫࠬ૟")]):
    debug=1
def Variable15(name=Variable4 (u"ࠬ࠭ૠ")):
    debug=1
def l1lllll111l11l111_tv_(name=Variable4 (u"࠭ࠧ૨")):
    debug=1
def Variable16(top):
    debug=1
def Variable17():
    debug=1
def run(argument):
    try:
        debug=1
    except: pass
def l1lllll1lll11l111_tv_(fname):
    debug=1
def l1lllll1l1l11l111_tv_():
    debug=1

