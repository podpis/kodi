# coding: UTF-8
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬࡬ࡴࡲࡡ࡯ࡦ࡬ࡥ࠳ࡺࡶ࠰ࠩ୩")
l1llll1ll1l11l111_tv_= cookielib.LWPCookieJar()
l1lll1l1lll11l111_tv_=Variable4 (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ୪")
l1lll11l11l11l111_tv_=l1lll1l1lll11l111_tv_
def l1ll1llllll11l111_tv_(url,l1llll1ll1l11l111_tv_=l1llll1ll1l11l111_tv_,l1lll11l11l11l111_tv_=l1lll1l1lll11l111_tv_):
    l1ll1lll11l11l111_tv_=Variable4 (u"ࠫࠬ୫")
    try:
        class l1lll1111ll11l111_tv_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l1ll1lll1ll11l111_tv_(s):
            try:
                offset=1 if s[0]==Variable4 (u"ࠬ࠱ࠧ୬") else 0
                val = int(eval(s.replace(Variable4 (u"࠭ࠡࠬ࡝ࡠࠫ୭"),Variable4 (u"ࠧ࠲ࠩ୮")).replace(Variable4 (u"ࠨࠣࠤ࡟ࡢ࠭୯"),Variable4 (u"ࠩ࠴ࠫ୰")).replace(Variable4 (u"ࠪ࡟ࡢ࠭ୱ"),Variable4 (u"ࠫ࠵࠭୲")).replace(Variable4 (u"ࠬ࠮ࠧ୳"),Variable4 (u"࠭ࡳࡵࡴࠫࠫ୴"))[offset:]))
                return val
            except:
                pass
        if l1llll1ll1l11l111_tv_==None:
            l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l1lll1111ll11l111_tv_, urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        opener.addheaders = [(Variable4 (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ୵"), l1lll11l11l11l111_tv_)]
        try:
            response = opener.open(url)
            result=l1ll1lll11l11l111_tv_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l1ll1lll11l11l111_tv_ = e.read()
        l1lll1l111l11l111_tv_ = re.compile(Variable4 (u"ࠨࡰࡤࡱࡪࡃࠢ࡫ࡵࡦ࡬ࡱࡥࡶࡤࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠱࠿ࠪࠤ࠲ࡂࠬ୶")).findall(result)[0]
        init = re.compile(Variable4 (u"ࠩࡶࡩࡹ࡚ࡩ࡮ࡧࡲࡹࡹࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡠ࠮ࢁ࡜ࡴࠬ࠱࠮ࡄ࠴ࠪ࠻ࠪ࠱࠮ࡄ࠯ࡽ࠼ࠩ୷")).findall(result)[0]
        l1lll11llll11l111_tv_ = re.compile(Variable4 (u"ࡵࠦࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࡧࡱࡵࡱࡡ࠭࡜ࠪ࠽࡟ࡷ࠯࠮࠮ࠫࠫࡤ࠲ࡻࠨ୸")).findall(result)[0]
        l1lll11l1ll11l111_tv_ = l1ll1lll1ll11l111_tv_(init)
        lines = l1lll11llll11l111_tv_.split(Variable4 (u"ࠫࡀ࠭୹"))
        if l1lll1l111l11l111_tv_:
            for line in lines:
                if len(line)>0 and Variable4 (u"ࠬࡃࠧ୺") in line:
                    l1lll11ll1l11l111_tv_=line.split(Variable4 (u"࠭࠽ࠨ୻"))
                    l1ll1ll1lll11l111_tv_ = l1ll1lll1ll11l111_tv_(l1lll11ll1l11l111_tv_[1])
                    l1lll11l1ll11l111_tv_ = int(eval(str(l1lll11l1ll11l111_tv_)+l1lll11ll1l11l111_tv_[0][-1]+str(l1ll1ll1lll11l111_tv_)))
            l1ll1llll1l11l111_tv_ = l1lll11l1ll11l111_tv_ + len(urlparse.urlparse(url).netloc)
            u=url
            query = Variable4 (u"ࠧࠦࡵ࠲ࡧࡩࡴ࠭ࡤࡩ࡬࠳ࡱ࠵ࡣࡩ࡭ࡢ࡮ࡸࡩࡨ࡭ࡁ࡭ࡷࡨ࡮࡬ࡠࡸࡦࡁࠪࡹࠦ࡫ࡵࡦ࡬ࡱࡥࡡ࡯ࡵࡺࡩࡷࡃࠥࡴࠩ୼") % (u, l1lll1l111l11l111_tv_, l1ll1llll1l11l111_tv_)
            if Variable4 (u"ࠨࡶࡼࡴࡪࡃࠢࡩ࡫ࡧࡨࡪࡴࠢࠡࡰࡤࡱࡪࡃࠢࡱࡣࡶࡷࠧ࠭୽") in result:
                l1lll111lll11l111_tv_=re.compile(Variable4 (u"ࠩࡱࡥࡲ࡫࠽ࠣࡲࡤࡷࡸࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ୾")).findall(result)[0]
                query = Variable4 (u"ࠪࠩࡸ࠵ࡣࡥࡰ࠰ࡧ࡬࡯࠯࡭࠱ࡦ࡬ࡰࡥࡪࡴࡥ࡫ࡰࡄࡶࡡࡴࡵࡀࠩࡸࠬࡪࡴࡥ࡫ࡰࡤࡼࡣ࠾ࠧࡶࠪ࡯ࡹࡣࡩ࡮ࡢࡥࡳࡹࡷࡦࡴࡀࠩࡸ࠭୿") % (u,urllib.quote_plus(l1lll111lll11l111_tv_), l1lll1l111l11l111_tv_, l1ll1llll1l11l111_tv_)
                time.sleep(5)
            l1llll1l11l11l111_tv_ =Variable4 (u"ࠫࠬ஀").join([Variable4 (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬ஁")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
            opener = urllib2.build_opener(l1lll1111ll11l111_tv_,urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
            opener.addheaders = [(Variable4 (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪஂ"), l1lll11l11l11l111_tv_)]
            opener.addheaders.append((Variable4 (u"ࠧࡤࡱࡲ࡯࡮࡫ࠧஃ"),l1llll1l11l11l111_tv_))
            opener.addheaders.append((Variable4 (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ஄"),Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩ࡭ࡱ࡯ࡳࡦࡴ࠱ࡸࡻ࠵ࠧஅ")))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
        return l1llll1ll1l11l111_tv_
    except:
        return None
def l1lll1l11ll11l111_tv_(l11ll111l11l111_tv_):
    l1lll111l1l11l111_tv_=Variable4 (u"ࠪࠫஆ")
    if os.path.isfile(l11ll111l11l111_tv_):
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        l1llll1ll1l11l111_tv_.load(l11ll111l11l111_tv_)
        for c in l1llll1ll1l11l111_tv_:
            l1lll111l1l11l111_tv_+=Variable4 (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫஇ")%(c.name, c.value)
    return l1lll111l1l11l111_tv_
