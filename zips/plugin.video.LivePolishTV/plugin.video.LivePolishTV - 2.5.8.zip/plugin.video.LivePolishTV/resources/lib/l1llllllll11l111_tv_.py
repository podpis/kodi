# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩ࡯ࡣࡷࡺ࠳ࡶ࡬࠰ࠩ႑")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭႒")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ႓"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠩࠪ႔")
    return l11ll11ll11l111_tv_
def l11ll1lll1l11l111_tv_(url=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡪࡩࡺࡦ࡮࡬ࡺࡪ࠴ࡴࡷ࠱ࡵ࠲ࡵ࡮ࡰࡀࡴࡀ࠸࠶࠽࠵࠹࠲ࠩࡨ࡮ࡸࡥࡤࡶࠪ႕")):
    req = urllib2.Request(url,data=None,headers={Variable4 (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ႖"):l1lll1l1lll11l111_tv_,Variable4 (u"࡛ࠬࡰࡨࡴࡤࡨࡪ࠳ࡉ࡯ࡵࡨࡧࡺࡸࡥ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡵࠪ႗"):Variable4 (u"࠭࠱ࠨ႘")})
    response = urllib2.urlopen(req, timeout=15)
    l11ll111lll11l111_tv_ = response.geturl()
    response.close()
    return l11ll111lll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    l1lll1lll1l11l111_tv_=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡧࡦࡾࡪࡲࡩࡷࡧ࠱ࡸࡻ࠵࡮ࡢ࠯ࡽࡽࡼࡵ࠯ࠨ႙")
    content = l111111l11l111_tv_(l1lll1lll1l11l111_tv_)
    a= re.findall(Variable4 (u"ࠣ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠫ࠭ࡡ࡞ࠨ࡟࠮࠭ࠬࠦࡣ࡭ࡣࡶࡷࡂ࠭ࡣࡩࡣࡱࡲࡪࡲࠧࠡࡣ࡯ࡸࡂ࠭ࠨ࡜ࡠࠪࡡ࠰࠯ࠧࠡࡶ࡬ࡸࡱ࡫࠽ࠨࠪ࡞ࡢࠬࡣࠫࠪࠩࡁࡠࡸ࠰࠼ࡴࡲࡤࡲ࠭ࡡ࡞࠿࡟࠮࠭ࡃࡂࡢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠪࠬࡠࡤࠧ࡞࠭ࠬࠫࠥࡺࡩࡵ࡮ࡨࡁࠬ࠮࡛࡟ࠩࡠ࠯࠮࠭࠾࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂ࠭ࡤࡢࡶࡤࠫࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠫࡀ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃ࡜ࠣ࠰࠮ࡃࡡࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࠨႚ"),content)
    out=[]
    for t1,l11ll11llll11l111_tv_,l11ll11ll1l11l111_tv_,l11ll1l11ll11l111_tv_,l11ll1l111l11l111_tv_,l11ll1l1lll11l111_tv_,l11ll1l1l1l11l111_tv_,l11ll1ll11l11l111_tv_,code in a:
        title = l11ll1l1l1l11l111_tv_+l11ll11llll11l111_tv_ +Variable4 (u"ࠩࠣࡂࠥ࠭ႛ")+l11ll1ll11l11l111_tv_
        l1llll11lll11l111_tv_ = t1
        href = l11ll1l111l11l111_tv_
        code = code
        out.append({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩႜ"):title,Variable4 (u"ࠫࡹࡼࡩࡥࠩႝ"):title,Variable4 (u"ࠬ࡯࡭ࡨࠩ႞"):Variable4 (u"࠭ࠧ႟"),Variable4 (u"ࠧࡶࡴ࡯ࠫႠ"):href,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧႡ"):l11ll11llll11l111_tv_,Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩႢ"):Variable4 (u"ࠪࠫႣ"),Variable4 (u"ࠫࡵࡲ࡯ࡵࠩႤ"):Variable4 (u"ࠬ࠭Ⴅ"),Variable4 (u"࠭ࡣࡰࡦࡨࠫႦ"):code})
    if addheader and len(out):
        t=Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮࡭ࡦࡥࡽࡩࡱ࡯ࡶࡦࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫႧ") %time.strftime(Variable4 (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨႨ"))
        out.insert(0,{Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨႩ"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨႪ"):Variable4 (u"ࠫࠬႫ"),Variable4 (u"ࠬ࡯࡭ࡨࠩႬ"):Variable4 (u"࠭ࠧႭ"),Variable4 (u"ࠧࡶࡴ࡯ࠫႮ"):l1llll111ll11l111_tv_,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧႯ"):Variable4 (u"ࠩࠪႰ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪႱ"):Variable4 (u"ࠫࠬႲ")})
    return out
l11ll11l11l11l111_tv_=[Variable4 (u"ࠬࡼ࠲࠯ࡷࡶࡸࡷ࡫ࡡ࡮࡫ࡻ࠲ࡨࡵ࡭ࠨႳ"),Variable4 (u"࠭ࡵࡴࡶࡵࡩࡦࡳࡩࡹ࠰ࡦࡳࡲ࠭Ⴔ"),Variable4 (u"ࠧࡸ࡫ࡱࡸࡪࡾ࠮࡭࡫ࡰࡥ࠲ࡩࡩࡵࡻ࠱ࡨࡪ࠭Ⴕ"),Variable4 (u"ࠨࡵࡷࡥࡹ࡯ࡣ࠯ࡷ࠰ࡴࡷࡵ࠮ࡧࡴࠪႶ"),
    Variable4 (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࠱࡭ࡳ࠭Ⴗ"),Variable4 (u"ࠪࡻ࡮ࢀࡪࡢ࠰ࡷࡺࠬႸ"),Variable4 (u"ࠫࡼࡽࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠨႹ"),Variable4 (u"ࠬࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰࡬ࡷࠬႺ"),Variable4 (u"࠭ࡴࡦ࡮ࡨ࠱ࡼ࡯ࡺ࡫ࡣ࠱ࡧࡴࡳࠧႻ"),Variable4 (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡦࡱࡧࡣ࡬࠰ࡦࡳࡲ࠭Ⴜ"),
    Variable4 (u"ࠨࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧႽ"),Variable4 (u"ࠩࡧࡥࡷࡳ࡯ࡸࡣ࠰ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠴ࡩ࡯ࡨࡲࠫႾ"),Variable4 (u"ࠪࡸࡻ࠳ࡷࡦࡧࡥ࠲ࡨࡵ࡭ࠨႿ"),Variable4 (u"ࠫࡩࡧࡲ࡮ࡱࡺࡥ࠲ࡺࡶ࠯ࡲ࡯ࠫჀ"),Variable4 (u"ࠬࡺࡥ࡭ࡧࡹ࡬ࡸ࠴ࡰ࡭ࠩჁ")]
def l1llll1ll11l111_tv_(url=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡦࡥࡽࡩࡱ࡯ࡶࡦ࠰ࡷࡺ࠴ࡴࡡ࠮ࡼࡼࡻࡴ࠵ࡰࡪ࡮࡮ࡥࡤࡴ࡯ࡻࡰࡤ࠳ࡨ࡫ࡲࡳࡣࡧ࠱ࡨࢀࡡࡳࡰ࡬࠱ࡷࡧࡤࡰ࡯࠰ࡸࡷ࡫ࡦ࡭࠯ࡪࡨࡦࡴࡳ࡬࠯ࡳࡰࡺࡹ࡬ࡪࡩࡤ࠱࠼࠶࠶࠶࠹࠱࡬ࡹࡳ࡬ࠨჂ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l11ll1ll1ll11l111_tv_ = re.findall(Variable4 (u"ࠢ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂ࠭࡬ࡪࡰ࡮ࡣࡹ࡯ࡴ࡭ࡧࠪࡂ࠭ࡡ࡞࠿࡟࠮ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠫࡀ࠾ࡤࠤࡷ࡫࡬࠾ࠩࡱࡳ࡫ࡵ࡬࡭ࡱࡺࠫࠥࡺࡡࡳࡩࡨࡸࡂ࠭࡟ࡣ࡮ࡤࡲࡰ࠭ࠠࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨჃ"),content,re.DOTALL)
    for title,l11ll11ll11l111_tv_ in l11ll1ll1ll11l111_tv_:
        out.append({Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧჄ"):title.strip(),Variable4 (u"ࠩࡷࡺ࡮ࡪࠧჅ"):title.strip(),Variable4 (u"ࠪࡹࡷࡲࠧ჆"):l11ll11ll11l111_tv_.replace(Variable4 (u"ࠫࠨࡩࠧჇ"),Variable4 (u"ࠬࠬࡤࡪࡴࡨࡧࡹ࠭჈"))})
    return out
def l111l1lll11l111_tv_(item):
    host = item.get(Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬ჉"))
    print item
    url = l11ll1lll1l11l111_tv_(item.get(Variable4 (u"ࠧࡶࡴ࡯ࠫ჊")))
    print url
    l1lll1ll11l11l111_tv_=Variable4 (u"ࠨࠩ჋")
    if Variable4 (u"ࠩࡶࡸࡦࡺࡩࡤ࠰ࡸ࠱ࡵࡸ࡯࠯ࡨࡵࠫ჌") in host or Variable4 (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬჍ") in url:
        data=Variable4 (u"ࠫࡸࡸࡣ࠾ࠤࠨࡷࠧ࠭჎")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif Variable4 (u"ࠬࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡷ࠰ࡳࡰࠬ჏") in url:
        from l1llll111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"࠭ࡵࡳ࡮ࠪა"),Variable4 (u"ࠧࠨბ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠨࠩგ")
    elif Variable4 (u"ࠩࡷࡩࡱ࡫ࡶࡩࡵ࠱ࡴࡱ࠭დ") in url:
        from l1ll111ll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠪࡹࡷࡲࠧე"),Variable4 (u"ࠫࠬვ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠬ࠭ზ")
    if Variable4 (u"࠭ࡴࡷ࠯ࡺࡩࡪࡨ࠮ࡤࡱࡰࠫთ") in url:
        from l1llllll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠧࡶࡴ࡯ࠫი"),Variable4 (u"ࠨࠩკ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠩࠪლ")
    elif Variable4 (u"ࠪࡻ࡮ࡴࡴࡦࡺ࠱ࡰ࡮ࡳࡡ࠮ࡥ࡬ࡸࡾ࠴ࡤࡦࠩმ") in url:
        from l1l11ll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠫࡺࡸ࡬ࠨნ"),Variable4 (u"ࠬ࠭ო")) if l1lll1ll11l11l111_tv_ else Variable4 (u"࠭ࠧპ")
    elif Variable4 (u"ࠧࡶࡵࡷࡶࡪࡧ࡭ࡪࡺࠪჟ") in url:
        l1lll1ll11l11l111_tv_ = l11ll11l1ll11l111_tv_(url)
    elif Variable4 (u"ࠨࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡧࡲࡡࡤ࡭ࠪრ") in url:
        from l11l111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠩࡸࡶࡱ࠭ს"),Variable4 (u"ࠪࠫტ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠫࠬუ")
    elif Variable4 (u"ࠬࡲ࡯ࡰ࡭ࡱ࡭࡯࠴ࡩ࡯ࠩფ") in url:
        from l1lll1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"࠭ࡵࡳ࡮ࠪქ"),Variable4 (u"ࠧࠨღ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠨࠩყ")
    elif Variable4 (u"ࠩࡺ࡭ࡿࡰࡡ࠯ࡶࡹࠫშ") in url:
        from l1l1lllll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠪࡹࡷࡲࠧჩ"),Variable4 (u"ࠫࠬც"))  if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠬ࠭ძ")
    elif Variable4 (u"࠭ࡤࡢࡴࡰࡳࡼࡧ࠭ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠱࡭ࡳ࡬࡯ࠨწ") in url:
        from l11l11l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠧࡶࡴ࡯ࠫჭ"),Variable4 (u"ࠨࠩხ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠩࠪჯ")
    elif Variable4 (u"ࠪࡸࡪࡲࡥ࠮ࡹ࡬ࡾ࡯ࡧࠧჰ") in url:
        from l11llll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠫࡺࡸ࡬ࠨჱ"),Variable4 (u"ࠬ࠭ჲ")) if l1lll1ll11l11l111_tv_ else Variable4 (u"࠭ࠧჳ")
    elif Variable4 (u"ࠧࡸࡹࡺ࠲ࡹࡼࡰ࠯ࡲ࡯ࠫჴ") in host:
        from l11ll1lll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(Variable4 (u"ࠨࡷࡵࡰࠬჵ"),Variable4 (u"ࠩࠪჶ"))  if l1lll1ll11l11l111_tv_ else Variable4 (u"ࠪࠫჷ")
    else:
        l1l11l1l1ll11l111_tv_ (u"ࠫࡊࡒࡓࡆࠩჸ")
        data = l111111l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    print(Variable4 (u"ࠬࡼࡩࡥࡧࡲࠫჹ"),l1lll1ll11l11l111_tv_)
    return l1lll1ll11l11l111_tv_
