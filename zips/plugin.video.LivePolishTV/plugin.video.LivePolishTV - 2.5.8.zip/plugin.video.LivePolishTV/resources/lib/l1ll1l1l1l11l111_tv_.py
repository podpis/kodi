# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,json,time
import cookielib
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡴ࡯ࡸࡣࡷࡺ࠳ࡴࡥࡵࠩᎵ")
l1lll1ll1ll11l111_tv_=10
l1lll1l1lll11l111_tv_=Variable4 (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᎶ")
__all__=[Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᎷ"),Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪᎸ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ꮉ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫᎺ")
    return l11ll11ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"ࠫࠬᎻ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᎼ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = Variable4 (u"࠭ࠧᎽ").join([Variable4 (u"ࠧࠦࡵࡀࠩࡸࡁࠧᎾ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠨࠩᎿ")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,c = l111111l11l111_tv_(Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡱࡳࡼࡧࡴࡷ࠰ࡱࡩࡹ࠵ࡳࡵࡴࡨࡥࡲࡹࠧᏀ"))
    try:
        data = json.loads(content)
    except:
        data=[]
    out=[]
    for d in data:
        l1llll11lll11l111_tv_= l1llll111ll11l111_tv_+d.get(Variable4 (u"ࠪࡰࡴ࡭࡯ࠨᏁ"))
        title=d.get(Variable4 (u"ࠫࡳࡧ࡭ࡦࠩᏂ"))
        href=l1llll111ll11l111_tv_+Variable4 (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࠬᏃ")+d.get(Variable4 (u"࠭ࡣࡩࡣࡱࡩࡱ࠭Ꮔ"))+Variable4 (u"ࠧࡀࠩᏅ")+c
        out.append({Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᏆ"):title.strip(),Variable4 (u"ࠩࡷࡺ࡮ࡪࠧᏇ"):title.strip(),Variable4 (u"ࠪ࡭ࡲ࡭ࠧᏈ"):l1llll11lll11l111_tv_,Variable4 (u"ࠫࡺࡸ࡬ࠨᏉ"):href,Variable4 (u"ࠬ࡭ࡲࡰࡷࡳࠫᏊ"):Variable4 (u"࠭ࠧᏋ"),Variable4 (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᏌ"):Variable4 (u"ࠨࠩᏍ")})
    if addheader and len(out):
        t=Variable4 (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡼࡩࡱࡲ࡯ࡸ࡟ࡘࡴࡩࡧࡴࡦࡦ࠽ࠤࠪࡹࠠࠩࡰࡲࡻࡦࡺࡶ࠯ࡰࡨࡸ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᏎ") %time.strftime(Variable4 (u"ࠥࠩࡩ࠵ࠥ࡮࠱ࠨ࡝࠿ࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣᏏ"))
        out.insert(0,{Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᏐ"):t,Variable4 (u"ࠬࡺࡶࡪࡦࠪᏑ"):Variable4 (u"࠭ࠧᏒ"),Variable4 (u"ࠧࡪ࡯ࡪࠫᏓ"):Variable4 (u"ࠨࠩᏔ"),Variable4 (u"ࠩࡸࡶࡱ࠭Ꮥ"):l1llll111ll11l111_tv_,Variable4 (u"ࠪ࡫ࡷࡵࡵࡱࠩᏖ"):Variable4 (u"ࠫࠬᏗ"),Variable4 (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᏘ"):Variable4 (u"࠭ࠧᏙ")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local={})
def l111l1lll11l111_tv_(url):
    url,l1llll1l11l11l111_tv_=url.split(Variable4 (u"ࠧࡀࠩᏚ")) if Variable4 (u"ࠨࡁࠪᏛ")in url else (url,Variable4 (u"ࠩࠪᏜ"))
    print url,l1llll1l11l11l111_tv_
    l1lll1ll11l11l111_tv_=[]
    header ={Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᏝ"):l1lll1l1lll11l111_tv_,
            Variable4 (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧᏞ"):Variable4 (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭Ꮯ"),
            Variable4 (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᏠ"):url,
            Variable4 (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧᏡ"):l1llll1l11l11l111_tv_,
            }
    content,c = l111111l11l111_tv_(url,header=header)
    try:
        data = json.loads(content)
        if not data.get(Variable4 (u"ࠨ࡮࡬ࡱ࡮ࡺࠧᏢ"),False):
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠩࡸࡶࡱ࠭Ꮳ"):data.get(Variable4 (u"ࠪࡹࡷࡲࠧᏤ"))}]
        else:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠫࡲࡹࡧࠨᏥ"):Variable4 (u"ࠬࡕࡧࡳࡣࡱ࡭ࡨࢀ࡯࡯ࡣࠣࡨࡴࡹࡴचࡲࡱࡳॠऍࠠ࡮ࡣࡷࡩࡷ࡯ࡡृࡷ࠱ࡠࡳ࡙ࡥࡳࡹࡨࡶࡾࠦࡳआࠢࡲࡦࡪࡩ࡮ࡪࡧࠣࡴࡷࢀࡥࡤ࡫ईঀࡴࡴࡥ࠯ࠩᏦ")}]
    except:
        l1lll1ll11l11l111_tv_=[{Variable4 (u"࠭࡭ࡴࡩࠪᏧ"):Variable4 (u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠡࡼࠣࡳࡩࡩࡺࡺࡶࡤࡲ࡮࡫࡭ࠡॼࡵࣷࡩࡲࡡࠨᏨ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠨ࡞ࡱࠫᏩ"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᏪ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡹࡷࡲࠧᏫ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᏬ")))
        print l1lll1ll11l11l111_tv_
