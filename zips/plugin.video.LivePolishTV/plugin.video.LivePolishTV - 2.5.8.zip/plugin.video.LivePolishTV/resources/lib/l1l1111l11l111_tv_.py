# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib,cookielib
import re,json
#from ramic import go as l1l1lllllll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡨࡷࡰࡧࡧࡰ࠰ࡳࡰ࠴ࡺࡶࠨ෾")
l1lll1l1lll11l111_tv_=Variable4 (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ෿")
l1lll1ll1ll11l111_tv_=10
class l1lll1111ll11l111_tv_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"ࠧࠨ฀")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_),l1lll1111ll11l111_tv_())
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬก"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = Variable4 (u"ࠩࠪข").join([Variable4 (u"ࠪࠩࡸࡃࠥࡴ࠽ࠪฃ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠫࠬค")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡨࡷࡰࡧࡧࡰ࠰ࡳࡰ࠴ࡺࡶ࠰࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠯࠭ࡂࡀ࡮ࡳࡧࠡࡣ࡯ࡸࡂࠨ࠮ࠫࡁࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠱ࡁࡀ࠴ࡧ࠾ࠨฅ")).findall(content)
    l1l1llll11l11l111_tv_=[]
    for href,l1ll111111l11l111_tv_,l1l1lllll1l11l111_tv_ in l1lll1lllll11l111_tv_:
        title = l1l1lllllll11l111_tv_[Variable4 (u"࠭ࡤࡦࡥࡲࡨࡪࡎࡔࡎࡎࡨࡲࡹࡸࡩࡦࡵࠪฆ")](l1ll111111l11l111_tv_)
        l1l1l1ll11l111_tv_ = {Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ง"):title.strip(),Variable4 (u"ࠨࡷࡵࡰࠬจ"):href,Variable4 (u"ࠩ࡬ࡱ࡬࠭ฉ"):l1l1lllll1l11l111_tv_}
        l1l1llll11l11l111_tv_.append(l1l1l1ll11l111_tv_)
    if not l1l1llll11l11l111_tv_:
        l1l1llll11l11l111_tv_=[{Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩช"):Variable4 (u"ࠫࡓ࡯ࡣࠡࡰ࡬ࡩࠥࢀ࡮ࡢ࡮ࡨࡾ࡮ࡵ࡮ࡰࠩซ"),Variable4 (u"ࠬࡻࡲ࡭ࠩฌ"):Variable4 (u"࠭ࠧญ")}]
    return l1l1llll11l11l111_tv_
url=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡪࡹ࡫ࡢࡩࡲ࠲ࡵࡲ࠯ࡵࡸ࠲ࡴࡴࡲ࡯࠮ࡲࡤࡶࡹࡿ࠭ࡵࡸࠪฎ")
def l111l1lll11l111_tv_(url):
    content = l111111l11l111_tv_(url)
    l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠨࡷࡵࡰࠬฏ"):Variable4 (u"ࠩࠪฐ"),Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩฑ"):Variable4 (u"ࠫࡇࡸࡡ࡬ࠢॽࡶࣸࡪूࡢࠩฒ")}]
    found = re.findall(Variable4 (u"ࠬࡶ࡯ࡴࡶ࡟ࠬࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠴ࠫࡀࡵࡷࡶࡪࡧ࡭ࡖࡴ࡬࠾ࡡࡹࠪ࡜ࠤ࡟ࠫࡢ࠮࠮ࠬࡁࠬ࡟ࠧࡢࠧ࡞࡞ࡶ࠮ࢂ࠭ณ"),content)
    if found:
        l1l1llll1ll11l111_tv_ = l111111l11l111_tv_(found[0][0],Variable4 (u"࠭ࡳࡵࡴࡨࡥࡲ࡛ࡲࡪ࠿ࠪด")+urllib.quote(found[0][1]))
        if l1l1llll1ll11l111_tv_ and l1l1llll1ll11l111_tv_.startswith(Variable4 (u"ࠧࡩࡶࡷࡴࠬต")):
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠨࡷࡵࡰࠬถ"):l1l1llll1ll11l111_tv_,Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨท"):Variable4 (u"ࠪࡷࡹࡸࡥࡢ࡯ࠪธ")}]
    return l1lll1ll11l11l111_tv_
