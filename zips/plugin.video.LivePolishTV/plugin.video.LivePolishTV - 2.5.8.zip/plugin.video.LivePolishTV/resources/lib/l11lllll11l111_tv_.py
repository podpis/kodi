# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import re
import urllib2,urllib
import base64
import urlparse
import time,json
import os
l1lll1l1lll11l111_tv_=Variable4 (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠺࠶࠮࠱࠰࠵࠺࠻࠷࠮࠲࠲࠵ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫཕ")
l1llll111ll11l111_tv_ =Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡵ࡫ࡹ࡭࠳ࡶ࡬࠰ࠩབ")
__all__=[Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬབྷ"),Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪམ")]
fix={
Variable4 (u"ࠩࡗ࡚ࡕ࠷ࠠࡉࡆࠪཙ"):Variable4 (u"ࠪࡘ࡛ࡖࠠ࠲ࠩཚ"),
Variable4 (u"࡙ࠫ࡜ࡐ࠳ࠢࡋࡈࠬཛ"):Variable4 (u"࡚ࠬࡖࡑࠢ࠵ࠫཛྷ"),
Variable4 (u"࠭ࡐࡐࡎࡖࡅ࡙ࠦࡈࡅࠩཝ"):Variable4 (u"ࠧࡑࡱ࡯ࡷࡦࡺࠧཞ"),
Variable4 (u"ࠨࡖ࡙ࡒࠬཟ"):Variable4 (u"ࠩࡗ࡚ࡓ࠭འ"),
Variable4 (u"ࠪࡌࡇࡕࠠࡉࡆࠪཡ"):Variable4 (u"ࠫࡍࡈࡏࠨར"),
Variable4 (u"ࠬࡉࡁࡏࡃࡏࠤࡘࡖࡏࡓࡖࠪལ"): Variable4 (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡓࡱࡱࡵࡸࠬཤ"),
Variable4 (u"ࠧࡇࡋࡏࡑࡇࡕࡘࠡࡒࡕࡉࡒࡏࡕࡎࠩཥ"):Variable4 (u"ࠨࡈ࡬ࡰࡲࡨ࡯ࡹࠩས"),
Variable4 (u"ࠩࡐ࡭ࡳ࡯ࠠࡎ࡫ࡱ࡭ࠬཧ"):Variable4 (u"ࠪࡑ࡮ࡴࡩ࡮࡫ࡱ࡭࠰࠭ཨ"),
Variable4 (u"ࠫࡊ࡙ࡋࡂࠢࡗ࡚ࠬཀྵ"):Variable4 (u"ࠬࡋࡳ࡬ࡣࠣࡘ࡛࠭ཪ"),
Variable4 (u"࠭ࡐࡰ࡮ࡲࠤ࡙࡜ࠧཫ"):Variable4 (u"ࠧࡑࡱ࡯ࡳ࡚ࠥࡖࠨཬ"),
Variable4 (u"ࠨࡇࡖࡏࡆࠦࡐࡂࡔࡗ࡝ࠦ࠭཭"):Variable4 (u"ࠩࡈࡷࡰࡧࠠࡑࡣࡵࡸࠬ཮"),
Variable4 (u"ࠪࡇ࡟࡝ࡏࡓࡍࡄࠤࡕࡕࡌࡔࡍࡌࡉࠥࡘࡁࡅࡋࡒࠤࡑࡏࡖࡆࠩ཯"):Variable4 (u"ࠫࡈࢀࡷࣴࡴ࡮ࡥࠥࡖ࡯࡭ࡵ࡮࡭ࡪࠦࡒࡢࡦ࡬ࡳࠬ཰"),
Variable4 (u"ࠬ࡜ࡏཱ࡙ࠩ"):Variable4 (u"࠭ࡖࡐི࡚ࠪ"),
Variable4 (u"ࠧࡕ࡮ࡦࠤࡍࡊཱིࠧ"):Variable4 (u"ࠨࡖࡏࡇུࠬ"),
Variable4 (u"ࠩࡦࡥࡳࡧ࡬ࠡࡨ࡬ࡰࡲཱུ࠭"):Variable4 (u"ࠪࡇࡦࡴࡡ࡭࠭ࠣࡊ࡮ࡲ࡭ࠨྲྀ"),
Variable4 (u"ࠫࡈࡕࡍࡆࡆ࡜ࠤࡈࡋࡎࡕࡔࡄࡐࠬཷ"):Variable4 (u"ࠬࡉ࡯࡮ࡧࡧࡽࠥࡉࡥ࡯ࡶࡵࡥࡱ࠭ླྀ"),
Variable4 (u"࠭ࡐࡐࡎࡖࡅ࡙ࠦ࠲ࡉࡆࠪཹ"):Variable4 (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠ࠳ེࠩ"),
Variable4 (u"ࠨࡒࡒࡐࡘࡇࡔࠡࡕࡓࡓࡗ࡚ࠠࡉࡆཻࠪ"):Variable4 (u"ࠩࡓࡳࡱࡹࡡࡵࠢࡖࡴࡴࡸࡴࠨོ"),
Variable4 (u"ࠪࡘ࡛ࡖࠠࡉࡆཽࠪ"):Variable4 (u"࡙ࠫ࡜ࡐࠡࡊࡇࠫཾ"),
Variable4 (u"ࠬࡊࡩࡴࡥࡲࡺࡪࡸࡹࠡࡅ࡫ࡥࡳࡴࡥ࡭ࠩཿ"):Variable4 (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ྀࠪ")
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡵࡸ࡬ࡨཱྀࠬ")),Variable4 (u"ࠨࠩྂ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨྃ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[Variable4 (u"ࠪࡸࡻ࡯ࡤࠨ྄")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies={}):
    if not header:
        header = {Variable4 (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ྅"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=10)
        header[Variable4 (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ྆")]=response.info()[Variable4 (u"࠭ࡓࡦࡶ࠰ࡇࡴࡵ࡫ࡪࡧࠪ྇")]
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        req = urllib2.Request(url,data,headers=header)
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(url=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡶ࡬ࡺ࡮࠴ࡰ࡭࠱ࡤࡴ࡮࠴ࡰࡩࡲࠪྈ"),data=Variable4 (u"ࠨࡣࡦࡸ࡮ࡵ࡮࠾ࡉࡨࡸࡘࡺࡲࡦࡣࡰࡷࠬྉ"))
    content = json.loads(content) if content else {}
    content = content.get(Variable4 (u"ࠩ࡫ࡸࡲࡲࠧྊ"),Variable4 (u"ࠪࠫྋ"))
    l1llll11lll11l111_tv_ = re.compile(Variable4 (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩྌ"),re.DOTALL).findall(content)
    title = re.compile(Variable4 (u"ࠬࡂࡨ࠶ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠹ࡃ࠭ྍ"),re.DOTALL).findall(content)
    href = re.compile(Variable4 (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨྎ"),re.DOTALL).findall(content)
    out=[]
    for h,t,i in zip(href,title,l1llll11lll11l111_tv_):
        h = urlparse.urljoin(l1llll111ll11l111_tv_,h)
        t = t.strip()
        i = urlparse.urljoin(l1llll111ll11l111_tv_,i)
        out.append(l1lll1l1l1l11l111_tv_({Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ྏ"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ྐ"):t,Variable4 (u"ࠩ࡬ࡱ࡬࠭ྑ"):i,Variable4 (u"ࠪࡹࡷࡲࠧྒ"):h,Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪྒྷ"):Variable4 (u"ࠬ࠭ྔ"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ྕ"):Variable4 (u"ࠧࠨྖ")}))
    if addheader and out:
        t=Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡪࡶ࡬ࡺ࡮࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨྗ") %time.strftime(Variable4 (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ྘"))
        out.insert(0,{Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩྙ"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩྚ"):Variable4 (u"ࠬ࠭ྛ"),Variable4 (u"࠭ࡩ࡮ࡩࠪྜ"):Variable4 (u"ࠧࠨྜྷ"),Variable4 (u"ࠨࡷࡵࡰࠬྞ"):Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡸ࡮ࡼࡩ࠯ࡲ࡯࠳ࠬྟ"),Variable4 (u"ࠪ࡫ࡷࡵࡵࡱࠩྠ"):Variable4 (u"ࠫࠬྡ"),Variable4 (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬྡྷ"):Variable4 (u"࠭ࠧྣ")})
    return out
    content = l111111l11l111_tv_(url=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡶ࡬ࡺ࡮࠴ࡰ࡭࠱ࡤࡴ࡮࠴ࡰࡩࡲࠪྤ"),data=Variable4 (u"ࠨࡵࡷࡶࡪࡧ࡭࠾ࠧࡶࠪࡦࡩࡴࡪࡱࡱࡁࡌ࡫ࡴࡔࡶࡵࡩࡦࡳࠧྥ"))
def l111l1lll11l111_tv_(url=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡸ࡮ࡼࡩ࠯ࡲ࡯࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠲ࡺࡥ࡭ࡧࡺ࡭ࡿࡿࡪ࡯ࡻ࠲ࡈ࡮ࡹࡣࡰࡸࡨࡶࡾࡥࡃࡩࡣࡱࡲࡪࡲࠧྦ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠪ࡭ࡹ࡯ࡶࡪ࠰ࡳࡰࠬྦྷ") in url:
        content = l111111l11l111_tv_(url)
        l11ll11ll11l111_tv_=re.compile(Variable4 (u"ࠫࡵࡲࡡࡺࡏ࠶࡙࠽ࡨࡹࡈࡴ࡬ࡲࡩࡖ࡬ࡢࡻࡨࡶࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨ࡜ࠪࠩྨ")).findall(content)
        if l11ll11ll11l111_tv_:
            if l11ll11ll11l111_tv_[0].startswith(Variable4 (u"ࠬ࡮ࡴࡵࡲࠪྩ")):
                l1lll1ll11l11l111_tv_.append({Variable4 (u"࠭ࡵࡳ࡮ࠪྪ"):l11ll11ll11l111_tv_[0],Variable4 (u"ࠧࡵ࡫ࡷ࡭ࡱ࡫ࠧྫ"):Variable4 (u"ࠨࡎ࡬ࡺࡪ࠭ྫྷ"),Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫྭ"):1})
            else:
                l1l1ll1ll1l11l111_tv_=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡹ࡯ࡶࡪ࠰ࡳࡰ࠴ࡰࡳ࠰࡬ࡺࡴࡱࡧࡹࡦࡴ࠰࠻࠳࠶࠮࠴࠱࡭ࡻࡵࡲࡡࡺࡧࡵ࠲࡫ࡲࡡࡴࡪ࠱ࡷࡼ࡬ࠧྮ")
                l1l111l1l1l11l111_tv_ = l11ll11ll11l111_tv_[0].replace(Variable4 (u"ࠫ࡫ࡲࡶ࠻ࠩྯ"),Variable4 (u"ࠬ࠭ྰ")) + Variable4 (u"࠭ࠠࡴࡹࡩ࡙ࡷࡲ࠽ࠨྱ")+l1l1ll1ll1l11l111_tv_ + Variable4 (u"ࠧࠡࡵࡺࡪ࡛࡬ࡹ࠾࠳ࠣࡰ࡮ࡼࡥ࠾࠳ࠣࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩྲ")+url
                l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠨࡷࡵࡰࠬླ"):l1l111l1l1l11l111_tv_,Variable4 (u"ࠩࡷ࡭ࡹ࡯࡬ࡦࠩྴ"):Variable4 (u"ࠪࡐ࡮ࡼࡥࠨྵ"),Variable4 (u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭ྶ"):1})
        else:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠬࡳࡳࡨࠩྷ"):Variable4 (u"࡚࠭ࡣࡻࡷࠤࡼ࡯ࡥ࡭ࡷࠣࡨࡦࡸ࡭ࡰࡹࡼࡧ࡭ࠦࡵॽࡻࡷ࡯ࡴࡽ࡮ࡪ࡭ࣶࡻࠥࡱ࡯ࡳࡼࡼࡷࡹࡧࠠࡻࠢࡳࡳࡷࡺࡡ࡭ࡷࠤ࠲ࠬྸ")}]
    return l1lll1ll11l11l111_tv_
def l111l1lll11l111_tv_(url=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡶ࡬ࡺ࡮࠴ࡰ࡭࠱ࡲ࡫ࡱࡧࡤࡢ࡬࠱࡬ࡹࡳ࡬ࡀ࡭ࡤࡲࡦࡲ࠽ࡱࡱ࡯ࡷࡦࡺࡰ࡭ࡣࡼࠫྐྵ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠨ࡫ࡷ࡭ࡻ࡯࠮ࡱ࡮ࠪྺ") in url:
        ch= url.split(Variable4 (u"ࠩࡀࠫྻ"))[-1]
        content = l111111l11l111_tv_(url=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡹ࡯ࡶࡪ࠰ࡳࡰ࠴ࡧࡰࡪ࠰ࡳ࡬ࡵ࠭ྼ"),data=Variable4 (u"ࠫࡸࡺࡲࡦࡣࡰࡁࠪࡹࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡈࡧࡷࡗࡹࡸࡥࡢ࡯ࠪ྽")%ch)
        content = json.loads(content) if content else {}
        l11ll11ll11l111_tv_ = content.get(Variable4 (u"ࠬࡻࡲ࡭ࠩ྾"),Variable4 (u"࠭ࠧ྿"))
        if l11ll11ll11l111_tv_:
            l11ll11ll11l111_tv_ = l11ll11ll11l111_tv_.replace(Variable4 (u"ࠧ࠻࠺࠳ࠫ࿀"),Variable4 (u"ࠨ࠼࠻࠵ࠬ࿁"))
            l11ll11ll11l111_tv_ += Variable4 (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠪ࿂")%l1lll1l1lll11l111_tv_
            if l11ll11ll11l111_tv_:
                l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠪࡹࡷࡲࠧ࿃"):l11ll11ll11l111_tv_,Variable4 (u"ࠫࡹ࡯ࡴࡪ࡮ࡨࠫ࿄"):content.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ࿅"),ch),Variable4 (u"࠭ࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ࿆"):1})
            else:
                l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠧ࡮ࡵࡪࠫ࿇"):Variable4 (u"ࠨࡒࡵࡳࡧࡲࡥ࡮ࠢࡽࠤࡴࡩࡺࡺࡶࡤࡲ࡮࡫࡭ࠡॼࡵࣷࡩैࡡࠡ࡭ࡤࡲࡦैࡵ࠯ࠩ࿈")}]
        else:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠩࡰࡷ࡬࠭࿉"):Variable4 (u"ࠪࡔࡷࡵࡢ࡭ࡧࡰࠤࡿࠦ࡯ࡤࡼࡼࡸࡦࡴࡩࡦ࡯ࠣॾࡷࣹࡤृࡣࠣ࡯ࡦࡴࡡृࡷ࠱ࠫ࿊")}]
    return l1lll1ll11l11l111_tv_
