# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,time
import time,json,base64
import cookielib,os
import aes
l1llll111ll11l111_tv_=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡹࡰࡰࡴࡷ࠷࠻࠻࠮࡭࡫ࡹࡩ࠴ࡶ࡬࠰࡯ࡤ࡭ࡳ࠭᠘")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨ᠙")
__all__=[Variable4 (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨ᠚"),Variable4 (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡗ࡫ࡧࡩࡴ࠭᠛"),Variable4 (u"ࠬ࡭ࡥࡵࡕࡷࡶࡪࡧ࡭ࡴࠩ᠜")]
def l1lll1l1l1l11l111_tv_(item):
    return(item)
def l111111l11l111_tv_(url,data=None,header={},l1llll1l1l11l111_tv_=True):
    if l1llll1l1l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ᠝"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠧࠨ᠞")
    return l11ll11ll11l111_tv_
def l1l11l1l11l111_tv_(url,data=None,header={},l1llll1l1l11l111_tv_=True):
    l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
    if l1llll1l1l11l111_tv_:
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᠟"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠩࠪᠠ")
    c = Variable4 (u"ࠪࠫᠡ").join([Variable4 (u"ࠫࠪࡹ࠽ࠦࡵࠪᠢ")%(c.name,c.value) for c in l1llll1ll1l11l111_tv_]) if l1llll1ll1l11l111_tv_ else Variable4 (u"ࠬ࠭ᠣ")
    return l11ll11ll11l111_tv_,c
def l11l11l1l11l111_tv_(addheader=False):
    ret=Variable4 (u"࠭ࠧᠤ")
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    wrapper = re.compile(Variable4 (u"ࠧࠩࡪࡷࡸࡵࡡ࡞ࠣ࡟࠮࠳ࡦࡪࡶࡦࡴࡷ࡭ࡸ࡫࡭ࡦࡰࡷ࠲࡯ࡹ࡜ࡀ࡞ࡧ࠯࠮࠭ᠥ")).findall(content)
    l1ll1l111lll11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾ࡶࡧࡷ࡯ࡰࡵࠢࡷࡽࡵ࡫࠽ࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠤࡸࡸࡣ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࠶࠴࡭ࡦࡦ࡬ࡥࡳ࡫ࡴࡸࡱࡵ࡯࡮ࡴࡴࡦࡴࡱࡥࡹ࡯࡯࡯ࡣ࡯࠲ࡨࡵ࡭࠰࡬ࡶ࠳ࡡࡽࠫ࠯࡬ࡶ࠭ࠧ࠭ᠦ")).findall(content)
    for wrapper in l1ll1l111lll11l111_tv_:
        l1ll1l1111ll11l111_tv_ = l111111l11l111_tv_(wrapper)
        content=l1ll11l1llll11l111_tv_().l1ll1l1ll1ll11l111_tv_(l1ll1l1111ll11l111_tv_)
        ret = content
        ret = re.compile(Variable4 (u"ࠩࡵࡩࡹࡻࡲ࡯ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪᠧ")).findall(content)
        if ret:
            ret = ret[0]
            print Variable4 (u"ࠪ࡯ࡪࡿࠠࠦࡵࠪᠨ")%ret
            break
    url=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡵࡳࡳࡷࡺ࠳࠷࠷࠱ࡰ࡮ࡼࡥ࠰ࡲ࡯࠳ࡪࡼࡥ࡯ࡶࡶ࠳࠲࠵࠱࠰࠯࠲࠱࠴࠷࠲࠱ࠩᠩ")
    content = l111111l11l111_tv_(url)
    ids = [(a.start(), a.end()) for a in re.finditer(Variable4 (u"ࠬࡵ࡮ࡄ࡮࡬ࡧࡰࡃࠧᠪ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        l11ll1ll1ll11l111_tv_=re.compile(Variable4 (u"࠭࡜ࠩࠤࠫ࡟ࡣࠨ࡝ࠬࠫࠥ࠰ࠥࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠢ࠭ࠢࠥ࡟ࡣࠨ࡝ࠬࠤ࠯ࠤ࠶ࡢࠩࠨᠫ")).findall(l1l1lll1lll11l111_tv_)
        l1ll11lll1ll11l111_tv_=re.compile(Variable4 (u"ࠧ࠽࡫ࡰ࡫ࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᠬ")).findall(l1l1lll1lll11l111_tv_)
        t=re.compile(Variable4 (u"ࠨࡀࠫ࡟ࡣࡂ࡝ࠬࠫ࠿ࠫᠭ")).findall(l1l1lll1lll11l111_tv_)
        l1ll11llllll11l111_tv_ = Variable4 (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡨࡴࡨࡩࡳࡣ⠢࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᠮ") if l1l1lll1lll11l111_tv_.find(Variable4 (u"ࠪ࠳࡮ࡳࡡࡨࡧࡶ࠳ࡹࡿࡰࡦࡵ࠲ࡨࡴࡺ࠭ࡨࡴࡨࡩࡳ࠳ࡢࡪࡩ࠱ࡴࡳ࡭ࠧᠯ"))>0 else Variable4 (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࠬ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᠰ")
        if l11ll1ll1ll11l111_tv_ and l1ll11lll1ll11l111_tv_:
            event,l1ll1l1l1l1l11l111_tv_=l11ll1ll1ll11l111_tv_[0]
            url = Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡶࡴࡴࡸࡴ࠴࠸࠸࠲ࡱ࡯ࡶࡦ࠱ࡨࡲ࠴ࡲࡩ࡯࡭ࡶ࠳ࠪࡹ࠯࠲ࡂࠨࡷࠬᠱ")%(event.split(Variable4 (u"࠭࡟ࠨᠲ"))[-1],ret)
            l1ll1l11ll1l11l111_tv_,l1ll11llll1l11l111_tv_= t[:2]
            l1ll11ll111l11l111_tv_ = t[-1]
            quality =  t[-2].replace(Variable4 (u"ࠧࠧࡰࡥࡷࡵࡁࠧᠳ"),Variable4 (u"ࠨ࠮ࠪᠴ")) if len(t)==4 else Variable4 (u"ࠩࠪᠵ")
            title = Variable4 (u"ࠪࠩࡸࠫࡳ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠪࡹࠧᠶ")%(l1ll11llllll11l111_tv_,l1ll1l11ll1l11l111_tv_,l1ll11llll1l11l111_tv_,l1ll11lll1ll11l111_tv_[0])
            code=quality+l1ll11ll111l11l111_tv_
            out.append({Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᠷ"):title,Variable4 (u"ࠬࡺࡶࡪࡦࠪᠸ"):Variable4 (u"࠭ࠧᠹ"),Variable4 (u"ࠧࡶࡴ࡯ࠫᠺ"):url,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧᠻ"):Variable4 (u"ࠩࠪᠼ"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪᠽ"):Variable4 (u"ࠫࠬᠾ"),Variable4 (u"ࠬࡩ࡯ࡥࡧࠪᠿ"):code})
    return out
def l1llll1ll11l111_tv_(url):
    l1lll1lll1l11l111_tv_,ret=url.split(Variable4 (u"࠭ࡀࠨᡀ"))
    content = l111111l11l111_tv_(l1lll1lll1l11l111_tv_)
    l1ll1l1ll11l11l111_tv_=re.compile(Variable4 (u"ࠧ࠽ࡵࡳࡥࡳࠦࡩࡥ࠿࡞ࠦࡡ࠭࡝ࡴࡲࡤࡲࡤࡲࡩ࡯࡭ࡢࡰ࡮ࡴ࡫ࡴ࡝࡟ࠫࠧࡣࠠࡰࡰࡆࡰ࡮ࡩ࡫࠾ࠤ࡟ࡻ࠰ࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪᡁ")).findall(content)
    out=[]
    for i, s in enumerate(l1ll1l1ll11l11l111_tv_):
        l1ll1l11l1ll11l111_tv_=json.loads(base64.b64decode(s))
        ciphertext = Variable4 (u"ࠨࡕࡤࡰࡹ࡫ࡤࡠࡡࠪᡂ") + l1ll1l11l1ll11l111_tv_[Variable4 (u"ࠩࡶࠫᡃ")].decode(Variable4 (u"ࠪ࡬ࡪࡾࠧᡄ")) + base64.b64decode(l1ll1l11l1ll11l111_tv_[Variable4 (u"ࠫࡨࡺࠧᡅ")])
        src=aes.decrypt(ret,base64.b64encode(ciphertext))
        src=src.strip(Variable4 (u"ࠬࠨࠧᡆ")).replace(Variable4 (u"࠭࡜࡝ࠩᡇ"),Variable4 (u"ࠧࠨᡈ"))
        title = Variable4 (u"ࠨࡎ࡬ࡲࡰࠦࠥࡥࠩᡉ")%(i+1)
        out.append({Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᡊ"):title,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨᡋ"):title,Variable4 (u"ࠫࡰ࡫ࡹࠨᡌ"):ret,Variable4 (u"ࠬࡻࡲ࡭ࠩᡍ"):src,Variable4 (u"࠭ࡲࡦࡨࡸࡶࡱ࠭ᡎ"):l1lll1lll1l11l111_tv_,Variable4 (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᡏ"):Variable4 (u"ࠨࠩᡐ")})
    return out
def l111l1lll11l111_tv_(item):
    content = l111111l11l111_tv_(item.get(Variable4 (u"ࠩࡸࡶࡱ࠭ᡑ")),l1llll1l1l11l111_tv_=True)
    l1ll1ll111ll11l111_tv_ =Variable4 (u"ࠪࡏࡌ࡮࠰ࡥࡊࡄ࠺ࡑࡿ࠹࠴ࡦ࠶ࡧࡺ࡝࠱࠶ࡥࡏࡰ࠵ࡸࡌ࡯ࡄ࠶ࡐࡾ࡭࠯ࡊࡕ࡜࡮ࡐ࡜ࡴࡦࡋ࡯࠴ࡷࡑࡑ࠾࠿ࠪᡒ")
    l11ll1ll1ll11l111_tv_=re.compile(l1ll1ll111ll11l111_tv_.decode(Variable4 (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫᡓ")), re.IGNORECASE + re.DOTALL + re.MULTILINE + re.UNICODE).findall(content)
    l1ll1l1lllll11l111_tv_=Variable4 (u"ࠬࡐࡩࡎ࠿ࠪᡔ")
    l11ll11ll11l111_tv_ = [x for x in l11ll1ll1ll11l111_tv_ if l1ll1l1lllll11l111_tv_.decode(Variable4 (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ᡕ")) in x]
    l1ll1ll1111l11l111_tv_ = Variable4 (u"ࠧࡋ࡫ࡐࡳ࡝ࡍࡑࡳࡍࡗࡷࡂ࠭ᡖ")
    if l11ll11ll11l111_tv_:
        l11ll11ll11l111_tv_=re.sub(l1ll1ll1111l11l111_tv_.decode(Variable4 (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨᡗ")), lambda x: chr(int(x.group(1))), l11ll11ll11l111_tv_[0])
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᡘ"):l1lll1l1lll11l111_tv_,
                  Variable4 (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᡙ"):item.get(Variable4 (u"ࠫࡺࡸ࡬ࠨᡚ"))}
        data = l111111l11l111_tv_(l11ll11ll11l111_tv_,header=header,l1llll1l1l11l111_tv_=True)
        f=re.compile(Variable4 (u"ࠬ࠴ࠪࡀࡰࡤࡱࡪࡃࠢࡧࠤ࡟ࡷ࠯ࡼࡡ࡭ࡷࡨࡁࡠࠨ࡜ࠨ࡟ࠫ࡟ࡣࠨ࡜ࠨ࡟࠮࠭ࡠࠨ࡜ࠨ࡟ࠪᡛ")).findall(data)
        d=re.compile(Variable4 (u"࠭࠮ࠫࡁࡱࡥࡲ࡫࠽ࠣࡦࠥࡠࡸ࠰ࡶࡢ࡮ࡸࡩࡂࡡࠢ࡝ࠩࡠࠬࡠࡤࠢ࡝ࠩࡠ࠯࠮ࡡࠢ࡝ࠩࡠࠫᡜ")).findall(data)
        r=re.compile(Variable4 (u"ࠧ࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࡵࠦࡡࡹࠪࡷࡣ࡯ࡹࡪࡃ࡛ࠣ࡞ࠪࡡ࠭ࡡ࡞ࠣ࡞ࠪࡡ࠰࠯࡛ࠣ࡞ࠪࡡࠬᡝ")).findall(data)
        action=re.compile(Variable4 (u"ࠨ࡝࡟ࠫࠧࡣࡡࡤࡶ࡬ࡳࡳࡡ࡜ࠨࠤࡠ࡟࠱ࡢࡳ࡞ࠬ࡞ࡠࠬࠨ࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࡠࠬࠨ࡝ࠨᡞ")).findall(data)
        l1ll111ll1l11l111_tv_=re.compile(Variable4 (u"ࠩࡶࡶࡨࡃ࡛࡝ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠬࠨ࡝ࠨᡟ")).findall(data)
        if f and r and d and action:
            l11llll1l1l11l111_tv_=urllib.urlencode({Variable4 (u"ࠪࡨࠬᡠ"):d[0],Variable4 (u"ࠫ࡫࠭ᡡ"):f[0],Variable4 (u"ࠬࡸࠧᡢ"):r[0]})
            l1lllll1ll1l11l111_tv_,c= l1l11l1l11l111_tv_(action[0],l11llll1l1l11l111_tv_,header=header,l1llll1l1l11l111_tv_=True)
            l11ll11ll11l111_tv_=re.compile(Variable4 (u"࠭࡜ࠩ࡝࡟ࠫࠧࡣ࡛࡟ࠤ࡟ࠫࡢ࠱࡛࡝ࠩࠥࡡ࠱࡛ࠦ࡝ࠩࠥࡡࡠࡤࠢ࡝ࠩࡠ࠯ࡠࡢࠧࠣ࡟࠯ࠤࡠࡢࠧࠣ࡟ࠫ࡟ࡣࠨ࡜ࠨ࡟࠮࠭ࡠࡢࠧࠣ࡟࠯ࠤ࠶ࡢࠩࠨᡣ")).findall(l1lllll1ll1l11l111_tv_)
            l1ll1l11l1ll11l111_tv_=json.loads(base64.b64decode(l11ll11ll11l111_tv_[0]))
            ciphertext = Variable4 (u"ࠧࡔࡣ࡯ࡸࡪࡪ࡟ࡠࠩᡤ") + l1ll1l11l1ll11l111_tv_[Variable4 (u"ࠨࡵࠪᡥ")].decode(Variable4 (u"ࠩ࡫ࡩࡽ࠭ᡦ")) + base64.b64decode(l1ll1l11l1ll11l111_tv_[Variable4 (u"ࠪࡧࡹ࠭ᡧ")])
            src=aes.decrypt(item.get(Variable4 (u"ࠫࡰ࡫ࡹࠨᡨ")),base64.b64encode(ciphertext))
            src=src.replace(Variable4 (u"ࠬࠨࠧᡩ"),Variable4 (u"࠭ࠧᡪ")).replace(Variable4 (u"ࠧ࡝࡞ࠪᡫ"),Variable4 (u"ࠨࠩᡬ")).encode(Variable4 (u"ࠩࡸࡸ࡫࠳࠸ࠨᡭ"))
            data=l1l11l1l11l111_tv_(l1ll111ll1l11l111_tv_[-1],header=header,l1llll1l1l11l111_tv_=True) if l1ll111ll1l11l111_tv_ else Variable4 (u"ࠪࠫᡮ"),Variable4 (u"ࠫࠬᡯ")
            l1l1l11l11l111_tv_ =  re.compile(Variable4 (u"ࠬࡻࡲ࡭࠼࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠࠫᡰ")).findall(str(data[0])) if data else Variable4 (u"࠭ࠧᡱ")
            l1l1l11l11l111_tv_ = l1l1l11l11l111_tv_[0] if l1l1l11l11l111_tv_ else Variable4 (u"ࠧࠨᡲ")
            l1l11l1l11l111_tv_(l1l1l11l11l111_tv_)
            a,c=l1l11l1l11l111_tv_(src,header=header,l1llll1l1l11l111_tv_=True)
            if src.startswith(Variable4 (u"ࠨࡪࡷࡸࡵ࠭ᡳ")):
                href =src+Variable4 (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠪࡹࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠪࡹ࡙ࠦ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࡀࡗ࡭ࡵࡣ࡬ࡹࡤࡺࡪࡌ࡬ࡢࡵ࡫࠳࠷࠸࠮࠱࠰࠳࠲࠷࠶࠹ࠨᡴ")%(urllib.quote(action[0]),l1lll1l1lll11l111_tv_)
                print href
                return href
            else:
                href=aes.decode_hls(src)
                if href:
                    href +=Variable4 (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂࠫࡳࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠫࡳ࡚ࠧ࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࡁࡘ࡮࡯ࡤ࡭ࡺࡥࡻ࡫ࡆ࡭ࡣࡶ࡬࠴࠸࠲࠯࠲࠱࠴࠳࠸࠰࠺ࠩᡵ")%(urllib.quote(r[0]),l1lll1l1lll11l111_tv_)
                    return href
    return Variable4 (u"ࠫࠬᡶ")
def l11l1lll11l111_tv_(url,data=None,header={},l1llll1l1l11l111_tv_=True):
    l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
    if l1llll1l1l11l111_tv_:
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᡷ"):l1lll1l1lll11l111_tv_}
    l1ll1l11l11l11l111_tv_={}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        for k in response.headers.keys(): l1ll1l11l11l11l111_tv_[k]=response.headers[k]
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"࠭ࠧᡸ")
    c = Variable4 (u"ࠧࠨ᡹").join([Variable4 (u"ࠨࠧࡶࡁࠪࡹࠧ᡺")%(c.name,c.value) for c in l1llll1ll1l11l111_tv_]) if l1llll1ll1l11l111_tv_ else Variable4 (u"ࠩࠪ᡻")
    return l11ll11ll11l111_tv_,l1ll1l11l11l11l111_tv_
class l1ll11l1llll11l111_tv_:
    def l1ll1l1ll1ll11l111_tv_(self, data):
        try:
            l1ll111ll1ll11l111_tv_=data
            l1ll11ll11ll11l111_tv_ = Variable4 (u"ࠪࡩࡻࡧ࡬࡝࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡࡢࠨࡸ࠮࡬࠰ࡸ࠲ࡥ࡝࡞ࠬ࠲࠯ࡅࡽ࡝࡞ࠫࠬ࠳࠰࠿ࠪ࡞࡟࠭ࠬ᡼")
            l1ll11l111ll11l111_tv_=re.compile(l1ll11ll11ll11l111_tv_).findall(l1ll111ll1ll11l111_tv_)
            for l1ll1l1l11ll11l111_tv_ in l1ll11l111ll11l111_tv_:
                l1ll1l1l111l11l111_tv_=self.l1ll1l1l1lll11l111_tv_(l1ll1l1l11ll11l111_tv_)
                l1ll111ll1ll11l111_tv_=l1ll111ll1ll11l111_tv_.replace(l1ll1l1l11ll11l111_tv_,l1ll1l1l111l11l111_tv_)
            return re.sub(re.compile(Variable4 (u"ࠦࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡷ࠭࡫࠯ࡷ࠱࡫࡜ࠪ࠰࠭ࡃ࡯ࡵࡩ࡯࡞ࠫࠫࠬࡢࠩ࠼ࡿࠥ᡽"), re.DOTALL), Variable4 (u"ࠧࠨ᡾"), l1ll111ll1ll11l111_tv_, count=1)
        except:
            traceback.l1ll11l1ll1l11l111_tv_(file=sys.stdout)
            return data
    def l1ll11l1111l11l111_tv_(self, data):
        return Variable4 (u"࠭ࡷ࠭࡫࠯ࡷ࠱࡫ࠧ᡿") in data
    def l1ll1l1l1lll11l111_tv_(self, l1ll1l111l1l11l111_tv_):
        l1ll11ll1l1l11l111_tv_=Variable4 (u"ࠢࠣᢀ")
        try:
            l1ll11l1l1ll11l111_tv_=Variable4 (u"ࠣࡹ࠯࡭࠱ࡹࠬࡦ࠿ࠫࠦᢁ")+l1ll1l111l1l11l111_tv_+Variable4 (u"ࠩࠬࠫᢂ")
            exec (l1ll11l1l1ll11l111_tv_)
            l1ll11ll1l1l11l111_tv_=self.__1ll1l11111l11l111_tv_(w,i,s,e)
        except: traceback.l1ll11l1ll1l11l111_tv_(file=sys.stdout)
        return l1ll11ll1l1l11l111_tv_
    def __1ll1l11111l11l111_tv_( self,w, i, s, e):
        l1ll1l1lll1l11l111_tv_ = 0;
        l1ll11ll1lll11l111_tv_ = 0;
        l1ll11lll11l11l111_tv_ = 0;
        l1ll11l11l1l11l111_tv_ = [];
        l1ll111lllll11l111_tv_ = [];
        while True:
            if (l1ll1l1lll1l11l111_tv_ < 5):
                l1ll111lllll11l111_tv_.append(w[l1ll1l1lll1l11l111_tv_])
            elif (l1ll1l1lll1l11l111_tv_ < len(w)):
                l1ll11l11l1l11l111_tv_.append(w[l1ll1l1lll1l11l111_tv_]);
            l1ll1l1lll1l11l111_tv_+=1;
            if (l1ll11ll1lll11l111_tv_ < 5):
                l1ll111lllll11l111_tv_.append(i[l1ll11ll1lll11l111_tv_])
            elif (l1ll11ll1lll11l111_tv_ < len(i)):
                l1ll11l11l1l11l111_tv_.append(i[l1ll11ll1lll11l111_tv_])
            l1ll11ll1lll11l111_tv_+=1;
            if (l1ll11lll11l11l111_tv_ < 5):
                l1ll111lllll11l111_tv_.append(s[l1ll11lll11l11l111_tv_])
            elif (l1ll11lll11l11l111_tv_ < len(s)):
                l1ll11l11l1l11l111_tv_.append(s[l1ll11lll11l11l111_tv_]);
            l1ll11lll11l11l111_tv_+=1;
            if (len(w) + len(i) + len(s) + len(e) == len(l1ll11l11l1l11l111_tv_) + len(l1ll111lllll11l111_tv_) + len(e)):
                break;
        l1ll11l1l11l11l111_tv_ = Variable4 (u"ࠪࠫᢃ").join(l1ll11l11l1l11l111_tv_)
        l1ll111lll1l11l111_tv_ = Variable4 (u"ࠫࠬᢄ").join(l1ll111lllll11l111_tv_)
        l1ll11ll1lll11l111_tv_ = 0;
        l1ll11l11lll11l111_tv_ = [];
        for l1ll1l1lll1l11l111_tv_ in range(0,len(l1ll11l11l1l11l111_tv_),2):
            l1ll1l11llll11l111_tv_ = -1;
            if ( ord(l1ll111lll1l11l111_tv_[l1ll11ll1lll11l111_tv_]) % 2):
                l1ll1l11llll11l111_tv_ = 1;
            l1ll11l11lll11l111_tv_.append(chr(    int(l1ll11l1l11l11l111_tv_[l1ll1l1lll1l11l111_tv_: l1ll1l1lll1l11l111_tv_+2], 36) - l1ll1l11llll11l111_tv_));
            l1ll11ll1lll11l111_tv_+=1;
            if (l1ll11ll1lll11l111_tv_ >= len(l1ll111lllll11l111_tv_)):
                l1ll11ll1lll11l111_tv_ = 0;
        ret=Variable4 (u"ࠬ࠭ᢅ").join(l1ll11l11lll11l111_tv_)
        if Variable4 (u"࠭ࡥࡷࡣ࡯ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠮ࡷ࠭࡫࠯ࡷ࠱࡫ࠩࠨᢆ") in ret:
            ret=re.compile(Variable4 (u"ࠧࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡺ࠰࡮࠲ࡳ࠭ࡧ࡟࠭࠳࠰ࡽ࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪᢇ")).findall(ret)[0]
            return self.l1ll1l1l1lll11l111_tv_(ret)
        else:
            return ret
