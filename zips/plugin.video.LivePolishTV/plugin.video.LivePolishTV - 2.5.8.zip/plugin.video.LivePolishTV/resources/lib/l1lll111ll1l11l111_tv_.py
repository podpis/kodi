# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡰࡴࡣ࠰ࡸࡻ࠴ࡢ࡭ࡱࡪࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴࠭ᕚ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᕛ")
__all__=[Variable4 (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᕜ"),Variable4 (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱ࡜ࡩࡥࡧࡲࠫᕝ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᕞ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠫࠬᕟ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃ࠭ᕠ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᕡ"):title.strip(),Variable4 (u"ࠧࡵࡸ࡬ࡨࠬᕢ"):title.strip(),Variable4 (u"ࠨ࡫ࡰ࡫ࠬᕣ"):Variable4 (u"ࠩࠪᕤ"),Variable4 (u"ࠪࡹࡷࡲࠧᕥ"):href,Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᕦ"):Variable4 (u"ࠬ࠭ᕧ"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ᕨ"):Variable4 (u"ࠧࠨᕩ")})
    if addheader and len(out):
        t=Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡱࡵࡤ࠱ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᕪ") %time.strftime(Variable4 (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᕫ"))
        out.insert(0,{Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᕬ"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩᕭ"):Variable4 (u"ࠬ࠭ᕮ"),Variable4 (u"࠭ࡩ࡮ࡩࠪᕯ"):Variable4 (u"ࠧࠨᕰ"),Variable4 (u"ࠨࡷࡵࡰࠬᕱ"):l1llll111ll11l111_tv_,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨᕲ"):Variable4 (u"ࠪࠫᕳ"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᕴ"):Variable4 (u"ࠬ࠭ᕵ")})
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡰࡴࡣ࠰ࡸࡻ࠴ࡢ࡭ࡱࡪࡷࡵࡵࡴ࠯ࡤࡨ࠳ࡵ࠵ࡴࡷࡲ࠰࠵࠳࡮ࡴ࡮࡮ࠪᕶ")):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠧࡱࡵࡤ࠱ࡹࡼ࠮ࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩᕷ") in url:
        content = l111111l11l111_tv_(url)
        l1111l111ll11l111_tv_ = re.compile(Variable4 (u"ࠨࡦࡲࡧࡺࡳࡥ࡯ࡶ࠱ࡻࡷ࡯ࡴࡦ࡞ࠫࡹࡳ࡫ࡳࡤࡣࡳࡩࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࡞ࠬࠫᕸ")).findall(content)
        l1111l111ll11l111_tv_ = urllib.unquote(l1111l111ll11l111_tv_[0]) if l1111l111ll11l111_tv_ else Variable4 (u"ࠩࠪᕹ")
        src = re.compile(Variable4 (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᕺ"),re.IGNORECASE).findall(l1111l111ll11l111_tv_)
        if src:
            if src[0].startswith(Variable4 (u"ࠫ࡭ࡺࡴࡱࠩᕻ")):
                data = l111111l11l111_tv_(src[0])
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
                if l1ll11lll1l11l111_tv_:
                    return [{Variable4 (u"ࠬࡻࡲ࡭ࠩᕼ"):l1ll11lll1l11l111_tv_}]
            file = re.compile(Variable4 (u"࠭࡜ࡀࡨ࡬ࡰࡪࡃࠨ࠯ࠬࡂ࠭ࠩ࠭ᕽ")).findall(src[0])
            if file :
                l111111llll11l111_tv_ = file[0].split(Variable4 (u"ࠧࠧࠩᕾ"))[0]
                href = l111111llll11l111_tv_ + Variable4 (u"ࠨࠢࡶࡻ࡫࡛ࡲ࡭࠿ࠨࡷࠥࡲࡩࡷࡧࡀ࠵ࠥࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱ࠢࡳࡥ࡬࡫ࡕࡳ࡮ࡀࠩࡸ࠭ᕿ")%(src[0],url)
                l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠩࡸࡶࡱ࠭ᖀ"):href}]
            else:
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,l1111l111ll11l111_tv_)
                if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠪࡹࡷࡲࠧᖁ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
