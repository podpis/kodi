# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import re
import urllib2,urllib
l1lll1l1lll11l111_tv_=Variable4 (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ᳿")
l1llll111ll11l111_tv_ = Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼࡰࡴࡶࡵࡩࡦࡳ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࠨᴀ")
l11lll1llll11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡶࡦࡳ࡫ࡢ࠰ࡳࡶࡴࡾࡹ࠯ࡰࡨࡸ࠳ࡶ࡬࠰࡫ࡱࡨࡪࡾ࠮ࡱࡪࡳࡃࡶࡃࠧᴁ")
__all__=[Variable4 (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᴂ"),Variable4 (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯࡚࡮ࡪࡥࡰࠩᴃ")]
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies={}):
    if not header:
        header = {Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᴄ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠩࠪᴅ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(url=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻࡶࡳࡵࡴࡨࡥࡲ࠴ࡶࡰࡦ࠱ࡸࡻࡶ࠮ࡱ࡮ࠪᴆ")):
    data=l111111l11l111_tv_(url)
    l1l11ll111ll11l111_tv_=Variable4 (u"ࠦ࠴ࡹࡥࡴࡵ࠲ࡸࡻࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࡁࡲࡦ࡯࡫ࡣࡵࡡ࡬ࡨࡂࠫࡳࠣᴇ")
    l1l11ll1l11l11l111_tv_=re.compile(Variable4 (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴈ")).findall(data)
    l1l11ll11l1l11l111_tv_ = re.compile(Variable4 (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯࡭ࡨࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࠴ࡄࠧᴉ")).findall(data)
    len(l1l11ll1l11l11l111_tv_)
    len(l1l11ll11l1l11l111_tv_)
    out=[]
    for i in range(len(l1l11ll1l11l11l111_tv_)):
        l1l11ll11lll11l111_tv_ = l1l11ll1l11l11l111_tv_[i][0]
        title = l1l11ll11l1l11l111_tv_[i][1].decode(Variable4 (u"ࠧࡶࡶࡩ࠱࠽࠭ᴊ")) + Variable4 (u"ࠨࠢ࠽ࠤࠬᴋ") + l1l11ll1l11l11l111_tv_[i][1].decode(Variable4 (u"ࠩࡸࡸ࡫࠳࠸ࠨᴌ"))
        l1llll11lll11l111_tv_ = l1l11ll11l1l11l111_tv_[i][0]
        out.append({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᴍ"):title,Variable4 (u"ࠫ࡮ࡳࡧࠨᴎ"):l1llll11lll11l111_tv_,
                    Variable4 (u"ࠬࡻࡲ࡭ࠩᴏ"):url+l1l11ll111ll11l111_tv_ % l1l11ll11lll11l111_tv_})
    return out
def l111l1lll11l111_tv_(ex_link=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷࡲࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡶࡩࡸࡹ࠯ࡵࡸࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵࡅ࡯ࡣ࡬ࡨࡧࡹࡥࡩࡥ࠿࠴࠹࠹࠹࠸࠷࠲࠺ࠫᴐ")):
    data=l111111l11l111_tv_(ex_link)
    l1lll1ll11l11l111_tv_=[]
    l11l1l111ll11l111_tv_ = re.compile(Variable4 (u"ࠢ࠱࠼ࡾࡷࡷࡩ࠺ࠨࠪ࠱࠮ࡄ࠯ࠧࠣᴑ"), re.DOTALL).findall(data)
    if l11l1l111ll11l111_tv_:
        if Variable4 (u"ࠨ࡯ࡤࡸࡪࡸࡩࡢ࡮ࡢࡲ࡮࡫ࡤࡰࡵࡷࡩࡵࡴࡹࠨᴒ") in l11l1l111ll11l111_tv_[0]:
            data = l111111l11l111_tv_(l11lll1llll11l111_tv_+urllib.quote_plus(ex_link)+Variable4 (u"ࠩࠩ࡬ࡱࡃ࠲ࡢ࠷ࠪᴓ"))
            l11l1l111ll11l111_tv_ = re.compile(Variable4 (u"ࠥ࠴࠿ࢁࡳࡳࡥ࠽ࠫ࠭࠴ࠪࡀࠫࠪࠦᴔ"), re.DOTALL).findall(data)
        l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠫࡺࡸ࡬ࠨᴕ"):l11l1l111ll11l111_tv_[0],Variable4 (u"ࠬࡺࡩࡵ࡫࡯ࡩࠬᴖ"):Variable4 (u"࠭ࡌࡪࡸࡨࠫᴗ"),Variable4 (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩᴘ"):1})
    return l1lll1ll11l11l111_tv_
def _1l1l11l11l11l111_tv_(url=Variable4 (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡺࡶࡱ࠰ࡳࡰ࠴ࡺࡶࡱ࡮ࡤࡽࡪࡸ࠿ࡤࡪࡤࡲࡳ࡫࡬ࡠ࡫ࡧࡁ࠶࠼࠳࠵࠳࠼࠵ࠫࡧࡵࡵࡱࡳࡰࡦࡿ࠽ࡵࡴࡸࡩࠬᴙ")):
    l1lll1ll11l11l111_tv_=[{}]
    if Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡴࡷࡲ࡯ࡥࡾ࡫ࡲࠨᴚ") in url:
        data=l111111l11l111_tv_(url)
        src=re.compile(Variable4 (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᴛ")).findall(data)
        if src and src[0].startswith(Variable4 (u"ࠫ࠴ࡹࡥࡴࡵ࠲ࡸࡻࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࠩᴜ")):
            l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(Variable4 (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡶࡱࡵࡷࡶࡪࡧ࡭࠯ࡶࡹࡴ࠳ࡶ࡬ࠨᴝ")+src[0])
    elif Variable4 (u"࠭࠯ࡴࡧࡶࡷ࠴ࡺࡶࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫᴞ") in url:
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
    return l1lll1ll11l11l111_tv_
