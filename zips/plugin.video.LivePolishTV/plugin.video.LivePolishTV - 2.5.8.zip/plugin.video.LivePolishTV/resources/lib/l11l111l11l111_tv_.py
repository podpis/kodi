# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re
import cookielib
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡨ࡬ࡢࡥ࡮࠲ࡨࡵ࡭࠰ࠩᱏ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ᱐")
__all__=[Variable4 (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ᱑"),Variable4 (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡘ࡬ࡨࡪࡵࠧ᱒")]
def l111111l11l111_tv_(url,data=None,header={}):
    l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
    urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ᱓"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=Variable4 (u"ࠧࠨ᱔")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l11llll11ll11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾࡯࡭ࡡࡹࠪ࠿࡞ࡶ࠮ࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯࠭ࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧ᱕")).findall(content)
    for href,t in l11llll11ll11l111_tv_:
        out.append({Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ᱖"):t,Variable4 (u"ࠪࡸࡻ࡯ࡤࠨ᱗"):t,Variable4 (u"ࠫ࡮ࡳࡧࠨ᱘"):Variable4 (u"ࠬ࠭᱙"),Variable4 (u"࠭ࡵࡳ࡮ࠪᱚ"):href,Variable4 (u"ࠧࡨࡴࡲࡹࡵ࠭ᱛ"):Variable4 (u"ࠨࠩᱜ"),Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᱝ"):Variable4 (u"ࠪࠫᱞ"),Variable4 (u"ࠫࡵࡲ࡯ࡵࠩᱟ"):Variable4 (u"ࠬ࠭ᱠ"),Variable4 (u"࠭ࡣࡰࡦࡨࠫᱡ"):Variable4 (u"ࠧࠨᱢ")})
    if addheader and len(out):
        t=Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡦࡱࡧࡣ࡬ࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᱣ") %time.strftime(Variable4 (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᱤ"))
        out.insert(0,{Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᱥ"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩᱦ"):Variable4 (u"ࠬ࠭ᱧ"),Variable4 (u"࠭ࡩ࡮ࡩࠪᱨ"):Variable4 (u"ࠧࠨᱩ"),Variable4 (u"ࠨࡷࡵࡰࠬᱪ"):l1llll111ll11l111_tv_,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨᱫ"):Variable4 (u"ࠪࠫᱬ"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᱭ"):Variable4 (u"ࠬ࠭ᱮ")})
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢ࠯ࡥࡰࡦࡩ࡫࠯ࡥࡲࡱ࠴ࡺࡶ࡯࠹ࠪᱯ")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1ll1l111ll11l111_tv_ = re.compile(Variable4 (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫ࠧᱰ"),re.DOTALL).findall(content)
    src = [url] if Variable4 (u"ࠨ࡭ࡤࡲࡦࡲࡹࠨᱱ") in url else False
    if l1ll1l111ll11l111_tv_:
        src = re.compile(Variable4 (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᱲ")).findall(l1ll1l111ll11l111_tv_[0])
    if src:
        src = src[0]
        data = l111111l11l111_tv_(src)
        l1ll1l11lll11l111_tv_ = re.compile(Variable4 (u"ࠪ࡟ࡡ࠭ࠢ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫ࡞࠱ࡱ࠸ࡻ࠸ࡀࠫ࡞ࡠࠬࠨ࡝ࠨᱳ")).findall(data)
        if l1ll1l11lll11l111_tv_:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠫࡺࡸ࡬ࠨᱴ"):l1ll1l11lll11l111_tv_[0]}]
        else:
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠬࡻࡲ࡭ࠩᱵ"):l1ll11lll1l11l111_tv_}]
    if not l1lll1ll11l11l111_tv_:
        l1lll1ll11l11l111_tv_=[{Variable4 (u"࠭࡭ࡴࡩࠪᱶ"):Variable4 (u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠡࡼࡨࠤॿࡸࣳࡥॄࡨࡱࠬᱷ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠨ࡞ࡱࠫᱸ"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨᱹ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡹࡷࡲࠧᱺ")))
        print l1lll1ll11l11l111_tv_
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡺࡸ࡬ࠨᱻ")))
        print l1lll1ll11l11l111_tv_
