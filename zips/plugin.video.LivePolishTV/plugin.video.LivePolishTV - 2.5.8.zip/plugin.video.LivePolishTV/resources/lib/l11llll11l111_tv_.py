# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib,urlparse
import re,time
import l1l1lll1l11l111_tv_ as l1llll111lll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡯ࡱࡺࡻࡦࡺࡣࡩࡶࡹࡰ࡮ࡼࡥ࠯ࡰࡨࡸ࠴࠭ᐮ")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧᐯ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᐰ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫᐱ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠫࡁ࡮࠳࠿ࡕࡳࡳࡷࡺࡳࠡࡅ࡫ࡥࡳࡴࡥ࡭ࡵ࠿࠳࡭࠹࠾࡝ࡵ࠭ࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡨࡼࡹࡽࡩࡥࡩࡨࡸࠧࡄ࡜ࡴࠬ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᐲ"),re.DOTALL).findall(content)
    if l1lll1lllll11l111_tv_:
        for href,title in re.findall(Variable4 (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᐳ"),l1lll1lllll11l111_tv_[0]):
           out.append({Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᐴ"):title.strip(),Variable4 (u"ࠧࡵࡸ࡬ࡨࠬᐵ"):title.strip(),Variable4 (u"ࠨ࡫ࡰ࡫ࠬᐶ"):Variable4 (u"ࠩࠪᐷ"),Variable4 (u"ࠪࡹࡷࡲࠧᐸ"):urlparse.urljoin(l1llll111ll11l111_tv_,href),Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᐹ"):Variable4 (u"ࠬࡹࡰࡰࡴࡷࠫᐺ"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ᐻ"):Variable4 (u"ࠧࠨᐼ")})
    if addheader and len(out):
        t=Variable4 (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨ࡯ࡱࡺࡻࡦࡺࡣࡩࡶࡹࡰ࡮ࡼࡥࠡࡕࡓࡓࡗ࡚ࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᐽ") %time.strftime(Variable4 (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᐾ"))
        out.insert(0,{Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᐿ"):t,Variable4 (u"ࠫࡹࡼࡩࡥࠩᑀ"):Variable4 (u"ࠬ࠭ᑁ"),Variable4 (u"࠭ࡩ࡮ࡩࠪᑂ"):Variable4 (u"ࠧࠨᑃ"),Variable4 (u"ࠨࡷࡵࡰࠬᑄ"):l1llll111ll11l111_tv_,Variable4 (u"ࠩࡪࡶࡴࡻࡰࠨᑅ"):Variable4 (u"ࠪࠫᑆ"),Variable4 (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᑇ"):Variable4 (u"ࠬ࠭ᑈ")})
    return out
l1llll1ll11l111_tv_ = l1llll111lll11l111_tv_.l1llll1ll11l111_tv_
l111l1lll11l111_tv_ = l1llll111lll11l111_tv_.l111l1lll11l111_tv_
def test():
    out=l11l11l1l11l111_tv_()
    l1l1l1ll11l111_tv_=out[0]
    items=l1llll1ll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡵࡳ࡮ࠪᑉ")))
    for item in items:
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_( item )
