# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,json,time,urlparse
import cookielib
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡰࡦࡳࡥࡱࡺࡶ࠯ࡲ࡯࠳ࠬᑊ")
l1lll1ll1ll11l111_tv_=10
l1lll1l1lll11l111_tv_=Variable4 (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧᑋ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᑌ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠪࠫᑍ")
    return l11ll11ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=Variable4 (u"ࠫࠬᑎ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᑏ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = Variable4 (u"࠭ࠧᑐ").join([Variable4 (u"ࠧࠦࡵࡀࠩࡸࡁࠧᑑ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = Variable4 (u"ࠨࠩᑒ")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,c = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    data = re.findall(Variable4 (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡵࡤࡱࡣ࡯ࡸࡻ࠴ࡰ࡭࠱࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡷࡪࡦࡷ࡬ࡂࠨ࡜ࡥ࠭ࠥࠤ࡭࡫ࡩࡨࡪࡷࡁࠧࡢࡤࠬࠤࠣࡷࡷࡩ࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠯ࠬࡂ࠭ࠧ࠭ᑓ"),content)
    out=[]
    for href,title,l1llll11lll11l111_tv_ in data:
        out.append({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᑔ"):title.strip(),Variable4 (u"ࠫࡹࡼࡩࡥࠩᑕ"):title.strip(),Variable4 (u"ࠬ࡯࡭ࡨࠩᑖ"):l1llll11lll11l111_tv_,Variable4 (u"࠭ࡵࡳ࡮ࠪᑗ"):href,Variable4 (u"ࠧࡨࡴࡲࡹࡵ࠭ᑘ"):Variable4 (u"ࠨࠩᑙ"),Variable4 (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᑚ"):Variable4 (u"ࠪࠫᑛ")})
    if addheader and len(out):
        t=Variable4 (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡ࡚ࡶࡤࡢࡶࡨࡨ࠿ࠦࠥࡴࠢࠫࡳࡩࡶࡡ࡭ࡶࡹ࠭ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᑜ") %time.strftime(Variable4 (u"ࠧࠫࡤ࠰ࠧࡰ࠳ࠪ࡟࠺ࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥᑝ"))
        out.insert(0,{Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᑞ"):t,Variable4 (u"ࠧࡵࡸ࡬ࡨࠬᑟ"):Variable4 (u"ࠨࠩᑠ"),Variable4 (u"ࠩ࡬ࡱ࡬࠭ᑡ"):Variable4 (u"ࠪࠫᑢ"),Variable4 (u"ࠫࡺࡸ࡬ࠨᑣ"):l1llll111ll11l111_tv_,Variable4 (u"ࠬ࡭ࡲࡰࡷࡳࠫᑤ"):Variable4 (u"࠭ࠧᑥ"),Variable4 (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᑦ"):Variable4 (u"ࠨࠩᑧ")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local={})
def l111l1lll11l111_tv_(url):
    url,l1llll1l11l11l111_tv_=url.split(Variable4 (u"ࠩࡂࠫᑨ")) if Variable4 (u"ࠪࡃࠬᑩ")in url else (url,Variable4 (u"ࠫࠬᑪ"))
    print url,l1llll1l11l11l111_tv_
    l1lll1ll11l11l111_tv_=[]
    header ={Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᑫ"):l1lll1l1lll11l111_tv_,
            Variable4 (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩᑬ"):Variable4 (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨᑭ"),
            Variable4 (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᑮ"):url,
            Variable4 (u"ࠩࡆࡳࡴࡱࡩࡦࠩᑯ"):l1llll1l11l11l111_tv_,
            }
    content,c = l111111l11l111_tv_(url,header=header)
    l1ll11lll1l11l111_tv_=Variable4 (u"ࠪࠫᑰ")
    src = re.compile(Variable4 (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡪࡷࡧ࡭ࡦࠩᑱ"),re.DOTALL|re.I).findall(content)
    if src:
        if Variable4 (u"ࠬࡪࡥ࡬ࡱࡧࡩࡷ࠴ࡷࡴ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩᑲ") in src[0]:
            from l1llll11l11l111_tv_ import l1ll1111l1l11l111_tv_
            l1ll11lll1l11l111_tv_ = l1ll1111l1l11l111_tv_(src[0])
            print l1ll11lll1l11l111_tv_
        else:
            data,c = l111111l11l111_tv_(src[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
    if l1ll11lll1l11l111_tv_:
        l1lll1ll11l11l111_tv_.append({Variable4 (u"࠭ࡵࡳ࡮ࠪᑳ"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᑴ"):Variable4 (u"ࠨࡎ࡬ࡺࡪࠦࠧᑵ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,Variable4 (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᑶ"):1})
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠪࡠࡳ࠭ᑷ"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᑸ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬࡻࡲ࡭ࠩᑹ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡴࡪࡶ࡯ࡩࠬᑺ")))
        print l1lll1ll11l11l111_tv_
