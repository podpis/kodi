# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,time
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡨࡪࡱ࡯ࡥࡧࡵ࠲ࡼࡹ࠯ࠨ෋")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠹࠵࠴࠰࠯࠴࠹࠺࠶࠴࠱࠱࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ෌")
__all__=[Variable4 (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ෍"),Variable4 (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮࡙࡭ࡩ࡫࡯ࠨ෎")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫා"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"ࠨࠩැ")
    return l11ll11ll11l111_tv_
locals={
Variable4 (u"ࠤࡓࡳࡱࡹࡡࡵࠢ࠵ࠦෑ") 									:Variable4 (u"ࠥࠬࡕࡵ࡬࡜࡮ࡠ࠮ࡸࡧࡴ࡜࡞ࡶ࠱ࡢ࠰࠲ࠩ࡝࡟ࡷ࠲ࡣࠪࡕࡘࠬࡃ࠭ࡡ࡜ࡴ࠯ࡠ࠮ࡍࡊࠩࡀࠫࠥි"),
Variable4 (u"ࠦࡕࡵ࡬ࡴࡣࡷࠤࡘࡶ࡯ࡳࡶࠥී") 								:Variable4 (u"ࠧ࠮ࡐࡰ࡮࡞ࡰࡢ࠰ࡳࡢࡶ࡞ࡠࡸ࠳࡝ࠫࡕࡳࡳࡷࡺࠨ࡜࡞ࡶ࠱ࡢ࠰࠱ࠪࡁࠫ࡟ࡡࡹ࠭࡞ࠬࡗ࡚࠮ࡅࠨ࡜࡞ࡶ࠱ࡢ࠰ࡈࡅࠫࡂ࠭ࠧු"),
}
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(Variable4 (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡤࡦ࡭ࡲࡨࡪࡸ࠮ࡸࡵ࠲ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠳࡯࡯࡮࡬ࡲࡪ࠵ࠧ෕"))
    out=[]
    l1ll111llll11l111_tv_ = re.compile(Variable4 (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡵࡧࡪࡳࡷࡿࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡢࡳࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨූ")).findall(content)
    for group,l1ll11l1l1l11l111_tv_ in l1ll111llll11l111_tv_:
        l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾ࡤࠤࡹ࡯ࡴ࡭ࡧࡀࠦࡔ࡭࡬࡝ࡺࡦ࠸ࡡࡾ࠸࠶ࡦࡤ࡮ࠥ࠮࠮ࠫࡁࠬࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࠱ࡤࡂࠬ෗")).findall(l1ll11l1l1l11l111_tv_)
        for title,href,l1ll111l11l11l111_tv_ in l1lll1lllll11l111_tv_:
            out.append({Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨෘ"):title.strip(),Variable4 (u"ࠪࡸࡻ࡯ࡤࠨෙ"):title.strip(),Variable4 (u"ࠫ࡮ࡳࡧࠨේ"):l1ll111l11l11l111_tv_,Variable4 (u"ࠬࡻࡲ࡭ࠩෛ"):href,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬො"):group,Variable4 (u"ࠧࡤࡱࡧࡩࠬෝ"):group,Variable4 (u"ࠨࡷࡵࡰࡪࡶࡧࠨෞ"):Variable4 (u"ࠩࠣࠫෟ")})
    if addheader and len(out):
        t=Variable4 (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡽࡪࡲ࡬ࡰࡹࡠ࡙ࡵࡪࡡࡵࡧࡧ࠾ࠥࠫࡳࠡࠪࡧࡥࡷࡳ࡯ࡸࡣ࠰ࡸࡻ࠴ࡰ࡭ࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ෠") %time.strftime(Variable4 (u"ࠦࠪࡪ࠯ࠦ࡯࠲ࠩ࡞ࡀࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ෡"))
        out.insert(0,{Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ෢"):t,Variable4 (u"࠭ࡴࡷ࡫ࡧࠫ෣"):Variable4 (u"ࠧࠨ෤"),Variable4 (u"ࠨ࡫ࡰ࡫ࠬ෥"):Variable4 (u"ࠩࠪ෦"),Variable4 (u"ࠪࡹࡷࡲࠧ෧"):l1llll111ll11l111_tv_,Variable4 (u"ࠫ࡬ࡸ࡯ࡶࡲࠪ෨"):Variable4 (u"ࠬ࠭෩"),Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭෪"):Variable4 (u"ࠧࠨ෫")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,locals)
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    if Variable4 (u"ࠨࡧࡰࡦࡪࡪࠧ෬") in url:
        l1ll11lll1l11l111_tv_ = l1ll1111l1l11l111_tv_(url)
        if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠩࡸࡶࡱ࠭෭"):l1ll11lll1l11l111_tv_}]
    else:
        content = l111111l11l111_tv_(url)
        l1ll1111lll11l111_tv_ = re.compile(Variable4 (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠰ࡅࡳࡳࡥࡀࠦ࠭࠴ࠫࡦ࡯ࡥࡩࡩ࠴ࠪࡀࠫࠥ࠲࠰ࡅ࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩ෮")).findall(content)
        l1ll11l111l11l111_tv_ = re.findall(Variable4 (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯ࡥࡧ࡮ࡳࡩ࡫ࡲ࠯ࡹࡶ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠴ࠫࡀࠫࠥࡂࡡࡹࠪ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥ࠲࠰ࡅࠢ࡝ࡵ࠭ࡂࡡࡹࠪࡔࡶࡵࡩࡦࡳ࠮ࠫࡁ࠿࠳ࡦࡄࠧ෯"),content)
        if len(l1ll11l111l11l111_tv_)>1:
            import l1ll11l11ll11l111_tv_
            pool = l1ll11l11ll11l111_tv_.ThreadPool(len(l1ll11l111l11l111_tv_))
            l1ll111l1ll11l111_tv_ = [[] for x in range(len(l1ll11l111l11l111_tv_))]
            for i,l1l1l1ll11l111_tv_ in enumerate(l1ll11l111l11l111_tv_):
                time.sleep(0.1)
                pool.l1ll11l1lll11l111_tv_(l1ll1111l1l11l111_tv_, *(l1l1l1ll11l111_tv_.replace(Variable4 (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ෰"),Variable4 (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ෱")),l1ll111l1ll11l111_tv_,i))
            pool.l1ll11111ll11l111_tv_()
            print (Variable4 (u"ࠧࡱࡱࡲࡰࠥࡩ࡯࡮ࡲ࡯ࡸࡪࡪࠧෲ"),l1ll111l1ll11l111_tv_)
            for i,l1ll11lll1l11l111_tv_ in enumerate(l1ll111l1ll11l111_tv_):
                print l1ll11lll1l11l111_tv_
                if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠨࡷࡵࡰࠬෳ"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ෴"):Variable4 (u"ࠪࡐ࡮ࡴ࡫ࠡࠧࡧࠫ෵")%(i+1)})
        elif l1ll1111lll11l111_tv_:
            l1ll11lll1l11l111_tv_ = l1ll1111l1l11l111_tv_(l1ll1111lll11l111_tv_[0])
            if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠫࡺࡸ࡬ࠨ෶"):l1ll11lll1l11l111_tv_,Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫ෷"):Variable4 (u"࠭ࡌࡪࡰ࡮ࠫ෸")})
    return l1lll1ll11l11l111_tv_
def l1ll1111l1l11l111_tv_(url,l1ll11ll11l11l111_tv_=[],idx=-1):
    data = l111111l11l111_tv_(url)
    l1ll111ll1l11l111_tv_=re.compile(Variable4 (u"ࠧࡴࡴࡦࡁࡠࠨ࡜ࠨ࡟࡟ࡷ࠯࠮ࠨࡀ࠼࡫ࡸࡹࡶࡼ࠰࠱ࠬ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭෹"),re.DOTALL+re.IGNORECASE).findall(data)
    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    print l1ll11lll1l11l111_tv_
    if idx>=0 : l1ll11ll11l11l111_tv_[idx]=l1ll11lll1l11l111_tv_
    return l1ll11lll1l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[1]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠨ࡞ࡱࠫ෺"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ෻"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡹࡷࡲࠧ෼")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ෽")))
        print l1lll1ll11l11l111_tv_
