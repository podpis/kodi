# -*- coding: utf-8 -*-
import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7
def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
import urllib2,urllib
import re,time,urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡨࡦࡸ࡭ࡰࡹࡤ࠱ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ൩")
l1lll1l1lll11l111_tv_=Variable4 (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠹࠵࠴࠰࠯࠴࠹࠺࠶࠴࠱࠱࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ൪")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {Variable4 (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ൫"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"࠭ࠧ൬")
    return l11ll11ll11l111_tv_
def l1ll1l1l1ll11l111_tv_(url):
    l1lll1lll1l11l111_tv_=url
    try:
        req = urllib2.Request(url,headers={Variable4 (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ൭"):l1lll1l1lll11l111_tv_})
        response = urllib2.urlopen(req, timeout=15)
        l1lll1lll1l11l111_tv_=response.geturl()
        response.close()
    except: pass
    return l1lll1lll1l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(Variable4 (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡢ࠮ࡨࡵࡶࡳ࠾࠴࠵ࡤࡢࡴࡰࡳࡼࡧ࠭ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲࡟ࡣࡂ࡝ࠫࠫ࡞ࠦࡢࡄࠨ࡜ࡠ࠿ࡡ࠯࠯࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠩ൮")).findall(content)
    l1lll1lllll11l111_tv_ = l1lll1lllll11l111_tv_[1:-2] if len(l1lll1lllll11l111_tv_)>10 else l1lll1lllll11l111_tv_
    for href,title in l1lll1lllll11l111_tv_:
        if Variable4 (u"ࠩ࠿ࠫ൯") in title:
            continue
        out.append({Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ൰"):title.strip(),Variable4 (u"ࠫࡹࡼࡩࡥࠩ൱"):title.strip(),Variable4 (u"ࠬ࡯࡭ࡨࠩ൲"):Variable4 (u"࠭ࠧ൳"),Variable4 (u"ࠧࡶࡴ࡯ࠫ൴"):href,Variable4 (u"ࠨࡩࡵࡳࡺࡶࠧ൵"):Variable4 (u"ࠩࠪ൶"),Variable4 (u"ࠪࡹࡷࡲࡥࡱࡩࠪ൷"):Variable4 (u"ࠫࠬ൸")})
    if addheader and len(out):
        t=Variable4 (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡩࡧࡲ࡮ࡱࡺࡥ࠲ࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠯ࡱࡱࡰ࡮ࡴࡥࠪ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ൹") %time.strftime(Variable4 (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦൺ"))
        out.insert(0,{Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ൻ"):t,Variable4 (u"ࠨࡶࡹ࡭ࡩ࠭ർ"):Variable4 (u"ࠩࠪൽ"),Variable4 (u"ࠪ࡭ࡲ࡭ࠧൾ"):Variable4 (u"ࠫࠬൿ"),Variable4 (u"ࠬࡻࡲ࡭ࠩ඀"):l1llll111ll11l111_tv_,Variable4 (u"࠭ࡧࡳࡱࡸࡴࠬඁ"):Variable4 (u"ࠧࠨං"),Variable4 (u"ࠨࡷࡵࡰࡪࡶࡧࠨඃ"):Variable4 (u"ࠩࠪ඄")})
    return out
def l111l1lll11l111_tv_(url=Variable4 (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡨࡦࡸ࡭ࡰࡹࡤ࠱ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡵࡸࡳ࠱࠶࠵ࠧඅ")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1ll1l111ll11l111_tv_ = re.compile(Variable4 (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࠫආ"),re.DOTALL).findall(content)
    src = [url] if Variable4 (u"ࠬࡱࡡ࡯ࡣ࡯ࠫඇ") in url else []
    for m in l1ll1l111ll11l111_tv_:
        l11ll11ll11l111_tv_ = re.compile(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫඈ")).findall(m)
        if l11ll11ll11l111_tv_:
            if l11ll11ll11l111_tv_[0].startswith(Variable4 (u"ࠧࡩࡶࡷࡴࠬඉ")):
                src.append(urlparse.urljoin(l1llll111ll11l111_tv_,l11ll11ll11l111_tv_[0]))
            else:
                src.append(l11ll11ll11l111_tv_[0])
    if src:
        src = src[0]
        data = l111111l11l111_tv_(src)
        l1ll1l11lll11l111_tv_ = re.compile(Variable4 (u"ࠨ࡝࡟ࠫࠧࡣࠨࡩࡶࡷࡴ࠳࠰࡜࠯࡯࠶ࡹ࠽ࡅࠩ࡜࡞ࠪࠦࡢ࠭ඊ")).findall(data)
        if l1ll1l11lll11l111_tv_:
            l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠩࡸࡶࡱ࠭උ"):l1ll1l11lll11l111_tv_[0]}]
        else:
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_=[{Variable4 (u"ࠪࡹࡷࡲࠧඌ"):l1ll11lll1l11l111_tv_}]
            else:
                l1ll1l1111l11l111_tv_ = re.compile(Variable4 (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬඍ"),re.DOTALL).findall(data)
                l1ll1l1111l11l111_tv_ = l1ll1l1111l11l111_tv_[0] if l1ll1l1111l11l111_tv_ else Variable4 (u"ࠬ࠭ඎ")
                l1ll1l11l1l11l111_tv_ = re.compile(Variable4 (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫඏ")).findall(l1ll1l1111l11l111_tv_)
                data = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0]) if l1ll1l11l1l11l111_tv_ else Variable4 (u"ࠧࠨඐ")
                l1ll1l1l11l11l111_tv_ = re.compile(Variable4 (u"ࠨ࡝ࠥࡠࠬࡣࠨࡩࡶࡷࡴ࠳࠰࠿࡝࠰ࡰ࠷ࡺࡡ࠸࡞ࠫ࡞ࠦࡡ࠭࡝ࠨඑ")).findall(data)
                if l1ll1l1l11l11l111_tv_:
                    l1lll1ll11l11l111_tv_.append({Variable4 (u"ࠩࡸࡶࡱ࠭ඒ"):l1ll1l1l11l11l111_tv_[0],Variable4 (u"ࠪࡸ࡮ࡺࡩ࡭ࡧࠪඓ"):Variable4 (u"ࠫࡑ࡯ࡶࡦࠩඔ"),Variable4 (u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪࠧඕ"):1})
    if not l1lll1ll11l11l111_tv_:
        l1lll1ll11l11l111_tv_=[{Variable4 (u"࠭࡭ࡴࡩࠪඖ"):Variable4 (u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠡࡼࡨࠤॿࡸࣳࡥॄࡨࡱࠬ඗")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print Variable4 (u"ࠨ࡞ࡱࠫ඘"),l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡷ࡭ࡹࡲࡥࠨ඙"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪࡹࡷࡲࠧක")))
        print l1lll1ll11l11l111_tv_
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡺࡸ࡬ࠨඛ")))
        print l1lll1ll11l11l111_tv_
