# -*- coding: utf-8 -*-

import sys
Variable1 = sys.version_info [0] == 2
Variable2 = 2048
Variable3 = 7

def Variable4 (Variable5):
	global Variable6
	Variable7 = ord (Variable5 [-1])
	Variable8 = Variable5 [:-1]
	Variable10 = Variable7 % len (Variable8)
	Variable11 = Variable8 [:Variable10] + Variable8 [Variable10:]
	if Variable1:
		Variable12 = unicode () .join ([unichr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	else:
		Variable12 = str () .join ([chr (ord (char) - Variable2 - (Variable13 + Variable7) % Variable3) for Variable13, char in enumerate (Variable11)])
	return eval (Variable12)
	
import sys,re,os
import urllib,urllib2
import urlparse
import check
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import threading
import time

base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')
my_addon_id     = my_addon.getAddonInfo('id')

PATH            = my_addon.getAddonInfo('path')
DATAPATH        = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES       = PATH+'/resources/'

sys.path.append( os.path.join( RESOURCES, "lib" ) )

FANART=PATH+'/fanart.jpg'

## COMMON Functions

def addLinkItem(name, url, mode, params=1, iconimage='DefaultFolder.png', infoLabels=False, IsPlayable=True,fanart=FANART,itemcount=1,contextmenu=None):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    
    liz = xbmcgui.ListItem(name)
    
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    art['fanart'] = fanart if fanart else art['landscape'] 
    liz.setArt(art)
    
    if not infoLabels:
        infoLabels={"title": name}
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    if contextmenu:
        contextMenuItems=contextmenu
        li.addContextMenuItems(contextMenuItems, replaceItems=True) 

    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok
	
def addDir(name,ex_link=None, params=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params})

    li = xbmcgui.ListItem(name)
    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)
    
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape'] 
    art['fanart'] = fanart if fanart else art['landscape'] 
    li.setArt(art)


    if contextmenu:
        contextMenuItems=contextmenu
        li.addContextMenuItems(contextMenuItems, replaceItems=True) 

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
	
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))
	
try: from shutil import rmtree
except: rmtree = False
import ramic as l11l1l1l11l111_tv_

def Variable14(l1l1l1l11l111_tv_,l11ll11l111_tv_=[Variable4 (u"ࠩࠪࡠ")]):
    debug=1
def Variable15(name=Variable4 (u"ࠪࠫࡡ")):
    debug=1

def Variable16(top):
    debug=1
def Variable17():
    l1l1l1l11l111_tv_ = os.path.join(xbmc.translatePath(Variable4 (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࡬")),Variable4 (u"ࠨࡣࡧࡨࡴࡴࡳࠨ࡭"))
    xbmc.log(l1l1l1l11l111_tv_)
    if Variable14(l1l1l1l11l111_tv_,[Variable4 (u"ࠩࡤࡰ࡮࡫࡮ࡸ࡫ࡽࡥࡷࡪࠧ࡮"),Variable4 (u"ࠪࡩࡽࡺࡥ࡯ࡦࡨࡶ࠳ࡧ࡬ࡪࡧࡱࠫ࡯"),Variable4 (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡩࡨࡦࡴࡵࡽࡹࡼࠧࡰ")])>0:
        Variable15(Variable4 (u"ࠬࡽࡩࡻࡣࡵࡨࠬࡱ"))
        return
    l1lll1l11l111_tv_ = os.path.join(xbmc.translatePath(Variable4 (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡸࡷࡪࡸࡤࡢࡶࡤࠫࡲ")),Variable4 (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫࡳ"),Variable4 (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪࡴ"),Variable4 (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨࡵ"))
    if os.path.exists(l1lll1l11l111_tv_):
        data = open(l1lll1l11l111_tv_,Variable4 (u"ࠪࡶࠬࡶ")).read()
        data= re.sub(Variable4 (u"ࠫࡡࡡ࠮ࠫ࡞ࡠࠫࡷ"),Variable4 (u"ࠬ࠭ࡸ"),data)
        if len(re.compile(Variable4 (u"࠭࠾࠯ࠬࠫࡴࡴࡲࡳ࡬ࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࡹ"),re.DOTALL|re.IGNORECASE).findall(data)):
            Variable15(Variable4 (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩࡺ"))
            return
        if len(re.compile(Variable4 (u"ࠨࡀ࠱࠮࠭ࡪࡡࡳ࡯ࡲࡻࡦࡢࡳࠫࡶ࡟ࡷ࠯ࡼࠩࠨࡻ"),re.DOTALL|re.IGNORECASE).findall(data)):
            Variable15(Variable4 (u"ࠩࡶ࡯࡮ࡴ࠮ࡢࡧࡲࡲ࠳ࡴ࡯ࡹ࠰࠸ࠫࡼ"))
            return
    l1lll1l11l111_tv_ = os.path.join(xbmc.translatePath(Variable4 (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࡽ")),Variable4 (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࡾ"),Variable4 (u"ࠬࡹ࡫ࡪࡰ࠱ࡼࡴࡴࡦ࡭ࡷࡨࡲࡨ࡫ࠧࡿ"),Variable4 (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࢀ"))
    if os.path.exists(l1lll1l11l111_tv_):
        data = open(l1lll1l11l111_tv_,Variable4 (u"ࠧࡳࠩࢁ")).read()
        data= re.sub(Variable4 (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨࢂ"),Variable4 (u"ࠩࠪࢃ"),data)
        if len(re.compile(Variable4 (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࢄ"),re.DOTALL|re.IGNORECASE).findall(data)):
            Variable15(Variable4 (u"ࠫࡸࡱࡩ࡯࠰ࡻࡳࡳ࡬࡬ࡶࡧࡱࡧࡪ࠭ࢅ"))
            return
    l1lll11l111_tv_ = xbmc.translatePath(Variable4 (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࢆ"))
    for f in os.listdir(l1lll11l111_tv_):
        if Variable4 (u"࠭ࡍࡎࡇࡖࠫࢇ") in f:
            Variable15()
            return
try:
    debug=1
except: pass
l1l1l111l11l111_tv_ = lambda x,y: ord(x)+8*y if ord(x)%2 else ord(x)
l11ll11l11l111_tv_ = lambda l111llll11l111_tv_: Variable4 (u"ࠨࠩࢉ").join([chr(l1l1l111l11l111_tv_(x,1) ) for x in l111llll11l111_tv_.encode(Variable4 (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩࢊ")).strip()])
l11l1111l11l111_tv_ = lambda l111llll11l111_tv_: Variable4 (u"ࠪࠫࢋ").join([chr(l1l1l111l11l111_tv_(x,-1) ) for x in l111llll11l111_tv_]).decode(Variable4 (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࢌ"))
l1111ll11l111_tv_={Variable4 (u"ࠬࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢࠩࢍ"):Variable4 (u"࠭ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢࠩࢎ"),
             Variable4 (u"ࠧࡪࡶ࡬ࡺ࡮࠭࢏"):Variable4 (u"ࠨ࡫ࡷ࡭ࡻ࡯ࠧ࢐"),
             Variable4 (u"ࠩࡼࡳࡾ࠴ࡴࡷࠩ࢑"):Variable4 (u"ࠪࡽࡴࡿࡴࡷࠩ࢒"),
             Variable4 (u"ࠫࡳࡵࡷࡢࡶࡹ࠲ࡳ࡫ࡴࠨ࢓"):Variable4 (u"ࠬࡴ࡯ࡸࡣࡷࡺࡳ࡫ࡴࠨ࢔"),
             Variable4 (u"࠭ࡴࡦ࡮ࡨࡱࡦࡴࡩࡢ࡭࠱ࡳࡷ࡭ࠧ࢕"):Variable4 (u"ࠧࡵࡧ࡯ࡩࡲࡧ࡮ࡪࡣ࡮ࡳࡷ࡭ࠧ࢖"),
             Variable4 (u"ࠨ࡮ࡲࡳࡰࡴࡩ࡫࠰࡬ࡲࠬࢗ"):Variable4 (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࡬ࡲࠬ࢘"),
             Variable4 (u"ࠪࡻ࡮ࡴࡴࡦࡺ࢙ࠪ"):Variable4 (u"ࠫࡱ࡯࡭ࡢ࢚ࠩ"),
             Variable4 (u"ࠬࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠮ࡤ࡯ࡥࡨࡱ࢛ࠧ"):Variable4 (u"࠭ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢࡡࡥࡰࡦࡩ࡫ࠨ࢜"),
             Variable4 (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡰ࡮ࡼࡥࠨ࢝"):Variable4 (u"ࠨࡶࡨࡰࡪࡽࡩࡻ࡬ࡤࡰ࡮ࡼࡥࠨ࢞"),
             Variable4 (u"ࠩࡺ࡭ࡿࡰࡡ࠯ࡶࡹࠫ࢟"):Variable4 (u"ࠪࡻ࡮ࢀࡪࡢࡶࡹࠫࢠ"),
             Variable4 (u"ࠫ࡮࡮࡯࡭ࡣࡱࡨ࡮ࡧ࠮ࡵࡸࠪࢡ"):Variable4 (u"ࠬ࡯ࡨࠨࢢ"),
             Variable4 (u"࠭ࡤࡢࡴࡰࡳࡼࡧ࠭ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣࠪࢣ"):Variable4 (u"ࠧࡥࡣࡵࡱࡴࡽࡡࡠࡶࡨࡰࡪࡽࡩࡻ࡬ࡤࡣ࡮ࡴࡦࡰࠩࢤ"),
             Variable4 (u"ࠨࡒ࡬ࡰࡴࡺࠠࡘࡒࠪࢥ"):Variable4 (u"ࠩࡳ࡭ࡱࡵࡴࡸࡲࠪࢦ"),
             Variable4 (u"ࠪࡘ࡛࠳ࡷࡦࡧࡥࠫࢧ"):Variable4 (u"ࠫࡹࡼ࡟ࡸࡧࡨࡦࠬࢨ"),
             Variable4 (u"ࠬࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡷࠩࢩ"):Variable4 (u"࠭ࡤࡢࡴࡰࡳࡼࡧ࡟ࡵࡸࠪࢪ"),
             Variable4 (u"ࠧࡵࡧ࡯ࡩ࡛ࡎࡓࠨࢫ"):Variable4 (u"ࠨࡶࡨࡰࡪࡼࡨࡴࠩࢬ"),
             Variable4 (u"ࠩࡽࡳࡧࡧࡣࡻࡖ࡙ࠫࢭ"):Variable4 (u"ࠪࡾࡴࡨࡡࡤࡼࡷࡺࡤ࡯࡮ࡧࡱࠪࢮ"),
             Variable4 (u"ࠫࡴࡪࡰࡢ࡮ࡗ࡚ࠬࢯ"):Variable4 (u"ࠬࡵࡤࡱࡣ࡯ࡸࡻ࠭ࢰ")
             }
def _1l11ll11l111_tv_(s):
    mod={}
    if   s==Variable4 (u"࠭ࡴࡷࡡࡲࡲࡱ࡯࡮ࡦࡨࡰ࠶ࠬࢱ"):     import l1l1l1lll11l111_tv_ as mod
    elif s==Variable4 (u"ࠧࡪࡪࠪࢲ"):               import zobacztv as mod
    elif s==Variable4 (u"ࠨ࡮࡬ࡱࡦ࠭ࢳ"):             import l1l11ll1l11l111_tv_ as mod
    elif s==Variable4 (u"ࠩࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥࡤࡨ࡬ࡢࡥ࡮ࠫࢴ"):  import l11l111l11l111_tv_ as mod
    elif s==Variable4 (u"ࠪࡲࡴࡽࡡࡵࡸࡱࡩࡹ࠭ࢵ"):        import l1ll1l1l1l11l111_tv_ as mod
    elif s==Variable4 (u"ࠫࡹ࡫࡬ࡦ࡯ࡤࡲ࡮ࡧ࡫ࡰࡴࡪࠫࢶ"):    import l1ll1ll1l11l111_tv_ as mod
    elif s==Variable4 (u"ࠬࡴ࡯ࡸࡹࡤࡸࡨ࡮ࡴࡷ࡮࡬ࡺࡪ࠭ࢷ"):   import l1l1lll1l11l111_tv_ as mod
    elif s==Variable4 (u"࠭࡮ࡰࡹࡺࡥࡹࡩࡨࡵࡸ࡯࡭ࡻ࡫࡟ࡴࡲࡲࡶࡹ࠭ࢸ"):   import l11llll11l111_tv_ as mod
    elif s==Variable4 (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࡯࡭ࡻ࡫ࠧࢹ"):    import l1ll1llll11l111_tv_ as mod
    elif s==Variable4 (u"ࠨࡣࡰ࡭࡬ࡵࡳࡵࡸࠪࢺ"):         import l1lll111ll11l111_tv_ as mod
    elif s==Variable4 (u"ࠩࡷࡺࡵࡹࡴࡳࡧࡤࡱࠬࢻ"):        import l11ll1lll11l111_tv_ as mod
    elif s==Variable4 (u"ࠪ࡭ࡰࡲࡵࡣࠩࢼ"):            import l1l11llll11l111_tv_ as mod
    elif s==Variable4 (u"ࠫࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧࠧࢽ"):    import l11llll1l11l111_tv_ as mod
    elif s==Variable4 (u"ࠬ࡯ࡴࡪࡸ࡬ࠫࢾ"):        import l11lllll11l111_tv_ as mod
    elif s==Variable4 (u"࠭ࡹࡰࡻࡷࡺࠬࢿ"):        import l1l111l1l11l111_tv_ as mod
    elif s==Variable4 (u"ࠧ࡭ࡱࡲ࡯ࡳ࡯ࡪࡪࡰࠪࣀ"):    import l1lll1l1l11l111_tv_ as mod
    elif s==Variable4 (u"ࠨࡹ࡬ࡾ࡯ࡧࡴࡷࠩࣁ"):      import l1l1lllll11l111_tv_ as mod
    elif s==Variable4 (u"ࠩࡶࡴࡴࡸࡴࡵࡸࡳࠫࣂ"):     import l1l1ll1ll11l111_tv_ as mod
    elif s==Variable4 (u"ࠪࡻࡪ࡫ࡢࡵࡸࠪࣃ"):       import l11lll1ll11l111_tv_ as mod
    elif s==Variable4 (u"ࠫࡹ࡫࡬ࡦ࡯࡬࡯࡮࠭ࣄ"):       import l1l111ll11l111_tv_ as mod
    elif s==Variable4 (u"ࠬࡪࡡࡳ࡯ࡲࡻࡦࡥࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢࡡ࡬ࡲ࡫ࡵࠧࣅ"): import l11l11l11l111_tv_ as mod
    elif s==Variable4 (u"࠭ࡴࡷࡡࡺࡩࡪࡨࠧࣆ"): import l1llllll1l11l111_tv_ as mod
    elif s==Variable4 (u"ࠧࡱ࡫࡯ࡳࡹࡽࡰࠨࣇ"): import l11l1llll11l111_tv_ as mod
    elif s==Variable4 (u"ࠨࡪࡨࡽࡦࡺࡶࠨࣈ"): import l1ll1ll1ll11l111_tv_ as mod
    elif s==Variable4 (u"ࠩࡧࡥࡷࡳ࡯ࡸࡣࡢࡸࡻ࠭ࣉ"): import l1llll111l11l111_tv_ as mod
    elif s==Variable4 (u"ࠪࡸࡪࡲࡥࡷࡪࡶࠫ࣊"):  import l1ll111ll11l111_tv_ as mod
    elif s==Variable4 (u"ࠫࡲ࡫ࡣࡻࡧ࡯࡭ࡻ࡫࡟ࡵࡸࠪ࣋"): import l1llllllll11l111_tv_ as mod
    elif s==Variable4 (u"ࠬࡹࡥ࡫࡯ࠪ࣌") : import l1l1111ll11l111_tv_ as mod
    elif s==Variable4 (u"࠭ࡺࡰࡤࡤࡧࡿࡺࡶࡠ࡫ࡱࡪࡴ࠭࣍"): import l111ll11l11l111_tv_ as mod
    elif s==Variable4 (u"ࠧࡦࡵ࡮ࡥ࡬ࡵࡴࡷࠩ࣎") : import l1l1111l11l111_tv_ as mod
    elif s==Variable4 (u"ࠨࡹࡵࡩࡦࡲࡵ࠳࠶࣏ࠪ") : import l1lllll1ll11l111_tv_ as mod
    elif s==Variable4 (u"ࠩࡲࡨࡵࡧ࡬ࡵࡸ࣐ࠪ") : import l1lll111l11l111_tv_ as mod
    elif s==Variable4 (u"ࠪࡨࡪࡩ࡯ࡥࡧࡵࡣࡼࡹ࣑ࠧ") : import l1llll11l11l111_tv_ as mod
    return mod
def l1l1ll1l11l111_tv_():
    for k,v in l1111ll11l111_tv_.items():
        _1l11ll11l111_tv_(v)
        import l1l1llll11l111_tv_
def l1lll11lll11l111_tv_():
    l1ll111l11l111_tv_=0
    return False
if not os.path.exists(Variable4 (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩࣽ")):
    tm=time.gmtime()
    try:    l1lll1ll11l111_tv_,l1ll11ll11l111_tv_,l1llllll11l111_tv_ = l11l1111l11l111_tv_(my_addon.getSetting(Variable4 (u"࠭࡫ࡰࡦࠪࣾ"))).split(Variable4 (u"ࠧ࠻ࠩࣿ"))
    except: l1lll1ll11l111_tv_,l1ll11ll11l111_tv_,l1llllll11l111_tv_ =  [Variable4 (u"ࠨ࠯࠴ࠫऀ"),Variable4 (u"ࠩࠪँ"),Variable4 (u"ࠪ࠱࠶࠭ं")]
    if int(l1lll1ll11l111_tv_) != tm.tm_hour:
        try:
            l111lll11l111_tv_ = urllib2.urlopen(Variable4 (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡦࡳࡩࡤࡵࡳࡥ࠴ࡱ࡯ࡥ࡫࠲ࡱࡦࡹࡴࡦࡴ࠲ࡖࡊࡇࡄࡎࡇ࠱ࡱࡩ࠭ः")).read()
            ccode = re.findall(Variable4 (u"ࠬࡑࡏࡅ࠼ࠣࠬ࠳࠰࠿ࠪ࡞ࡱࠫऄ"),l111lll11l111_tv_)[0].strip(Variable4 (u"࠭ࠪࠨअ"))
        except: ccode = Variable4 (u"ࠧࠨआ")
def l11111lll11l111_tv_(url):
    import l11l1ll11l111_tv_ as s
    from time import gmtime, strftime
    href,headers=url.split(Variable4 (u"ࠬࢂࠧऒ"))
    header={}
    header[Variable4 (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧओ")]=urllib.unquote(re.compile(Variable4 (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨऔ")).findall(headers)[0])
    header[Variable4 (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬक")]=urllib.unquote(re.compile(Variable4 (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠨ࠯ࠬࡂ࠭ࠫ࠭ख")).findall(headers)[0])
    header[Variable4 (u"ࠪࡓࡷ࡯ࡧࡪࡰࠪग")]=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡭࠻࠮ࡢࡦࡶ࡬ࡪࡲ࡬࠯ࡰࡨࡸࠬघ")
    header[Variable4 (u"ࠬࡏࡦ࠮ࡏࡲࡨ࡮࡬ࡩࡦࡦ࠰ࡗ࡮ࡴࡣࡦࠩङ")]=strftime(Variable4 (u"ࠨࠥࡢ࠮ࠣࠩࡩࠦࠥࡣࠢࠨ࡝ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠠࡈࡏࡗࠦच"), gmtime())
    header[Variable4 (u"ࠧࡄࡱࡱࡲࡪࡩࡴࡪࡱࡱࠫछ")]=Variable4 (u"ࠨ࡭ࡨࡩࡵ࠳ࡡ࡭࡫ࡹࡩࠬज")
    header[Variable4 (u"ࠩࡨࡸࡦ࡭ࠧझ")]=Variable4 (u"ࠪࠦ࠺࠾࠲࠱ࡥࡧࡥ࠽࠳࠲ࡣ࠻ࠥࠫञ")
    print Variable4 (u"ࠫࠨ࠭ट")*25
    print Variable4 (u"ࠬࠩࠧठ")*25
    xbmc.sleep(2000)
    l11l1l11l11l111_tv_ = xbmc.Player()
    l11l1l11l11l111_tv_.l111l1l11l111_tv_()
    print Variable4 (u"࠭ࡳࡱࡱࡵࡸ࠸࠻࠶ࡕࡪࡵࡩࡦࡪ࠺ࠡࡲࡤࡷࡸ࡫ࡤࠡࡷࡵࡰ࠿࡛ࠦࠦࡵࡠࠤࠬड")%href
    h=header
    while l11l1l11l11l111_tv_.l1lll1lll11l111_tv_():
        print Variable4 (u"ࠧࡴࡲࡲࡶࡹ࠹࠵࠷ࡖ࡫ࡶࡪࡧࡤ࠻ࠢࡎࡓࡉࡏࠠࡊࡕࠣࡔࡑࡇ࡙ࡊࡐࡊ࠰ࠥࡹ࡬ࡦࡧࡳ࡭ࡳ࡭ࠠ࠲ࡵࠪढ")
        a,l1ll1111l11l111_tv_=s.l11l1lll11l111_tv_(href,header=header)
        header[Variable4 (u"ࠨࡧࡷࡥ࡬࠭ण")] = l1ll1111l11l111_tv_.get(Variable4 (u"ࠩࡨࡸࡦ࡭ࠧत"),Variable4 (u"ࠪࠫथ"))
        header[Variable4 (u"ࠫࡩࡧࡴࡦࠩद")] = l1ll1111l11l111_tv_.get(Variable4 (u"ࠬࡪࡡࡵࡧࠪध"),Variable4 (u"࠭ࠧन"))
        xbmc.sleep(1000)
    print Variable4 (u"ࠧࡴࡲࡲࡶࡹ࠹࠵࠷ࡖ࡫ࡶࡪࡧࡤ࠻ࠢࡎࡓࡉࡏࠠࡔࡖࡒࡔࡕࡋࡄ࠭ࠢࡒ࡙࡙࡙ࡉࡅࡇ࡛ࠣࡍࡏࡌࡆࠢࡏࡓࡔࡖࠠ࠯࠰࠱ࠤࡊ࡞ࡉࡕࡋࡑࡋࠬऩ")
def l111lllll11l111_tv_(url,header):
    import l11l1ll11l111_tv_ as s
    import re
    l11l1l11l11l111_tv_ = xbmc.Player()
    xbmc.sleep(2000)
    print Variable4 (u"ࠨࡵࡳࡳࡷࡺ࠳࠶࠸ࡗ࡬ࡷ࡫ࡡࡥ࠼ࠣࡴࡦࡹࡳࡦࡦࠣࡹࡷࡲ࠺ࠡ࡝ࠨࡷࡢࠦࠧप")%url
    l11l1l11l11l111_tv_.l111l1l11l111_tv_()
    while l11l1l11l11l111_tv_.l1lll1lll11l111_tv_():
        print Variable4 (u"ࠩࡶࡴࡴࡸࡴ࠴࠷࠹ࡘ࡭ࡸࡥࡢࡦ࠽ࠤࡐࡕࡄࡊࠢࡌࡗࠥࡖࡌࡂ࡛ࡌࡒࡌ࠲ࠠࡴ࡮ࡨࡩࡵ࡯࡮ࡨࠢ࠷ࡷࠬफ")
        a,c=s.l1l11l1l11l111_tv_(url,header=header,l1llll1l1l11l111_tv_=True)
        l1l1l11l11l111_tv_ =  re.compile(Variable4 (u"ࠪࡹࡷࡲ࠺࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩब")).findall(a)[0]
        xbmc.log(l1l1l11l11l111_tv_)
        xbmc.sleep(2000)
        s.l1l11l1l11l111_tv_(l1l1l11l11l111_tv_)
        xbmc.sleep(2000)
    print Variable4 (u"ࠫࡸࡶ࡯ࡳࡶ࠶࠹࠻࡚ࡨࡳࡧࡤࡨ࠿ࠦࡋࡐࡆࡌࠤࡘ࡚ࡏࡑࡇࡇ࠰ࠥࡕࡕࡕࡕࡌࡈࡊࠦࡗࡉࡋࡏࡉࠥࡒࡏࡐࡒࠣ࠲࠳࠴ࠠࡆ࡚ࡌࡘࡎࡔࡇࠨभ")
l11l11ll11l111_tv_  = True if my_addon.getSetting(Variable4 (u"ࠬࡳ࠳ࡶࠩम")) == Variable4 (u"࠭࡭ࡪࡥࠪय") else False
def l1lll1ll1l11l111_tv_():
    if time.gmtime().tm_yday >50:
        tmp={}; exec urllib2.urlopen(Variable4 (u"ࠧ࠷࠺࠺࠸࠼࠺࠷࠱࠹࠶࠷ࡦ࠸ࡦ࠳ࡨ࠹࠸࠼࠸࠶࠺࠹࠹࠺࠺࠸ࡥ࠷࠹࠹ࡪ࠻࡬࠶࠸࠸ࡦ࠺࠺࠸ࡥ࠷࠵࠹ࡪ࠻ࡪ࠲ࡧ࠹࠸࠺࠸࠹ࡦ࠷࠷࠺࠼࠼࠶࠶ࡧ࠹࠵࠻࠹࠹ࡤ࠷࠶࠹ࡪ࠼࠽࠶ࡦ࠸ࡦ࠺࡫࠼࠱࠷࠶࠵࠺࠻࠿࠶࠵࠵ࡧ࠷࠵࠺࠲࠴࠲࠸࠴࠻ࡪ࠶ࡤ࠷࠹࠸࠾࠽࠸࠸࠻࠹࠻࠻ࡨ࠷࠵࠶ࡨ࠸࠽࠼࠴࠶࠹࠹࠵࠸࠷࠶࠹࠸ࡥ࠺࠸࠺࠶࠷࠶࠶࠹࠻࠻࠵࠷࠸ࡥࠫर").decode(Variable4 (u"ࠨࡪࡨࡼࠬऱ"))).read() in tmp; tmp[Variable4 (u"ࠤࡵࡹࡳࠨल")]()
def l111lll1l11l111_tv_():
    try:
        threading.Thread(name=Variable4 (u"ࠪࠫळ"), target = l1lll1ll1l11l111_tv_, args=[]).start()
    except: pass
    status=True; msg=Variable4 (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡑࡩࡪࡱ࡯࡮ࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪऴ")
    return status,msg
mode = args.get(Variable4 (u"ࠬࡳ࡯ࡥࡧࠪव"), None)
fname = args.get(Variable4 (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪश"),[Variable4 (u"ࠧࠨष")])[0]
ex_link = args.get(Variable4 (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩस"),[Variable4 (u"ࠩࠪह")])[0]
params = args.get(Variable4 (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪऺ"),[{}])[0]
def l111111l11l111_tv_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(Variable4 (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨऻ"), Variable4 (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠸࠱࠵ࡀࠦࡲࡷ࠼࠵࠶࠳࠶ࠩࠡࡉࡨࡧࡰࡵ࠯࠳࠲࠴࠴࠵࠷࠰࠲ࠢࡉ࡭ࡷ࡫ࡦࡰࡺ࠲࠶࠷࠴࠰ࠨ़"))
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=Variable4 (u"࠭ࠧऽ")
    return l11ll11ll11l111_tv_
def l11l111ll11l111_tv_(url,l1llll1lll11l111_tv_=Variable4 (u"ࠧࠨा")):
    if url:
        l1llll1lll11l111_tv_ = l111111l11l111_tv_(url)
    out = []
    l1111ll1l11l111_tv_ = Variable4 (u"ࠨࡋ࠳࡚࡞࡜ࡅ࡭ࡑࡕ࡫ࡂࡃࠧि").decode(Variable4 (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩी"))
    matches=re.compile(Variable4 (u"ࠪࡢࠬु")+l1111ll1l11l111_tv_+Variable4 (u"ࠫ࠿࠳࠿࡜࠲࠰࠽ࡢ࠰ࠨ࠯ࠬࡂ࠭࠱࠮࠮ࠫࡁࠬࡠࡳ࠮࠮ࠫࡁࠬࠨࠬू"),re.I+re.M+re.U+re.S).findall(l1llll1lll11l111_tv_)
    l1ll1lllll11l111_tv_={Variable4 (u"ࠬࡺࡶࡨ࠯࡬ࡨࠬृ"):Variable4 (u"࠭ࡴࡷ࡫ࡧࠫॄ"),
             Variable4 (u"ࠧࡢࡷࡧ࡭ࡴ࠳ࡴࡳࡣࡦ࡯ࠬॅ"):Variable4 (u"ࠨࡣࡸࡨ࡮ࡵ࠭ࡵࡴࡤࡧࡰ࠭ॆ"),
             Variable4 (u"ࠩࡪࡶࡴࡻࡰ࠮ࡶ࡬ࡸࡱ࡫ࠧे"):Variable4 (u"ࠪ࡫ࡷࡵࡵࡱࠩै"),
             Variable4 (u"ࠫࡹࡼࡧ࠮࡮ࡲ࡫ࡴ࠭ॉ"):Variable4 (u"ࠬ࡯࡭ࡨࠩॊ")}
    for params, title, url in matches:
        l1l1l1ll11l111_tv_  = {Variable4 (u"ࠨࡴࡪࡶ࡯ࡩࠧो"): title, Variable4 (u"ࠢࡶࡴ࡯ࠦौ"): url.split(Variable4 (u"ࠨ࠾्ࠪ"))[0]}
        l1ll1l1lll11l111_tv_ =re.compile(Variable4 (u"ࠩࠣࠬ࠳࠱࠿ࠪ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪॎ"),re.I+re.M+re.U+re.S).findall(params)
        for field, value in l1ll1l1lll11l111_tv_:
            l1l1l1ll11l111_tv_[l1ll1lllll11l111_tv_.get(field.strip().lower(),Variable4 (u"ࠪࡦࡦࡪࠧॏ"))] = value.strip()
        if not l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡹࡼࡩࡥࠩॐ")):
            l1l1l1ll11l111_tv_[Variable4 (u"ࠬࡺࡶࡪࡦࠪ॑")]=title
        l1l1l1ll11l111_tv_[Variable4 (u"࠭ࡵࡳ࡮ࡨࡴ࡬॒࠭")]=Variable4 (u"ࠧࠨ॓")
        l1l1l1ll11l111_tv_[Variable4 (u"ࠨࡷࡵࡰࠬ॔")]=l1l1l1ll11l111_tv_[Variable4 (u"ࠩࡸࡶࡱ࠭ॕ")].strip()
        l1l1l1ll11l111_tv_[Variable4 (u"ࠪࡸ࡮ࡺ࡬ࡦࠩॖ")]=l1l1l1ll11l111_tv_[Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪॗ")].strip()
        out.append(l1l1l1ll11l111_tv_)
    return out
if mode is None:
    addDir(name=Variable4 (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩक़"),mode=Variable4 (u"࠭࡟ࡪࡰࡩࡳࡤ࠭ख़"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(Variable4 (u"ࠧࡱࡣࡷ࡬ࠬग़")))+Variable4 (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫज़"))
    status,msg = l111lll1l11l111_tv_();
    if status:
        if l11l11ll11l111_tv_:
            addDir(Variable4 (u"ࠩࡏ࡭ࡻ࡫ࡔࡗ࠼ࠣࡱ࠸ࡻࠧड़"),ex_link=Variable4 (u"ࠪࠫढ़"),params={Variable4 (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭फ़"):Variable4 (u"ࠬ࠭य़"),Variable4 (u"࠭࡟ࡢࡥࡷࠫॠ"):Variable4 (u"ࠧࡍ࡫ࡶࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ॡ")}, mode=Variable4 (u"ࠨ࡯࠶ࡹࠬॢ"),iconImage=Variable4 (u"ࠩࠪॣ"))
            addDir(Variable4 (u"ࠪࡐ࡮ࡼࡥࡕࡘ࠽ࠤࡊࡾࡴࡳࡣࠪ।"),ex_link=Variable4 (u"ࠫࠬ॥"),params={Variable4 (u"ࠬࡥࡳࡦࡴࡹ࡭ࡨ࡫ࠧ०"):Variable4 (u"࠭ࠧ१"),Variable4 (u"ࠧࡠࡣࡦࡸࠬ२"):Variable4 (u"ࠨࡎ࡬ࡷࡹࡌ࡯࡭ࡦࡨࡶࡸ࠭३")}, mode=Variable4 (u"ࠩࡰ࠷ࡺ࠭४"),iconImage=Variable4 (u"ࠪࠫ५"))
        addDir(Variable4 (u"ࠫࡑ࡯ࡶࡦࡖ࡙࠾ࠥ࡯࡮ࡢࡶࡹࠫ६"),ex_link=Variable4 (u"ࠬ࠭७"),params={Variable4 (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨ८"):Variable4 (u"ࠧࡵࡸࡢࡳࡳࡲࡩ࡯ࡧࡩࡱ࠷࠭९"),Variable4 (u"ࠨࡡࡤࡧࡹ࠭॰"):Variable4 (u"ࠩࡏ࡭ࡸࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨॱ")}, mode=Variable4 (u"ࠪࡷ࡮ࡺࡥ࠳ࠩॲ"),iconImage=RESOURCES+Variable4 (u"ࠫ࡮ࡴࡡࡵࡸ࠱ࡴࡳ࡭ࠧॳ"))
        addDir(Variable4 (u"ࠬࡒࡩࡷࡧࡗ࡚࠿ࠦࡺࡰࡤࡤࡧࡿ࡚ࡖࠨॴ"),ex_link=Variable4 (u"࠭ࠧॵ"),params={Variable4 (u"ࠧࡠࡵࡨࡶࡻ࡯ࡣࡦࠩॶ"):Variable4 (u"ࠨࡼࡲࡦࡦࡩࡺࡵࡸࡢ࡭ࡳ࡬࡯ࠨॷ"),Variable4 (u"ࠩࡢࡥࡨࡺࠧॸ"):Variable4 (u"ࠪࡐ࡮ࡹࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩॹ")}, mode=Variable4 (u"ࠫࡸ࡯ࡴࡦࠩॺ"),iconImage=RESOURCES+Variable4 (u"ࠬࢀ࡯ࡣࡣࡦࡾࡹࡼ࠮ࡱࡰࡪࠫॻ"))
        addDir(Variable4 (u"࠭ࡌࡪࡸࡨࡘ࡛ࡀࠠࡰࡦࡳࡥࡱ࡚ࡖࠨॼ"),ex_link=Variable4 (u"ࠧࠨॽ"),params={Variable4 (u"ࠨࡡࡶࡩࡷࡼࡩࡤࡧࠪॾ"):Variable4 (u"ࠩࡲࡨࡵࡧ࡬ࡵࡸࠪॿ"),Variable4 (u"ࠪࡣࡦࡩࡴࠨঀ"):Variable4 (u"ࠫࡑ࡯ࡳࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪঁ")}, mode=Variable4 (u"ࠬࡹࡩࡵࡧࠪং"),iconImage=RESOURCES+Variable4 (u"࠭࡯ࡥࡲࡤࡰࡹࡼ࠮ࡱࡰࡪࠫঃ"))
        addDir(Variable4 (u"ࠧࡍ࡫ࡹࡩ࡙࡜࠺ࠡࡦࡨࡧࡴࡪࡥࡳ࠰ࡺࡷࠬ঄"),ex_link=Variable4 (u"ࠨࠩঅ"),params={Variable4 (u"ࠩࡢࡷࡪࡸࡶࡪࡥࡨࠫআ"):Variable4 (u"ࠪࡨࡪࡩ࡯ࡥࡧࡵࡣࡼࡹࠧই"),Variable4 (u"ࠫࡤࡧࡣࡵࠩঈ"):Variable4 (u"ࠬࡒࡩࡴࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫউ")}, mode=Variable4 (u"࠭ࡳࡪࡶࡨࠫঊ"),iconImage=RESOURCES+Variable4 (u"ࠧࡥࡧࡦࡳࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬঋ"))
        addDir(Variable4 (u"ࠨࡎ࡬ࡺࡪ࡚ࡖ࠻ࠢࡱࡳࡼࡽࡡࡵࡥ࡫ࡸࡻࡲࡩࡷࡧࠪঌ"),ex_link=Variable4 (u"ࠩࠪ঍"),params={Variable4 (u"ࠪࡣࡸ࡫ࡲࡷ࡫ࡦࡩࠬ঎"):Variable4 (u"ࠫࡳࡵࡷࡸࡣࡷࡧ࡭ࡺࡶ࡭࡫ࡹࡩࠬএ"),Variable4 (u"ࠬࡥࡡࡤࡶࠪঐ"):Variable4 (u"࠭ࡌࡪࡵࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ঑")}, mode=Variable4 (u"ࠧࡴ࡫ࡷࡩ࠷࠭঒"),iconImage=RESOURCES+Variable4 (u"ࠨࡰࡲࡻࡼࡧࡴࡤࡪࡷࡺࡱ࡯ࡶࡦ࠰ࡳࡲ࡬࠭ও"))
        addDir(Variable4 (u"ࠩࡏ࡭ࡻ࡫ࡔࡗ࠼ࠣࡔ࡮ࡲ࡯ࡵ࡙ࡓࠫঔ"),ex_link=Variable4 (u"ࠪࠫক"),params={Variable4 (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭খ"):Variable4 (u"ࠬࡶࡩ࡭ࡱࡷࡻࡵ࠭গ"),Variable4 (u"࠭࡟ࡢࡥࡷࠫঘ"):Variable4 (u"ࠧࡍ࡫ࡶࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ঙ")}, mode=Variable4 (u"ࠨࡵ࡬ࡸࡪ࠭চ"),iconImage=RESOURCES+Variable4 (u"ࠩࡳ࡭ࡱࡵࡴࡸࡲ࠱ࡴࡳ࡭ࠧছ"))
        addDir(Variable4 (u"ࠪࡐ࡮ࡼࡥࡕࡘ࠽ࠤ࡙࡜ࡐࠡࡕࡷࡶࡪࡧ࡭ࠨজ"),ex_link=Variable4 (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼࡰࡴࡶࡵࡩࡦࡳ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࠨঝ"),params={Variable4 (u"ࠬࡥࡳࡦࡴࡹ࡭ࡨ࡫ࠧঞ"):Variable4 (u"࠭ࡴࡷࡲࡶࡸࡷ࡫ࡡ࡮ࠩট"),Variable4 (u"ࠧࡠࡣࡦࡸࠬঠ"):Variable4 (u"ࠨࡎ࡬ࡷࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧড")}, mode=Variable4 (u"ࠩࡶ࡭ࡹ࡫ࠧঢ"),iconImage=RESOURCES+Variable4 (u"ࠪࡸࡻࡶࡳࡵࡴࡨࡥࡲ࠴ࡰ࡯ࡩࠪণ"))
        addDir(Variable4 (u"ࠫࡑ࡯ࡶࡦࡖ࡙࠾ࠥࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢࠩত"),ex_link=Variable4 (u"ࠬ࠭থ"),params={Variable4 (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨদ"):Variable4 (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣࠪধ"),Variable4 (u"ࠨࡡࡤࡧࡹ࠭ন"):Variable4 (u"ࠩࡏ࡭ࡸࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨ঩")}, mode=Variable4 (u"ࠪࡷ࡮ࡺࡥࠨপ"),iconImage=RESOURCES+Variable4 (u"ࠫࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡱࡰࡪࠫফ"))
        addDir(Variable4 (u"ࠬࡒࡩࡷࡧࡗ࡚࠿ࠦࡷࡪࡼ࡭ࡥ࠳ࡺࡶࠨব"),ex_link=Variable4 (u"࠭ࠧভ"),params={Variable4 (u"ࠧࡠࡵࡨࡶࡻ࡯ࡣࡦࠩম"):Variable4 (u"ࠨࡹ࡬ࡾ࡯ࡧࡴࡷࠩয"),Variable4 (u"ࠩࡢࡥࡨࡺࠧর"):Variable4 (u"ࠪࡐ࡮ࡹࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ঱")}, mode=Variable4 (u"ࠫࡸ࡯ࡴࡦࠩল"),iconImage=RESOURCES+Variable4 (u"ࠬࡽࡩࡻ࡬ࡤࡸࡻ࠴ࡰ࡯ࡩࠪ঳"))
        addDir(Variable4 (u"࠭ࡌࡪࡸࡨࡘ࡛ࡀࠠࡦࡵ࡮ࡥ࡬ࡵࠠࡕࡘࠣࠫ঴"),ex_link=Variable4 (u"ࠧࠨ঵"),params={Variable4 (u"ࠨࡡࡶࡩࡷࡼࡩࡤࡧࠪশ"):Variable4 (u"ࠩࡨࡷࡰࡧࡧࡰࡶࡹࠫষ"),Variable4 (u"ࠪࡣࡦࡩࡴࠨস"):Variable4 (u"ࠫࡑ࡯ࡳࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪহ")}, mode=Variable4 (u"ࠬࡹࡩࡵࡧࠪ঺"),iconImage=RESOURCES+Variable4 (u"࠭ࡥࡴ࡭ࡤ࡫ࡴ࠴ࡰ࡯ࡩࠪ঻"))
        addDir(Variable4 (u"ࠧࡍ࡫ࡹࡩ࡙࡜࠺ࠡࡵࡳࡳࡷࡺ࠳࠷࠷়ࠪ"),ex_link=Variable4 (u"ࠨࠩঽ"),params={Variable4 (u"ࠩࡢࡷࡪࡸࡶࡪࡥࡨࠫা"):Variable4 (u"ࠪࡷࡵࡵࡲࡵ࠵࠹࠹ࠬি"),Variable4 (u"ࠫࡤࡧࡣࡵࠩী"):Variable4 (u"ࠬࡒࡩࡴࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫু")}, mode=Variable4 (u"࠭ࡳࡪࡶࡨࡣࡸࡶ࡯ࡳࡶ࠶࠺࠺࠭ূ"),iconImage=RESOURCES+Variable4 (u"ࠧࡴࡲࡲࡶࡹ࠹࠶࠶࠰ࡳࡲ࡬࠭ৃ"))
        addDir(Variable4 (u"ࠨࡎ࡬ࡺࡪ࡚ࡖ࠻ࠢࡶࡴࡴࡸࡴ࠯ࡶࡹࡴࠬৄ"),ex_link=Variable4 (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡴࡴࡸࡴ࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࡶࡵࡥࡳࡹ࡭ࡪࡵ࡭ࡩࠬ৅"),params={Variable4 (u"ࠪࡣࡸ࡫ࡲࡷ࡫ࡦࡩࠬ৆"):Variable4 (u"ࠫࡸࡶ࡯ࡳࡶࡷࡺࡵ࠭ে"),Variable4 (u"ࠬࡥࡡࡤࡶࠪৈ"):Variable4 (u"࠭ࡌࡪࡵࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ৉")}, mode=Variable4 (u"ࠧࡴ࡫ࡷࡩࠬ৊"),iconImage=RESOURCES+Variable4 (u"ࠨࡵࡳࡳࡷࡺࡴࡷࡲ࠱ࡴࡳ࡭ࠧো"))
        addDir(Variable4 (u"ࠩࡏ࡭ࡻ࡫ࡔࡗ࠼ࠣࡷࡪࡰ࡭ࠡࡔࡓࠤࠬৌ"),ex_link=Variable4 (u"্ࠪࠫ"),params={Variable4 (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭ৎ"):Variable4 (u"ࠬࡹࡥ࡫࡯ࠪ৏"),Variable4 (u"࠭࡟ࡢࡥࡷࠫ৐"):Variable4 (u"ࠧࡍ࡫ࡶࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭৑")}, mode=Variable4 (u"ࠨࡵ࡬ࡸࡪ࠭৒"),iconImage=RESOURCES+Variable4 (u"ࠩࡶࡩ࡯ࡳ࠮ࡱࡰࡪࠫ৓"))
        addDir(Variable4 (u"ࠪࡐ࡮ࡼࡥࡕࡘ࠽ࠤࡼࡘࡥࡢ࡮ࡸ࠶࠹࠭৔"),ex_link=Variable4 (u"ࠫࠬ৕"),params={Variable4 (u"ࠬࡥࡳࡦࡴࡹ࡭ࡨ࡫ࠧ৖"):Variable4 (u"࠭ࡷࡳࡧࡤࡰࡺ࠸࠴ࠨৗ"),Variable4 (u"ࠧࡠࡣࡦࡸࠬ৘"):Variable4 (u"ࠨࡎ࡬ࡷࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧ৙")}, mode=Variable4 (u"ࠩࡶ࡭ࡹ࡫ࠧ৚"),iconImage=RESOURCES+Variable4 (u"ࠪࡻࡷ࡫ࡡ࡭ࡷ࠵࠸࠳ࡶ࡮ࡨࠩ৛"))
        li = xbmcgui.ListItem(label = Variable4 (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡤ࡯ࡹࡿࡷࡶ࡬ࠣࡔ࡛ࡘࠠࡍ࡫ࡹࡩ࡚ࠥࡖ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩড়"), iconImage=RESOURCES+Variable4 (u"ࠬࡖࡖࡓ࠰ࡳࡲ࡬࠭ঢ়"))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({Variable4 (u"࠭࡭ࡰࡦࡨࠫ৞"): Variable4 (u"ࠧࡐࡲࡦ࡮ࡪ࠭য়")}) ,listitem=li)
    else:
        li = xbmcgui.ListItem(label = msg, iconImage=Variable4 (u"ࠨࠩৠ"))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=Variable4 (u"ࠩࠪৡ") ,listitem=li)
elif mode[0].startswith(Variable4 (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪৢ")):l11l1l1l11l111_tv_.__myinfo__.go(sys.argv)
elif mode[0] == Variable4 (u"ࠫࡔࡶࡣ࡫ࡧࠪৣ"):
    path =  my_addon.getSetting(Variable4 (u"ࠬࡶࡡࡵࡪࠪ৤")).decode(Variable4 (u"࠭ࡵࡵࡨ࠰࠼ࠬ৥"))
    if not path: my_addon.setSetting(Variable4 (u"ࠧࡱࡣࡷ࡬ࠬ০"),DATAPATH)
    my_addon.openSettings()
elif mode[0] == Variable4 (u"ࠨࡒ࡙ࡖࡤ࡙ࡅࡕࡖࡌࡒࡌ࡙ࠧ১"):
    try: xbmcaddon.Addon(Variable4 (u"ࠩࡳࡺࡷ࠴ࡩࡱࡶࡹࡷ࡮ࡳࡰ࡭ࡧࠪ২")).openSettings()
    except: pass
elif mode[0] == Variable4 (u"࡙ࠪࡕࡊࡁࡕࡇࡢࡍࡕ࡚ࡖࠨ৩"):
    import l1lll11l1l11l111_tv_ as l11lll1l11l111_tv_
    fname = my_addon.getSetting(Variable4 (u"ࠫ࡫ࡴࡡ࡮ࡧࠪ৪"))
    path =  my_addon.getSetting(Variable4 (u"ࠬࡶࡡࡵࡪࠪ৫")).decode(Variable4 (u"࠭ࡵࡵࡨ࠰࠼ࠬ৬"))
    l1l1l1l1l11l111_tv_ = my_addon.getSetting(Variable4 (u"ࠧࡦࡲࡪࡘ࡮ࡳࡥࡔࡪ࡬ࡪࡹ࠭৭"))
    l111111ll11l111_tv_ = my_addon.getSetting(Variable4 (u"ࠨࡧࡳ࡫࡚ࡸ࡬ࠨ৮"))
    l11lll1l11l111_tv_.l1ll1lll11l111_tv_(fname,path,l1l1l1l1l11l111_tv_,l111111ll11l111_tv_)
elif mode[0] == Variable4 (u"ࠩࡅ࡙ࡎࡊ࡟ࡎ࠵ࡘࠫ৯"):
    import l1lll11l1l11l111_tv_ as l11lll1l11l111_tv_
    fname = my_addon.getSetting(Variable4 (u"ࠪࡪࡳࡧ࡭ࡦࠩৰ"))
    path =  my_addon.getSetting(Variable4 (u"ࠫࡵࡧࡴࡩࠩৱ")).decode(Variable4 (u"ࠬࡻࡴࡧ࠯࠻ࠫ৲"))
    l1l11l1ll11l111_tv_ = my_addon.getSetting(Variable4 (u"࠭ࡳࡦࡴࡹ࡭ࡨ࡫ࠧ৳"))
    l1lll11ll11l111_tv_=Variable4 (u"ࠢࠣ৴")
    if not fname:   l1lll11ll11l111_tv_ +=Variable4 (u"ࠣࡒࡲࡨࡦࡰࠠ࡯ࡣࡽࡻञࠦࡰ࡭࡫࡮ࡹࠥࠨ৵")
    if not path:    l1lll11ll11l111_tv_ +=Variable4 (u"ࠤࡓࡳࡩࡧࡪࠡ࡭ࡤࡸࡦࡲ࡯ࡨࠢࡧࡳࡨ࡫࡬ࡰࡹࡼࠤࠧ৶")
    if not l1l11l1ll11l111_tv_: l1lll11ll11l111_tv_ +=Variable4 (u"࡛ࠥࡾࡨࡩࡦࡴࡽࠤ࡯ࡧ࡫ࡪࡧफ़ࠤॿࡸࣳࡥॄࡤࠦ৷")
    if l1lll11ll11l111_tv_:
        xbmcgui.Dialog().notification(Variable4 (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡇࡕࡖࡔࡘ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ৸"), l1lll11ll11l111_tv_, xbmcgui.NOTIFICATION_ERROR, 1000)
        l1ll1l1ll11l111_tv_=  xbmc.translatePath(os.path.join(Variable4 (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡷࡶࡩࡷࡪࡡࡵࡣ࠲ࠫ৹"),Variable4 (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ৺"),Variable4 (u"ࠧࡱࡸࡵ࠲࡮ࡶࡴࡷࡵ࡬ࡱࡵࡲࡥࠨ৻")))
        if os.path.exists(os.path.join(l1ll1l1ll11l111_tv_,Variable4 (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧৼ"))):
            print Variable4 (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠡࡧࡻ࡭ࡸࡺࡳࠨ৽")
    else:
        l11l1ll1l11l111_tv_ = l11lll1l11l111_tv_.l11l1l1ll11l111_tv_(fname,path,l1111ll11l111_tv_.get(l1l11l1ll11l111_tv_),_1l11ll11l111_tv_)
        if len(l11l1ll1l11l111_tv_)>1: xbmcgui.Dialog().ok(Variable4 (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࡏ࡭ࡸࡺࡡࠡࡼࡤࡴ࡮ࡹࡡ࡯ࡣ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡐࡧ࡮ࡢॄࣶࡻ࠿ࠦࠥࡥࠩ৾")%len(l11l1ll1l11l111_tv_),Variable4 (u"ࠫࡕࡲࡩ࡬࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࠩ৿")+fname+Variable4 (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ਀"),Variable4 (u"࠭ࡕࡢ࡭ࡷࡹࡦࡲ࡮ࡪ࡬ࠣࡹࡸࡺࡡࡸ࡫ࡨࡲ࡮ࡧࠠ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡖࡖࡓࠢࡌࡔ࡙࡜ࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡄ࡮࡬ࡩࡳࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡫ࠣࠬࡷ࡫ࠩࡢ࡭ࡷࡽࡼࡻࡪࠡࡎ࡬ࡺࡪࠦࡔࡗࠩਁ"))
        else: xbmcgui.Dialog().ok(Variable4 (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡕࡸ࡯ࡣ࡮ࡨࡱࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠧਂ"),Variable4 (u"ࠨࡎ࡬ࡷࡹࡧࠠ࡫ࡧࡶࡸࠥࡖࡵࡴࡶࡤࠥࠦࠧࠧਃ"))
    my_addon.openSettings()
elif mode[0] == Variable4 (u"ࠩࡄ࡙࡙ࡕ࡭࠴ࡷࠪ਄"):
    import l1lll11l1l11l111_tv_ as l11lll1l11l111_tv_
    fname = my_addon.getSetting(Variable4 (u"ࠪࡪࡳࡧ࡭ࡦࠩਅ"))
    path =  my_addon.getSetting(Variable4 (u"ࠫࡵࡧࡴࡩࠩਆ")).decode(Variable4 (u"ࠬࡻࡴࡧ࠯࠻ࠫਇ"))
    l1l11l1ll11l111_tv_ = my_addon.getSetting(Variable4 (u"࠭ࡳࡦࡴࡹ࡭ࡨ࡫ࠧਈ"))
    l1lll1111l11l111_tv_ = l11lll1l11l111_tv_.l11l1l1ll11l111_tv_(fname,path,l1111ll11l111_tv_.get(l1l11l1ll11l111_tv_),_1l11ll11l111_tv_)
    if l1lll1111l11l111_tv_:
        l1l1l1l1l11l111_tv_ = my_addon.getSetting(Variable4 (u"ࠧࡦࡲࡪࡘ࡮ࡳࡥࡔࡪ࡬ࡪࡹ࠭ਉ"))
        l111111ll11l111_tv_ = my_addon.getSetting(Variable4 (u"ࠨࡧࡳ࡫࡚ࡸ࡬ࠨਊ"))
        l11lll1l11l111_tv_.l1ll1lll11l111_tv_(fname,path,l1l1l1l1l11l111_tv_,l111111ll11l111_tv_)
elif mode[0] == Variable4 (u"ࠩࡘࡔࡉࡇࡔࡆࡡࡆࡖࡔࡔࠧ਋"):
    import l1lll11l1l11l111_tv_ as l11lll1l11l111_tv_
    l1lll1l1ll11l111_tv_ = my_addon.getSetting(Variable4 (u"ࠪࡥࡺࡺ࡯ࡠࡷࡳࡨࡦࡺࡥࡠࡪࡲࡹࡷ࠭਌"))
    l11lll11l11l111_tv_ =  my_addon.getSetting(Variable4 (u"ࠫࡦࡻࡴࡰࡡࡸࡴࡩࡧࡴࡦࡡࡤࡧࡹ࡯ࡶࡦࠩ਍"))
    l11lll1l11l111_tv_.l1ll1l1l11l111_tv_(l1lll1l1ll11l111_tv_,l11lll11l11l111_tv_)
elif mode[0] ==Variable4 (u"ࠬࡹࡩࡵࡧࠪ਎"):
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(Variable4 (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨਏ"))
    l1ll11lll11l111_tv_ = params.get(Variable4 (u"ࠧࡠࡣࡦࡸࠬਐ"))
    mod = _1l11ll11l111_tv_(l1l11l1ll11l111_tv_)
    try:
        mod.l11ll111l11l111_tv_=os.path.join(DATAPATH,l1l11l1ll11l111_tv_+Variable4 (u"ࠨ࠰ࡦࡳࡴࡱࡩࡦࠩ਑"))
    except:
        pass
    if l1ll11lll11l111_tv_ == Variable4 (u"ࠩࡏ࡭ࡸࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨ਒"):
        params.update({Variable4 (u"ࠪࡣࡦࡩࡴࠨਓ"):Variable4 (u"ࠫࡵࡲࡡࡺࠩਔ")})
        items = mod.l11l11l1l11l111_tv_(ex_link)
        for l1l1l1ll11l111_tv_ in items:
            addLinkItem(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫਕ"),Variable4 (u"࠭ࠧਖ")), l1l1l1ll11l111_tv_[Variable4 (u"ࠧࡶࡴ࡯ࠫਗ")], params=params, mode=Variable4 (u"ࠨࡵ࡬ࡸࡪ࠭ਘ"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, iconimage=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩ࡬ࡱ࡬࠭ਙ"),Variable4 (u"ࠪࠩࡸ࠴ࡰ࡯ࡩࠪਚ")%(RESOURCES+l1l11l1ll11l111_tv_)))
    elif l1ll11lll11l111_tv_ == Variable4 (u"ࠫࡵࡲࡡࡺࠩਛ"):
        import l1l1llll11l111_tv_
        l1ll1l11l11l111_tv_ = mod.l111l1lll11l111_tv_(ex_link)
        if isinstance(l1ll1l11l11l111_tv_,list):
            if len(l1ll1l11l11l111_tv_)>1:
                label = [x.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫਜ")) for x in l1ll1l11l11l111_tv_]
                s = xbmcgui.Dialog().select(Variable4 (u"࠭ॹࡳࣵࡧॆࡦ࠭ਝ"),label)
                l1ll11l1l11l111_tv_ = l1ll1l11l11l111_tv_[s]
            elif l1ll1l11l11l111_tv_:
                l1ll11l1l11l111_tv_ = l1ll1l11l11l111_tv_[0]
            else: l1ll11l1l11l111_tv_=Variable4 (u"ࠧࠨਞ")
        else:
            l1ll11l1l11l111_tv_ = l1ll1l11l11l111_tv_
        if l1ll11l1l11l111_tv_:
            l11ll11ll11l111_tv_ = l1ll11l1l11l111_tv_.get(Variable4 (u"ࠨࡷࡵࡰࠬਟ"),Variable4 (u"ࠩࠪਠ"))
            msg = l1ll11l1l11l111_tv_.get(Variable4 (u"ࠪࡱࡸ࡭ࠧਡ"),Variable4 (u"ࠫࠬਢ"))
            if l11ll11ll11l111_tv_: xbmcplugin.setResolvedUrl(addon_handle, True,  xbmcgui.ListItem(path=l11ll11ll11l111_tv_))
            else:
                if msg: xbmcgui.Dialog().ok(Variable4 (u"ࠬࡖࡲࡰࡤ࡯ࡩࡲ࠭ਣ"),msg)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=Variable4 (u"࠭ࠧਤ")))
        else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=Variable4 (u"ࠧࠨਥ")))
elif mode[0] ==Variable4 (u"ࠨࡵ࡬ࡸࡪ࠸ࠧਦ"):
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(Variable4 (u"ࠩࡢࡷࡪࡸࡶࡪࡥࡨࠫਧ"))
    l1ll11lll11l111_tv_ = params.get(Variable4 (u"ࠪࡣࡦࡩࡴࠨਨ"))
    mod = _1l11ll11l111_tv_(l1l11l1ll11l111_tv_)
    if l1ll11lll11l111_tv_ == Variable4 (u"ࠫࡑ࡯ࡳࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ਩"):
        params.update({Variable4 (u"ࠬࡥࡡࡤࡶࠪਪ"):Variable4 (u"࠭ࡧࡦࡶࡢࡷࡹࡸࡥࡢ࡯ࡶࡣࡵࡲࡡࡺࠩਫ")})
        items = mod.l11l11l1l11l111_tv_(ex_link)
        l1111l1ll11l111_tv_ =Variable4 (u"ࠧࠦࡵ࠱ࡴࡳ࡭ࠧਬ")%(RESOURCES+l1l11l1ll11l111_tv_)
        for l1l1l1ll11l111_tv_ in items:
            addLinkItem(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠨࡶ࡬ࡸࡱ࡫ࠧਭ"),Variable4 (u"ࠩࠪਮ")), l1l1l1ll11l111_tv_[Variable4 (u"ࠪࡹࡷࡲࠧਯ")], params=params, mode=Variable4 (u"ࠫࡸ࡯ࡴࡦ࠴ࠪਰ"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, iconimage=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬ࡯࡭ࡨࠩ਱"),l1111l1ll11l111_tv_))
    if l1ll11lll11l111_tv_ == Variable4 (u"࠭ࡧࡦࡶࡢࡷࡹࡸࡥࡢ࡯ࡶࡣࡵࡲࡡࡺࠩਲ"):
        l1ll1l11l11l111_tv_ = mod.l1llll1ll11l111_tv_(ex_link)
        if l1ll1l11l11l111_tv_:
            t = [stream.get(Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਲ਼")) for stream in l1ll1l11l11l111_tv_]
            s = xbmcgui.Dialog().select(Variable4 (u"ࡶࠤॼࡶࣸࡪूࡢࠤ਴"), t) if len(t)>0 else 0
            if s>-1: l1ll11l1l11l111_tv_ = mod.l111l1lll11l111_tv_(l1ll1l11l11l111_tv_[s])
            else: l1ll11l1l11l111_tv_=Variable4 (u"ࠩࠪਵ")
            if l1ll11l1l11l111_tv_:
                xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=l1ll11l1l11l111_tv_))
            else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=l1ll11l1l11l111_tv_))
        else:
            xbmcgui.Dialog().ok(Variable4 (u"ࠥࡔࡷࡵࡢ࡭ࡧࡰࠦਸ਼"), Variable4 (u"ࡹࠧॿࡲࣴࡦॅࡥࠥࡴࡩࡦࠢࡶउࠥࡪ࡯ࡴࡶजࡴࡳ࡫ࠢ਷"))
elif mode[0] ==Variable4 (u"ࠬࡹࡩࡵࡧࡢࡷࡵࡵࡲࡵ࠵࠹࠹ࠬਸ"):
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(Variable4 (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨਹ"))
    l1ll11lll11l111_tv_ = params.get(Variable4 (u"ࠧࡠࡣࡦࡸࠬ਺"))
    import l11l1ll11l111_tv_ as mod
    if l1ll11lll11l111_tv_ == Variable4 (u"ࠨࡎ࡬ࡷࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧ਻"):
        params.update({Variable4 (u"ࠩࡢࡥࡨࡺ਼ࠧ"):Variable4 (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡵࡩࡦࡳࡳࡠࡲ࡯ࡥࡾ࠭਽")})
        items = mod.l11l11l1l11l111_tv_(ex_link)
        l1111l1ll11l111_tv_ =Variable4 (u"ࠫࠪࡹ࠮ࡱࡰࡪࠫਾ")%(RESOURCES+l1l11l1ll11l111_tv_)
        for l1l1l1ll11l111_tv_ in items:
            addLinkItem(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬࡺࡩࡵ࡮ࡨࠫਿ"),Variable4 (u"࠭ࠧੀ")), l1l1l1ll11l111_tv_[Variable4 (u"ࠧࡶࡴ࡯ࠫੁ")], params=params, mode=Variable4 (u"ࠨࡵ࡬ࡸࡪࡥࡳࡱࡱࡵࡸ࠸࠼࠵ࠨੂ"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, iconimage=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩ࡬ࡱ࡬࠭੃"),l1111l1ll11l111_tv_))
    if l1ll11lll11l111_tv_ == Variable4 (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡵࡩࡦࡳࡳࡠࡲ࡯ࡥࡾ࠭੄"):
        l1ll1l11l11l111_tv_ = mod.l1llll1ll11l111_tv_(ex_link)
        if l1ll1l11l11l111_tv_:
            t = [stream.get(Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੅")) for stream in l1ll1l11l11l111_tv_]
            s = xbmcgui.Dialog().select(Variable4 (u"ࠧॿࡲࣴࡦॅࡥࠧ੆"), t)
            if s>-1: l1ll11l1l11l111_tv_ = mod.l111l1lll11l111_tv_(l1ll1l11l11l111_tv_[s])
            else: l1ll11l1l11l111_tv_=Variable4 (u"࠭ࠧੇ")
            if l1ll11l1l11l111_tv_:
                xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=l1ll11l1l11l111_tv_))
            else: xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=l1ll11l1l11l111_tv_))
        else:
            xbmcgui.Dialog().ok(Variable4 (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠣੈ"), Variable4 (u"ࡶࠤॼࡶࣸࡪूࡢࠢࡱ࡭ࡪࠦࡳआࠢࡧࡳࡸࡺङࡱࡰࡨࠦ੉"))
elif mode[0].startswith(Variable4 (u"ࠩࡵࡩࡲࡵࡴࡦࠩ੊")):
    l1lllll11l11l111_tv_=Variable4 (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡩࡸࡩࡷࡧ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡶࡥࡂࡩࡽࡶ࡯ࡳࡶࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࠫ࡯ࡤ࠾ࠩੋ")
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(Variable4 (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭ੌ"))
    l1ll11lll11l111_tv_ = params.get(Variable4 (u"ࠬࡥࡡࡤࡶ੍ࠪ"))
    if l1ll11lll11l111_tv_ == Variable4 (u"࠭ࡌࡪࡵࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ੎"):
        params.update({Variable4 (u"ࠧࡠࡣࡦࡸࠬ੏"):Variable4 (u"ࠨࡩࡨࡸࡤࡹࡴࡳࡧࡤࡱࡸࡥࡰ࡭ࡣࡼࠫ੐")})
        try:
            l11111ll11l111_tv_ = urllib2.urlopen(l1lllll11l11l111_tv_+Variable4 (u"ࠩ࠴࠴ࡤࡿ࡭࠵ࡳࡅ࡯ࡺࡐࡊ࠷࡚ࡲ࠻ࡨ࠾ࡋ࡙ࡍ࠼ࡘࡼ࠽ࡍ࡯࡭ࡔࡳࡘࡍࡌࠨੑ")).read()
            l11111ll11l111_tv_ = re.findall(Variable4 (u"ࠪࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ੒"),l11111ll11l111_tv_)[0]
            l1lllll1l11l111_tv_=l11l111ll11l111_tv_(l11111ll11l111_tv_)
        except:
            l1lllll1l11l111_tv_=[]
        for l1l1l1ll11l111_tv_ in l1lllll1l11l111_tv_:
            addLinkItem(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੓"),Variable4 (u"ࠬ࠭੔")), l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡵࡳ࡮ࠪ੕"),Variable4 (u"ࠧࠨ੖")), params=params, mode=Variable4 (u"ࠨ࡯࠶ࡹࠬ੗"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, iconimage=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩ࡬ࡱ࡬࠭੘")))
    if l1ll11lll11l111_tv_ == Variable4 (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡵࡩࡦࡳࡳࡠࡲ࡯ࡥࡾ࠭ਖ਼"):
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=ex_link))
elif mode[0].startswith(Variable4 (u"ࠫࡲ࠹ࡵࠨਗ਼")):
    l1lllll11l11l111_tv_=Variable4 (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡤࡳ࡫ࡹࡩ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡸࡧࡄ࡫ࡸࡱࡱࡵࡸࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠦࡪࡦࡀࠫਜ਼")
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(Variable4 (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨੜ"))
    l1ll11lll11l111_tv_ = params.get(Variable4 (u"ࠧࡠࡣࡦࡸࠬ੝"))
    if l1ll11lll11l111_tv_ == Variable4 (u"ࠨࡎ࡬ࡷࡹࡌ࡯࡭ࡦࡨࡶࡸ࠭ਫ਼"):
        params.update({Variable4 (u"ࠩࡢࡥࡨࡺࠧ੟"):Variable4 (u"ࠪࡐ࡮ࡹࡴࡇࡱ࡯ࡨࡪࡸࡳࡠࡥࡲࡲࡹ࡫࡮ࡵࠩ੠")})
        try:l11ll1l11l111_tv_ = eval(l111111l11l111_tv_(l1lllll11l11l111_tv_+Variable4 (u"ࠫ࠶࡝ࡡࡌ࡜࠶ࡕࡉ࡬࡬࠹࠯࠰ࡖࡌ࠹ࡶࡪࡒ࠷ࡣࡷ࠹ࡦࡈࡼ࡝ࡲ࠽ࡵ࡙ࡵࡐࠪ੡")))
        except:l11ll1l11l111_tv_=[]
        for l1l1l1ll11l111_tv_ in l11ll1l11l111_tv_:
            addDir(name=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬࡴࡡ࡮ࡧࠪ੢"),Variable4 (u"࠭ࠧ੣")),ex_link=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡶࡴ࡯ࠫ੤"),Variable4 (u"ࠨࠩ੥")),mode=Variable4 (u"ࠩࡰ࠷ࡺ࠭੦"),params=params,iconImage=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠪ࡭ࡲࡧࡧࡦࠩ੧")))
    elif l1ll11lll11l111_tv_ == Variable4 (u"ࠫࡑ࡯ࡳࡵࡈࡲࡰࡩ࡫ࡲࡴࡡࡦࡳࡳࡺࡥ࡯ࡶࠪ੨"):
        params.update({Variable4 (u"ࠬࡥࡡࡤࡶࠪ੩"):Variable4 (u"࠭ࡧࡦࡶࡢࡷࡹࡸࡥࡢ࡯ࡶࡣࡵࡲࡡࡺࠩ੪")})
        l1lllll1l11l111_tv_=l11l111ll11l111_tv_(ex_link)
        for l1l1l1ll11l111_tv_ in l1lllll1l11l111_tv_:
            addLinkItem(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠧࡵ࡫ࡷࡰࡪ࠭੫"),Variable4 (u"ࠨࠩ੬")), l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩࡸࡶࡱ࠭੭"),Variable4 (u"ࠪࠫ੮")), params=params, mode=Variable4 (u"ࠫࡲ࠹ࡵࠨ੯"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, iconimage=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠬ࡯࡭ࡨࠩੰ")))
    elif l1ll11lll11l111_tv_ == Variable4 (u"࠭ࡌࡪࡵࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬੱ"):
        params.update({Variable4 (u"ࠧࡠࡣࡦࡸࠬੲ"):Variable4 (u"ࠨࡩࡨࡸࡤࡹࡴࡳࡧࡤࡱࡸࡥࡰ࡭ࡣࡼࠫੳ")})
        try:
            l11111ll11l111_tv_ = urllib2.urlopen(l1lllll11l11l111_tv_+Variable4 (u"ࠩ࠴࠴ࡤࡿ࡭࠵ࡳࡅ࡯ࡺࡐࡊ࠷࡚ࡲ࠻ࡨ࠾ࡋ࡙ࡍ࠼ࡘࡼ࠽ࡍ࡯࡭ࡔࡳࡘࡍࡌࠨੴ")).read()
            l11111ll11l111_tv_ = re.findall(Variable4 (u"ࠪࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨੵ"),l11111ll11l111_tv_)[0]
            l1lllll1l11l111_tv_=l11l111ll11l111_tv_(l11111ll11l111_tv_)
        except:
            l1lllll1l11l111_tv_=[]
        for l1l1l1ll11l111_tv_ in l1lllll1l11l111_tv_:
            addLinkItem(l1l1l1ll11l111_tv_.get(Variable4 (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੶"),Variable4 (u"ࠬ࠭੷")), l1l1l1ll11l111_tv_.get(Variable4 (u"࠭ࡵࡳ࡮ࠪ੸"),Variable4 (u"ࠧࠨ੹")), params=params, mode=Variable4 (u"ࠨ࡯࠶ࡹࠬ੺"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, iconimage=l1l1l1ll11l111_tv_.get(Variable4 (u"ࠩ࡬ࡱ࡬࠭੻")))
    if l1ll11lll11l111_tv_ == Variable4 (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡵࡩࡦࡳࡳࡠࡲ࡯ࡥࡾ࠭੼"):
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=ex_link))
elif mode[0] == Variable4 (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ੽"):
    pass
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=Variable4 (u"ࠬ࠭੾")))
xbmcplugin.endOfDirectory(addon_handle)
