# -*- coding: utf-8 -*-
"""
Created on Tue Jan 05 19:15:01 2016

@author: ramic
"""

print 'makem3u'
#http://localhost/jsonrpc?request={%22jsonrpc%22:%222.0%22,%22method%22:%22Addons.ExecuteAddon%22,%22params%22:{%22addonid%22:%22plugin.video.LivePolishTV%22,%22params%22:[%22mode=TEST%22]},%22id%22:1}