# -*- coding: utf-8 -*-
import urllib2,urllib
import re,json
import struct,base64
import urlparse,cookielib

BASEURL='http://www.rtve.es'
def getUrl(url,data=None,headers={}):
    if headers:
        my_header=headers
    else:
        my_header = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'}
    data = urllib.urlencode(data) if data else None
    req = urllib2.Request(url,data,my_header)
    try:
        response = urllib2.urlopen(req,timeout=10)
        link =  response.read()
        response.close()
    except:
        link=''
    return link
    
def getLiveChannels():
    out=[]
    url='http://www.rtve.es/api-multisignal/1/assets/'
    content  = getUrl(url)
    Chrtpm={'La 1': "rtmp://rtvegeofs.fplive.net:1935/rtvegeoargmex-live-live/RTVE_LA1_LV3_WEB_GL7 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf pageUrl=http://www.rtve.es/directo/la-1/ live=true swfVfy=true timeout=5",
            'La 2':  "rtmp://rtvefs.fplive.net:1935/rtve-live-live/RTVE_LA2_LV3_WEB_GL0 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf pageUrl=http://www.rtve.es/directo/la-2/ live=true swfVfy=true timeout=5",
            'Teledeporte':  "rtmp://rtvegeofs.fplive.net:1935/rtvegeo-live-live/RTVE_TDP_LV3_WEB_GL1 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf pageUrl=http://www.rtve.es/directo/teledeporte/ live=true swfVfy=true timeout=5",
            '24 Horas':  "rtmp://rtvefs.fplive.net:443/rtve2-live-live/RTVE_24H_LV3_WEB_GL8 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf pageUrl=http://www.rtve.es/directo/canal-24h/ live=true swfVfy=true timeout=5",
    }
    data = json.loads(content)
    items = data.get('page').get('items')
    for item in items:
        #item = items[1]
        fanart = BASEURL+ item.get('imageLiveUrl','')
        img = BASEURL+ item.get('imageUrl','')
        plot = item.get('eventDescription','')
        id = item.get('asset',{}).get('id',0)
        channelName = item.get('asset',{}).get('name','')
        title = item.get('title','').encode('utf-8')
        #url = Chrtpm.get(channelName)
        url = getLiveUrl(id)
        t = '[B]%s[/B] [COLOR lightblue]%s[/COLOR]'%(channelName,unicode(title,'utf-8'))
        code = '[COLOR lightgreen]live[/COLOR]' if url.startswith('rtmp') else '[COLOR orange]region?[/COLOR]'
        out.append({'title':t,'url':url,'img':img,'fanart':fanart,'code':code})
    # tu='rtmp://rtvegeofs.fplive.net/rtvegeoargmex-live-live/RTVE_LA1_LV3_WEB_GL7 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf live=true swfVfy=true'
    # out.append({'title':'test','url':tu,'img':'','fanart':''})
    return out    

def getLiveUrl(id='1688877'):
    #rtmp://rtvefs.fplive.net:1935/rtve2-live-live?ovpfv=2.1.2<playpath>RTVE_24H_LV3_WEB_GL8?aksessionid=1476118000421_127342 <swfUrl>http://swf.rtve.es/swf/4.3.14/RTVEPlayerVideo.swf <pageUrl>http://www.rtve.es/directo/canal-24h/

    vurl =''
    purl = 'http://www.rtve.es/ztnr/movil/thumbnail/default/videos/%s.png' % str(id)
    data = getUrl(purl)
    rtmp = _decrypt_url(data)
    if rtmp.startswith('rtmp'):
        vurl = rtmp + ' swfUrl=http://swf.rtve.es/swf/4.3.14/RTVEPlayerVideo.swf live=true swfVfy=true'
    elif rtmp.startswith('http'):
        vurl = rtmp
    else:
        vurl =''
    return vurl
        

def _decrypt_url(png):
    encrypted_data = base64.b64decode(png)
    text_index = encrypted_data.find(b'tEXt')
    text_chunk = encrypted_data[text_index - 4:]
    length = struct.unpack('!I', text_chunk[:4])[0]
    # Use bytearray to get integers when iterating in both python 2.x and 3.x
    data = bytearray(text_chunk[8:8 + length])
    data = [chr(b) for b in data if b != 0]
    hash_index = data.index('#')
    alphabet_data = data[:hash_index]
    url_data = data[hash_index + 1:]

    alphabet = []
    e = 0
    d = 0
    for l in alphabet_data:
        if d == 0:
            alphabet.append(l)
            d = e = (e + 1) % 4
        else:
            d -= 1
    url = ''
    f = 0
    e = 3
    b = 1
    for letter in url_data:
        if f == 0:
            l = int(letter) * 10
            f = 1
        else:
            if e == 0:
                l += int(letter)
                url += alphabet[l]
                e = (b + 3) % 4
                f = 0
                b += 1
            else:
                e -= 1

    return url
    