# -*- coding: utf-8 -*-
import urllib2,urllib
import re,json
import struct,base64
import urlparse,cookielib

BASEURL='http://www.cbsnews.com/live/'
def getUrl(url,data=None,headers={}):
    if headers:
        my_header=headers
    else:
        my_header = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'}
    data = urllib.urlencode(data) if data else None
    req = urllib2.Request(url,data,my_header)
    try:
        response = urllib2.urlopen(req,timeout=10)
        link =  response.read()
        response.close()
    except:
        link=''
    return link
    
def getRoot(): 
    content =getUrl(BASEURL)
    fanart = re.compile('<meta name="twitter:image" content="(.*?)">').findall(content)
    fanart = fanart[0] if fanart else ''
    urllive = re.compile('<script type="text/javascript" src="(.*/VideoPlayer.js\?v=.*?)"></script>').findall(content)
    dvrs = re.compile('<li class="dvr">(.*?)</li>',re.DOTALL).findall(content)
    out=[]
    if urllive:
        out.append({'title':'CBSN - Live Streaming','url':urllive[0],'img':fanart,'code':'[COLOR lightblue]live[/COLOR]','fanart':fanart})
    for dvr in dvrs:
        #dvr = dvrs[0]
        href = re.compile('href="(.*?)"').findall(dvr)
        title = re.compile('title="(.*?)"').findall(dvr)
        duration = re.compile('"time">(.*?)</span>').findall(dvr)
        plot = re.compile('<span class="headline">(.*?)<').findall(dvr)
        if href and title:
            duration = duration[0] if duration else ''
            plot = plot[0] if plot else ''
            out.append({'title':title[0],'url':href[0],'img':fanart,'code':duration,'plot':plot,'fanart':fanart})
    return out

# url='http://cbsn2.cbsistatic.com/scripts/VideoPlayer.js?v=f4cea35fc2e80d07a7a4dd201f5924924b3786ef'
# url='http://www.cbsnews.com/live/video/can-samsung-recover-from-galaxy-note-7-controversy/'
def getStream(url):
    v = ''
    if 'VideoPlayer' in url:
        v = getLiveStream(url)
    else:
        content =getUrl(url)
        urlstream = re.compile('<script type="text/javascript" src="(.*/VideoPlayer.js\?v=.*?)"></script>').findall(content)
        if urlstream:
            v = getLiveStream(urlstream[0])
    return v
    
def getLiveStream(url):
    v=''
    content =getUrl(url)
    href = re.compile('hlsurl\s*=\s*\'(.*?)\';').findall(content)
    if href:
        v=href[0]
    return v
    