# -*- coding: utf-8 -*-
import urllib2,urllib
import re,json
import urlparse,cookielib

BASEURL='http://www.rtve.es'
def getUrl(url,data=None,headers={}):
    if headers:
        my_header=headers
    else:
        my_header = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'}
    data = urllib.urlencode(data) if data else None
    req = urllib2.Request(url,data,my_header)
    try:
        response = urllib2.urlopen(req,timeout=10)
        link =  response.read()
        response.close()
    except:
        link=''
    return link
    
def getLiveChannels():
    out=[]
    url='http://www.rtve.es/api-multisignal/1/assets/'
    content  = getUrl(url)
    Chrtpm={'La 1': "rtmp://rtvegeofs.fplive.net:1935/rtvegeoargmex-live-live/RTVE_LA1_LV3_WEB_GL7 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf pageUrl=http://www.rtve.es/directo/la-1/ live=true swfVfy=true timeout=5",
            'La 2':  "rtmp://rtvefs.fplive.net:1935/rtve-live-live/RTVE_LA2_LV3_WEB_GL0 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf pageUrl=http://www.rtve.es/directo/la-2/ live=true swfVfy=true timeout=5",
            'Teledeporte':  "rtmp://rtvegeofs.fplive.net:1935/rtvegeo-live-live/RTVE_TDP_LV3_WEB_GL1 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf pageUrl=http://www.rtve.es/directo/teledeporte/ live=true swfVfy=true timeout=5",
            '24 Horas':  "rtmp://rtvefs.fplive.net:443/rtve2-live-live/RTVE_24H_LV3_WEB_GL8 swfUrl=http://swf.rtve.es/swf/4.3.13/RTVEPlayerVideo.swf pageUrl=http://www.rtve.es/directo/canal-24h/ live=true swfVfy=true timeout=5",
    }
    data = json.loads(content)
    items = data.get('page').get('items')
    for item in items:
        #item = items[0]
        fanart = BASEURL+ item.get('imageLiveUrl','')
        img = BASEURL+ item.get('imageUrl','')
        plot = item.get('eventDescription','')
        id = item.get('asset',{}).get('id',0)
        channelName = item.get('asset',{}).get('name','')
        title = item.get('title','').encode('utf8')
        url = Chrtpm.get(channelName)
        out.append({'title':'%s %s'%(channelName,''),'url':url,'img':img,'fanart':fanart})

    return out    

def unicodePLchar(txt):
    if type(txt) is not str:
        txt=txt.encode('utf-8')
    txt = txt.replace('&nbsp;','')
    txt = txt.replace('#038;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8217;','\'')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    return txt