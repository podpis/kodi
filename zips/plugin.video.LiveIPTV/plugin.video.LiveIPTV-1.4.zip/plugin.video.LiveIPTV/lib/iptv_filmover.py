# -*- coding: utf-8 -*-

import urllib2,urllib,json
import re,os
from urlparse import urlparse


BASEURL= "http://iptv.filmover.com/tag/iptv-links-url/"
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'


def getUrl(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link
    
def get_root():
    content = getUrl(BASEURL)
    ids = [(a.start(), a.end()) for a in re.finditer('<div class="entry clearfix">', content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ]
        p = re.compile('<p>(IPTV.*?)</p>',re.DOTALL).findall(subset)
        title = re.search('addthis:title=[\'"](.*?)[\'"]',subset)
        if p and title:
            txt = p[0].replace(title.group(1),'')
            if '#EXTINF' in txt:
                txt = txt.split('<')[0].strip()
                m3u_content = txt.replace(' #EXTINF','\n#EXTINF')
                md = m3u_txt2dict(txt.strip())
            else:
                links = re.compile('(http:.*?)[ <]{1}').findall(txt)
                for i,href in enumerate(links):
                    out.append({'title':'#%d %s'%(i+1,title.group(1)),'img':'','url':href,'code':''})
    return out

#url='http://cp.dmbshare.net:8000/get.php?username=andreas1&#038;password=andreas1&#038;type=m3u'
#FIX
def download_m3u(url):  
    content = getUrl(url)
    return m3u_txt2dict(content)
    
def m3u_txt2dict(m3u_content):
    out = []
    matches=re.compile('^#EXTINF:-?[0-9]*(.*?),(.*?)[\n ](.*?)$',re.I+re.M+re.U+re.S).findall(m3u_content)
   
    renTags={'tvg-id':'tvid',
             'audio-track':'audio-track',
             'group-title':'group',
             'tvg-logo':'img'}
                 
    for params, title, url in matches:
        one  = {"title": title, "url": url.split('<')[0]}
        match_params =re.compile(' (.+?)="(.*?)"',re.I+re.M+re.U+re.S).findall(params)
        for field, value in match_params:
            one[renTags.get(field.strip().lower(),'bad')] = value.strip()
        if not one.get('tvid'):
            one['tvid']=title
       
        one['urlepg']=''
        one['url']=one['url'].strip()
        one['title']=one['title'].strip()
        out.append(one)
    return out                