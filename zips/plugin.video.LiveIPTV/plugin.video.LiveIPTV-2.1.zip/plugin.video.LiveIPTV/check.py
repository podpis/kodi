# coding: UTF-8
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def l1ll1l1l_iptv_(l1l1llll_iptv_,l1l1lll1_iptv_=[l1l1111_iptv_ (u"ࠫࠬभ")]):
    debug=1
def l1ll1ll1_iptv_(name=l1l1111_iptv_ (u"ࠬ࠭म")):
    debug=1
def l1ll11ll_iptv_(top):
    debug=1
def check():
    l1l1llll_iptv_ = xbmc.translatePath(os.path.join(l1l1111_iptv_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࠫष"),l1l1111_iptv_ (u"ࠨࡪࡲࡱࡪ࠭स"),l1l1111_iptv_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩह")))
    if l1ll1l1l_iptv_(l1l1llll_iptv_,[l1l1111_iptv_ (u"ࠪࡥࡱ࡯ࡥ࡯ࡹ࡬ࡾࡦࡸࡤࠨऺ"),l1l1111_iptv_ (u"ࠫࡪࡾࡴࡦࡰࡧࡩࡷ࠴ࡡ࡭࡫ࡨࡲࠬऻ"),l1l1111_iptv_ (u"ࠬ࡭࡬ࡢࡦ࡬ࡥࡹࡵࡲࠨ़")])>0:
        l1ll1ll1_iptv_(l1l1111_iptv_ (u"࠭ࡷࡪࡼࡤࡶࡩ࠭ऽ"))
        return
    l1ll11l1_iptv_ = xbmc.translatePath(os.path.join(l1l1111_iptv_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬा"),l1l1111_iptv_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬि"),l1l1111_iptv_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡢࡧࡲࡲ࠳ࡴ࡯ࡹ࠰࠸ࠫी"),l1l1111_iptv_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩु")))
    if os.path.exists(l1ll11l1_iptv_):
        data = open(l1ll11l1_iptv_,l1l1111_iptv_ (u"ࠫࡷ࠭ू")).read()
        data= re.sub(l1l1111_iptv_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬृ"),l1l1111_iptv_ (u"࠭ࠧॄ"),data)
        if len(re.compile(l1l1111_iptv_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ॅ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll1ll1_iptv_(l1l1111_iptv_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪॆ"))
            return
    l1ll11l1_iptv_ = xbmc.translatePath(os.path.join(l1l1111_iptv_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧे"),l1l1111_iptv_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧै"),l1l1111_iptv_ (u"ࠫࡸࡱࡩ࡯࠰ࡻࡳࡳ࡬࡬ࡶࡧࡱࡧࡪ࠭ॉ"),l1l1111_iptv_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫॊ")))
    if os.path.exists(l1ll11l1_iptv_):
        data = open(l1ll11l1_iptv_,l1l1111_iptv_ (u"࠭ࡲࠨो")).read()
        data= re.sub(l1l1111_iptv_ (u"ࠧ࡝࡝࠱࠮ࡡࡣࠧौ"),l1l1111_iptv_ (u"ࠨ्ࠩ"),data)
        if len(re.compile(l1l1111_iptv_ (u"ࠩࡁ࠲࠯࠮ࡰࡰ࡮ࡶ࡯ࡦࡢࡳࠫࡶ࡟ࡷ࠯ࡼࠩࠨॎ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll1ll1_iptv_(l1l1111_iptv_ (u"ࠪࡷࡰ࡯࡮࠯ࡺࡲࡲ࡫ࡲࡵࡦࡰࡦࡩࠬॏ"))
            return
    l1l1llll_iptv_ = xbmc.translatePath(os.path.join(l1l1111_iptv_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩॐ"),l1l1111_iptv_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪࡹࠧ॑")))
    if os.path.exists(l1l1llll_iptv_):
        if l1ll1l1l_iptv_(l1l1llll_iptv_,[l1l1111_iptv_ (u"࠭࡫ࡪࡦࡶ॒ࠫ")])>0:
            l1ll1ll1_iptv_(l1l1111_iptv_ (u"ࠧࡸ࡫ࡽࡥࡷࡪࠧ॓"))
            return
try:
    debug=1
except: pass
