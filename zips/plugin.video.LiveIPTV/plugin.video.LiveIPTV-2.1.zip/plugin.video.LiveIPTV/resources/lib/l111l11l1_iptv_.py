# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
l11llllll_iptv_= l1l1111_iptv_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡸࡻ࠴ࡦࡪ࡮ࡰࡳࡻ࡫ࡲ࠯ࡥࡲࡱ࠴ࡺࡡࡨ࠱࡬ࡴࡹࡼ࠭࡭࡫ࡱ࡯ࡸ࠳ࡵࡳ࡮࠲ࠦ૕")
l11l111l1_iptv_ = 10
l11l11l1l_iptv_=l1l1111_iptv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ૖")
l111lllll_iptv_ = l1l1111_iptv_ (u"ࠪࡍ࠵࡜࡙ࡗࡇ࡯ࡓࡗ࡭࠽࠾ࠩ૗").decode(l1l1111_iptv_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ૘"))
def l1ll1ll_iptv_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l1111_iptv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ૙"), l11l11l1l_iptv_)
    if cookies:
        req.add_header(l1l1111_iptv_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨ૚"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11l111l1_iptv_)
        l1l111l_iptv_ = response.read()
        response.close()
    except:
        l1l111l_iptv_=l1l1111_iptv_ (u"ࠧࠨ૛")
    return l1l111l_iptv_
def l1llllll_iptv_():
    content = l1ll1ll_iptv_(l11llllll_iptv_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l1111_iptv_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡥ࡯ࡶࡵࡽࠥࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢ࠿ࠩ૜"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l111l1lll_iptv_ = content[ ids[i][1]:ids[i+1][0] ]
        p = re.compile(l1l1111_iptv_ (u"ࠩ࠿ࡴࡃ࠮ࡉࡑࡖ࡙࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ૝"),re.DOTALL).findall(l111l1lll_iptv_)
        title = re.search(l1l1111_iptv_ (u"ࠪࡥࡩࡪࡴࡩ࡫ࡶ࠾ࡹ࡯ࡴ࡭ࡧࡀ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࠬ૞"),l111l1lll_iptv_)
        if p and title:
            l111l11ll_iptv_ = p[0].replace(title.group(1),l1l1111_iptv_ (u"ࠫࠬ૟"))
            if l111lllll_iptv_ in l111l11ll_iptv_:
                l111l11ll_iptv_ = l111l11ll_iptv_.split(l1l1111_iptv_ (u"ࠬࡂࠧૠ"))[0].strip()
                l11111_iptv_ = l111l11ll_iptv_.replace(l1l1111_iptv_ (u"࠭ࠠࠨૡ")+l111lllll_iptv_,l1l1111_iptv_ (u"ࠧ࡝ࡰࠪૢ")+l111lllll_iptv_)
                l111l1l1l_iptv_ = l111l1l11_iptv_(l111l11ll_iptv_.strip())
            else:
                l111l1ll1_iptv_ = re.compile(l1l1111_iptv_ (u"ࠨࠪ࡫ࡸࡹࡶ࠺࠯ࠬࡂ࠭ࡠࠦ࠼࡞ࡽ࠴ࢁࠬૣ")).findall(l111l11ll_iptv_)
                for i,href in enumerate(l111l1ll1_iptv_):
                    out.append({l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ૤"):l1l1111_iptv_ (u"ࠪࠧࠪࡪࠠࠦࡵࠪ૥")%(i+1,title.group(1)),l1l1111_iptv_ (u"ࠫ࡮ࡳࡧࠨ૦"):l1l1111_iptv_ (u"ࠬ࠭૧"),l1l1111_iptv_ (u"࠭ࡵࡳ࡮ࠪ૨"):href,l1l1111_iptv_ (u"ࠧࡤࡱࡧࡩࠬ૩"):l1l1111_iptv_ (u"ࠨࠩ૪")})
    return out
def l111ll111_iptv_(url):
    content = l1ll1ll_iptv_(url)
    return l111l1l11_iptv_(content)
def l111l1l11_iptv_(l11111_iptv_):
    out = []
    l1l1lll_iptv_=re.compile(l1l1111_iptv_ (u"ࠩࡡࠫ૫")+l111lllll_iptv_+l1l1111_iptv_ (u"ࠪ࠾࠲ࡅ࡛࠱࠯࠼ࡡ࠯࠮࠮ࠫࡁࠬ࠰࠭࠴ࠪࡀࠫ࡞ࡠࡳࠦ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧ૬"),re.I+re.M+re.U+re.S).findall(l11111_iptv_)
    l111ll1_iptv_={l1l1111_iptv_ (u"ࠫࡹࡼࡧ࠮࡫ࡧࠫ૭"):l1l1111_iptv_ (u"ࠬࡺࡶࡪࡦࠪ૮"),
             l1l1111_iptv_ (u"࠭ࡡࡶࡦ࡬ࡳ࠲ࡺࡲࡢࡥ࡮ࠫ૯"):l1l1111_iptv_ (u"ࠧࡢࡷࡧ࡭ࡴ࠳ࡴࡳࡣࡦ࡯ࠬ૰"),
             l1l1111_iptv_ (u"ࠨࡩࡵࡳࡺࡶ࠭ࡵ࡫ࡷࡰࡪ࠭૱"):l1l1111_iptv_ (u"ࠩࡪࡶࡴࡻࡰࠨ૲"),
             l1l1111_iptv_ (u"ࠪࡸࡻ࡭࠭࡭ࡱࡪࡳࠬ૳"):l1l1111_iptv_ (u"ࠫ࡮ࡳࡧࠨ૴")}
    for params, title, url in l1l1lll_iptv_:
        l11lll1_iptv_  = {l1l1111_iptv_ (u"ࠧࡺࡩࡵ࡮ࡨࠦ૵"): title, l1l1111_iptv_ (u"ࠨࡵࡳ࡮ࠥ૶"): url.split(l1l1111_iptv_ (u"ࠧ࠽ࠩ૷"))[0]}
        l1111ll_iptv_ =re.compile(l1l1111_iptv_ (u"ࠨࠢࠫ࠲࠰ࡅࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ૸"),re.I+re.M+re.U+re.S).findall(params)
        for field, value in l1111ll_iptv_:
            l11lll1_iptv_[l111ll1_iptv_.get(field.strip().lower(),l1l1111_iptv_ (u"ࠩࡥࡥࡩ࠭ૹ"))] = value.strip()
        if not l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠪࡸࡻ࡯ࡤࠨૺ")):
            l11lll1_iptv_[l1l1111_iptv_ (u"ࠫࡹࡼࡩࡥࠩૻ")]=title
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬૼ")]=l1l1111_iptv_ (u"࠭ࠧ૽")
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫ૾")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬ૿")].strip()
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ଀")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩଁ")].strip()
        out.append(l11lll1_iptv_)
    return out
