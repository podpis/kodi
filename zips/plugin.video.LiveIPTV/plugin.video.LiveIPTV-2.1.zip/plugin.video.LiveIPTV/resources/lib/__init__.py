# coding: UTF-8
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)