# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import urllib2,urllib
import re,json
import struct,base64
import urlparse,cookielib
l11llllll_iptv_=l1l1111_iptv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡨࡳ࡯ࡧࡺࡷ࠳ࡩ࡯࡮࠱࡯࡭ࡻ࡫࠯ࠨম")
def l1ll1ll_iptv_(url,data=None,headers={}):
    if headers:
        l11lll1ll_iptv_=headers
    else:
        l11lll1ll_iptv_ = {l1l1111_iptv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬয"):l1l1111_iptv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧর")}
    data = urllib.urlencode(data) if data else None
    req = urllib2.Request(url,data,l11lll1ll_iptv_)
    try:
        response = urllib2.urlopen(req,timeout=10)
        l1l111l_iptv_ =  response.read()
        response.close()
    except:
        l1l111l_iptv_=l1l1111_iptv_ (u"ࠪࠫ঱")
    return l1l111l_iptv_
def l11l11l_iptv_():
    content =l1ll1ll_iptv_(l11llllll_iptv_)
    fanart = re.compile(l1l1111_iptv_ (u"ࠫࡁࡳࡥࡵࡣࠣࡲࡦࡳࡥ࠾ࠤࡷࡻ࡮ࡺࡴࡦࡴ࠽࡭ࡲࡧࡧࡦࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠭ল")).findall(content)
    fanart = fanart[0] if fanart else l1l1111_iptv_ (u"ࠬ࠭঳")
    l11lllll1_iptv_ = re.compile(l1l1111_iptv_ (u"࠭࠼ࡴࡥࡵ࡭ࡵࡺࠠࡵࡻࡳࡩࡂࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭࠳࡛࡯ࡤࡦࡱ࡞ࡔࡱࡧࡹࡦࡴࡠ࠮࠳ࡰࡳ࡝ࡁࡹࡁ࠳࠰࠿ࠪࠤࡁࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭঴")).findall(content)
    l1l1111l1_iptv_ = re.compile(l1l1111_iptv_ (u"ࠧ࠽࡮࡬ࠤࡨࡲࡡࡴࡵࡀࠦࡩࡼࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭঵"),re.DOTALL).findall(content)
    out=[]
    if l11lllll1_iptv_:
        out.append({l1l1111_iptv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧশ"):l1l1111_iptv_ (u"ࠩࡆࡆࡘࡔࠠ࠮ࠢࡏ࡭ࡻ࡫ࠠࡔࡶࡵࡩࡦࡳࡩ࡯ࡩࠪষ"),l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧস"):l11lllll1_iptv_[0],l1l1111_iptv_ (u"ࠫ࡮ࡳࡧࠨহ"):fanart,l1l1111_iptv_ (u"ࠬࡩ࡯ࡥࡧࠪ঺"):l1l1111_iptv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟࡯࡭ࡻ࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ঻"),l1l1111_iptv_ (u"ࠧࡧࡣࡱࡥࡷࡺ়ࠧ"):fanart})
    for l11lll1l1_iptv_ in l1l1111l1_iptv_:
        href = re.compile(l1l1111_iptv_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧঽ")).findall(l11lll1l1_iptv_)
        title = re.compile(l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩা")).findall(l11lll1l1_iptv_)
        l11llll1l_iptv_ = re.compile(l1l1111_iptv_ (u"ࠪࠦࡹ࡯࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩি")).findall(l11lll1l1_iptv_)
        l1l111l11_iptv_ = re.compile(l1l1111_iptv_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࡭࡫ࡱࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ী")).findall(l11lll1l1_iptv_)
        if href and title:
            l11llll1l_iptv_ = l11llll1l_iptv_[0] if l11llll1l_iptv_ else l1l1111_iptv_ (u"ࠬ࠭ু")
            l1l111l11_iptv_ = l1l111l11_iptv_[0] if l1l111l11_iptv_ else l1l1111_iptv_ (u"࠭ࠧূ")
            out.append({l1l1111_iptv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ৃ"):title[0],l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬৄ"):href[0],l1l1111_iptv_ (u"ࠩ࡬ࡱ࡬࠭৅"):fanart,l1l1111_iptv_ (u"ࠪࡧࡴࡪࡥࠨ৆"):l11llll1l_iptv_,l1l1111_iptv_ (u"ࠫࡵࡲ࡯ࡵࠩে"):l1l111l11_iptv_,l1l1111_iptv_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬৈ"):fanart})
    return out
def l1l1l_iptv_(url):
    v = l1l1111_iptv_ (u"࠭ࠧ৉")
    if l1l1111_iptv_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭৊") in url:
        v = l1l11111l_iptv_(url)
    else:
        content =l1ll1ll_iptv_(url)
        l11llll11_iptv_ = re.compile(l1l1111_iptv_ (u"ࠨ࠾ࡶࡧࡷ࡯ࡰࡵࠢࡷࡽࡵ࡫࠽ࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯࠵ࡖࡪࡦࡨࡳࡕࡲࡡࡺࡧࡵ࠲࡯ࡹ࡜ࡀࡸࡀ࠲࠯ࡅࠩࠣࡀ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬো")).findall(content)
        if l11llll11_iptv_:
            v = l1l11111l_iptv_(l11llll11_iptv_[0])
    return v
def l1l11111l_iptv_(url):
    v=l1l1111_iptv_ (u"ࠩࠪৌ")
    content =l1ll1ll_iptv_(url)
    href = re.compile(l1l1111_iptv_ (u"ࠪ࡬ࡱࡹࡵࡳ࡮࡟ࡷ࠯ࡃ࡜ࡴࠬ࡞ࡠࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠ࠿্ࠬ")).findall(content)
    if href:
        v=l1l111111_iptv_(href[0])
    return v
def l1l111111_iptv_(v):
    out=[]
    if l1l1111_iptv_ (u"ࠫࡲ࠹ࡵࠨৎ") in v:
        content =l1ll1ll_iptv_(v)
        if l1l1111_iptv_ (u"ࠬࡋࡘࡕࡏ࠶࡙ࠬ৏") in content:
            l1l111l1l_iptv_=re.compile(l1l1111_iptv_ (u"࠭ࡒࡆࡕࡒࡐ࡚࡚ࡉࡐࡐࡀࠬ࠳࠰࠿ࠪ࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫ৐")).findall(content)
            for label,l1l1111ll_iptv_ in l1l111l1l_iptv_:
                out.append({l1l1111_iptv_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭৑"):label,l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬ৒"):l1l1111ll_iptv_})
    return out
