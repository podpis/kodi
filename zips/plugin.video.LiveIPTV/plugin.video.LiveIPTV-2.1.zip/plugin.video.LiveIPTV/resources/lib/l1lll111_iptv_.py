# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import urllib2,urllib
import re,json
import struct,base64
import urlparse,cookielib
l11llllll_iptv_=l1l1111_iptv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡳࡶࡹࡩ࠳࡫ࡳࠨଖ")
def l1ll1ll_iptv_(url,data=None,headers={}):
    if headers:
        l11lll1ll_iptv_=headers
    else:
        l11lll1ll_iptv_ = {l1l1111_iptv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨଗ"):l1l1111_iptv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪଘ")}
    data = urllib.urlencode(data) if data else None
    req = urllib2.Request(url,data,l11lll1ll_iptv_)
    try:
        response = urllib2.urlopen(req,timeout=10)
        l1l111l_iptv_ =  response.read()
        response.close()
    except:
        l1l111l_iptv_=l1l1111_iptv_ (u"࠭ࠧଙ")
    return l1l111l_iptv_
def l1llll1_iptv_():
    out=[]
    url=l1l1111_iptv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡷࡺࡶࡦ࠰ࡨࡷ࠴ࡧࡰࡪ࠯ࡰࡹࡱࡺࡩࡴ࡫ࡪࡲࡦࡲ࠯࠲࠱ࡤࡷࡸ࡫ࡴࡴ࠱ࠪଚ")
    content  = l1ll1ll_iptv_(url)
    l1111l1l1_iptv_={l1l1111_iptv_ (u"ࠨࡎࡤࠤ࠶࠭ଛ"): l1l1111_iptv_ (u"ࠤࡵࡸࡲࡶ࠺࠰࠱ࡵࡸࡻ࡫ࡧࡦࡱࡩࡷ࠳࡬ࡰ࡭࡫ࡹࡩ࠳ࡴࡥࡵ࠼࠴࠽࠸࠻࠯ࡳࡶࡹࡩ࡬࡫࡯ࡢࡴࡪࡱࡪࡾ࠭࡭࡫ࡹࡩ࠲ࡲࡩࡷࡧ࠲ࡖ࡙࡜ࡅࡠࡎࡄ࠵ࡤࡒࡖ࠴ࡡ࡚ࡉࡇࡥࡇࡍ࠹ࠣࡷࡼ࡬ࡕࡳ࡮ࡀ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡼ࡬࠮ࡳࡶࡹࡩ࠳࡫ࡳ࠰ࡵࡺࡪ࠴࠺࠮࠴࠰࠴࠷࠴ࡘࡔࡗࡇࡓࡰࡦࡿࡥࡳࡘ࡬ࡨࡪࡵ࠮ࡴࡹࡩࠤࡵࡧࡧࡦࡗࡵࡰࡂ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡵࡸࡻ࡫࠮ࡦࡵ࠲ࡨ࡮ࡸࡥࡤࡶࡲ࠳ࡱࡧ࠭࠲࠱ࠣࡰ࡮ࡼࡥ࠾ࡶࡵࡹࡪࠦࡳࡸࡨ࡙ࡪࡾࡃࡴࡳࡷࡨࠤࡹ࡯࡭ࡦࡱࡸࡸࡂ࠻ࠢଜ"),
            l1l1111_iptv_ (u"ࠪࡐࡦࠦ࠲ࠨଝ"):  l1l1111_iptv_ (u"ࠦࡷࡺ࡭ࡱ࠼࠲࠳ࡷࡺࡶࡦࡨࡶ࠲࡫ࡶ࡬ࡪࡸࡨ࠲ࡳ࡫ࡴ࠻࠳࠼࠷࠺࠵ࡲࡵࡸࡨ࠱ࡱ࡯ࡶࡦ࠯࡯࡭ࡻ࡫࠯ࡓࡖ࡙ࡉࡤࡒࡁ࠳ࡡࡏ࡚࠸ࡥࡗࡆࡄࡢࡋࡑ࠶ࠠࡴࡹࡩ࡙ࡷࡲ࠽ࡩࡶࡷࡴ࠿࠵࠯ࡴࡹࡩ࠲ࡷࡺࡶࡦ࠰ࡨࡷ࠴ࡹࡷࡧ࠱࠷࠲࠸࠴࠱࠴࠱ࡕࡘ࡛ࡋࡐ࡭ࡣࡼࡩࡷ࡜ࡩࡥࡧࡲ࠲ࡸࡽࡦࠡࡲࡤ࡫ࡪ࡛ࡲ࡭࠿࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡲࡵࡸࡨ࠲ࡪࡹ࠯ࡥ࡫ࡵࡩࡨࡺ࡯࠰࡮ࡤ࠱࠷࠵ࠠ࡭࡫ࡹࡩࡂࡺࡲࡶࡧࠣࡷࡼ࡬ࡖࡧࡻࡀࡸࡷࡻࡥࠡࡶ࡬ࡱࡪࡵࡵࡵ࠿࠸ࠦଞ"),
            l1l1111_iptv_ (u"࡚ࠬࡥ࡭ࡧࡧࡩࡵࡵࡲࡵࡧࠪଟ"):  l1l1111_iptv_ (u"ࠨࡲࡵ࡯ࡳ࠾࠴࠵ࡲࡵࡸࡨ࡫ࡪࡵࡦࡴ࠰ࡩࡴࡱ࡯ࡶࡦ࠰ࡱࡩࡹࡀ࠱࠺࠵࠸࠳ࡷࡺࡶࡦࡩࡨࡳ࠲ࡲࡩࡷࡧ࠰ࡰ࡮ࡼࡥ࠰ࡔࡗ࡚ࡊࡥࡔࡅࡒࡢࡐ࡛࠹࡟ࡘࡇࡅࡣࡌࡒ࠱ࠡࡵࡺࡪ࡚ࡸ࡬࠾ࡪࡷࡸࡵࡀ࠯࠰ࡵࡺࡪ࠳ࡸࡴࡷࡧ࠱ࡩࡸ࠵ࡳࡸࡨ࠲࠸࠳࠹࠮࠲࠵࠲ࡖ࡙࡜ࡅࡑ࡮ࡤࡽࡪࡸࡖࡪࡦࡨࡳ࠳ࡹࡷࡧࠢࡳࡥ࡬࡫ࡕࡳ࡮ࡀ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡳࡶࡹࡩ࠳࡫ࡳ࠰ࡦ࡬ࡶࡪࡩࡴࡰ࠱ࡷࡩࡱ࡫ࡤࡦࡲࡲࡶࡹ࡫࠯ࠡ࡮࡬ࡺࡪࡃࡴࡳࡷࡨࠤࡸࡽࡦࡗࡨࡼࡁࡹࡸࡵࡦࠢࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠹ࠧଠ"),
            l1l1111_iptv_ (u"ࠧ࠳࠶ࠣࡌࡴࡸࡡࡴࠩଡ"):  l1l1111_iptv_ (u"ࠣࡴࡷࡱࡵࡀ࠯࠰ࡴࡷࡺࡪ࡬ࡳ࠯ࡨࡳࡰ࡮ࡼࡥ࠯ࡰࡨࡸ࠿࠺࠴࠴࠱ࡵࡸࡻ࡫࠲࠮࡮࡬ࡺࡪ࠳࡬ࡪࡸࡨ࠳ࡗ࡚ࡖࡆࡡ࠵࠸ࡍࡥࡌࡗ࠵ࡢ࡛ࡊࡈ࡟ࡈࡎ࠻ࠤࡸࡽࡦࡖࡴ࡯ࡁ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡽࡦ࠯ࡴࡷࡺࡪ࠴ࡥࡴ࠱ࡶࡻ࡫࠵࠴࠯࠵࠱࠵࠸࠵ࡒࡕࡘࡈࡔࡱࡧࡹࡦࡴ࡙࡭ࡩ࡫࡯࠯ࡵࡺࡪࠥࡶࡡࡨࡧࡘࡶࡱࡃࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡶࡹࡼࡥ࠯ࡧࡶ࠳ࡩ࡯ࡲࡦࡥࡷࡳ࠴ࡩࡡ࡯ࡣ࡯࠱࠷࠺ࡨ࠰ࠢ࡯࡭ࡻ࡫࠽ࡵࡴࡸࡩࠥࡹࡷࡧࡘࡩࡽࡂࡺࡲࡶࡧࠣࡸ࡮ࡳࡥࡰࡷࡷࡁ࠺ࠨଢ"),
    }
    data = json.loads(content)
    items = data.get(l1l1111_iptv_ (u"ࠩࡳࡥ࡬࡫ࠧଣ")).get(l1l1111_iptv_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠩତ"))
    for item in items:
        fanart = l11llllll_iptv_+ item.get(l1l1111_iptv_ (u"ࠫ࡮ࡳࡡࡨࡧࡏ࡭ࡻ࡫ࡕࡳ࡮ࠪଥ"),l1l1111_iptv_ (u"ࠬ࠭ଦ"))
        l11ll1lll_iptv_ = l11llllll_iptv_+ item.get(l1l1111_iptv_ (u"࠭ࡩ࡮ࡣࡪࡩ࡚ࡸ࡬ࠨଧ"),l1l1111_iptv_ (u"ࠧࠨନ"))
        l1l111l11_iptv_ = item.get(l1l1111_iptv_ (u"ࠨࡧࡹࡩࡳࡺࡄࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠫ଩"),l1l1111_iptv_ (u"ࠩࠪପ"))
        id = item.get(l1l1111_iptv_ (u"ࠪࡥࡸࡹࡥࡵࠩଫ"),{}).get(l1l1111_iptv_ (u"ࠫ࡮ࡪࠧବ"),0)
        l1llllll1l_iptv_ = item.get(l1l1111_iptv_ (u"ࠬࡧࡳࡴࡧࡷࠫଭ"),{}).get(l1l1111_iptv_ (u"࠭࡮ࡢ࡯ࡨࠫମ"),l1l1111_iptv_ (u"ࠧࠨଯ"))
        title = item.get(l1l1111_iptv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧର"),l1l1111_iptv_ (u"ࠩࠪ଱")).encode(l1l1111_iptv_ (u"ࠪࡹࡹ࡬࠭࠹ࠩଲ"))
        url = l11111lll_iptv_(id)
        t = l1l1111_iptv_ (u"ࠫࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣࠠ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹࡨ࡬ࡶࡧࡠࠩࡸࡡ࠯ࡄࡑࡏࡓࡗࡣࠧଳ")%(l1llllll1l_iptv_,unicode(title,l1l1111_iptv_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ଴")))
        code = l1l1111_iptv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸ࡬ࡸࡥࡦࡰࡠࡰ࡮ࡼࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩଵ") if url.startswith(l1l1111_iptv_ (u"ࠧࡳࡶࡰࡴࠬଶ")) else l1l1111_iptv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࡴࡨ࡫࡮ࡵ࡮ࡀ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪଷ")
        out.append({l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨସ"):t,l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧହ"):url,l1l1111_iptv_ (u"ࠫ࡮ࡳࡧࠨ଺"):l11ll1lll_iptv_,l1l1111_iptv_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬ଻"):fanart,l1l1111_iptv_ (u"࠭ࡣࡰࡦࡨ଼ࠫ"):code})
    return out
def l11111lll_iptv_(id=l1l1111_iptv_ (u"ࠧ࠲࠸࠻࠼࠽࠽࠷ࠨଽ")):
    l111111ll_iptv_ =l1l1111_iptv_ (u"ࠨࠩା")
    l1lllll1l1_iptv_ = l1l1111_iptv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡲࡵࡸࡨ࠲ࡪࡹ࠯ࡻࡶࡱࡶ࠴ࡳ࡯ࡷ࡫࡯࠳ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠯ࡥࡧࡩࡥࡺࡲࡴ࠰ࡸ࡬ࡨࡪࡵࡳ࠰ࠧࡶ࠲ࡵࡴࡧࠨି") % str(id)
    data = l1ll1ll_iptv_(l1lllll1l1_iptv_)
    l1111111l_iptv_ = _1llllll11_iptv_(data)
    if l1111111l_iptv_.startswith(l1l1111_iptv_ (u"ࠪࡶࡹࡳࡰࠨୀ")):
        l111111ll_iptv_ = l1111111l_iptv_ + l1l1111_iptv_ (u"ࠫࠥࡹࡷࡧࡗࡵࡰࡂ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡷࡧ࠰ࡵࡸࡻ࡫࠮ࡦࡵ࠲ࡷࡼ࡬࠯࠵࠰࠶࠲࠶࠺࠯ࡓࡖ࡙ࡉࡕࡲࡡࡺࡧࡵ࡚࡮ࡪࡥࡰ࠰ࡶࡻ࡫ࠦ࡬ࡪࡸࡨࡁࡹࡸࡵࡦࠢࡶࡻ࡫࡜ࡦࡺ࠿ࡷࡶࡺ࡫ࠧୁ")
    elif l1111111l_iptv_.startswith(l1l1111_iptv_ (u"ࠬ࡮ࡴࡵࡲࠪୂ")):
        l111111ll_iptv_ = l1111111l_iptv_
    else:
        l111111ll_iptv_ =l1l1111_iptv_ (u"࠭ࠧୃ")
    return l111111ll_iptv_
def _1llllll11_iptv_(l1lllll1ll_iptv_):
    l111111l1_iptv_ = base64.b64decode(l1lllll1ll_iptv_)
    l1111l11l_iptv_ = l111111l1_iptv_.find(l1lllllll1_iptv_ (u"ࠧࡵࡇ࡛ࡸࠬୄ"))
    l11111l11_iptv_ = l111111l1_iptv_[l1111l11l_iptv_ - 4:]
    length = struct.unpack(l1l1111_iptv_ (u"ࠨࠣࡌࠫ୅"), l11111l11_iptv_[:4])[0]
    data = bytearray(l11111l11_iptv_[8:8 + length])
    data = [chr(b) for b in data if b != 0]
    l11111l1l_iptv_ = data.index(l1l1111_iptv_ (u"ࠩࠦࠫ୆"))
    l1llllllll_iptv_ = data[:l11111l1l_iptv_]
    l1111l111_iptv_ = data[l11111l1l_iptv_ + 1:]
    l11111ll1_iptv_ = []
    e = 0
    d = 0
    for l in l1llllllll_iptv_:
        if d == 0:
            l11111ll1_iptv_.append(l)
            d = e = (e + 1) % 4
        else:
            d -= 1
    url = l1l1111_iptv_ (u"ࠪࠫେ")
    f = 0
    e = 3
    b = 1
    for l11111111_iptv_ in l1111l111_iptv_:
        if f == 0:
            l = int(l11111111_iptv_) * 10
            f = 1
        else:
            if e == 0:
                l += int(l11111111_iptv_)
                url += l11111ll1_iptv_[l]
                e = (b + 3) % 4
                f = 0
                b += 1
            else:
                e -= 1
    return url
