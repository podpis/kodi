# -*- coding: utf-8 -*-
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin

base_url     = sys.argv[0]
addon_handle = int(sys.argv[1])
args         = urlparse.parse_qs(sys.argv[2][1:])
my_addon     = xbmcaddon.Addon()
addonName    = my_addon.getAddonInfo('name')
PATH         = my_addon.getAddonInfo('path')
DATAPATH     = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES    = PATH+'/resources/'
FANART       = ''

import resources.lib.zalukaj as zalukaj
zalukaj.COOKIEFILE = os.path.join(DATAPATH,'zalukaj.cookie')
my_addon.setSetting('set','set')

def addLinkItem(name, url, mode, params = {}, iconimage = 'DefaultFolder.png', infoLabels = False, isFolder = False, IsPlayable = True, fanart = FANART, itemcount = 1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    liz = xbmcgui.ListItem(name)
    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconimage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    liz.setArt(art)

    if not infoLabels:
        infoLabels={"title": name}

    liz.setInfo(type="video", infoLabels=infoLabels)

    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')

    isFolder = infoLabels.get('isFolder',isFolder)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=isFolder,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok

def addDir(name, ex_link = None, params = {}, mode = 'folder', iconImage = 'DefaultFolder.png', infoLabels = None, fanart = FANART, contextmenu = None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link': ex_link, 'params': params})
    li = xbmcgui.ListItem(name)

    if infoLabels:
        li.setInfo(type="video", infoLabels=infoLabels)

    art_keys=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    art = dict(zip(art_keys,[iconImage for x in art_keys]))
    art['landscape'] = fanart if fanart else art['landscape']
    art['fanart'] = fanart if fanart else art['landscape']
    li.setArt(art)

    if contextmenu:
        contextMenuItems = contextmenu
        li.addContextMenuItems(contextMenuItems, replaceItems = True)

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def encoded_dict(in_dict):
    out_dict = {}

    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        out_dict[k] = v

    return out_dict

def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

def ListMovies(ex_link, data = None):
    filmy,pagination = zalukaj.scanMainpage(ex_link,data)

    if not filmy:
        xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
        return

    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=pagination[0], params={}, mode='page:ListItems', IsPlayable=False)

    items=len(filmy)

    for f in filmy:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=items)

    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> Następna strona >>[/COLOR]', url=pagination[1], params={}, mode='page:ListItems', IsPlayable=False)

    xbmcplugin.setContent(addon_handle, 'movies')

def ListSeriale(ex_link, nextMode):
    seriale = zalukaj.getSeriale(ex_link)
    items=len(seriale)
    if ex_link == "latest":
        nextMode = "getSeasons"
    for f in seriale:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode=nextMode, iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=items)

    xbmcplugin.setContent(addon_handle, 'tvshows')

def getSeasons(ex_link):
    seasons = zalukaj.getSeasons(ex_link)
    if not seasons:
        xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
        return

    items=len(seasons)

    for f in seasons:
        addLinkItem(name=f.get('title',''), url=f.get('url',''), mode='getEpisodes', iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=items)

    xbmcplugin.setContent(addon_handle, 'tvshows')

def getEpisodes(ex_link):
    episodes = zalukaj.getEpisodes(ex_link)
    if not episodes:
        xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
        return

    items = len(episodes)

    for f in episodes:
        addLinkItem(name=f.get('title'), url=f.get('url',''), mode='getLinks', iconimage=f.get('img'), infoLabels=f, isFolder=False, IsPlayable=True,itemcount=items)

    xbmcplugin.setContent(addon_handle, 'episodes')

def getLinks(ex_link):
    vlinks = zalukaj.getVideoUrl(ex_link)
    stream_url = ''
    vl = str(eval(str(vlinks)))

    if vlinks and vlinks[0].get('href',False):
        rurl = vlinks[0].get('href','')

        if not stream_url:
            import resolveurl as urlresolver
            try:
                stream_url = urlresolver.resolve(rurl)
            except Exception,e:
                stream_url=''
                xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
    elif vlinks:
        if '[{}]' in vl:
           xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Duże obciążenie! Chwilowo tylko użytkownicy z kontem VIP mają dostęp do strony.')
           stream_url = ''
           return
        else:
           t = [ x.get('label') for x in vlinks]
           select = xbmcgui.Dialog().select("Sources", t)
           if select > -1:
              stream_url = vlinks[select].get('url')

    # Loading links without a resolver not working here
    #if ".mp4" in rurl or ".avi" in rurl or ".mkv" in rurl:
    #    xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=rurl))
    #    return

    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))

def login():
    u = my_addon.getSetting('user')
    p = my_addon.getSetting('pass')
    l = my_addon.getSetting('login')

    if u and p and l == 'true':
        data = zalukaj.getLogin(u,p)

        if data.get('title',False):
            addDir(data.get('title'),ex_link=data.get('url'), mode='ListItems', iconImage=data.get('img'),infoLabels=data)
        elif data.get('msg',False):
            xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',data.get('msg'))

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]

sortV = my_addon.getSetting('sortV')
sortN = my_addon.getSetting('sortN') if sortV else 'ostatnio dodane'
if not sortV: sortV='ostatnio-dodane'

orderV = my_addon.getSetting('orderV')
orderN = my_addon.getSetting('orderN') if orderV else 'wszystkie'
if not orderV: orderV='wszystkie'

if mode is None:
    login()
    addDir(name="[COLOR blue]Filmy Gatunek[/COLOR]",ex_link='',params={},mode='ListFilmyGatunek',iconImage='')
    addDir(name="   Ostatnio dodane",ex_link='https://zalukaj.com/cache/lastadded.html',params={},mode='ListItems',iconImage='')
    addDir(name="   Ostatnio oglądane",ex_link='https://zalukaj.com/cache/lastseen.html',params={},mode='ListItems',iconImage='')
    addDir(name="   Najpopularniejsze",ex_link='https://zalukaj.com/cache/wyswietlenia-tydzien.html',params={},mode='ListItems',iconImage='')
    addDir('   Szukaj filmu','',mode='SzukajFilmy')
    addDir(name="[COLOR blue]Seriale[/COLOR]",ex_link='all',params={},mode='ListSeriale',iconImage='')
    addDir(name="   Ostatnio zaktualizowane",ex_link='latest',params={},mode='ListSerialeOstatnie',iconImage='')

elif mode[0] =='ListFilmyGatunek':
    filmy,pagination = zalukaj.Gatunek(ex_link)
    addLinkItem("[COLOR blue]Sortuj:[/COLOR] [B]"+sortN+"[/B]",'',mode='filtr:sort',iconimage='',IsPlayable=False)
    addLinkItem("[COLOR blue]Wyświetl:[/COLOR] [B]"+orderN+"[/B]",'',mode='filtr:order',iconimage='',IsPlayable=False)

    for f in filmy:
        href=f.get('url','')+','.join([sortV,orderV,'strona-1'])
        addLinkItem(name=f.get('title'), url=href, mode='ListItems', iconimage=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,itemcount=len(filmy))

elif 'filtr' in mode[0]:
    _type = mode[0].split(":")[-1]

    if _type=='sort':
        label=['ostatnio dodane','ostatnio oglądane','odsłon','ulubione','oceny','mobilne']
        value=['ostatnio-dodane','ostatnio-ogladane','odslon','ulubione','oceny','mobilne']
        msg = 'Sortowanie'
    elif _type=='order':
        label=['wszystkie','z lektorem','napisy pl','nietłumaczone']
        value=['wszystkie','tlumaczone','napisy-pl','nie-tlumaczone']
        msg = 'Wyświetl'

    s = xbmcgui.Dialog().select(msg,label)
    s = s if s > -1 else 0
    my_addon.setSetting(_type+'V',value[s])
    my_addon.setSetting(_type+'N',label[s])
    xbmc.executebuiltin('XBMC.Container.Refresh')

elif mode[0] =='SzukajFilmy':
    d = xbmcgui.Dialog().input('Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
    if d:
        rurl='https://zalukaj.com/szukaj'
        data='searchinput=%s'%d.strip().replace(' ','+')
        ListMovies(rurl,data)

elif mode[0].startswith('page'):
    tmp, nmode = mode[0].split(':')
    url = build_url({'mode': nmode, 'foldername': '', 'ex_link': ex_link, 'params': params})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'ListItems':ListMovies(ex_link,None)
elif mode[0] == 'ListSeriale':ListSeriale(ex_link,'getSeasons')
elif mode[0] == 'getSeasons':getSeasons(ex_link)
elif mode[0] == 'ListSerialeOstatnie':ListSeriale(ex_link,'getEpisodes')
elif mode[0] == 'getEpisodes':getEpisodes(ex_link)
elif mode[0] == 'getLinks': getLinks(ex_link)
else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
xbmcplugin.endOfDirectory(addon_handle)
