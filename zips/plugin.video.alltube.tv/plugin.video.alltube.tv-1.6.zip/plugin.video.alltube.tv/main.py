# -*- coding: utf-8 -*-

import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver

try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer("alltubetv")

import resources.lib.alltube as alltube
import resources.lib.cdaresolver as cdaresolver
import resources.lib.playernautresolver as playernautresolver


base_url        = sys.argv[0]
addon_handle    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
my_addon        = xbmcaddon.Addon()
addonName       = my_addon.getAddonInfo('name')

PATH        = my_addon.getAddonInfo('path')
DATAPATH    = xbmc.translatePath(my_addon.getAddonInfo('profile')).decode('utf-8')
RESOURCES   = PATH+'/resources/'

alltube.COOKIEFILE=os.path.join(DATAPATH,'alltube.cookie')

FANART=RESOURCES+'fanart.png'


## COMMON Functions

def addLinkItem(name, url, mode, page=1, iconimage=None, infoLabels=False, IsPlayable=True,fanart=FANART,itemcount=1):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':page})
    
    if iconimage==None:
        iconimage='DefaultFolder.png'
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    
    if not infoLabels:
        infoLabels={"title": name}
    liz.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        liz.setProperty('IsPlayable', 'true')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    contextMenuItems = []
    contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)        
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False,totalItems=itemcount)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok

def addDir(name,ex_link=None, page=1, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=FANART,contextmenu=None):
    url = build_url({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'page' : page})
    #li = xbmcgui.ListItem(name.encode("utf-8"), iconImage=iconImage)
    li = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    if infoLabels:
        li.setInfo(type="movie", infoLabels=infoLabels)
    if fanart:
        li.setProperty('fanart_image', fanart )
    if contextmenu:
        contextMenuItems=contextmenu
        li.addContextMenuItems(contextMenuItems, replaceItems=True) 
    else:
        contextMenuItems = []
        contextMenuItems.append(('Informacja', 'XBMC.Action(Info)'),)
        li.addContextMenuItems(contextMenuItems, replaceItems=False)  
          
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")

def addSeparator(name, url='', mode='', iconimage=None, fanart=FANART):
    u = build_url({'mode': mode, 'foldername': name, 'ex_link' : url, 'page':1})
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setProperty('IsPlayable', 'false')
    if fanart:
        liz.setProperty('fanart_image',fanart)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz,isFolder=False)
    return ok

def encoded_dict(in_dict):
    out_dict = {}
    for k, v in in_dict.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            # Must be encoded in UTF-8
            v.decode('utf8')
        out_dict[k] = v
    return out_dict
    
def build_url(query):
    return base_url + '?' + urllib.urlencode(encoded_dict(query))

## sub functions
    
#ex_link='http://alltube.tv/filmy-online/'
def ListMovies(ex_link,page):
    url,data = ex_link.split('?') if '?'in ex_link else (ex_link,None)
    filmy,pagination = alltube.scanMainpage(url,int(page),data)
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__M', page=pagination[0], IsPlayable=False)
    items=len(filmy)
    
    for f in filmy:
        print f
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=items,fanart=f.get('img'))
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__M', page=pagination[1], IsPlayable=False)
    xbmcplugin.setContent(addon_handle, 'movies')

def ListFun(ex_link,page):
    url,data = ex_link.split('?') if '?'in ex_link else (ex_link,None)
    filmy,pagination = alltube.scanFun(url,int(page),data)
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__F', page=pagination[0], IsPlayable=False)
    items=len(filmy)
    
    for f in filmy:
        print f
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,itemcount=items,fanart=f.get('img'))
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__F', page=pagination[1], IsPlayable=False)
    xbmcplugin.setContent(addon_handle, 'movies')

def ListSeriale(ex_link,page):
    filmy,pagination = alltube.scanTVshows(ex_link,int(page))
    my_mode = 'getEpisodes'
    if 'true' in my_addon.getSetting('groupEpisodes'):
        my_mode = 'getSeasons'
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__S', page=pagination[0], IsPlayable=False)
    items=len(filmy)
    for f in filmy:
        #addDir(name=f.get('title'), ex_link=f.get('href'), mode='getEpisodes', iconImage=f.get('img'), infoLabels=f, fanart=f.get('img'))
        addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), infoLabels=f, fanart=f.get('img'))
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__S', page=pagination[1], IsPlayable=False)
    xbmcplugin.setContent(addon_handle, 'tvshows')
        
def getSeasons(ex_link):
    episodes = alltube.scanEpisodes(ex_link)
    seasons =alltube.splitToSeasons(episodes)
    for s_name in sorted(seasons.keys()):
        addDir(name=s_name, ex_link=urllib.quote(str(seasons[s_name])), mode='getEpisodes2')
    xbmcplugin.setContent(addon_handle, 'season')
    
def ListEpisodes(ex_link):
    episodes = alltube.scanEpisodes(ex_link)
    for f in episodes:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=f.get('img'))
    xbmcplugin.setContent(addon_handle, 'episodes')

def ListEpisodes2(ex_link):
    episodes = eval(urllib.unquote(ex_link))
    for f in episodes:
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=f.get('img'))
    xbmcplugin.setContent(addon_handle, 'episodes')

    
def FSLinks(ex_link,tryb='search',page=1):
    pagination=(None,None)
    my_mode = 'getEpisodes'
    if 'true' in my_addon.getSetting('groupEpisodes'):
        my_mode = 'getSeasons'
    if   tryb=='search':
        filmy,seriale = alltube.Search(ex_link)
    elif tryb=='playlist':
        out, pagination = alltube.getPlaylistContent(ex_link,page)
        filmy,seriale = out
    else:
        filmy = seriale = []
    
    if pagination[0]:
        addLinkItem(name='[COLOR blue]<< poprzednia strona <<[/COLOR]', url=ex_link, mode='__page__P', page=pagination[0], IsPlayable=False)
        
    for f in filmy:
        f['title']='[COLOR orange](F)[/COLOR] '+f.get('title')
        addLinkItem(name=f.get('title'), url=f.get('href'), mode='getLinks', iconimage=f.get('img'), infoLabels=f, IsPlayable=True,fanart=f.get('img'))
    for f in seriale:
        f['title']='[COLOR purple](S)[/COLOR] '+f.get('title')
        addDir(name=f.get('title'), ex_link=f.get('href'), mode=my_mode, iconImage=f.get('img'), infoLabels=f, fanart=f.get('img'))
    
    if pagination[1]:
        addLinkItem(name='[COLOR blue]>> następna strona >>[/COLOR]', url=ex_link, mode='__page__P', page=pagination[1], IsPlayable=False)


    
def getLinks(ex_link):
    links = alltube.getVideoLinks(ex_link)
    # if links:
    #     links = sorted(links, key=lambda elem: "%s%d" % (elem.get('wersja',''), 100-elem.get('rate',100)))
    stream_url=''
    #print '$'*4
    #print links
    t = [ x.get('title') for x in links]
    u = [ x.get('url') for x in links]
    h = [ x.get('host') for x in links]
    selection = xbmcgui.Dialog().select("Wersja | Ocena | [Host] ", t)
    if selection>-1:
        link = u[selection]
        #print link
        if 'cda' in h[selection]:
            #print 'CDA'
            stream_url = cdaresolver.getVideoUrls(link)
            if type(stream_url) is list:
                qualityList = [x[0] for x in stream_url]
                selection = xbmcgui.Dialog().select("Quality [can be set default]", qualityList)
                if selection>-1:
                    stream_url = cdaresolver.getVideoUrls(stream_url[selection][1])
                else:
                    stream_url=''
        elif 'playernaut' in h[selection]:
            stream_url = playernautresolver.getVideoUrls(link)
            if type(stream_url) is list:
                qualityList = [x[0] for x in stream_url]
                hrefs = [x[1] for x in stream_url]
                selection = xbmcgui.Dialog().select("Quality [can be set default]", qualityList)
                if selection>-1:
                    stream_url=hrefs[selection]
                else:
                    stream_url=''
                
        else: 
            #xbmcgui.Dialog().ok('link',link)
            try:
                stream_url = urlresolver.resolve(link)
                # print '$$urlresolver',stream_url
                # xbmcgui.Dialog().ok('resolved!!',stream_url)
            except Exception,e:
                stream_url=''
                s = xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]','Może inny link będzie działał?','UTRresolver ERROR: [%s]'%str(e))
    
    print stream_url
    if stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, True, xbmcgui.ListItem(path=stream_url))
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))
        
## Historia wyszukiwania
def HistoryLoad():
    return cache.get('history').split(';')

def HistoryAdd(entry):
    history = HistoryLoad()
    if history == ['']:
        history = []
    history.insert(0, entry)
    cache.set('history',';'.join(history[:50]))

def HistoryDel(entry):
    history = HistoryLoad()
    history.remove(entry)
    if history:
        cache.set('history',';'.join(history[:50]))
    else:
        HistoryClear()

def HistoryClear():
    cache.delete('history')


## ######################
## MAIN
## ######################
            
    
xbmcplugin.setContent(addon_handle, 'movies')	

f_filtrV = my_addon.getSetting('f_filtrV')
f_filtrN = my_addon.getSetting('f_filtrN') if f_filtrV else 'Nowe'
s_filtrV = my_addon.getSetting('s_filtrV')
s_filtrN = my_addon.getSetting('s_filtrN') if s_filtrV else 'Nowe'

mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
page = args.get('page',[1])[0]

if mode is None:

    addLinkItem("[COLOR blue]Filmy Filtr[/COLOR]",'',mode='setFiltr:f_',iconimage=RESOURCES+'filmy.png',IsPlayable=False)
    addDir(name="  [COLOR lightblue]Filmy[/COLOR] [COLOR blue][B]"+f_filtrN+"[/B][/COLOR]",ex_link='http://alltube.tv/filmy-online/',page=1, mode='ListMovies',iconImage=RESOURCES+'filmy.png')
    addDir(name="  [COLOR lightblue]=> [Gatunek][/COLOR]",ex_link='gatunek',page=1, mode='GatunekRok',iconImage=RESOURCES+'filmy.png',fanart=FANART)
    addDir(name="  [COLOR lightblue]=> [Rok][/COLOR]",ex_link='rok',page=1, mode='GatunekRok',iconImage=RESOURCES+'filmy.png',fanart=FANART)
    addDir(name="  [COLOR lightblue]=> [Język][/COLOR]",ex_link='jezyk',page=1, mode='GatunekRok',iconImage=RESOURCES+'filmy.png',fanart=FANART)
    # Seriale
    addLinkItem("[COLOR green]Seriale Filtr[/COLOR]" ,'',mode='setFiltr:s_',iconimage=RESOURCES+'seriale.png',IsPlayable=False)
    addDir(name="  [COLOR lightgreen]Seriale[/COLOR] [COLOR green][B]"+s_filtrN+"[/B][/COLOR]",ex_link=None,page=1, mode='ListSeriale',iconImage=RESOURCES+'seriale.png')
    addDir(name="[COLOR yellow]D[COLOR blue]L[COLOR red]A [COLOR lightgreen]D[COLOR purple]Z[COLOR gold]I[COLOR blue]E[COLOR red]C[COLOR lightgreen]I[/COLOR]",ex_link='http://alltube.tv/filmy-online/kategoria[5]+wersja[Lektor,Dubbing,PL]+', mode='ListMovies',iconImage=RESOURCES+'dzieci.png')
    addDir(name="Anime",ex_link='http://alltube.tv/anime/',page=1, mode='ListAnime',iconImage=RESOURCES+'anime.png',fanart=FANART)
    addDir(name="Fun",ex_link='http://alltube.tv/fun/', mode='ListFun',iconImage=RESOURCES+'fun.png')
    addDir(name="Fun [Kategorie]",ex_link='',page=1, mode='FunKategorie',iconImage=RESOURCES+'fun.png',fanart=FANART)
    addDir(name="[COLOR cyan]Playlisty[/COLOR]",ex_link='', mode='Playlist',iconImage=RESOURCES+'playlisty.png')
    
    addDir('Szukaj','',mode='Szukaj',iconImage=RESOURCES+'szukaj.png')
    #addLinkItem('-=Opcje=-','','Opcje',IsPlayable=False)

elif 'setFiltr' in mode[0]:
    _type = mode[0].split(":")[-1]
    label=['Nowe','Nowe linki','Najpopularniejsze','Najwyżej oceniane']
    value=['?filter=new','?filter=updated','?filter=popular','?filter=rate']
    s = xbmcgui.Dialog().select('Wybierz Filtr',label)
    s = s if s>-1 else 0
    my_addon.setSetting(_type+'filtrV',value[s])
    my_addon.setSetting(_type+'filtrN',label[s])
    xbmc.executebuiltin('XBMC.Container.Refresh')

elif mode[0] == '__page__M':
    url = build_url({'mode': 'ListMovies', 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    
elif mode[0] == '__page__S':
    url = build_url({'mode': 'ListSeriale', 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == '__page__P':
    url = build_url({'mode': 'PlaylistLinks', 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
    
elif mode[0] == '__page__F':
    url = build_url({'mode': 'ListFun', 'foldername': '', 'ex_link' : ex_link, 'page': page})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)    

elif mode[0] == 'Playlist':
    items = alltube.getPlaylist()
    for f in items:
        addDir(name=f.get('title'), ex_link=f.get('href'), mode='PlaylistLinks', iconImage=f.get('img'), infoLabels=f, fanart=f.get('img'))

elif mode[0] == 'PlaylistLinks':
    FSLinks(ex_link,tryb='playlist',page=page)

elif mode[0] == 'ListMovies':
    ListMovies(ex_link+f_filtrV,page)
    xbmcplugin.setContent(addon_handle, 'movies')	

elif mode[0] == 'ListAnime':
    ListMovies(ex_link,page)
    xbmcplugin.setContent(addon_handle, 'movies')	

elif mode[0] == 'ListFun':
    ListFun(ex_link,page)
    xbmcplugin.setContent(addon_handle, 'movies')	
    
elif mode[0] == 'getSeasons':
    getSeasons(ex_link)
    xbmcplugin.setContent(addon_handle, 'tvshows')	
    
elif mode[0] == 'getEpisodes':
    ListEpisodes(ex_link)
    xbmcplugin.setContent(addon_handle, 'episodes')

elif mode[0] == 'getEpisodes2':
    ListEpisodes2(ex_link)
    xbmcplugin.setContent(addon_handle, 'episodes')
    
elif mode[0] == 'ListSeriale':
    ListSeriale(s_filtrV.strip('?'),page)
    xbmcplugin.setContent(addon_handle, 'tvshows')
    
elif mode[0] == 'getLinks':
    getLinks(ex_link)

elif mode[0] == 'searchItems':
    FSLinks(ex_link,'search')

elif mode[0] == 'FunKategorie':
    data = alltube.funKategorie()
    for one in data:
        title = alltube.unicodePLchar(one[1])
        addDir(name=title,ex_link=one[0], mode='ListFun',iconImage=RESOURCES+'fun.png')
            
elif mode[0] == 'GatunekRok':
    data = alltube.filter(ex_link)
    if data:
        ret = xbmcgui.Dialog().select('Wybierz:', data[0])
        if ret>-1:
            href = 'http://alltube.tv/filmy-online/'+data[1][ret]
            url = build_url({'mode': 'ListMovies', 'foldername': '', 'ex_link' : href, 'page': 1})
            xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)

elif mode[0] == 'Opcje':
    my_addon.openSettings()   

elif mode[0] =='Szukaj':
    addDir('[COLOR green]Nowe Szukanie[/COLOR]','',mode='SzukajNowe')
    historia = HistoryLoad()
    if not historia == ['']:
        for entry in historia:
            contextmenu = []
            contextmenu.append(('Usuń', 'XBMC.Container.Refresh(%s)'% build_url({'mode': 'SzukajUsun', 'ex_link' : entry})),)
            contextmenu.append(('Usuń całą historię', 'XBMC.Container.Update(%s)' % build_url({'mode': 'SzukajUsunAll'})),)
            addDir(name=entry, ex_link=entry.replace(' ','+'), mode='searchItems', fanart=None, contextmenu=contextmenu) 
        

elif mode[0] =='SzukajNowe':
    d = xbmcgui.Dialog().input('Szukaj, Podaj tytul filmu/serialu/bajki', type=xbmcgui.INPUT_ALPHANUM)
    if d:
        HistoryAdd(d)
        FSLinks(d.replace(' ','+'),'search')

elif mode[0] =='SzukajUsun':
    HistoryDel(ex_link)
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))

    
elif mode[0] == 'SzukajUsunAll':
    HistoryClear()
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'%  build_url({'mode': 'Szukaj'}))

elif mode[0] == 'folder':
    pass

else:
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem(path=''))        


xbmcplugin.endOfDirectory(addon_handle)

