# -*- coding: utf-8 -*-

import urllib2,urllib
import re,random,json
import cookielib

TIMEOUT=10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'

def getUrl(url,data=None,header={},setCookies=True):
    cookie=''
    cj=[]
    if setCookies:
        cj = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        urllib2.install_opener(opener)
    if not header:
        header = {'User-Agent':UA}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link =  response.read()
        response.close()
        cookie = ''.join(['%s=%s;'%(c.name, c.value) for c in cj])

    except urllib2.HTTPError as e:
        link = ''
    return link,cookie

#url='https://www.rapidvideo.com/?v=H2bfLedo'
#url='http://www.rapidvideo.com/embed/H0fjftnF'
def getVideoUrls(url):
    url = url.replace('http:','https:').replace('/embed/','/?v=')
    content,c = getUrl(url)
    match = re.findall('''["']?sources['"]?\s*:\s*(\[.*?\])''', content)
    videos=''
    if not match:
        data = {}
        data['confirm.y'] = random.randint(0, 120)
        data['confirm.x'] = random.randint(0, 120)
        header={'User-Agent':UA,'Referer':url}
        post_url = url + '#'
        content,c = getUrl(post_url,urllib.urlencode(data),header=header)
        match = re.findall('''["']?sources['"]?\s*:\s*(\[.*?\])''', content)
        
    if match:
        print match
        try:
            data = json.loads(match[0])
            videos=[]
            for d in data:
                if isinstance(d,dict): 
                    vu = d.get('file','')+'|User-Agent=%s&Referer=%s'%(UA,url)
                    videos.append((d.get('label',''),vu)) 
        except:
            videos = re.findall('''['"]?file['"]?\s*:\s*['"]?([^'"]+)''', match[0])
            if videos:
                videos = videos[0].replace('\/', '/')
                videos += '|User-Agent=%s&Referer=%s'%(UA,url)
    return videos




